package svl.kadatha.filex;
import android.os.*;
import android.view.*;
import android.widget.*;
import android.widget.RelativeLayout.*;
import java.util.*;
import java.io.*;
import android.graphics.drawable.*;
import android.graphics.*;
import android.content.*;

public class FileReplaceConfirmationDialog extends android.support.v4.app.DialogFragment
{

	private TextView confirmation_message_textview;
	private Button yes_button,no_button;
	private String duplicate_file_name;
	private CheckBox apply_all_checkbox;
	private FileReplaceListener fileReplaceListener;
	private Context context;
	private ViewGroup buttons_layout;
	
	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		// TODO: Implement this method
		super.onCreate(savedInstanceState);
		setRetainInstance(true);
		setCancelable(false);
		
		Bundle bundle=getArguments();
		duplicate_file_name=bundle.getString("duplicate_file_name");
		
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
	{
		// TODO: Implement this method
		//return super.onCreateView(inflater, container, savedInstanceState);
		context=getContext();
		View v=inflater.inflate(R.layout.fragment_replace_confirmation,container,false);
		confirmation_message_textview=v.findViewById(R.id.dialog_fragment_replace_message);
		buttons_layout=v.findViewById(R.id.fragment_replace_confirmation_button_layout);
		buttons_layout.addView(new EquallyDistributedChildrenLayout(context,2));
		yes_button=buttons_layout.findViewById(R.id.first_button);
		yes_button.setText("Yes");
		no_button=buttons_layout.findViewById(R.id.second_button);
		no_button.setText("No");
		confirmation_message_textview.setText("A file with same name already exists. Do you want to replace it? '"+duplicate_file_name+"'");
		apply_all_checkbox=v.findViewById(R.id.dialog_fragment_applyall_confirmationCheckBox);
		
		yes_button.setOnClickListener(new View.OnClickListener()
		{
			public void onClick(View v)
			{
				
				if(fileReplaceListener!=null)
				{
					fileReplaceListener.onReplaceClick(true,apply_all_checkbox.isChecked());
				}
				dismissAllowingStateLoss();
			}
			
		});
		
		no_button.setOnClickListener(new View.OnClickListener()
		{
			public void onClick(View v)
			{			
				
				if(fileReplaceListener!=null)
				{
					fileReplaceListener.onReplaceClick(false,apply_all_checkbox.isChecked());
				}
				dismissAllowingStateLoss();
				
			}
			
		});
		return v;
	}

	@Override
	public void onResume()
	{
		// TODO: Implement this method
		super.onResume();
		Window window=getDialog().getWindow();
		window.setLayout(Global.DIALOG_WIDTH,LayoutParams.WRAP_CONTENT);
		window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
	}
	
	@Override
	public void onDestroyView() 
	{
		if (getDialog() != null && getRetainInstance()) 
		{
			getDialog().setDismissMessage(null);
		}
		super.onDestroyView();

	}
	
	public void setReplaceListener(FileReplaceListener fileReplaceListener)
	{
		this.fileReplaceListener=fileReplaceListener;
	}


	interface FileReplaceListener
	{
		public void onReplaceClick(boolean replace, boolean replaceall);

	}
	
}
