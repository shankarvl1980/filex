package svl.kadatha.filex;
import android.support.v4.app.*;
import android.content.*;

public class FragmentViewPager extends android.support.v4.app.FragmentStatePagerAdapter
{
	Context context;
	FragmentViewPager(FragmentManager fm, Context context)
	{
		super(fm);
		this.context=context;
	}

	@Override
	public Fragment getItem(int p1)
	{
		// TODO: Implement this method
		//if(p1==0)
		{
		
			return new DetailFragment();
			
		}
		//else
		//{
			//((MainActivity)context).createFragmentTransaction(DetailFragment.FILECLICKSELECTED);
		//}
		
		
	}

	@Override
	public int getCount()
	{
		// TODO: Implement this method
		return 10;
	}


	
}
