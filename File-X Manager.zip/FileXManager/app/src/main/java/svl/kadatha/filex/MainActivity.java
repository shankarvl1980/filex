package svl.kadatha.filex;

import android.*;
import android.content.*;
import android.content.pm.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.net.*;
import android.os.*;
import android.support.design.widget.*;
import android.support.v4.view.*;
import android.support.v4.widget.*;
import android.support.v7.app.*;
import android.support.v7.widget.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.util.*;
import java.util.zip.*;
import android.support.v4.app.*;
import android.content.res.*;
import java.text.*;
import android.support.v4.content.*;
import android.view.animation.*;


public class MainActivity extends AppCompatActivity
{
	static boolean FIRST_START=true, ARCHIVE_VIEW;
	private boolean working_dir_open,library_or_search_shown;
	DrawerLayout drawerLayout;
	private ImageButton home_button,extract_imagebutton,cut,copy,delete,overflow;
	private ImageButton paste_toolbar_create_file,paste_toolbar_refresh,paste,paste_cancel,paste_toolbar_delete;
	private ImageButton create_file,search,refresh,view,finish;
	private FloatingActionButton floating_button_back;
	ImageButton parent_dir_imagebutton,rename;
	private ImageView working_dir_expand_indicator,library_expand_indicator;
	Button num_selected_btn;
	
	android.support.v7.widget.Toolbar top_toolbar,extract_toolbar,bottom_toolbar,paste_toolbar,actionmode_toolbar;
	LinearLayout drawer;
	private RecyclerView storageDirListRecyclerView,workingDirListRecyclerView,libraryRecyclerView;
	TextView current_dir_textview;
	private Switch switchHideFile;
	Context context=this;
	private int countBackPressed=0;
	ViewPager viewPager;
	static TinyDB TINYDB;
	static File ARCHIVE_EXTRACT_DIR,ZIP_FILE;
	static List<String> LIBRARY_CATEGORIES=new ArrayList<>();
	private LinearLayout working_dir_button_layout,working_dir_heading_layout,library_heading_layout;
	
	
	static boolean SHOW_HIDDEN_FILE,NOTIFICATION_PERMISSION_GRANTED;
	static int DIALOG_FRAG_TRANS_VALUE;
	static String STORAGE_ITEM_SELECTED="",TOOLBAR_SHOWN="bottom";
	static ArrayList<FilePOJO> STORAGE_DIR=new ArrayList<>();
	static LinkedList<FilePOJO> RECENTS=new LinkedList<>();
	static IndexedLinkedHashMap<String,SpacePOJO> SPACE_ARRAY=new IndexedLinkedHashMap<>();
	
	private StorageRecyclerAdapter storageRecyclerAdapter;
	private WorkingDirRecyclerAdapter workingDirRecyclerAdapter;
	

	private ArrayList<String> working_dir_arraylist=new ArrayList<>();
	private TopToolbarClickListener topToolbarClickListener;
	ActionModeListener actinModeListener;
	private PasteToolbarClickListener pasteToolbarClickListener;
	private BottomToolbarClickListener bottomToolbarClickListener;
	android.support.v7.widget.ListPopupWindow listPopWindow;
	ArrayList<ListPopupWindowPOJO> list_popupwindowpojos=new ArrayList<>();
	static int RECYCLERVIEWITEM_MARGIN;
	static HashMap<String,Bitmap>APK_ICON_HASHMAP=new HashMap<>();
	static PackageManager PM;
	static int ARCHIVE_CACHE_DIR_LENGTH;
	static DividerItemDecoration DIVIDERITEMDECORATION;
	static FragmentManager FM;
	static String FILE_DELETE_INTENT_ACTION;
	private DeleteOtherActivityBroadcastReceiver deleteOtherActivityBroadcastReceiver;
	private static boolean STATE_CHANGED;
	static String TOOLBAR_SHOWN_PRIOR_ARCHIVE="";
	
	@Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
		context=this;
		PermissionsUtil permissionUtil=new PermissionsUtil(context,MainActivity.this);
		permissionUtil.check_storage_permission();
		NOTIFICATION_PERMISSION_GRANTED=permissionUtil.check_notification_policy();
		TINYDB=new TinyDB(context);
		
		Global.GET_SCREEN_DIMENSIONS(context);
		Global.GET_URI_PERMISSIONS_LIST(context);
		Global.GET_IMAGEVIEW_DIMENSIONS(context);
		Global.GET_SORT(TINYDB);
	
		setContentView(R.layout.main);
		FM=getSupportFragmentManager();
		PM=getPackageManager();
		FILE_DELETE_INTENT_ACTION=getPackageName()+".FILE_DELETE";
		deleteOtherActivityBroadcastReceiver=new DeleteOtherActivityBroadcastReceiver();
		
		IntentFilter intentFilter=new IntentFilter();
		intentFilter.addAction(FILE_DELETE_INTENT_ACTION);
		LocalBroadcastManager.getInstance(this).registerReceiver(deleteOtherActivityBroadcastReceiver,intentFilter);
	
		ARCHIVE_EXTRACT_DIR=new File(getCacheDir(),"Archive");

	
		StatusBarTint.darkenStatusBar(this,R.color.toolbar_background);
		RECYCLERVIEWITEM_MARGIN=Global.GET_RECYCLERVIEWMARGIN(context);
		DIVIDERITEMDECORATION=new DividerItemDecoration(context,DividerItemDecoration.VERTICAL);
		ARCHIVE_CACHE_DIR_LENGTH=MainActivity.ARCHIVE_EXTRACT_DIR.getAbsolutePath().length();
		
		drawerLayout=findViewById(R.id.drawer_layout);
		drawer=findViewById(R.id.drawer_linearlayout);


		top_toolbar=findViewById(R.id.top_toolbar);
		home_button=top_toolbar.findViewById(R.id.top_toolbar_home_button);
		parent_dir_imagebutton=top_toolbar.findViewById(R.id.top_toolbar_parent_dir_imagebutton);
		current_dir_textview=top_toolbar.findViewById(R.id.top_toolbar_current_dir_label);
		num_selected_btn=top_toolbar.findViewById(R.id.num_selected);

		topToolbarClickListener=new TopToolbarClickListener();
		home_button.setOnClickListener(topToolbarClickListener);
		parent_dir_imagebutton.setOnClickListener(topToolbarClickListener);
		current_dir_textview.setOnClickListener(topToolbarClickListener);
		num_selected_btn.setOnClickListener(topToolbarClickListener);
		
		
		floating_button_back=findViewById(R.id.floating_action_button_back);
		floating_button_back.setOnClickListener(new View.OnClickListener()
		{
			public void onClick(View p1)
			{
				onBackPressed();
			}
		});
		
		EquallyDistributedImageButtonsLayout tb_layout =new EquallyDistributedImageButtonsLayout(this,5,Global.SCREEN_WIDTH,Global.SCREEN_HEIGHT);
		int bottom_drawables []={R.drawable.document_add_icon,R.drawable.search_icon,R.drawable.refresh_icon,R.drawable.view_icon,R.drawable.exit_icon};
		tb_layout.setResourceImageDrawables(bottom_drawables);
		bottom_toolbar=findViewById(R.id.bottom_toolbar);
		bottom_toolbar.addView(tb_layout);
		create_file=bottom_toolbar.findViewById(R.id.image_btn_1);
		search=bottom_toolbar.findViewById(R.id.image_btn_2);
		refresh=bottom_toolbar.findViewById(R.id.image_btn_3);
		view=bottom_toolbar.findViewById(R.id.image_btn_4);
		finish=bottom_toolbar.findViewById(R.id.image_btn_5);
		bottomToolbarClickListener=new BottomToolbarClickListener();
		create_file.setOnClickListener(bottomToolbarClickListener);
		search.setOnClickListener(bottomToolbarClickListener);
		refresh.setOnClickListener(bottomToolbarClickListener);
		view.setOnClickListener(bottomToolbarClickListener);
		finish.setOnClickListener(bottomToolbarClickListener);
		
		
		tb_layout =new EquallyDistributedImageButtonsLayout(this,5,Global.SCREEN_WIDTH,Global.SCREEN_HEIGHT);
		int paste_drawables []={R.drawable.document_add_icon,R.drawable.refresh_icon,R.drawable.paste_icon,R.drawable.delete_icon,R.drawable.no_icon};
		tb_layout.setResourceImageDrawables(paste_drawables);
		paste_toolbar=findViewById(R.id.paste_toolbar);
		paste_toolbar.addView(tb_layout);
		paste_toolbar_create_file=paste_toolbar.findViewById(R.id.image_btn_1);
		paste_toolbar_refresh=paste_toolbar.findViewById(R.id.image_btn_2);
		paste=paste_toolbar.findViewById(R.id.image_btn_3);
		paste_toolbar_delete=paste_toolbar.findViewById(R.id.image_btn_4);
		paste_cancel=paste_toolbar.findViewById(R.id.image_btn_5);
		
		pasteToolbarClickListener=new PasteToolbarClickListener();
		paste_toolbar_create_file.setOnClickListener(pasteToolbarClickListener);
		paste_toolbar_refresh.setOnClickListener(pasteToolbarClickListener);
		paste.setOnClickListener(pasteToolbarClickListener);
		paste_cancel.setOnClickListener(pasteToolbarClickListener);
		paste_toolbar_delete.setOnClickListener(pasteToolbarClickListener);
		
		
		extract_toolbar=findViewById(R.id.extract_toolbar);
		extract_imagebutton=extract_toolbar.findViewById(R.id.extract_imagebutton);
		extract_imagebutton.setOnClickListener(new View.OnClickListener()
		{
			public void onClick(View v)
			{
				DetailFragment df=(DetailFragment)FM.findFragmentById(R.id.detail_fragment);
				Bundle bundle=new Bundle();
				ArrayList<String> files_selected_array=new ArrayList<>();
				ArrayList<String> zipentry_selected_array=new ArrayList<>();
				files_selected_array.add(ZIP_FILE.getAbsolutePath());
				if(df.file_selected_array.size()!=0)
				{
					recursivefilepath(zipentry_selected_array,df.file_selected_array);
					
				}
				bundle.putStringArrayList("files_selected_array",files_selected_array);
				bundle.putStringArrayList("zipentry_selected_array",zipentry_selected_array);
				ArchiveSetUpDialog unziparchiveDialog=new ArchiveSetUpDialog("unzip");
				unziparchiveDialog.setArguments(bundle);
				unziparchiveDialog.show(FM,null);
		
				df.clearSelection();
	
		
			}
		});
		
		tb_layout =new EquallyDistributedImageButtonsLayout(this,5,Global.SCREEN_WIDTH,Global.SCREEN_HEIGHT);
		int actionmode_drawables []={R.drawable.cut_icon,R.drawable.copy_icon,R.drawable.rename_icon,R.drawable.delete_icon,R.drawable.overflow_icon};
		tb_layout.setResourceImageDrawables(actionmode_drawables);
		actionmode_toolbar=findViewById(R.id.actionmode_toolbar);
		actionmode_toolbar.addView(tb_layout);
		cut=actionmode_toolbar.findViewById(R.id.image_btn_1);
		copy=actionmode_toolbar.findViewById(R.id.image_btn_2);
		rename=actionmode_toolbar.findViewById(R.id.image_btn_3);
		delete=actionmode_toolbar.findViewById(R.id.image_btn_4);
		overflow=actionmode_toolbar.findViewById(R.id.image_btn_5);
		
		
		list_popupwindowpojos.add(new ListPopupWindowPOJO(R.drawable.send_icon,"Send"));
		list_popupwindowpojos.add(new ListPopupWindowPOJO(R.drawable.properties_icon,"Properties"));
		list_popupwindowpojos.add(new ListPopupWindowPOJO(R.drawable.compress_icon,"Compress"));
		list_popupwindowpojos.add(new ListPopupWindowPOJO(R.drawable.extract_icon,"Extract"));
		
		listPopWindow=new android.support.v7.widget.ListPopupWindow(this);
		listPopWindow.setAdapter(new ListPopupWindowArrayAdapter(this,0,list_popupwindowpojos));
		listPopWindow.setAnchorView(overflow);
		listPopWindow.setWidth(getResources().getDimensionPixelSize(R.dimen.list_popupwindow_width));
		listPopWindow.setModal(true);
		
		
		actinModeListener=new ActionModeListener();
		cut.setOnClickListener(actinModeListener);
		copy.setOnClickListener(actinModeListener);
		delete.setOnClickListener(actinModeListener);
		rename.setOnClickListener(actinModeListener);
		overflow.setOnClickListener(actinModeListener);
		
		/*
		viewPager=(ViewPager)findViewById(R.id.view_pager);
		viewPager.setOffscreenPageLimit(10);
		FragmentViewPager viewPagerAdapter=new FragmentViewPager(getSupportFragmentManager(),context);
		viewPager.setAdapter(viewPagerAdapter);
		
*/
		SHOW_HIDDEN_FILE=TINYDB.getBoolean("show_hidden_file");
		Global.RECYCLER_VIEW_FONT_SIZE_FACTOR=TINYDB.getInt("recycler_view_font_size_factor");
		if(!TINYDB.getBoolean("not_first_run"))
		{
			Global.RECYCLER_VIEW_FONT_SIZE_FACTOR=1;
			TINYDB.putBoolean("not_first_run",true);
			TINYDB.putInt("recycler_view_font_size_factor",Global.RECYCLER_VIEW_FONT_SIZE_FACTOR);
		}


		storageDirListRecyclerView=findViewById(R.id.drawer_recyclerview);
		storageDirListRecyclerView.addItemDecoration(DIVIDERITEMDECORATION);
		if(STORAGE_DIR.size()==0)
		{
			STORAGE_DIR=StorageUtil.getSdCardPaths(context,true);
		}
		
		storageRecyclerAdapter=new StorageRecyclerAdapter(STORAGE_DIR);
		storageDirListRecyclerView.setAdapter(storageRecyclerAdapter);
		storageDirListRecyclerView.setLayoutManager(new LinearLayoutManager(this));
		

		
		
		working_dir_heading_layout=findViewById(R.id.working_dir_heading_layout);
		working_dir_heading_layout.setOnClickListener(new View.OnClickListener()
		{
			public void onClick(View v)
			{
				if(workingDirListRecyclerView.getVisibility()==View.GONE)
				{
					working_dir_expand_indicator.setImageResource(R.drawable.right_arrow_icon);
					workingDirListRecyclerView.setVisibility(View.VISIBLE);
					working_dir_button_layout.setVisibility(View.VISIBLE);
					working_dir_open=true;
				
				}
				else
				{
					working_dir_expand_indicator.setImageResource(R.drawable.down_arrow_icon);
					workingDirListRecyclerView.setVisibility(View.GONE);
					working_dir_button_layout.setVisibility(View.GONE);
					working_dir_open=false;
					
				}
			}
		});
		
		working_dir_expand_indicator=findViewById(R.id.working_dir_expand_indicator);
		workingDirListRecyclerView=findViewById(R.id.working_dir_recyclerview);
		workingDirListRecyclerView.addItemDecoration(DIVIDERITEMDECORATION);
		working_dir_arraylist=TINYDB.getListString("working_dir_arraylist");
		workingDirRecyclerAdapter=new WorkingDirRecyclerAdapter(context,working_dir_arraylist);
		workingDirRecyclerAdapter.setOnItemClickListener(new WorkingDirRecyclerAdapter.ItemClickListener()
		{
			public void onItemClick(int pos,String item_name)
			{
				
				 STORAGE_ITEM_SELECTED=working_dir_arraylist.get(pos);
				 drawerLayout.closeDrawer(((MainActivity)context).drawer);
				 if(!new File(STORAGE_ITEM_SELECTED).exists())
				 {
					 print("Directory does not exist.");
				 }
				 
			}
			
			public void onItemLongClick(int pos, String item_name)
			{
				
			}
		});
		workingDirListRecyclerView.setAdapter(workingDirRecyclerAdapter);
		workingDirListRecyclerView.setLayoutManager(new LinearLayoutManager(this));
		setRecyclerViewHeight(workingDirListRecyclerView);
		
		working_dir_button_layout=findViewById(R.id.working_dir_button_layout);
		
		library_heading_layout=findViewById(R.id.library_heading_layout);
		library_heading_layout.setOnClickListener(new View.OnClickListener()
		{
			public void onClick(View v)
			{
				if(libraryRecyclerView.getVisibility()==View.GONE)
				{
					library_expand_indicator.setImageResource(R.drawable.right_arrow_icon);
					libraryRecyclerView.setVisibility(View.VISIBLE);
					library_or_search_shown=true;
					
					
				}
				else
				{
					library_expand_indicator.setImageResource(R.drawable.down_arrow_icon);
					libraryRecyclerView.setVisibility(View.GONE);
					library_or_search_shown=false;
					
				}
			}
		});
		
		library_expand_indicator=findViewById(R.id.library_expand_indicator);
		LIBRARY_CATEGORIES=Arrays.asList(getResources().getStringArray(R.array.library_categories));
		libraryRecyclerView=findViewById(R.id.library_recyclerview);
		libraryRecyclerView.addItemDecoration(DIVIDERITEMDECORATION);
		libraryRecyclerView.setAdapter(new LibraryRecyclerAdapter(LIBRARY_CATEGORIES));
		libraryRecyclerView.setLayoutManager(new LinearLayoutManager(this));
		
		switchHideFile=findViewById(R.id.switch_hide_file);
		switchHideFile.setChecked(MainActivity.SHOW_HIDDEN_FILE);
		
		switchHideFile.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener()
		{
			public void onCheckedChanged(CompoundButton cb, final boolean checked)
			{
				Handler h=new Handler();
				h.postDelayed(new Runnable()
				{
					public void run()
					{
						MainActivity.SHOW_HIDDEN_FILE=checked;
						TINYDB.putBoolean("show_hidden_file",MainActivity.SHOW_HIDDEN_FILE);
						DetailFragment df=(DetailFragment)FM.findFragmentById(R.id.detail_fragment);
						if(df.fileclickselected.exists())
						{
							df.adapter.refresh(null);
						}
					}
				},500);

			}
		});
	
		
		
		drawerLayout.addDrawerListener(new DrawerLayout.DrawerListener()
		{
			public void onDrawerOpened(View v)
			{
				STORAGE_ITEM_SELECTED="";
			}
			
			public void onDrawerClosed(View v)
			{
				if(STORAGE_ITEM_SELECTED!="")
				{
					File f=new File(STORAGE_ITEM_SELECTED);
					if(f.exists())
					{
						createFragmentTransaction(new File(STORAGE_ITEM_SELECTED),null);
					}
					else
					{
						createFragmentTransaction(STORAGE_ITEM_SELECTED);
					}

					STORAGE_ITEM_SELECTED="";
				}
			}
			
			public void onDrawerStateChanged(int p){}
			
			public void onDrawerSlide(View v, float f){}
			
		});
		
		
		if(savedInstanceState==null)
		{
			if(STORAGE_DIR.get(0).getPath().equals("/"))
			{
				createFragmentTransaction(STORAGE_DIR.get(1).getFile(),null);
			}
			else
			{
				createFragmentTransaction(STORAGE_DIR.get(0).getFile(),null);
			}
			
		}
		
		FM.addOnBackStackChangedListener(new android.support.v4.app.FragmentManager.OnBackStackChangedListener()
		{
			public void onBackStackChanged()
			{

			}
		});
		
		USBBroadcastReceiver.USBATTACHDETACHLISTENER=new USBBroadcastReceiver.USBAttachDetachListener()
		{
			public void onUSBAttachDetach()
			{
				storageRecyclerAdapter.notifyDataSetChanged();
			}
		};
		
	}

	
	public ArrayList<String> recursivefilepath(ArrayList<String> file_pathstring_array, List<File> file_array)
	{
		int size=file_array.size();
		for(int i=0;i<size;i++)
		{
			File f=file_array.get(i);
			if(f.isDirectory())
			{
				if(f.list().length==0)
				{
					file_pathstring_array.add(f.getAbsolutePath()+File.separator);
				}
				else
				{
					recursivefilepath(file_pathstring_array,Arrays.asList(f.listFiles()));
				}
			}
			else
			{
				file_pathstring_array.add(f.getAbsolutePath());
			}
		}
		return file_pathstring_array;
	}
	
	
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults)
	{
		// TODO: Implement this method
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		final List<String> permission_not_granted_list=new ArrayList<>();
		if(requestCode==PermissionsUtil.STORAGE_PERMISSIONS_REQUEST_CODE && grantResults.length>0)
		{
			for(int i=0;i<permissions.length;i++)
			{
				if(grantResults[i]!=PackageManager.PERMISSION_GRANTED)
				{
					permission_not_granted_list.add(permissions[i]);
				}
			}
			
		}
		if(grantResults.length==0 || !permission_not_granted_list.isEmpty())
		{
			for(String permission:permission_not_granted_list)
			{
				boolean show_rationale=shouldShowRequestPermissionRationale(permission);
				{
					if(!show_rationale)
					{
						print("Permissions not granted for "+permission_not_granted_list);
						finish();
					}
					else if(permission.equals(Manifest.permission.WRITE_EXTERNAL_STORAGE))
					{
						showDialogOK("Read and write permissions are must for the app to work. Please grant the permissions",new DialogInterface.OnClickListener()
						{
							@Override
							public void onClick(DialogInterface dialog, int which) 
							{
								switch (which) 
								{
									case DialogInterface.BUTTON_POSITIVE:
										new PermissionsUtil(context,MainActivity.this).check_storage_permission();
										break;
									case DialogInterface.BUTTON_NEGATIVE:
									// proceed with logic by disabling the related features or quit the app.
										print("Permissions not granted for "+permission_not_granted_list);
										finish();
										break;
								}
							}
						});
					}
				}
			}
			
		}
		else if(requestCode==PermissionsUtil.NOTIFICATION_PERMISSION_REQUEST_CODE && permissions.length>0)
		{
			if(grantResults[0]!=PackageManager.PERMISSION_GRANTED)
			{
				print("Permission not granted for "+android.Manifest.permission.ACCESS_NOTIFICATION_POLICY+". Hide feature will not work");
			}
		}
	}
		
	private void showDialogOK(String message, DialogInterface.OnClickListener okListener) 
	{
        new android.support.v7.app.AlertDialog.Builder(context)
			.setMessage(message)
			.setPositiveButton("OK", okListener)
			.setNegativeButton("Cancel", okListener)
			.create()
			.show();

	}
    
	@Override
	protected void onNewIntent(Intent intent)
	{
		// TODO: Implement this method
		super.onNewIntent(intent);
		String receivedType=intent.getType();
		String receivedAction=intent.getAction();
		Uri uri=intent.getData();
		if(receivedAction.equals(Intent.ACTION_VIEW) &&  uri !=null && receivedType!=null)
		{
			ZIP_FILE=new File(uri.getPath());
			ZipFile zipfile=null;
			if(receivedType.endsWith("zip"))
			{
				try
				{
					zipfile=new ZipFile(ZIP_FILE);
				}
				catch(IOException e)
				{
					print("Bad zip file");
					return;
				}
				
				ArchiveViewAsyncTask archiveViewAsyncTask=new ArchiveViewAsyncTask(zipfile);
				archiveViewAsyncTask.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
				
			}
			
		}
		
	}
	
	@Override
	protected void onStart()
	{
		// TODO: Implement this method
		super.onStart();
		new Thread(new Runnable()
		{
			public void run()
			{
				for(FilePOJO file:STORAGE_DIR)
				{
					long totalspace=0,availabelspace=0;
					if(file.getPath().equals(File.separator))
					{
						SPACE_ARRAY.put(file.getPath(),new SpacePOJO(file.getPath(),totalspace,availabelspace));
						
						//TOTAL_SPACE.put(file.getPath(),FileUtil.humanReadableByteCount(totalspace,false));
						//USED_SPACE.put(file.getPath(),FileUtil.humanReadableByteCount(availabelspace,false));
						continue;
					}

					totalspace=file.getFile().getTotalSpace();
					availabelspace=file.getFile().getUsableSpace();
					SPACE_ARRAY.put(file.getPath(),new SpacePOJO(file.getPath(),totalspace,availabelspace));
					//TOTAL_SPACE.put(file.getPath(),FileUtil.humanReadableByteCount(totalspace,false));
					//USED_SPACE.put(file.getPath(),FileUtil.humanReadableByteCount(totalspace-availabelspace,false));
				}
			}
		}).start();
		
		
		 if(STATE_CHANGED)
		 {
		 	STATE_CHANGED=false;
			DetailFragment df=(DetailFragment)FM.findFragmentById(R.id.detail_fragment);
		 	if(df!=null &&  df.fileclickselected.exists())
		 	{
		 		df.refresh_data();
		 	}

		 }
		 
		
		
	}
	
	
	/*
	@Override
	protected void onResume()
	{
		// TODO: Implement this method
		super.onResume();
		ExplorerApplication.activityResumed();
	}
*/

	// @TargetApi(Build.VERSION_CODES.LOLLIPOP)
	 @Override
	 public final void onActivityResult(final int requestCode, final int resultCode, final Intent resultData) 
	 {
	 	super.onActivityResult(requestCode,resultCode,resultData);
		 
	 }
	

	@Override
	protected void onSaveInstanceState(Bundle outState)
	{
		// TODO: Implement this method
		super.onSaveInstanceState(outState);
		
		outState.putBoolean("working_dir_open",working_dir_open);
		outState.putBoolean("library_or_search_shown",library_or_search_shown);
		
	}

	@Override
	protected void onRestoreInstanceState(Bundle savedInstanceState)
	{
		// TODO: Implement this method
		super.onRestoreInstanceState(savedInstanceState);

		DetailFragment df=(DetailFragment)FM.findFragmentById(R.id.detail_fragment);
		

		if(TOOLBAR_SHOWN.equals("actionmode"))
		{
			actionmode_toolbar.setVisibility(View.VISIBLE);
			bottom_toolbar.setVisibility(View.GONE);
			paste_toolbar.setVisibility(View.GONE);
		}
		else if(TOOLBAR_SHOWN.equals("paste"))
		{
			paste_toolbar.setVisibility(View.VISIBLE);
			bottom_toolbar.setVisibility(View.GONE);
			actionmode_toolbar.setVisibility(View.GONE);
		}
		else if(TOOLBAR_SHOWN.equals("extract"))
		{
			extract_toolbar.setVisibility(View.VISIBLE);
			parent_dir_imagebutton.setEnabled(false);
			parent_dir_imagebutton.setAlpha(100);
			bottom_toolbar.setVisibility(View.GONE);
		}
		

		if(df.mselecteditems.size()>1)
		{

			rename.setEnabled(false);
			rename.setAlpha(100);
		}


		if(working_dir_open=savedInstanceState.getBoolean("working_dir_open"))
		{
			working_dir_expand_indicator.setImageResource(R.drawable.right_arrow_icon);
			workingDirListRecyclerView.setVisibility(View.VISIBLE);
			working_dir_button_layout.setVisibility(View.VISIBLE);
		}
		if(library_or_search_shown=savedInstanceState.getBoolean("library_or_search_shown"))
		{
			library_expand_indicator.setImageResource(R.drawable.right_arrow_icon);
			libraryRecyclerView.setVisibility(View.VISIBLE);
		}
		
	}
	
	
	
	public void createFragmentTransaction(File file,String index_file)
	{
	
		//ViewPagerFragment viewPagerFragment=new ViewPagerFragment();
		String fragment_tag=new String();
		
		DetailFragment df=null;
		if(FM.getBackStackEntryCount()>0)
		{
			df=(DetailFragment)FM.findFragmentById(R.id.detail_fragment);
			fragment_tag=df.getTag();
		}
		
		
		if(file.getAbsolutePath().equals(fragment_tag))
		{
			FM.popBackStack();
		}
		
		if(file.isDirectory())
		{
			
			if(df!=null && df.asyncTaskLibrarySearch!=null)
			{
				df.asyncTaskLibrarySearch.cancel(true);
			}
			
			
			android.support.v4.app.FragmentTransaction ft=FM.beginTransaction();
			ft.replace(R.id.detail_fragment,DetailFragment.getNewInstance(index_file),file.getAbsolutePath());
			ft.addToBackStack(file.getAbsolutePath());
			ft.setTransition(android.support.v4.app.FragmentTransaction.TRANSIT_FRAGMENT_FADE);
			ft.commit();
			actionmode_finish(file.getAbsolutePath());

		}
		
	}
	
	public void createFragmentTransaction(String detailfragment_tag)
	{

		//ViewPagerFragment viewPagerFragment=new ViewPagerFragment();
		String fragment_tag=new String();
		DetailFragment df=null;
		if(FM.getBackStackEntryCount()>0)
		{
			df=(DetailFragment)FM.findFragmentById(R.id.detail_fragment);
			fragment_tag=df.getTag();
		}
		
		if(df!=null && df.asyncTaskLibrarySearch!=null)
		{
			df.asyncTaskLibrarySearch.cancel(true);
			
		}
		
		if(detailfragment_tag.equals(fragment_tag))
		{
			
			FM.popBackStack();
		}
		
		
		android.support.v4.app.FragmentTransaction ft=FM.beginTransaction();
		ft.replace(R.id.detail_fragment,DetailFragment.getNewInstance(null),detailfragment_tag);
		//ft.replace(R.id.detail_fragment,viewPagerFragment);
		ft.addToBackStack(detailfragment_tag);
		ft.setTransition(android.support.v4.app.FragmentTransaction.TRANSIT_FRAGMENT_FADE);
		ft.commit();
		actionmode_finish(detailfragment_tag);

	}
	

	@Override
	public void onBackPressed()
	{
		// TODO: Implement this method
		DetailFragment df=(DetailFragment)FM.findFragmentById(R.id.detail_fragment);
		//String current_tag=df.getTag();
		boolean drawerOpen=drawerLayout.isDrawerOpen(drawer);
		if(drawerOpen)
		{
			drawerLayout.closeDrawer(drawer);
		}
		
		else if(df.mselecteditems.size()>0)
		{
			actionmode_finish(df.getTag());
			
		}
		
		else
		{
		
			if(df.getTag().equals(ARCHIVE_EXTRACT_DIR.getAbsolutePath()) && ARCHIVE_VIEW)
			{
				
				archive_exit();
			}
			if(FM.getBackStackEntryCount()>1)
			{
				if(TOOLBAR_SHOWN.equals("bottom"))
				{
					bottom_toolbar.animate().translationY(0).setInterpolator(new DecelerateInterpolator(1));
					bottom_toolbar.setVisibility(View.VISIBLE);
				}


				else if(TOOLBAR_SHOWN.equals("paste"))
				{
					paste_toolbar.animate().translationY(0).setInterpolator(new DecelerateInterpolator(1));
					paste_toolbar.setVisibility(View.VISIBLE);

				}

				else if(TOOLBAR_SHOWN.equals("extract"))
				{
					extract_toolbar.animate().translationY(0).setInterpolator(new DecelerateInterpolator(1));
					extract_toolbar.setVisibility(View.VISIBLE);

				}
		
				FM.popBackStackImmediate();
				
				int frag=1;
				String df_tag=FM.getBackStackEntryAt(FM.getBackStackEntryCount()-frag).getName();
				
				while(!new File(df_tag).exists() && !LIBRARY_CATEGORIES.contains(df_tag) && !df_tag.equals(DetailFragment.SEARCH_RESULT))
				{
					
					FM.popBackStackImmediate();
				 	df_tag=FM.getBackStackEntryAt(FM.getBackStackEntryCount()-frag).getName();
				}
				if(df_tag.equals(ARCHIVE_EXTRACT_DIR.getAbsolutePath()) && ARCHIVE_VIEW)
				{

					parent_dir_imagebutton.setEnabled(false);
					parent_dir_imagebutton.setAlpha(100);
				}


				
			
				countBackPressed=0;
			}

			else
			{
				countBackPressed++;
				if(countBackPressed==1)
				{
					print("Press again to close the app");
				}
				else
				{
					if(getCacheDir().exists())
					{
						new AsyncTaskDeleteDirectory(getCacheDir()).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
					}
					finish();
					
				}
			}
			
		}
	}

	@Override
	protected void onPause()
	{
		// TODO: Implement this method
		super.onPause();
		ExplorerApplication.activityPaused();
	}

	@Override
	protected void onDestroy()
	{
		// TODO: Implement this method
		LocalBroadcastManager.getInstance(this).unregisterReceiver(deleteOtherActivityBroadcastReceiver);
		super.onDestroy();
		
		
	}
	
	


	public void actionmode_finish(String detailfrag_tag)
	{
		
		DetailFragment df=(DetailFragment)FM.findFragmentById(R.id.detail_fragment);
		listPopWindow.dismiss();

		if(detailfrag_tag.startsWith(ARCHIVE_EXTRACT_DIR.getAbsolutePath()) &&  ARCHIVE_VIEW)
		{
			extract_toolbar.setVisibility(View.VISIBLE);
			extract_toolbar.animate().translationY(0).setInterpolator(new DecelerateInterpolator(1));
			paste_toolbar.setVisibility(View.GONE);
			bottom_toolbar.setVisibility(View.GONE);
			TOOLBAR_SHOWN="extract";
			if(detailfrag_tag.equals(ARCHIVE_EXTRACT_DIR.getAbsolutePath()))
			{
				parent_dir_imagebutton.setEnabled(false);
				parent_dir_imagebutton.setAlpha(100);
			}
			
		}
		else if(DetailFragment.CUT_SELECTED|| DetailFragment.COPY_SELECTED)
		//else if(TOOLBAR_SHOWN.equals("paste"))
		{
			paste_toolbar.setVisibility(View.VISIBLE);
			paste_toolbar.animate().translationY(0).setInterpolator(new DecelerateInterpolator(1));
			bottom_toolbar.setVisibility(View.GONE);
			TOOLBAR_SHOWN="paste";
			parent_dir_imagebutton.setEnabled(true);
			parent_dir_imagebutton.setAlpha(255);
		}
		else
		{
			parent_dir_imagebutton.setEnabled(true);
			parent_dir_imagebutton.setAlpha(255);
			
			archive_exit();
			
			//it is nothing but archive_exit method
			/*
			if(ARCHIVE_EXTRACT_DIR.exists())
			{
				new AsyncTaskDeleteDirectory(ARCHIVE_EXTRACT_DIR).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
			}
			bottom_toolbar.setVisibility(View.VISIBLE);
			extract_toolbar.setVisibility(View.GONE);
			paste_toolbar.setVisibility(View.GONE);
			TOOLBAR_SHOWN="bottom";
			ARCHIVE_VIEW=false;
			*/
			
		}
		
		actionmode_toolbar.setVisibility(View.GONE);
		
		if(df!=null)
		{
			df.clearSelection();
			df.is_toolbar_visible=true;
			
		}
		
	}
	
	public void archive_exit()
	{
		ProgressBarFragment pbf=new ProgressBarFragment();
		pbf.show(FM,"");
		if(ARCHIVE_EXTRACT_DIR.exists())
		{
			
			FileUtil.deleteNativeDirectory(ARCHIVE_EXTRACT_DIR);
		}
		
		if(TOOLBAR_SHOWN_PRIOR_ARCHIVE.equals("paste"))
		{
			paste_toolbar.setVisibility(View.VISIBLE);
			paste_toolbar.animate().translationY(0).setInterpolator(new DecelerateInterpolator(1));
			TOOLBAR_SHOWN=TOOLBAR_SHOWN_PRIOR_ARCHIVE;
			TOOLBAR_SHOWN_PRIOR_ARCHIVE="";
			bottom_toolbar.setVisibility(View.GONE);
		
		}
		else
		
		{
			bottom_toolbar.setVisibility(View.VISIBLE);
			bottom_toolbar.animate().translationY(0).setInterpolator(new DecelerateInterpolator(1));
			TOOLBAR_SHOWN="bottom";
			paste_toolbar.setVisibility(View.GONE);
		}
			
		
		actionmode_toolbar.setVisibility(View.GONE);
		extract_toolbar.setVisibility(View.GONE);
		
		ARCHIVE_VIEW=false;
		pbf.dismissAllowingStateLoss();
	
	}
	
	
	public void workingDirAdd(View v)
	{
		DetailFragment df=(DetailFragment)FM.findFragmentById(R.id.detail_fragment);
		working_dir_arraylist=TINYDB.getListString("working_dir_arraylist");
		if(working_dir_arraylist.size()>10)
		{
			print("More than 10 directories cannot be added");
			return;
		}
		
		String f=df.getTag();
	
		if(new File(f).isDirectory() && !working_dir_arraylist.contains(f) && !STORAGE_DIR.contains(f) && !ARCHIVE_VIEW)
		{
			int i=workingDirRecyclerAdapter.insert(f);
			workingDirListRecyclerView.scrollToPosition(i);
			working_dir_arraylist.add(f);
			TINYDB.putListString("working_dir_arraylist",working_dir_arraylist);
			setRecyclerViewHeight(workingDirListRecyclerView);
		}
		
	}
	
	public void workingDirRemove(View v)
	{
		
		working_dir_arraylist=TINYDB.getListString("working_dir_arraylist");
		if(working_dir_arraylist.size()==0 || working_dir_arraylist==null)
		{
			return;
		}
		
		if(WorkingDirRecyclerAdapter.CUSTOMDIRSELECTEDDIRS.size()<1)
		{
			print("Select directories by long pressing");
		}
		else
		{
			working_dir_arraylist.removeAll(WorkingDirRecyclerAdapter.CUSTOMDIRSELECTEDDIRS);
			int i=workingDirRecyclerAdapter.remove(WorkingDirRecyclerAdapter.CUSTOMDIRSELECTEDDIRS);
			TINYDB.putListString("working_dir_arraylist",working_dir_arraylist);
			workingDirListRecyclerView.scrollToPosition(i);
			setRecyclerViewHeight(workingDirListRecyclerView);
		}
		
	}
	

	private void setRecyclerViewHeight(android.support.v7.widget.RecyclerView v)
	{
		int h=v.getAdapter().getItemCount()*90;
		v.getLayoutParams().height=h<450 ? h : 450;
	}

	
	private void paste_pastecancel_view_procedure(DetailFragment df)
	{
		
		DetailFragment.CUT_SELECTED=false;
		DetailFragment.COPY_SELECTED=false;
		bottom_toolbar.setVisibility(View.VISIBLE);
		bottom_toolbar.animate().translationY(0).setInterpolator(new DecelerateInterpolator(1));
		paste_toolbar.setVisibility(View.GONE);
		actionmode_toolbar.setVisibility(View.GONE);
		TOOLBAR_SHOWN="bottom";
		df.clearSelection();
		df.is_toolbar_visible=true;

	}
	
	
	
	/*
	
	class ViewPagerAdapter extends android.support.v4.app.FragmentPagerAdapter
	{
		ViewPagerAdapter(android.support.v4.app.FragmentManager fm)
		{
			super(fm);

		}

		@Override
		public android.support.v4.app.Fragment getItem(int p1)
		{
			// TODO: Implement this method

			DetailFragment frg=new DetailFragment();
			return frg;

		}

		@Override
		public int getCount()
		{
			// TODO: Implement this method
			return 10;
		}
	}
	
	*/
	public ArrayList<File> iterate_to_attach_file(ArrayList<File> file_list)
	{
		ArrayList<File> file_list_excluding_dir=new ArrayList<>();
		for(File f:file_list)
		{
			if(!f.isDirectory())
			{
				file_list_excluding_dir.add(f);
			}
		}
		return file_list_excluding_dir;
	}
	
	private class TopToolbarClickListener implements View.OnClickListener
	{

		@Override
		public void onClick(View v)
		{
			// TODO: Implement this method
			final DetailFragment df=(DetailFragment)FM.findFragmentById(R.id.detail_fragment);
			switch(v.getId())
			{
				
				case R.id.top_toolbar_home_button:
					if(drawerLayout.isDrawerOpen(drawer))
					{
						drawerLayout.closeDrawer(drawer);

					}
					else
					{
						drawerLayout.openDrawer(drawer);

					}
					break;
					
				case R.id.top_toolbar_parent_dir_imagebutton:
					{
						File parent_file=null;
						if(df.fileclickselected.isDirectory())
						{
							parent_file=df.fileclickselected.getParentFile();
						}
						if(parent_file!=null && parent_file.list()!=null)
						{
							createFragmentTransaction(parent_file,null);
						}
	
					}
					break;
					
				case R.id.top_toolbar_current_dir_label:
					RecentDialog recentDialogFragment=new RecentDialog();
					recentDialogFragment.show(FM,"recent_file_dialog");
					break;
					
				case R.id.num_selected:
					if(df.adapter==null)
					{
						return;
					}
					if(df.mselecteditems.size()<df.adapter.filePOJO_list.size())
					{
						df.adapter.selectAll();
					}
					else
					{
						df.adapter.deselectAll();

					}
					break;
			}
			
		}

	}
	
	private class BottomToolbarClickListener implements View.OnClickListener
	{

		@Override
		public void onClick(View v)
		{
			DetailFragment df=(DetailFragment)FM.findFragmentById(R.id.detail_fragment);
			switch(v.getId())
			{
				
				case R.id.image_btn_1:
					CreateFileAlertDialog dialog=new CreateFileAlertDialog();
					dialog.show(FM,"create_file_dialog");
					break;
				case R.id.image_btn_2:
					SearchDialog searchDialog=new SearchDialog();
					searchDialog.show(FM,"search_dialog");
					break;
				case R.id.image_btn_3:
					actionmode_finish(df.getTag());
					FM.beginTransaction().detach(df).attach(df).commit();
					break;
					
				case R.id.image_btn_4:
					ViewDialog viewDialog=new ViewDialog();
					viewDialog.show(FM,"view_dialog");
					break;
					
				case R.id.image_btn_5:
					
					if(getCacheDir().exists())
					{
						new AsyncTaskDeleteDirectory(getCacheDir()).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
					}
					finish();
					
			}
		}

	}
	
	
	private class PasteToolbarClickListener implements View.OnClickListener
	{

		@Override
		public void onClick(View v)
		{
			// TODO: Implement this method
			DetailFragment df=(DetailFragment)FM.findFragmentById(R.id.detail_fragment);
			Bundle bundle=new Bundle();
			ArrayList<String> files_selected_array=new ArrayList<>();
			ArrayList<Integer> files_selected_index_array=new ArrayList<>();
			switch(v.getId())
			{
				
				case R.id.image_btn_1:
				
					CreateFileAlertDialog dialog=new CreateFileAlertDialog();
					dialog.show(FM,"create_file_dialog");
					df.clearSelection();
					break;
				
				case R.id.image_btn_2:
					df.clearSelection();
					FM.beginTransaction().detach(df).attach(df).commit();
					break;
				
				case R.id.image_btn_3:
					boolean isSourceFromInternal=FileUtil.isFromInternal(DetailFragment.FILE_SELECTED_FOR_CUT_COPY.get(0));
					boolean isWritable=FileUtil.isWritable(new File(df.getTag(),DetailFragment.FILE_SELECTED_FOR_CUT_COPY.get(0).getName()));
					if(DetailFragment.FILE_SELECTED_FOR_CUT_COPY.get(0).getParent().equals(df.getTag()))
					{

						print(DetailFragment.COPY_SELECTED ? "Selected file/s have been copied.":"Selected file/s have been moved.");
						DetailFragment.FILE_SELECTED_FOR_CUT_COPY=new ArrayList<>();
						paste_pastecancel_view_procedure(df);
						break;
					}
					for(File f:DetailFragment.FILE_SELECTED_FOR_CUT_COPY)
					{
						files_selected_array.add(f.getAbsolutePath());
					}
					bundle.putString("source_folder",DetailFragment.FILE_SELECTED_FOR_CUT_COPY.get(0).getParent());
					bundle.putStringArrayList("files_selected_array",files_selected_array);
					PasteSetUpDialog pasteSetUpDialog=new PasteSetUpDialog();
					DetailFragment.FILE_SELECTED_FOR_CUT_COPY=new ArrayList<>();
					bundle.putString("dest_folder",df.getTag());
					bundle.putBoolean("cut",DetailFragment.CUT_SELECTED);
					bundle.putBoolean("isWritable",isWritable);
					bundle.putBoolean("isSourceFromInternal",isSourceFromInternal);
					pasteSetUpDialog.setArguments(bundle);
					pasteSetUpDialog.show(FM,"paste_dialog");
					paste_pastecancel_view_procedure(df);
					break;
					

					
				case R.id.image_btn_4:
					
					if(df.mselecteditems.size()>0)
					{
						int size=df.file_selected_array.size();
						for(int i=0;i<size;i++)
						{
							files_selected_array.add(df.file_selected_array.get(i).getAbsolutePath());
							files_selected_index_array.add(df.mselecteditems.keyAt(i));
						}

						bundle.putStringArrayList("files_selected_array",files_selected_array);
						bundle.putIntegerArrayList("files_selected_index_array",files_selected_index_array);
						DeleteFileAlertDialog deleteFileAlertDialogBuilder=new DeleteFileAlertDialog();
						
						df.mselecteditems=new SparseBooleanArray();
						deleteFileAlertDialogBuilder.setArguments(bundle);
						deleteFileAlertDialogBuilder.show(FM,"delete_dialog");
						df.clearSelection();
			
						break;
					}
					else
					{
						print("Select file/s to delete");
						break;
					}
				case R.id.image_btn_5:

					DetailFragment.FILE_SELECTED_FOR_CUT_COPY=new ArrayList<>();
					paste_pastecancel_view_procedure(df);

					break;
					
			}
			
		}

	}
	
	
	private class ActionModeListener implements View.OnClickListener
	{
		@Override
		public void onClick(View v)
		{
			final DetailFragment df=(DetailFragment)FM.findFragmentById(R.id.detail_fragment);
			final Bundle bundle=new Bundle();
			final ArrayList<String> files_selected_array=new ArrayList<>();
			final ArrayList<Integer> files_selected_index_array=new ArrayList<>();

			switch(v.getId())
			{
				

				case R.id.image_btn_1:
					DetailFragment.CUT_SELECTED=true;
					DetailFragment.COPY_SELECTED=false;
					DetailFragment.FILE_SELECTED_FOR_CUT_COPY=new ArrayList<>();
					DetailFragment.FILE_SELECTED_FOR_CUT_COPY.addAll(df.file_selected_array);
					actionmode_finish(df.getTag());
					break;

				case R.id.image_btn_2:
					DetailFragment.COPY_SELECTED=true;
					DetailFragment.CUT_SELECTED=false;
					DetailFragment.FILE_SELECTED_FOR_CUT_COPY=new ArrayList<>();
					DetailFragment.FILE_SELECTED_FOR_CUT_COPY.addAll(df.file_selected_array);
					actionmode_finish(df.getTag());
					break;



				case R.id.image_btn_3:
					RenameFileDialog.OLDFILE=df.file_selected_array.get(0);
					RenameFileDialog renameFileAlertDialogBuilder=new RenameFileDialog();
					renameFileAlertDialogBuilder.show(FM,"rename_dialog");
					actionmode_finish(df.getTag());
					break;

				case R.id.image_btn_4:
					int size=df.file_selected_array.size();
					for(int i=0;i<size;i++)
					{
						files_selected_array.add(df.file_selected_array.get(i).getAbsolutePath());
						files_selected_index_array.add(df.mselecteditems.keyAt(i));
					}

					bundle.putStringArrayList("files_selected_array",files_selected_array);
					bundle.putIntegerArrayList("files_selected_index_array",files_selected_index_array);
					DeleteFileAlertDialog deleteFileAlertDialogBuilder=new DeleteFileAlertDialog();
					deleteFileAlertDialogBuilder.setArguments(bundle);
					deleteFileAlertDialogBuilder.show(FM,"delete_dialog");
					actionmode_finish(df.getTag());
					break;
					
				case R.id.image_btn_5:
					
					listPopWindow.setOnItemClickListener(new AdapterView.OnItemClickListener()
					{
						
						public void onItemClick(AdapterView<?> p1, View p2, int p3, long p4)
						{
							switch(p3)
							{

								
								case 0:
									ArrayList<File> file_list_excluding_dir=new ArrayList<>();
									file_list_excluding_dir=iterate_to_attach_file(df.file_selected_array);
									if(file_list_excluding_dir.size()==0)
									{
										print("Directories/Folders can not be sent. Select at least one file which is not directory");
										actionmode_finish(df.getTag());
										break;
									}
									try
									{
										FileIntentDispatch.sendFile(MainActivity.this,file_list_excluding_dir);
									}
									catch(IOException e){}
									actionmode_finish(df.getTag());
									break;
								case 1:
									for(File f:df.file_selected_array)
									{
										files_selected_array.add(f.getAbsolutePath());
									}
									bundle.putStringArrayList("files_selected_array",files_selected_array);
									PropertiesDialog propertiesDialog=new PropertiesDialog();
									propertiesDialog.setArguments(bundle);
									propertiesDialog.show(FM,"properties_dialog");
									actionmode_finish(df.getTag());
									break;
								case 2:
									for(File f:df.file_selected_array)
									{
										files_selected_array.add(f.getAbsolutePath());
									}
									bundle.putStringArrayList("files_selected_array",files_selected_array);
									ArchiveSetUpDialog ziparchiveDialog=new ArchiveSetUpDialog("zip");
									ziparchiveDialog.setArguments(bundle);
									ziparchiveDialog.show(FM,"zip_dialog");
									actionmode_finish(df.getTag());
									break;
								case 3:
									if(df.file_selected_array.size()!=1)
									{
										print("Select only a zip file");
										actionmode_finish(df.getTag());
										break;
									}
									String file_name=df.file_selected_array.get(0).getName();
									String file_ext="";
									int idx=file_name.lastIndexOf(".");
									if(idx!=-1)
									{
										file_ext=file_name.substring(idx+1);
									}
									if(file_ext.matches(("(?i)zip")))
									{
										for(File f:df.file_selected_array)
										{
											files_selected_array.add(f.getAbsolutePath());
										}
										bundle.putStringArrayList("files_selected_array",files_selected_array);

										ArchiveSetUpDialog unziparchiveDialog=new ArchiveSetUpDialog("unzip");
										unziparchiveDialog.setArguments(bundle);
										unziparchiveDialog.show(FM,"unzip_dialog");
										actionmode_finish(df.getTag());
										break;
									}
									else
									{
										print("Select only a zip file");
										actionmode_finish(df.getTag());
										break;
									}
								
									
								default:
									break;

							}
						}
					});
					listPopWindow.show();
					
					break;
					
				default:
					break;
			}
		}
	}

	private class StorageRecyclerAdapter extends RecyclerView.Adapter<StorageRecyclerAdapter.ViewHolder>
	{
		//Context context;
		List<FilePOJO> storage_dir_arraylist;

		StorageRecyclerAdapter(List<FilePOJO> storage_dir_arraylist)
		{
			this.storage_dir_arraylist=storage_dir_arraylist;
		}

		class ViewHolder extends RecyclerView.ViewHolder
		{
			View v;
			ImageView imageview;
			TextView textView_recent_dir;

			ViewHolder(View v)
			{
				super(v);
				this.v=v;
				imageview=v.findViewById(R.id.image_storage_dir);
				textView_recent_dir=v.findViewById(R.id.text_storage_dir_name);

				v.setOnClickListener(new View.OnClickListener()
					{

						public void onClick(View p)
						{
							
							STORAGE_ITEM_SELECTED=storage_dir_arraylist.get(getAdapterPosition()).getPath();
							drawerLayout.closeDrawer(drawer);
							
						}

					});

			}

		}

		@Override
		public StorageRecyclerAdapter.ViewHolder onCreateViewHolder(ViewGroup p1, int p2)
		{
			// TODO: Implement this method
			//View v=LayoutInflater.from(p1.getContext()).inflate(android.R.layout.simple_list_item_1,p1,false);
			View v=LayoutInflater.from(p1.getContext()).inflate(R.layout.storage_dir_recyclerview_layout,p1,false);
			return new ViewHolder(v);
		}

		@Override
		public void onBindViewHolder(StorageRecyclerAdapter.ViewHolder p1, int p2)
		{
			// TODO: Implement this method
			
				if(storage_dir_arraylist.get(p2).getPath().equals("/"))
				{
					
					p1.imageview.setImageResource(R.drawable.device_icon);
					p1.textView_recent_dir.setText("Root Directory");
				}
				else
				{
					p1.textView_recent_dir.setText(storage_dir_arraylist.get(p2).getName());
					p1.imageview.setImageResource(R.drawable.sdcard_icon);
				}
				

		}

		@Override
		public int getItemCount()
		{
			// TODO: Implement this method
			return storage_dir_arraylist.size();
		}

	}
	
	private class LibraryRecyclerAdapter extends RecyclerView.Adapter<LibraryRecyclerAdapter.ViewHolder>
	{
	
		List<String> storage_dir_arraylist;

		LibraryRecyclerAdapter(List<String> storage_dir_arraylist)
		{
			this.storage_dir_arraylist=storage_dir_arraylist;
	
		}

		class ViewHolder extends RecyclerView.ViewHolder
		{
			View v;
			ImageView imageview,overlay_imageview;
			TextView textView_recent_dir;

			ViewHolder(View v)
			{
				super(v);
				this.v=v;
				imageview=v.findViewById(R.id.image_storage_dir);
				overlay_imageview=v.findViewById(R.id.overlay_image_storage_dir);
				textView_recent_dir=v.findViewById(R.id.text_storage_dir_name);
				imageview.setVisibility(View.GONE);
				overlay_imageview.setVisibility(View.GONE);
				v.setOnClickListener(new View.OnClickListener()
					{

						public void onClick(View p)
						{

							STORAGE_ITEM_SELECTED=storage_dir_arraylist.get(getAdapterPosition());
							drawerLayout.closeDrawer(drawer);

						}

					});

			}

		}

		@Override
		public LibraryRecyclerAdapter.ViewHolder onCreateViewHolder(ViewGroup p1, int p2)
		{
			// TODO: Implement this method
			//View v=LayoutInflater.from(p1.getContext()).inflate(android.R.layout.simple_list_item_1,p1,false);
			View v=LayoutInflater.from(p1.getContext()).inflate(R.layout.storage_dir_recyclerview_layout,p1,false);
			return new ViewHolder(v);
		}

		@Override
		public void onBindViewHolder(LibraryRecyclerAdapter.ViewHolder p1, int p2)
		{
			// TODO: Implement this method
			
			p1.textView_recent_dir.setText(storage_dir_arraylist.get(p2));
		

		}

		@Override
		public int getItemCount()
		{
			// TODO: Implement this method
			return storage_dir_arraylist.size();
		}

	}
	
	private class ArchiveViewAsyncTask extends AsyncTask<Void, Void, Boolean>
	{
		ZipFile zipfile;
		//File zip_file;
		boolean success;
		ProgressBarFragment progressbarFragment=new ProgressBarFragment();
		ArchiveViewAsyncTask(ZipFile zip_file)
		{
			this.zipfile=zip_file;
		}
		@Override
		protected void onPreExecute()
		{
			// TODO: Implement this method
			super.onPreExecute();
			progressbarFragment.show(FM,"progressbar_dialog");
			
		}

		@Override
		protected Boolean doInBackground(Void[] p1)
		{
			// TODO: Implement this method
			
			//try
			{
				if(ARCHIVE_EXTRACT_DIR.exists())
				{

					FileUtil.deleteNativeDirectory(ARCHIVE_EXTRACT_DIR);
				}

			}
			//catch(IOException e){}
			Enumeration zip_entries=zipfile.entries();

			while(zip_entries.hasMoreElements())
			{
				ZipEntry zipentry=(ZipEntry)zip_entries.nextElement();
				File f=new File(ARCHIVE_EXTRACT_DIR,zipentry.getName());
				if(zipentry.isDirectory() && !f.exists())
				{
					success=f.mkdirs();
				}
				else if(!zipentry.isDirectory())
				{
					if(!f.getParentFile().exists())
					{
						success=f.getParentFile().mkdirs();
					}
					try
					{
						success=f.createNewFile();

					}
					catch(IOException e)
					{

					}
				}

			}
			return success;
		}

		@Override
		protected void onPostExecute(Boolean result)
		{
			// TODO: Implement this method
			super.onPostExecute(result);
			progressbarFragment.dismissAllowingStateLoss();
			ARCHIVE_VIEW=result;
			if(result)
			{
				
				TOOLBAR_SHOWN_PRIOR_ARCHIVE=TOOLBAR_SHOWN;
				createFragmentTransaction(ARCHIVE_EXTRACT_DIR,null);
				
			}

			else
			{
				{
					if(ARCHIVE_EXTRACT_DIR.exists())
					{
						FileUtil.deleteNativeDirectory(ARCHIVE_EXTRACT_DIR);
					}
					
					
				}
			}
		}

	}
	
	

	public class AsyncTaskDeleteDirectory extends AsyncTask<Void,Void,Boolean>
	{
		File dir;
		ProgressBarFragment pbf=new ProgressBarFragment();
		
		AsyncTaskDeleteDirectory(File f)
		{
			dir=f;

		}

		@Override
		protected void onPreExecute()
		{
			// TODO: Implement this method
			super.onPreExecute();
			pbf.show(FM,"progressbar_dialog");
		}



		@Override
		protected Boolean doInBackground(Void[] p1)
		{
			// TODO: Implement this method
			{
				FileUtil.deleteNativeDirectory(dir);
			}
			return !dir.exists();

		}

		@Override
		protected void onPostExecute(Boolean result)
		{
			// TODO: Implement this method
			super.onPostExecute(result);
			pbf.dismissAllowingStateLoss();
		}

	}
	

	

	static boolean whether_matched_recognised_files(String file_ext)
	{
		
		if(file_ext.matches(Global.OTHER_TEXT_REGEX) ||

		   file_ext.matches(Global.IMAGE_REGEX) ||

		   file_ext.matches(Global.AUDIO_REGEX) ||

		   file_ext.matches(Global.VIDEO_REGEX) ||

		   file_ext.matches(Global.ZIP_REGEX) ||

		   file_ext.matches(Global.UNIX_ARCHIVE_REGEX) ||

		   file_ext.matches(Global.APK_REGEX) ||

		   file_ext.matches(Global.PDF_REGEX) ||

		   file_ext.matches(Global.DOC_REGEX) ||
		   
		   file_ext.matches(Global.XLS_REGEX) ||
			
		   file_ext.matches(Global.PPT_REGEX) ||
		   
		   file_ext.matches(Global.DB_REGEX) ||
		   
		   file_ext.matches(Global.RTF_REGEX))
		   
		{
			return true;
		}
		else
		{
			return false;
		}

	}
	
	static void workout_availablespace()
	{
		for(FilePOJO file:STORAGE_DIR)
		{
			long totalspace=0,availabelspace=0;
			if(file.getPath().equals(File.separator))
			{
				SPACE_ARRAY.put(file.getPath(),new SpacePOJO(file.getPath(),totalspace,availabelspace));
				//USED_SPACE.put(file.getPath(),FileUtil.humanReadableByteCount(availabelspace,false));
				continue;
			}
			totalspace=file.getFile().getTotalSpace();
			availabelspace=file.getFile().getUsableSpace();
			SPACE_ARRAY.put(file.getPath(),new SpacePOJO(file.getPath(),totalspace,availabelspace));
			//USED_SPACE.put(file.getPath(),FileUtil.humanReadableByteCount(totalspace-availabelspace,false));
		}
		
	}
	
	static Class getEmptyService()
	{
		Class emptyService=null;
		if(ArchiveDeletePasteFileService1.SERVICE_COMPLETED)
		{
			emptyService=ArchiveDeletePasteProgressActivity1.class;
		}
		else if(ArchiveDeletePasteFileService2.SERVICE_COMPLETED)
		{
			emptyService=ArchiveDeletePasteProgressActivity2.class;
		}
		
		else if(ArchiveDeletePasteFileService3.SERVICE_COMPLETED)
		{
			emptyService=ArchiveDeletePasteProgressActivity3.class;
		}
	
		return emptyService;
	}
	
	private class DeleteOtherActivityBroadcastReceiver extends BroadcastReceiver
	{

		@Override
		public void onReceive(Context p1, Intent p2)
		{
			// TODO: Implement this method
			STATE_CHANGED=p2.getBooleanExtra("deleted",false);
			
		}

		
		
	}
	
	
	private void print(String msg)
	{

		android.widget.Toast.makeText(this,msg,android.widget.Toast.LENGTH_SHORT).show();
	}
	
}
