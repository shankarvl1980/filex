package svl.kadatha.filex;
import android.support.v4.app.*;
import android.os.*;
import android.view.*;
import android.content.*;
import android.widget.*;
import android.support.v7.widget.*;
import java.util.*;
import android.util.*;
import android.net.*;
import android.provider.*;
import java.io.*;
import android.graphics.drawable.*;
import android.graphics.*;
import android.media.*;
import android.view.View.*;
import android.view.animation.*;
import android.support.design.widget.*;
import android.app.*;

public class AudioSavedListDetailsDialog extends android.support.v4.app.DialogFragment
{
	private CurrentListRecyclerViewAdapter currentAudioListRecyclerViewAdapter;
	private Context context;
	private RecyclerView CurrentAudioListRecyclerview;
	private Button audio_select_btn;
	
	private TextView dialog_title,empty_audio_list_tv;
	private android.support.v7.widget.Toolbar bottom_toolbar;
	private ImageButton remove_btn,play_btn,send_btn,properties_btn,add_list_btn;
	public SparseBooleanArray mselecteditems=new SparseBooleanArray();
	public List<AudioPOJO> audio_selected_array=new ArrayList<>();
	public List<AudioPOJO> clicked_audio_list;
	private AudioSelectListener audioSelectListener;
	private String audio_list_clicked_name;
	private int saved_audio_clicked_pos;
	private AsyncTaskStatus asyncTaskStatus;
	private int number_button=4;
	private boolean toolbar_visible;
	private int scroll_distance;
	private FloatingActionButton floating_back_button;
	private int num_all_audio;
	private boolean whether_audios_set_to_current_list;
	private int current_play_number;
	
	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		// TODO: Implement this method
		super.onCreate(savedInstanceState);
		setRetainInstance(true);
		asyncTaskStatus=AsyncTaskStatus.NOT_YET_STARTED;

		Bundle bundle=getArguments();
		if(bundle!=null)
		{
			saved_audio_clicked_pos=bundle.getInt("pos");
			audio_list_clicked_name=bundle.getString("list_name");
			
		}
		
		if(saved_audio_clicked_pos!=0)
		{
		
			number_button=5;
			
		}
		
	
		
		current_play_number=AudioPlayerService.CURRENT_PLAY_NUMBER;
		
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
	{
		// TODO: Implement this method
		context=getContext();
		View v=inflater.inflate(R.layout.fragment_audio_saved_list_details,container,false);
		dialog_title=v.findViewById(R.id.audio_saved_list_panel_title_TextView);
		dialog_title.setText(audio_list_clicked_name);
		audio_select_btn=v.findViewById(R.id.num_audio_selected);
		audio_select_btn.setOnClickListener(new View.OnClickListener()
			{
				public void onClick(View p1)
				{

					if(mselecteditems.size()<num_all_audio)
					{
						mselecteditems=new SparseBooleanArray();
						audio_selected_array=new ArrayList<>();
						for(int i=0;i<num_all_audio;i++)
						{
							mselecteditems.put(i,true);
							audio_selected_array.add(clicked_audio_list.get(i));
						}
						
						currentAudioListRecyclerViewAdapter.notifyDataSetChanged();
						
						bottom_toolbar.animate().translationY(0).setInterpolator(new DecelerateInterpolator(1));
						toolbar_visible=true;
						scroll_distance=0;
					}
					else
					{
						clear_selection();
					}
					audio_select_btn.setText(mselecteditems.size()+"/"+num_all_audio);
				}
			});
		


	
		
		if(mselecteditems.size()<1)
		{
			
		}
		
		CurrentAudioListRecyclerview=v.findViewById(R.id.fragment_audio_saved_list_recyclerview);
		CurrentAudioListRecyclerview.setLayoutManager(new LinearLayoutManager(context));
		CurrentAudioListRecyclerview.addOnScrollListener(new RecyclerView.OnScrollListener()
		{
				final int threshold=5;
				public void onScrolled(RecyclerView rv, int dx, int dy)
				{
					super.onScrolled(rv,dx,dy);
					if(scroll_distance>threshold && toolbar_visible)
					{
						bottom_toolbar.animate().translationY(bottom_toolbar.getHeight()).setInterpolator(new AccelerateInterpolator(1));
						toolbar_visible=false;
						scroll_distance=0;
					}
					else if(scroll_distance<-threshold && !toolbar_visible)
					{
						if(mselecteditems.size()>0)
						{
							bottom_toolbar.animate().translationY(0).setInterpolator(new DecelerateInterpolator(1));
							toolbar_visible=true;
							scroll_distance=0;
						}

					}

					if((toolbar_visible && dy>0) || (!toolbar_visible && dy<0))
					{
						scroll_distance+=dy;
					}

				}
			
			
		});
		empty_audio_list_tv=v.findViewById(R.id.fragment_empty_audio_saved_list_tv);
		
		floating_back_button=v.findViewById(R.id.fragment_audio_saved_list_floating_action_button);
		floating_back_button.setOnClickListener(new View.OnClickListener()
			{
				public void onClick(View p1)
				{
					if(mselecteditems.size()>0)
					{
						clear_selection();
						audio_select_btn.setText(mselecteditems.size()+"/"+num_all_audio);
					}
					else
					{
						dismissAllowingStateLoss();
					}
				}

			});
		
		
		EquallyDistributedImageButtonsLayout tb_layout =new EquallyDistributedImageButtonsLayout(context,number_button,Global.DIALOG_WIDTH,Global.DIALOG_WIDTH);
		int drawables []={R.drawable.delete_icon,R.drawable.play_icon,R.drawable.send_icon,R.drawable.properties_icon,R.drawable.add_list_icon};
		tb_layout.setResourceImageDrawables(drawables);
			
		bottom_toolbar=v.findViewById(R.id.fragment_audio_saved_list_bottom_toolbar);
		
		bottom_toolbar.addView(tb_layout);
		//remove_btn,play_btn,send_btn,properties_btn;
		remove_btn=bottom_toolbar.findViewById(R.id.image_btn_1);
		play_btn=bottom_toolbar.findViewById(R.id.image_btn_2);
		send_btn=bottom_toolbar.findViewById(R.id.image_btn_3);
		properties_btn=bottom_toolbar.findViewById(R.id.image_btn_4);
		add_list_btn=bottom_toolbar.findViewById(R.id.image_btn_5);

		ToolbarButtonClickListener toolbarButtonClickListener=new ToolbarButtonClickListener();
		remove_btn.setOnClickListener(toolbarButtonClickListener);
		play_btn.setOnClickListener(toolbarButtonClickListener);
		send_btn.setOnClickListener(toolbarButtonClickListener);
		properties_btn.setOnClickListener(toolbarButtonClickListener);
		add_list_btn.setOnClickListener(toolbarButtonClickListener);
		
		
		if(mselecteditems.size()==0)
		{
			bottom_toolbar.setVisibility(View.GONE);
			bottom_toolbar.animate().translationY(bottom_toolbar.getHeight()).setInterpolator(new AccelerateInterpolator(1));
			toolbar_visible=false;
		}
		else
		{
			//bottom_toolbar.animate().translationY(0).setInterpolator(new DecelerateInterpolator(1));
			toolbar_visible=true;
		}
		
		if(asyncTaskStatus!=AsyncTaskStatus.STARTED)
		{
			new FetchAudioListDetailsAsyncTask().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
		}
		
		audio_select_btn.setText(mselecteditems.size()+"/"+num_all_audio);
		return v;
	}

	private void fetch_audio_list(String list_name, int pos)
	{
		
		if(pos==0)
		{
			for(AudioPOJO audio:AudioPlayerService.AUDIO_QUEUED_ARRAY)
			{
				if(new File(audio.getData()).exists())
				{
					clicked_audio_list.add(audio);
				}
			}
		
		}

		else if(AudioPlayerActivity.AUDIO_SAVED_LIST.contains(list_name))
		{
			
			audio_list_clicked_name=list_name;
			clicked_audio_list=((AudioPlayerActivity)context).audioDatabaseHelper.getAudioList(list_name);
			Iterator<AudioPOJO> it=clicked_audio_list.iterator();
			while(it.hasNext())
			{
				AudioPOJO audio=it.next();
				if(!new File(audio.getData()).exists())
				{
					((AudioPlayerActivity)context).audioDatabaseHelper.delete(list_name,audio.getId());
					it.remove();
				}
			}
			
		}

	}

	private void remove_and_save(String list_name,List<AudioPOJO> audio_list_to_be_removed, SparseBooleanArray index)
	{
		
		ProgressBarFragment pbf=new ProgressBarFragment();
		pbf.show(((AudioPlayerActivity)context).fm,"");
		AudioPlayerService.AUDIO_QUEUED_ARRAY.removeAll(audio_list_to_be_removed);
		clicked_audio_list.removeAll(audio_list_to_be_removed);
		int size=audio_list_to_be_removed.size();
		for(int i=0;i<size;i++)
		{
			int key=index.keyAt(i);
			
			if(AudioPlayerService.CURRENT_PLAY_NUMBER>=key)
			{
				AudioPlayerService.CURRENT_PLAY_NUMBER--;
			}
		}
		
		if(AudioPlayerService.CURRENT_PLAY_NUMBER<0)
		{
			AudioPlayerService.CURRENT_PLAY_NUMBER=0;
		}
		if(saved_audio_clicked_pos!=0)
		{
	
			((AudioPlayerActivity)context).audioDatabaseHelper.delete(list_name,audio_list_to_be_removed);
			
			
		}
		
		pbf.dismissAllowingStateLoss();

	}
	
	public void onAudioChange(int play_number)
	{
		currentAudioListRecyclerViewAdapter.notifyDataSetChanged();
		/*
		currentAudioListRecyclerViewAdapter.notifyItemChanged(current_play_number);
		currentAudioListRecyclerViewAdapter.notifyItemChanged(play_number);
		current_play_number=play_number;
		*/
	}

	@Override
	public void onResume()
	{
		// TODO: Implement this method
		super.onResume();

		Window window=getDialog().getWindow();
		if(context.getResources().getBoolean(R.bool.is_land))
		{
			window.setLayout(Global.DIALOG_WIDTH,Global.DIALOG_WIDTH);

		}
		else
		{
			window.setLayout(Global.DIALOG_WIDTH,Global.DIALOG_HEIGHT);
		}

		window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
	}
	
	
	@Override
	public void onDestroyView()
	{
		// TODO: Implement this method
		
		if(getDialog()!=null && getRetainInstance())
		{
			getDialog().setDismissMessage(null);
		}
		super.onDestroyView();
	}
	
	private class FetchAudioListDetailsAsyncTask extends AsyncTask<Void,Void,Void>
	{
		ProgressBarFragment pbf;
		@Override
		protected void onPreExecute()
		{
			// TODO: Implement this method
			super.onPreExecute();
			asyncTaskStatus=AsyncTaskStatus.STARTED;
			pbf=new ProgressBarFragment();
			pbf.show(((AudioPlayerActivity)context).fm,"");
		}

		@Override
		protected void onCancelled(Void result)
		{
			// TODO: Implement this method
			super.onCancelled(result);
			pbf.dismissAllowingStateLoss();
		}

		
		@Override
		protected Void doInBackground(Void[] p1)
		{
			// TODO: Implement this method
			if(clicked_audio_list!=null)
			{
				return null;
			}
			clicked_audio_list=new ArrayList<>();
			fetch_audio_list(audio_list_clicked_name,saved_audio_clicked_pos);
			return null;
		}

		@Override
		protected void onPostExecute(Void result)
		{
			// TODO: Implement this method
			super.onPostExecute(result);
			currentAudioListRecyclerViewAdapter=new CurrentListRecyclerViewAdapter();
			CurrentAudioListRecyclerview.setAdapter(currentAudioListRecyclerViewAdapter);
			num_all_audio=clicked_audio_list.size();
			if(num_all_audio==0)
			{
				CurrentAudioListRecyclerview.setVisibility(View.GONE);
				empty_audio_list_tv.setVisibility(View.VISIBLE);
			}
			audio_select_btn.setText(mselecteditems.size()+"/"+num_all_audio);
			CurrentAudioListRecyclerview.scrollToPosition(AudioPlayerService.CURRENT_PLAY_NUMBER);
			pbf.dismissAllowingStateLoss();
			asyncTaskStatus=AsyncTaskStatus.COMPLETED;
		}


	}

	public void clear_selection()
	{
		audio_selected_array=new ArrayList<>();
		mselecteditems=new SparseBooleanArray();
		currentAudioListRecyclerViewAdapter.notifyDataSetChanged();

		bottom_toolbar.animate().translationY(bottom_toolbar.getHeight()).setInterpolator(new AccelerateInterpolator(1));
		toolbar_visible=false;
		scroll_distance=0;

	} 
	
	private class ToolbarButtonClickListener implements View.OnClickListener
	{

		@Override
		public void onClick(View p1)
		{
			// TODO: Implement this method
			final Bundle bundle=new Bundle();
			final ArrayList<String> files_selected_array=new ArrayList<>();

			switch(p1.getId())
			{

				case R.id.image_btn_1:
					if(audio_selected_array.size()<1)
					{
						break;
					}
					remove_and_save(audio_list_clicked_name,audio_selected_array,mselecteditems);
					print("Removed the selected audios");
					break;
				case R.id.image_btn_2:
					if(audio_selected_array.size()<1)
					{
						break;
					}
					AudioPlayerService.AUDIO_QUEUED_ARRAY=new ArrayList<>();
					AudioPlayerService.AUDIO_QUEUED_ARRAY.addAll(audio_selected_array);
					if(AudioPlayerService.AUDIO_QUEUED_ARRAY.size()!=0)
					{
						AudioPlayerService.CURRENT_PLAY_NUMBER=0;
						AudioPOJO audio=AudioPlayerService.AUDIO_QUEUED_ARRAY.get(AudioPlayerService.CURRENT_PLAY_NUMBER);
						Uri data=null;
						File f=new File(audio.getData());
						if(f.exists())
						{
							data=Uri.fromFile(f);
						}
						else
						{

							data=null;
						}

						if(audioSelectListener!=null)
						{
							audioSelectListener.onAudioSelect(data,audio);
						}

					}
					break;


				case R.id.image_btn_3:
					if(audio_selected_array.size()<1)
					{
						break;
					}
					ArrayList<File> file_list=new ArrayList<>();
					for(AudioPOJO audio:audio_selected_array)
					{
						file_list.add(new File(audio.getData()));
					}

					try
					{
						FileIntentDispatch.sendFile(((AudioPlayerActivity)context),file_list);
					}
					catch(IOException e){}
					break;

				case R.id.image_btn_4:
					if(audio_selected_array.size()<1)
					{
						break;
					}
					for(AudioPOJO audio:audio_selected_array)
					{
						files_selected_array.add(audio.getData());
					}
					bundle.putStringArrayList("files_selected_array",files_selected_array);
					PropertiesDialog propertiesDialog=new PropertiesDialog();
					propertiesDialog.setArguments(bundle);
					propertiesDialog.show(((AudioPlayerActivity)context).getSupportFragmentManager(),"properties_dialog");
					break;

				case R.id.image_btn_5:
					if(audio_selected_array.size()<1)
					{
						break;
					}
					AudioPlayerService.AUDIO_QUEUED_ARRAY=audio_selected_array;
					print("Added selected audios to the current playing list");
					break;
				default:
					break;

			}
			clear_selection();
			((AudioPlayerActivity)context).trigger_enable_disable_previous_next_btns();
		}
			

	}

	
	
	private class CurrentListRecyclerViewAdapter extends RecyclerView.Adapter <CurrentListRecyclerViewAdapter.ViewHolder>
	{


		class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener, AdapterView.OnLongClickListener
		{
			AudioListRecyclerViewItem view;
			int pos;

			ViewHolder (AudioListRecyclerViewItem view)
			{

				super(view);
				this.view=view;

				view.setOnClickListener(this);
				view.setOnLongClickListener(this);

			}


			@Override
			public void onClick(View p1)
			{
				pos=getAdapterPosition();
				if(mselecteditems.size()>0)
				{

					onLongClickProcedure(p1);
				}
				else 
				{

					AudioPOJO audio=clicked_audio_list.get(pos);
			
					Uri data=null;
					File f=new File(audio.getData());
					if(f.exists())
					{
						data=Uri.fromFile(f);
					}
					else
					{

						data=null;
					}
	
					if(audioSelectListener!=null)
					{
						audioSelectListener.onAudioSelect(data,audio);
					}
	
					if(!whether_audios_set_to_current_list)
					{
						AudioPlayerService.AUDIO_QUEUED_ARRAY=new ArrayList<>();
						AudioPlayerService.AUDIO_QUEUED_ARRAY=clicked_audio_list;
						whether_audios_set_to_current_list=true;
					}
					AudioPlayerService.CURRENT_PLAY_NUMBER=pos;
					onAudioChange(pos);
					((AudioPlayerActivity)context).trigger_enable_disable_previous_next_btns();
					
				}

			}


			@Override
			public boolean onLongClick(View p1)
			{

				onLongClickProcedure(p1);
				return true;
			}

			private void onLongClickProcedure(View v)
			{
				pos=getAdapterPosition();

				if(mselecteditems.get(pos,false))
				{
					mselecteditems.delete(pos);
					//mainActivity.num_selected_btn.setText(MSELECTEDITEMS.size()+"/"+file_list_size);
					v.setSelected(false);
					audio_selected_array.remove(clicked_audio_list.get(pos));
					if(mselecteditems.size()>=1)
					{
						bottom_toolbar.setVisibility(View.VISIBLE);
						bottom_toolbar.animate().translationY(0).setInterpolator(new DecelerateInterpolator(1));
						toolbar_visible=true;
						scroll_distance=0;

					}


					if(mselecteditems.size()==0)
					{

						bottom_toolbar.animate().translationY(bottom_toolbar.getHeight()).setInterpolator(new AccelerateInterpolator(1));
						toolbar_visible=false;
						scroll_distance=0;

					}
				}
				else
				{
					mselecteditems.put(pos,true);

					//mainActivity.num_selected_btn.setText(MSELECTEDITEMS.size()+"/"+file_list_size);
					v.setSelected(true);
					audio_selected_array.add(clicked_audio_list.get(pos));
					bottom_toolbar.setVisibility(View.VISIBLE);
					bottom_toolbar.animate().translationY(0).setInterpolator(new DecelerateInterpolator(1));
					toolbar_visible=true;
					scroll_distance=0;
			
					if(mselecteditems.size()==1)
					{

					

					}

					else if(mselecteditems.size()>1)
					{
				
			

					}

				}
				audio_select_btn.setText(mselecteditems.size()+"/"+num_all_audio);
			}
		}

	
		@Override
		public ViewHolder onCreateViewHolder(ViewGroup p1, int p2)
		{

			return new ViewHolder(new AudioListRecyclerViewItem(context));

		}

		@Override
		public void onBindViewHolder(CurrentListRecyclerViewAdapter.ViewHolder p1, int p2)
		{

			AudioPOJO audio=clicked_audio_list.get(p2);
			String title=audio.getTitle();
			String album="Album: "+audio.getAlbum();
			long duration=Long.parseLong(audio.getDuration());
			String duration_str="Duration: "+ (String.format("%d:%02d",duration/1000/60,duration/1000%60));
			String artist="Artists: "+audio.getArtist();
			Bitmap art=audio.getAlbumArt();
			p1.view.setData(title,album,duration_str,artist,art);
			p1.view.setSelected(mselecteditems.get(p2,false));
			/*
			if(saved_audio_clicked_pos==0 && p2==AudioPlayerService.CURRENT_PLAY_NUMBER)
			{
				p1.view.set_background_color(R.color.select_color2);
			}
			else
			{
				p1.view.set_background_color(Color.TRANSPARENT);
			}
*/


		}


		@Override
		public int getItemCount()
		{	
			num_all_audio=clicked_audio_list.size();
			return num_all_audio;
		}
		

	}


	 interface AudioSelectListener
	 {
	 	public void onAudioSelect(Uri data,AudioPOJO audio);
	 }

	 public void setAudioSelectListener(AudioSelectListener listener)
	 {
	 	audioSelectListener=listener;
	 }

	private enum AsyncTaskStatus
	{
		NOT_YET_STARTED, STARTED, COMPLETED
	}
	private void print(String msg)
	{
		Toast.makeText(context,msg,Toast.LENGTH_SHORT).show();
	}
}
