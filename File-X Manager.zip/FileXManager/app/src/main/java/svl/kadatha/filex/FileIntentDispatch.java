package svl.kadatha.filex;
import java.util.*;
import java.io.*;
import android.content.Intent;
import android.net.*;
import android.content.Context;
import android.webkit.*;
import android.support.v7.app.*;
import android.os.*;

class FileIntentDispatch
{
	
	public static void openFile(Context context,File file, String file_type) throws IOException
	{
		
		OpenFileIntentDispatchAsyncTask openFileIntentDispatchAsyncTask=new OpenFileIntentDispatchAsyncTask(context,file,file_type);
		openFileIntentDispatchAsyncTask.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
		
	}
	
	public static void sendFile(Context context, ArrayList<File> file_list) throws IOException
	{

		SendFileIntentDispatchAsyncTask sendFileIntentDispatchAsyncTask=new SendFileIntentDispatchAsyncTask(context,file_list);
		sendFileIntentDispatchAsyncTask.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
	}

	public static void sendUri(Context context, ArrayList<Uri> uri_list) throws IOException
	{

		SendUriIntentDispatchAsyncTask sendUriIntentDispatchAsyncTask=new SendUriIntentDispatchAsyncTask(context,uri_list);
		sendUriIntentDispatchAsyncTask.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
	}
	
    private static void open_file(Context context, File url, String type)
	{
        // Create URI
        File file=url;
		String file_name=url.toString();
		String file_extn="";
		int file_extn_idx=file_name.lastIndexOf(".");
		if(file_extn_idx!=-1)
		{
			file_extn=file_name.substring(file_extn_idx+1);
		}
		
        Uri uri = Uri.fromFile(file);
        Intent intent = new Intent(Intent.ACTION_VIEW);
		
      	if(type!=null && type!="")
		{
			intent.setDataAndType(uri, type);
		}
		else if (file_extn.matches(Global.DOC_REGEX))
		{
            intent.setDataAndType(uri, "application/msword");
        } 
		else if(file_extn.matches(Global.PDF_REGEX)) 
		{
            intent.setDataAndType(uri, "application/pdf");
        } 
		else if(file_extn.matches(Global.PPT_REGEX) ) 
		{
            intent.setDataAndType(uri, "application/vnd.ms-powerpoint");
        }
		else if(file_extn.matches(Global.XLS_REGEX)) 
		{
            intent.setDataAndType(uri, "application/vnd.ms-excel");
        } 
		else if(file_extn.matches(Global.ZIP_REGEX)) 
		{
            intent.setDataAndType(uri, "application/zip");
        }
		else if(file_extn.matches(Global.RTF_REGEX)) 
		{
            intent.setDataAndType(uri, "application/rtf");
        }
		else if(file_extn.matches(Global.AUDIO_REGEX) ) 
		{
            intent.setDataAndType(uri, "audio/*");
        }
		else if(file_extn.matches(Global.IMAGE_REGEX)) 
		{
            intent.setDataAndType(uri, "image/*");
        }
		else if(file_extn.matches(Global.APK_REGEX)) 
		{
            intent.setDataAndType(uri, "application/vnd.android.package-archive");
        }
		else if(file_extn.matches(Global.VIDEO_REGEX))
		{
            intent.setDataAndType(uri, "video/*");
        }
		else if(file_extn.matches(Global.DB_REGEX))
		{
			String [] mimeTypes={"application/vnd.sqlite3","application/x-sqlite3"};
			intent.putExtra(Intent.EXTRA_MIME_TYPES,mimeTypes);
			intent.setData(uri);
		}
		else 
		{
            intent.setDataAndType(uri,"text/*");
		
        }

		intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		Intent chooser=Intent.createChooser(intent,"Select app");
		if(intent.resolveActivity(context.getPackageManager())!=null)
		{
			context.startActivity(chooser);
		}
		else
		{
			intent.setDataAndType(uri,"text/*");
			chooser=Intent.createChooser(intent,"Select app");
			context.startActivity(chooser);
		}
		
	}
	
	private static void send_file(Context context, ArrayList<File> file_list)
	{

		ArrayList<Uri> uri_list=new ArrayList<>();
		for(File f:file_list)
		{
			uri_list.add(Uri.fromFile(f));
		}

		Intent intent=new Intent(Intent.ACTION_SEND_MULTIPLE);
		intent.putParcelableArrayListExtra(Intent.EXTRA_STREAM,uri_list);
		intent.putExtra(Intent.EXTRA_SUBJECT,file_list.get(0).getName());
		intent.setType("*/*");
		
		intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		Intent chooser=Intent.createChooser(intent,"Select app");
		if(intent.resolveActivity(context.getPackageManager())!=null)
		{
			context.startActivity(chooser);
		}
		
		
	}
	
	private static void send_uri(Context context, ArrayList<Uri> uri_list)
	{

		
		String extra=new File(uri_list.get(0).getPath()).getName();
		if(extra==null)
		{
			extra="";
		}
		Intent intent=new Intent(Intent.ACTION_SEND_MULTIPLE);
		intent.putParcelableArrayListExtra(Intent.EXTRA_STREAM,uri_list);
		intent.putExtra(Intent.EXTRA_SUBJECT,extra);
		intent.setType("*/*");

		intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		Intent chooser=Intent.createChooser(intent,"Select app");
		if(intent.resolveActivity(context.getPackageManager())!=null)
		{
			context.startActivity(chooser);
		}


	}
	
	
	private static class OpenFileIntentDispatchAsyncTask extends AsyncTask<Void,Void,Void>
	{
		Context context;
		File file;
		String file_type;
		ProgressBarFragment pbf=new ProgressBarFragment();
	
		OpenFileIntentDispatchAsyncTask(Context context,File file,String file_type)
		{
			this.context=context;
			this.file=file;
			this.file_type=file_type;
		}

		@Override
		protected void onPreExecute()
		{
			// TODO: Implement this method
			super.onPreExecute();
			pbf.show(((AppCompatActivity)context).getSupportFragmentManager(),"progressbar_dialog");
		}
		
		
		@Override
		protected Void doInBackground(Void[] p1) 
		{
			// TODO: Implement this method
		
			open_file(context, file,file_type);
			
			return null;
		}

		@Override
		protected void onPostExecute(Void result)
		{
			// TODO: Implement this method
			super.onPostExecute(result);
			pbf.dismissAllowingStateLoss();
		
		}
		
		
	}
	
	private static class SendFileIntentDispatchAsyncTask extends AsyncTask<Void,Void,Void>
	{
		Context context;
		File file;
		ArrayList<File> file_list;
		ProgressBarFragment pbf=new ProgressBarFragment();

		SendFileIntentDispatchAsyncTask(Context context, ArrayList<File> file_list)
		{
			this.context=context;
			this.file_list=file_list;
	
		}

		@Override
		protected void onPreExecute()
		{
			// TODO: Implement this method
			super.onPreExecute();
			pbf.show(((AppCompatActivity)context).getSupportFragmentManager(),"progressbar_dialog");
		}


		@Override
		protected Void doInBackground(Void[] p1) 
		{
			// TODO: Implement this method
		
		
			send_file(context,file_list);
		
			return null;
		}

		@Override
		protected void onPostExecute(Void result)
		{
			// TODO: Implement this method
			super.onPostExecute(result);
			pbf.dismissAllowingStateLoss();

		}


	}

	private static class SendUriIntentDispatchAsyncTask extends AsyncTask<Void,Void,Void>
	{
		Context context;
		File file;
		ArrayList<Uri> uri_list;
		ProgressBarFragment pbf=new ProgressBarFragment();

		SendUriIntentDispatchAsyncTask(Context context, ArrayList<Uri> uri_list)
		{
			this.context=context;
			this.uri_list=uri_list;

		}

		@Override
		protected void onPreExecute()
		{
			// TODO: Implement this method
			super.onPreExecute();
			pbf.show(((AppCompatActivity)context).getSupportFragmentManager(),"progressbar_dialog");
		}


		@Override
		protected Void doInBackground(Void[] p1) 
		{
			// TODO: Implement this method


			send_uri(context,uri_list);

			return null;
		}

		@Override
		protected void onPostExecute(Void result)
		{
			// TODO: Implement this method
			super.onPostExecute(result);
			pbf.dismissAllowingStateLoss();

		}


	}
}
