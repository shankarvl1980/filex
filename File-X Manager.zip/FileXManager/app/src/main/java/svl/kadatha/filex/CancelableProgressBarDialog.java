package svl.kadatha.filex;
import android.support.v4.app.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import android.content.*;
import android.graphics.drawable.*;
import android.graphics.*;
import android.widget.TableRow.*;



public class CancelableProgressBarDialog extends android.support.v4.app.DialogFragment
{
	private Button cancel_button;
	private ViewGroup button_layout;
	private Context context;
	private TextView title;
	private String title_string;
	private ProgresBarFragmentCancelListener progresBarFragmentCancelListener;
	private ProgressBar pb;
	
	CancelableProgressBarDialog(String title)
	{
		title_string=title;
	}
	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		// TODO: Implement this method
		super.onCreate(savedInstanceState);
		setCancelable(false);
		setRetainInstance(true);
		if(savedInstanceState!=null)
		{
			title_string=savedInstanceState.getString("title");
		}
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
	{
		// TODO: Implement this method
		context=getContext();
		View v=inflater.inflate(R.layout.fragment_cancelable_progressbar,container,false);
		title=v.findViewById(R.id.fragment_cancelable_pbf_title);
		pb=v.findViewById(R.id.fragment_cancelable_progressbar_pb);
		
		button_layout=v.findViewById(R.id.fragment_cancelable_pbf_button_layout);
		button_layout.addView(new EquallyDistributedChildrenLayout(context,1));
		cancel_button=button_layout.findViewById(R.id.first_button);
		cancel_button.setText("Cancel");
		cancel_button.setOnClickListener(new Button.OnClickListener()
		{
			public void onClick(View p)
			{
				
		
				if(progresBarFragmentCancelListener!=null)
				{
					
					progresBarFragmentCancelListener.on_cancel_progress();
					
				}
			
			}
			
		});
		
		return v;
	}



	@Override
	public void onResume()
	{
		// TODO: Implement this method
		super.onResume();
		Window window=getDialog().getWindow();
		window.setLayout(Global.DIALOG_WIDTH,LayoutParams.WRAP_CONTENT);
		window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
		title.setText(title_string);
	}
	
	

	@Override
	public void onDestroyView()
	{
		// TODO: Implement this method
		
		if(getDialog()!=null && getRetainInstance())
		{
			getDialog().setDismissMessage(null);
		}
		super.onDestroyView();
	}
	
	
	public void set_title(String heading)
	{
		title.setText(heading);
	}
	public void setProgressBarCancelListener(ProgresBarFragmentCancelListener listener)
	{
		progresBarFragmentCancelListener=listener;
	}
	
	interface ProgresBarFragmentCancelListener
	{
		public void on_cancel_progress();
	}
	
	
	private void print(String msg)
	{
		Toast.makeText(context,msg,Toast.LENGTH_SHORT).show();
	}
}
