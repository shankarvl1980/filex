package svl.kadatha.filex;
import android.app.*;
import android.content.*;
import android.media.*;
import android.media.session.*;
import android.net.*;
import android.os.*;
import android.provider.*;
import android.support.v4.app.*;
import android.support.v4.content.*;
import android.support.v4.media.session.*;
import android.telephony.*;
import android.widget.*;
import java.io.*;
import java.util.*;



public class AudioPlayerService extends Service implements MediaPlayer.OnCompletionListener, MediaPlayer.OnErrorListener,MediaPlayer.OnSeekCompleteListener,
MediaPlayer.OnInfoListener, MediaPlayer.OnBufferingUpdateListener, MediaPlayer.OnPreparedListener,AudioManager.OnAudioFocusChangeListener
{
	private Binder binder=new AudioBinder();
	public MediaPlayer MP;
	public boolean prepared,playmode,stopped,completed;
	public int total_duration;
	private MediaPlayerServicePrepareListener mediaPlayerServicePrepareListener;
	private AudioManager audio_manager;
	private boolean ongoingcall=false;
	private TelephonyManager telephonyManager;
	private LocalBroadcastManager localBroadcastManager;
	static List<AudioPOJO> AUDIO_QUEUED_ARRAY=new ArrayList<>();
	static int CURRENT_PLAY_NUMBER;
	private final int notification_id=808;


	public static final String ACTION_PLAY = "action_play";
	public static final String ACTION_PAUSE = "action_pause";
	public static final String ACTION_REWIND = "action_rewind";
	public static final String ACTION_FAST_FORWARD = "action_fast_foward";

	public static final String ACTION_STOP = "action_stop";

	public AudioPOJO current_audio;
	
	
	private NotificationPanel nPanel;
	
	
	@Override
	public void onCreate()
	{
		// TODO: Implement this method
		super.onCreate();
		localBroadcastManager=LocalBroadcastManager.getInstance(this);
		telephonyManager=(TelephonyManager)getSystemService(Context.TELEPHONY_SERVICE);
		telephonyManager.listen(new PhoneStateListener()
			{
				public void onCallStateChanged(int state, String phonenumber)
				{
					switch(state)
					{

						case TelephonyManager.CALL_STATE_OFFHOOK:
						case TelephonyManager.CALL_STATE_RINGING:
							if(MP!=null)
							{
								pause();
								ongoingcall=true;
							}
							break;

						case TelephonyManager.CALL_STATE_IDLE:
							if(ongoingcall)
							{
								ongoingcall=false;
								MP.start();

							}

					}
				}
			},PhoneStateListener.LISTEN_CALL_STATE);


	}
	
	@Override
	public int onStartCommand(Intent intent, int flags, int startId)
	{
		// TODO: Implement this method
		Uri data=intent.getData();
	
		if(request_focus()==false)
		{
			stopSelf();
		}
		
		if(data!=null)
		{
			initMediaPlayer(data);
			nPanel=new NotificationPanel(this);
			startForeground(notification_id,nPanel.get_notification());

		}

		String action = intent.getStringExtra("DO");
		if(action!=null)
		{
			if (action.equals("previous")) 
			{
				goto_previous();

			} 
			else if (action.equals("start_pause")) 
			{


				if(prepared && !playmode)
				{

					start();


				}
				else if(prepared && playmode)
				{
					pause();


				}

			}
			else if(action.equals("next"))
			{
				goto_next();
			}
			else if(action.equals("cancel"))
			{
				stop();

			}
			send_broadcast(action);
		}
	
	
		return START_NOT_STICKY;
	}

	
	

	private void initMediaPlayer(Uri data)
	{
		if(MP!=null)
		{
			MP.stop();
			MP.reset();
		}
		MP=new MediaPlayer();
		MP.setOnCompletionListener(this);
		MP.setOnErrorListener(this);
		MP.setOnBufferingUpdateListener(this);
		MP.setOnSeekCompleteListener(this);
		MP.setOnInfoListener(this);
		MP.setOnPreparedListener(this);
		MP.setAudioStreamType(AudioManager.STREAM_MUSIC);
		
		try
		{
			MP.setDataSource(this,data);
		}
		catch(IOException e)
		{
			stop();
			return;
		}
		MP.prepareAsync();
		
	}
	
	
	public void start()
	{
		if(prepared)
		{
			
				if(request_focus())
				{
					MP.start();
					playmode=true;
					completed=false;
					nPanel=new NotificationPanel(this);
					nPanel.notify_notification();
				}
			
		}
	}
	
	public void pause()
	{				
		if(prepared)
		{
			MP.pause();
			playmode=false;
			nPanel=new NotificationPanel(this);
			nPanel.notify_notification();
			
		}
	
	}
	
	public void goto_next()
	{
		
		CURRENT_PLAY_NUMBER++;
		if(AUDIO_QUEUED_ARRAY.size()==0 || CURRENT_PLAY_NUMBER>AUDIO_QUEUED_ARRAY.size()-1 || CURRENT_PLAY_NUMBER<0)
		{
			CURRENT_PLAY_NUMBER=AUDIO_QUEUED_ARRAY.size()-1;
			return;
		}
		
		
		current_audio=AUDIO_QUEUED_ARRAY.get(CURRENT_PLAY_NUMBER);
		AudioPlayerActivity.AUDIO_FILE=new File(current_audio.getData());
		 
		
		Uri data=null;
		File f=new File(current_audio.getData());
		if(f.exists())
		{
			data=Uri.fromFile(f);
		}
		else
		{
			
			data=null;
		}
	
		initMediaPlayer(data);
		send_broadcast("next");
		
		 
	}
	

	public void goto_previous()
	{
		CURRENT_PLAY_NUMBER--;
		if(AudioPlayerService.AUDIO_QUEUED_ARRAY.size()==0 || CURRENT_PLAY_NUMBER<0 || CURRENT_PLAY_NUMBER> AUDIO_QUEUED_ARRAY.size()-1)
		{
			CURRENT_PLAY_NUMBER=0;
			return;
		}
		
		current_audio=AudioPlayerService.AUDIO_QUEUED_ARRAY.get(CURRENT_PLAY_NUMBER);
		AudioPlayerActivity.AUDIO_FILE=new File(current_audio.getData());
		
		Uri data=null;
		File f=new File(current_audio.getData());
		if(f.exists())
		{
			data=Uri.fromFile(f);
		}
		else
		{

			data=null;
		}
		
		initMediaPlayer(data);
		send_broadcast("previous");

	}
	
	
	public void seek_to(int counter)
	{
		if(prepared)
		{
			MP.seekTo(counter);
		}
		
	}
	
	public void move_backward()
	{
		if(prepared)
		{
			int backward_pos=MP.getCurrentPosition()-5000;
			MP.seekTo(backward_pos<0 ? 0 : backward_pos);
		}
		
	}
	
	public void move_forward()
	{
		
		if(prepared)
		{
			int forward_pos=MP.getCurrentPosition()+5000;
			MP.seekTo(forward_pos>total_duration ? total_duration : forward_pos);
		
		}
	
	}
	
	public int get_duration()
	{
		return total_duration;
	}
	
	public int get_current_position()
	{
		if(prepared)
		{
			return MP.getCurrentPosition();
		}
		return 0;
	}
	
	public boolean is_playing()
	{
		if(prepared)
		{
			return MP.isPlaying();
		}
		return false;
	}
	
	public void stop()
	{
		if(MP!=null)
		{
			MP.stop();
			MP.reset();
			MP.release();
			
		}
		MP=null;
		stopped=true;
		prepared=false;
		send_broadcast("stop");
		stopForeground(true);
		stopSelf();
	
	}
	
	private boolean request_focus()
	{
		audio_manager=(AudioManager)getSystemService(Context.AUDIO_SERVICE);
		int result =audio_manager.requestAudioFocus(this,AudioManager.STREAM_MUSIC,AudioManager.AUDIOFOCUS_GAIN);
		if(result==AudioManager.AUDIOFOCUS_REQUEST_GRANTED)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	private void send_broadcast(String action)
	{
		Intent broadcast_intent=new Intent();
		broadcast_intent.setAction(AudioPlayerActivity.AUDIO_NOTIFICATION_INTENT_ACTION);
		broadcast_intent.putExtra("action",action);
		localBroadcastManager.sendBroadcast(broadcast_intent);
	}
	
	private boolean removeAudioFocus()
	{
		return AudioManager.AUDIOFOCUS_REQUEST_GRANTED==audio_manager.abandonAudioFocus(this);
	}

	@Override
	public void onPrepared(MediaPlayer p1)
	{
		// TODO: Implement this method
		prepared=true;
		stopped=false;
		total_duration=MP.getDuration();
		if(mediaPlayerServicePrepareListener!=null)
		{
			mediaPlayerServicePrepareListener.onMediaPrepare();
		}
		start();
	}


	@Override
	public void onSeekComplete(MediaPlayer p1)
	{
		// TODO: Implement this method

	}

	@Override
	public void onAudioFocusChange(int focusState)
	{
		// TODO: Implement this method
		switch(focusState)
		{
			case AudioManager.AUDIOFOCUS_GAIN:
				
				if(MP!=null)
				{
					MP.setVolume(1f,1f);
				}
				break;
			
			
			
			case AudioManager.AUDIOFOCUS_LOSS:
				if(MP!=null)
				{
					pause();
				}
				send_broadcast("start_pause");
				break;
			
			case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT:
				if(MP!=null)
				{
					pause();
				}
				break;
			case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK:
				if(MP!=null)
				{
					MP.setVolume(0.2f,0.2f);
				}
				break;
			
		}
		
	}


	
	@Override
	public void onBufferingUpdate(MediaPlayer p1, int p2)
	{
		// TODO: Implement this method
	}

	@Override
	public boolean onError(MediaPlayer p1, int p2, int p3)
	{
		// TODO: Implement this method
		switch(p2)
		{
			case MediaPlayer.MEDIA_ERROR_NOT_VALID_FOR_PROGRESSIVE_PLAYBACK:
				break;
			
			case MediaPlayer.MEDIA_ERROR_SERVER_DIED:
				break;
			
			case MediaPlayer.MEDIA_ERROR_UNKNOWN:
				
				break;
			
		}
		stop();
		return false;
	}

	@Override
	public void onCompletion(MediaPlayer p1)
	{
		// TODO: Implement this method
		completed=true;
		playmode=false;
		nPanel=new NotificationPanel(this);
		nPanel.notify_notification();
		goto_next();

	}

	@Override
	public boolean onInfo(MediaPlayer p1, int p2, int p3)
	{
		// TODO: Implement this method
		return false;
	}

	
	@Override
	public IBinder onBind(Intent p1)
	{
		// TODO: Implement this method
		if(binder==null)
		{
			binder=new AudioBinder();
		}

		return binder;
	}

	


	@Override
	public void onDestroy()
	{
		// TODO: Implement this method
		
		super.onDestroy();
		
	
		if(MP!=null)
		{
			stop();
		}
		removeAudioFocus();
		
	}
	
	
	
	class AudioBinder extends Binder
	{
		public AudioPlayerService getService()
		{
			return AudioPlayerService.this;
		}
	}

	interface MediaPlayerServicePrepareListener
	{
		public void onMediaPrepare();
	}
	
	public void setMediaPlayerPrepareListener(MediaPlayerServicePrepareListener listener)
	{
		mediaPlayerServicePrepareListener=listener;
	}

	public class NotificationPanel 
	{

		private Context parent;
		private android.app.NotificationManager nManager;
		private android.support.v4.app.NotificationCompat.Builder nBuilder;
		private NotificationChannel notification_channel;
		private RemoteViews remoteView;

		public NotificationPanel(Context parent) 
		{
			// TODO Auto-generated constructor stub
			this.parent = parent;
			nManager = (android.app.NotificationManager) parent.getSystemService(Context.NOTIFICATION_SERVICE);
			if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.O)
			{
				
				notification_channel=new NotificationChannel("asc","notification_channel",2);
				notification_channel.enableLights(true);
				notification_channel.setDescription("nc");
				nManager.createNotificationChannel(notification_channel);
				nBuilder = new android.support.v4.app.NotificationCompat.Builder(parent,"asc");
				nBuilder.setContentTitle("Explorer")
					.setSmallIcon(R.drawable.ic_launcher)
					.setAutoCancel(true)
					.setStyle(new NotificationCompat.DecoratedCustomViewStyle());
			}
			else
			{
				nBuilder = new android.support.v4.app.NotificationCompat.Builder(parent);
				nBuilder.setContentTitle("Explorer")
					.setSmallIcon(R.drawable.ic_launcher)
					.setAutoCancel(true)
					.setStyle(new NotificationCompat.DecoratedCustomViewStyle());
			}
			

			

			remoteView = new RemoteViews(parent.getPackageName(), R.layout.audio_notification_view);
			
			if(playmode)
			{
				remoteView.setImageViewResource(R.id.audio_notification_play_pause,R.drawable.pause_icon);
			}
			else
			{
				remoteView.setImageViewResource(R.id.audio_notification_play_pause,R.drawable.play_icon);
			}
			String name="";
			if(current_audio!=null)
			{
				name=current_audio.getTitle();
			}
			else if(AudioPlayerActivity.AUDIO_FILE!=null)
			{
				name=AudioPlayerActivity.AUDIO_FILE.getName();
			}
	
			remoteView.setTextViewText(R.id.audio_notification_audio_name,name);
			
			//set the button listeners
			setListeners(remoteView);
			nBuilder.setCustomBigContentView(remoteView);
		}
		
		public Notification get_notification()
		{
			return nBuilder.build();
		}
		public void notify_notification()
		{

			
			nManager.notify(notification_id, nBuilder.build());

		}

		public void setListeners(RemoteViews view)
		{
			//listener 1
			Intent previous = new Intent(parent,AudioPlayerService.class);
			previous.putExtra("DO", "previous");
			PendingIntent prev = PendingIntent.getService(parent, 0, previous, PendingIntent.FLAG_CANCEL_CURRENT);
			view.setOnClickPendingIntent(R.id.audio_notification_previous, prev);


			//listener 2
			Intent pause = new Intent(parent, AudioPlayerService.class);
			pause.putExtra("DO", "start_pause");
			PendingIntent start = PendingIntent.getService(parent, 1, pause, PendingIntent.FLAG_CANCEL_CURRENT);
			view.setOnClickPendingIntent(R.id.audio_notification_play_pause, start);

			//listener 3
			Intent next = new Intent(parent, AudioPlayerService.class);
			next.putExtra("DO", "next");
			PendingIntent nxt = PendingIntent.getService(parent, 2, next, PendingIntent.FLAG_CANCEL_CURRENT);
			view.setOnClickPendingIntent(R.id.audio_notification_next, nxt);
			
			//listener 4
			Intent cancel = new Intent(parent, AudioPlayerService.class);
			cancel.putExtra("DO", "cancel");
			PendingIntent close = PendingIntent.getService(parent, 3, cancel, PendingIntent.FLAG_CANCEL_CURRENT);
			view.setOnClickPendingIntent(R.id.audio_notification_close, close);
			
			Intent back=new Intent(parent, AudioPlayerActivity.class);
			PendingIntent bck=PendingIntent.getActivity(parent,4,back,PendingIntent.FLAG_CANCEL_CURRENT);
			view.setOnClickPendingIntent(R.id.audio_notification_back,bck);

		}

		public void notificationCancel() 
		{
			nManager.cancel(notification_id);
		}
		
	}
	



	public enum PlaybackStatus
	{
		PLAYING,
		PAUSED
		}
	
	
}
