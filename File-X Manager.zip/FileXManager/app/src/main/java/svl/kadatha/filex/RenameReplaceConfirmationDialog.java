package svl.kadatha.filex;
import android.widget.*;
import android.os.*;
import android.view.*;
import android.widget.TableRow.*;
import android.graphics.drawable.*;
import android.graphics.*;
import java.io.*;
import android.support.v7.app.*;
import android.content.*;

public class RenameReplaceConfirmationDialog extends android.support.v4.app.DialogFragment
{
	
	private TextView confirmation_message_textview;
	private Button yes_button,no_button;
	private String rename_file_name;
	private RenameReplaceDialogListener renameDialogListener;
	private ViewGroup buttons_layout;
	private Context context;


	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		// TODO: Implement this method
		super.onCreate(savedInstanceState);
		setRetainInstance(true);
		setCancelable(false);
		Bundle bundle=getArguments();
		rename_file_name=bundle.getString("rename_file_name");
	
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
	{
		// TODO: Implement this method
		//return super.onCreateView(inflater, container, savedInstanceState);
		context=getContext();
		View v=inflater.inflate(R.layout.fragment_archivereplace_confirmation,container,false);
		confirmation_message_textview=v.findViewById(R.id.dialog_fragment_archive_replace_message);
		buttons_layout=v.findViewById(R.id.fragment_archivereplace_confirmation_button_layout);
		buttons_layout.addView(new EquallyDistributedChildrenLayout(context,2));
		yes_button=buttons_layout.findViewById(R.id.first_button);
		yes_button.setText("Yes");
		no_button=buttons_layout.findViewById(R.id.second_button);
		no_button.setText("No");
		confirmation_message_textview.setText("A file with same name already exists. Do you want to overwrite it? '"+rename_file_name+"'");
		
		yes_button.setOnClickListener(new View.OnClickListener()
			{
				public void onClick(View v)
				{
					
					if(renameDialogListener!=null)
					{
						renameDialogListener.rename_file();
					}
					dismissAllowingStateLoss();


				}

			});

		no_button.setOnClickListener(new View.OnClickListener()
			{
				public void onClick(View v)
				{
					dismissAllowingStateLoss();
				}

			});
		return v;
	}

	@Override
	public void onResume()
	{
		// TODO: Implement this method
		
		super.onResume();
		Window window=getDialog().getWindow();
		window.setLayout(Global.DIALOG_WIDTH,LayoutParams.WRAP_CONTENT);
		window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
		
	}



	@Override
	public void onDestroyView() {
		if (getDialog() != null && getRetainInstance()) {
			getDialog().setDismissMessage(null);
		}
		super.onDestroyView();

	}
	public void setRenameReplaceDialogListener(RenameReplaceDialogListener listener)
	{
		renameDialogListener=listener;
	}

	interface RenameReplaceDialogListener
	{

		public void rename_file();
	}
	
}
