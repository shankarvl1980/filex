package svl.kadatha.filex;
import android.os.*;
import android.view.*;
import android.widget.*;
import java.io.*;
import android.content.*;
import android.widget.AbsListView.*;
import android.view.inputmethod.*;
import android.graphics.drawable.*;
import android.graphics.*;
import android.net.*;
import java.util.*;

public class CreateFileDialog extends android.support.v4.app.DialogFragment
{
	private TextView dialog_heading_textview,file_label_textview,no_of_files_textview,files_size_textview;
	private EditText new_file_name_edittext;
	private Button okbutton,cancelbutton;
	private DetailFragment df;
	private int file_type;
	private Context context;
	private InputMethodManager imm;
	private final int request_code=56;
	private boolean permission_requested;
	private String baseFolder="";
	private Uri uri;
	private ViewGroup buttons_layout;
	
	
	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		// TODO: Implement this method
		super.onCreate(savedInstanceState);
		file_type=getArguments().getInt("file_type");
		this.setRetainInstance(true);
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
	{
		// TODO: Implement this method
		
		context=getContext();
		View v=inflater.inflate(R.layout.fragment_create_rename_delete,container,false);
		df=(DetailFragment)MainActivity.FM.findFragmentById(R.id.detail_fragment);
		dialog_heading_textview=v.findViewById(R.id.dialog_fragment_rename_delete_title);
		file_label_textview=v.findViewById(R.id.dialog_fragment_rename_delete_message);
		new_file_name_edittext=v.findViewById(R.id.dialog_fragment_rename_delete_newfilename);
		no_of_files_textview=v.findViewById(R.id.dialog_fragment_rename_delete_no_of_files);
		files_size_textview=v.findViewById(R.id.dialog_fragment_rename_delete_total_size);
		no_of_files_textview.setVisibility(View.GONE);
		files_size_textview.setVisibility(View.GONE);
		buttons_layout=v.findViewById(R.id.fragment_create_rename_delete_button_layout);
		buttons_layout.addView(new EquallyDistributedChildrenLayout(context,2));
		okbutton=buttons_layout.findViewById(R.id.first_button);
		okbutton.setText("OK");
		cancelbutton=buttons_layout.findViewById(R.id.second_button);
		cancelbutton.setText("Cancel");
		
		imm=(InputMethodManager)context.getSystemService(Context.INPUT_METHOD_SERVICE);
		if(file_type==0)
		{
			dialog_heading_textview.setText("Enter file name");
			file_label_textview.setText("File Name:");
		}
		else
		{
			dialog_heading_textview.setText("Enter folder name");
			file_label_textview.setText("Folder Name:");
		}
		okbutton.setOnClickListener(new View.OnClickListener()
		{
			public void onClick(View v)
			{
					
					
				String new_name=new_file_name_edittext.getText().toString().trim();
				if(new_name.equals("") || new_name.equals(null))
				{
					print("Name field cannot be empty");
					return;
				}
				if(CheckStringForSpecialCharacters.whetherStringContains(new_name))
				{
					print("Avoid name involving characters '\\*:?/'");
					return;
				}

				String new_file_name=df.getTag()+File.separator+new_name;
				File file=new File(new_file_name);
				if(file.exists())
				{
					print("'"+new_name+"' can not be created. A file with the same name already exists");
					imm.hideSoftInputFromWindow(new_file_name_edittext.getWindowToken(),0);
					dismissAllowingStateLoss();
					return;
				}
				else if(!new File(df.getTag()).exists())
				{
					print("'"+new_name+"' can not be created.");
					imm.hideSoftInputFromWindow(new_file_name_edittext.getWindowToken(),0);
					dismissAllowingStateLoss();
					return;
				}
				boolean isWritable=FileUtil.isWritable(file);
				boolean file_created=false;
				if(file_type==0)
				{
							
					if(isWritable)
					{
						file_created=FileUtil.createNativeNewFile(file);
					}
					else
					{
						for(Map.Entry<Uri,String> entry : Global.URI_STRING_HASHMAP.entrySet())
						{
							if(df.getTag().startsWith(entry.getValue()))
							{
									
								baseFolder=entry.getValue();
								uri=entry.getKey();
								break;
							}
						}
								
							
						if(baseFolder.equals(""))
						{
									
							SAFPermissionHelperDialog safpermissionhelper=new SAFPermissionHelperDialog();
							safpermissionhelper.set_safpermissionhelperlistener(new SAFPermissionHelperDialog.SafPermissionHelperListener()
							{
								public void onOKBtnClicked()
								{
									checkSAFPermission();
								}

								public void onCancelBtnClicked()
								{
									dismissAllowingStateLoss();
								}
							});
							safpermissionhelper.show(MainActivity.FM,"saf_permission_dialog");
							permission_requested=true;
							file_created=false;
						}
						else
						{
									
							file_created=FileUtil.createSAFNewFile(file,context,uri,baseFolder);
						}
					}
							
							
				}
				else if(file_type==1)
				{
					if(isWritable)
					{
						file_created=FileUtil.mkdirNative(file);
					}
					else
					{
						for(Map.Entry<Uri,String> entry : Global.URI_STRING_HASHMAP.entrySet())
						{
							if(df.getTag().startsWith(entry.getValue()))
							{
								baseFolder=entry.getValue();
								uri=entry.getKey();
								break;
							}
						}
					
								
								
						if(baseFolder.equals(""))
						{
							SAFPermissionHelperDialog safpermissionhelper=new SAFPermissionHelperDialog();
							safpermissionhelper.set_safpermissionhelperlistener(new SAFPermissionHelperDialog.SafPermissionHelperListener()
							{
								public void onOKBtnClicked()
								{
									checkSAFPermission();
								}

								public void onCancelBtnClicked()
								{
									dismissAllowingStateLoss();
								}
							});
							safpermissionhelper.show(MainActivity.FM,"saf_permission_dialog");
							permission_requested=true;
							file_created=false;
						}
						else
						{
									
							file_created=FileUtil.mkdirSAF(file,context,uri,baseFolder);
						}
					}
				}
								
			
				if(file_created)
				{

					df.adapter.refresh(file);
					print("'"+new_name+ "' created");

							//View v=frag.linearLayoutManager.findViewByPosition(indexOfFileInserted+1);
							//setAnimation(v);

				}
				else
				{
					print("'"+new_name+"' could not be created.");
				}

				imm.hideSoftInputFromWindow(new_file_name_edittext.getWindowToken(),0);
				if(!permission_requested)
				{
					dismissAllowingStateLoss();
				}
				
					
			}	
				

		});
			
		cancelbutton.setOnClickListener(new View.OnClickListener()
		{
			public void onClick(View v)
			{
				imm.hideSoftInputFromWindow(new_file_name_edittext.getWindowToken(),0);
				dismissAllowingStateLoss();
			}
				
				
		});
			
			
		return v;
	}

	@Override
	public void onResume()
	{
		// TODO: Implement this method
		super.onResume();
		Window window=getDialog().getWindow();
		window.setLayout(Global.DIALOG_WIDTH,LayoutParams.WRAP_CONTENT);
		window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
		new_file_name_edittext.requestFocus();
		imm.toggleSoftInput(InputMethodManager.SHOW_FORCED,0);
	
	}

	
	public void checkSAFPermission()
	{
		Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
		startActivityForResult(intent, request_code);
		
	}

	// @TargetApi(Build.VERSION_CODES.LOLLIPOP)
	@Override
	public final void onActivityResult(final int requestCode, final int resultCode, final Intent resultData) 
	{
	 
		if (requestCode == this.request_code && resultCode==getActivity().RESULT_OK) 
		{
			Uri treeUri = null;
			// Get Uri from Storage Access Framework.
			treeUri = resultData.getData();
			String uri_file_path=FileUtil.getFullPathFromTreeUri(treeUri,context);
			Iterator<Map.Entry<Uri,String>> iterator=Global.URI_STRING_HASHMAP.entrySet().iterator();
			while(iterator.hasNext())
			{
				Map.Entry<Uri,String> entry=iterator.next();
				if(entry.getValue().startsWith(uri_file_path))
				{
					iterator.remove();
				}
			}


			Global.URI_STRING_HASHMAP.put(treeUri,uri_file_path);


			// Persist access permissions.
			final int takeFlags = resultData.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
			context.getContentResolver().takePersistableUriPermission(treeUri, takeFlags);
			
			permission_requested=false;
			okbutton.callOnClick();

		}
		
	}

	@Override
	public void onCancel(DialogInterface dialog)
	{
		// TODO: Implement this method
		
		imm.hideSoftInputFromWindow(new_file_name_edittext.getWindowToken(),0);
		super.onCancel(dialog);
	}
	
	

	@Override
	public void onDismiss(DialogInterface dialog)
	{
		// TODO: Implement this method
		imm.hideSoftInputFromWindow(new_file_name_edittext.getWindowToken(),0);
		super.onDismiss(dialog);
		
	}
	

	@Override
	public void onDestroyView() 
	{
		if (getDialog() != null && getRetainInstance()) 
		{
			getDialog().setDismissMessage(null);
		}
		super.onDestroyView();
	}

	private void print(String msg)
	{
		Toast.makeText(context,msg,Toast.LENGTH_SHORT).show();
	}
	
}
