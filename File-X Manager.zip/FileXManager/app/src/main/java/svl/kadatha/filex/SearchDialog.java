package svl.kadatha.filex;
import android.support.v4.app.*;
import android.os.*;
import android.view.*;
import android.widget.Gallery.*;
import android.graphics.drawable.*;
import android.graphics.*;
import android.widget.*;
import android.content.*;
import android.support.v7.widget.*;
import java.util.*;
import android.util.*;

public class SearchDialog extends android.support.v4.app.DialogFragment
{
	private EditText search_file_name;
	private CheckBox wholeword_checkbox,casesensitive_checkbox,regex_checkbox;
	private RadioGroup rg;
	private RadioButton file_rb,dir_rb,file_dir_rb;;
	private RecyclerView search_recyclerview;
	private Button ok_button,cancel_button;
	private SparseBooleanArray dir_selected_booleanarray=new SparseBooleanArray();
	private List<FilePOJO> selected_search_dir_list=new ArrayList<>();
	private SearchRecyclerViewAdapter searchRecyclerViewAdapter;
	private ViewGroup buttons_layout;
	private Context context;
	private List<FilePOJO> storage_list=new ArrayList<>();
	
	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		// TODO: Implement this method
		super.onCreate(savedInstanceState);
		
		setRetainInstance(true);
		for(FilePOJO filepojo:MainActivity.STORAGE_DIR)
		{
			if(!filepojo.getPath().equals("/"))
			{
				storage_list.add(filepojo);
			}
		}
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
	{
		// TODO: Implement this method
		
		context=getContext();
		View v=inflater.inflate(R.layout.fragment_search_parameters,container,false);
		search_file_name=v.findViewById(R.id.dialog_fragment_search_file_edittext);
		wholeword_checkbox=v.findViewById(R.id.dialog_fragment_search_wholeword_checkbox);
		casesensitive_checkbox=v.findViewById(R.id.dialog_fragment_search_casesensitive_checkbox);
		regex_checkbox=v.findViewById(R.id.dialog_fragment_search_regex_checkbox);
		rg=v.findViewById(R.id.dialog_fragment_search_rg);
		rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener()
		{
			public void onCheckedChanged(RadioGroup p1, int p2)
			{
				switch(p2)
				{
					case R.id.dialog_search_rb_filetype:
						DetailFragment.SEARCH_FILE_TYPE="f";
						break;
					case R.id.dialog_search_rb_foldertype:
						DetailFragment.SEARCH_FILE_TYPE="d";
						break;
					case R.id.dialog_search_rb_filefoldertype:
						DetailFragment.SEARCH_FILE_TYPE="fd";
						break;
				}
			}
		});
		file_rb=v.findViewById(R.id.dialog_search_rb_filetype);
		dir_rb=v.findViewById(R.id.dialog_search_rb_foldertype);
		file_dir_rb=v.findViewById(R.id.dialog_search_rb_filefoldertype);
		if(DetailFragment.SEARCH_FILE_TYPE!=null)
		{
			switch(DetailFragment.SEARCH_FILE_TYPE)
			{
				case "d":
					dir_rb.setChecked(true);
					break;
				case "fd":
					file_dir_rb.setChecked(true);
					break;
				default:
					file_rb.setChecked(true);
					break;

			}
		}
		else
		{
			file_rb.setChecked(true);
		}
		
		search_recyclerview=v.findViewById(R.id.dialog_fragment_search_storage_dir_recyclerview);
		search_recyclerview.addItemDecoration(MainActivity.DIVIDERITEMDECORATION);
		searchRecyclerViewAdapter=new SearchRecyclerViewAdapter(storage_list);
		search_recyclerview.setAdapter(searchRecyclerViewAdapter);
		search_recyclerview.setLayoutManager(new LinearLayoutManager(context));
		buttons_layout=v.findViewById(R.id.fragment_search_parameters_button_layout);
		buttons_layout.addView(new EquallyDistributedChildrenLayout(context,2));
		ok_button=buttons_layout.findViewById(R.id.first_button);
		ok_button.setText("OK");
		ok_button.setOnClickListener(new View.OnClickListener()
		{
			public void onClick(View v)
			{

				//String f_n,f_t;
				if(search_file_name.getText().toString().trim().equals(""))
				{
					print("Enter name");
					return;
				}
				else
				{
					DetailFragment.SEARCH_FILE_NAME=search_file_name.getText().toString().trim();
				}
				if(selected_search_dir_list.size()==0)
				{
					print("Select directory to be searched in");
					return;
				}
				else
				{
					DetailFragment.SEARCH_IN_DIR=new ArrayList<>();
					for(FilePOJO f:selected_search_dir_list)
					{
						if(!DetailFragment.SEARCH_IN_DIR.contains(f))
						{
							DetailFragment.SEARCH_IN_DIR.add(f);
						}
						
					}
					
				}
				DetailFragment.SEARCH_WHOLEWORD=wholeword_checkbox.isChecked();
				DetailFragment.SEARCH_CASESENSITIVE=casesensitive_checkbox.isChecked();
				DetailFragment.SEARCH_REGEX=regex_checkbox.isChecked();
				/*
				if(rg.getCheckedRadioButtonId()==R.id.dialog_search_rb_filetype)
				{
					DetailFragment.SEARCH_FILE_TYPE="f";
					
				}
				else if(rg.getCheckedRadioButtonId()==R.id.dialog_search_rb_foldertype)
				{
					DetailFragment.SEARCH_FILE_TYPE="d";
				}
				else
				{
					DetailFragment.SEARCH_FILE_TYPE="fd";
				}
				*/
				((MainActivity)context).createFragmentTransaction(DetailFragment.SEARCH_RESULT);
				
				dismissAllowingStateLoss();
			}
		});
		
		cancel_button=buttons_layout.findViewById(R.id.second_button);
		cancel_button.setText("Cancel");
		cancel_button.setOnClickListener(new View.OnClickListener()
		{
			public void onClick(View v)
			{
				dismissAllowingStateLoss();
			}
		});
		USBBroadcastReceiver.USBATTACHDETACHLISTENER=new USBBroadcastReceiver.USBAttachDetachListener()
		{
			public void onUSBAttachDetach()
			{
				searchRecyclerViewAdapter.notifyDataSetChanged();
			}
		};
		return v;
	}

	@Override
	public void onResume()
	{
		// TODO: Implement this method
		super.onResume();
		Window window=getDialog().getWindow();
		window.setLayout(Global.DIALOG_WIDTH,LayoutParams.WRAP_CONTENT);
		window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
		
	}

	@Override
	public void onDestroyView() 
	{
		if (getDialog() != null && getRetainInstance()) 
		{
			getDialog().setDismissMessage(null);
		}
		super.onDestroyView();
	}

	private void print(String msg)
	{
		Toast.makeText(context,msg,Toast.LENGTH_SHORT).show();
	}
	
	public class SearchRecyclerViewAdapter extends RecyclerView.Adapter<SearchRecyclerViewAdapter.VH>
	{

		List<FilePOJO> storage_list=new ArrayList<>();
		
		SearchRecyclerViewAdapter(List<FilePOJO> storage_list)
		{
			this.storage_list=storage_list;
		}
		

		class VH extends RecyclerView.ViewHolder
		{
			View v;
			ImageView iv;
			TextView tv;
			CheckBox cb;
			int pos;
			VH(View vi)
			{
				super(vi);
				this.v=vi;
				iv=v.findViewById(R.id.image_search_storage_dir);
				tv=v.findViewById(R.id.text_search_storage_dir_name);
				cb=v.findViewById(R.id.checkbox_search_storage);

				cb.setOnCheckedChangeListener(new CheckBox.OnCheckedChangeListener()
				{
					public void onCheckedChanged(CompoundButton p1, boolean p2)
					{
						pos=getAdapterPosition();
						if(p2)
						{
							dir_selected_booleanarray.put(pos,p2);
							selected_search_dir_list.add(storage_list.get(pos));
						}
						else
						{
							dir_selected_booleanarray.delete(pos);
							selected_search_dir_list.remove(storage_list.get(pos));

						}

					}

				});
				

			}

		}
		@Override
		public SearchDialog.SearchRecyclerViewAdapter.VH onCreateViewHolder(ViewGroup p1, int p2)
		{
			// TODO: Implement this method
			View itemview=LayoutInflater.from(p1.getContext()).inflate(R.layout.search_storage_dir_recyclerview_layout,p1,false);
			return new VH(itemview);
		
		}

		@Override
		public void onBindViewHolder(SearchDialog.SearchRecyclerViewAdapter.VH p1, int p2)
		{
			// TODO: Implement this method
			
			//if(!storage_list.get(p2).getPath().equals("/"))
			{
				//p1.iv.setImageResource(R.drawable.device_icon);
				//p1.tv.setText("Root Directory");

			//}
			//else
			//{
				p1.iv.setImageResource(R.drawable.sdcard_icon);
				p1.tv.setText(storage_list.get(p2).getName());
				if(dir_selected_booleanarray.size()==0)
				{
					p1.cb.setChecked(true);
				}
			}
		
			p1.cb.setChecked(dir_selected_booleanarray.get(p2,false));
			
		}
		
		@Override
		public int getItemCount()
		{
			// TODO: Implement this method
			return storage_list.size();
		}

	}
	
}
