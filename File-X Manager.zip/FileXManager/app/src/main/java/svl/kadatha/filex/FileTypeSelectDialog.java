package svl.kadatha.filex;
import android.support.v4.app.*;
import android.os.*;
import android.view.*;
import android.content.*;
import android.graphics.drawable.*;
import android.graphics.*;
import android.support.v7.widget.*;
import android.widget.*;
import java.util.*;


public class FileTypeSelectDialog extends DialogFragment
{
	private Context context;
	private ViewGroup button_layout;
	private RecyclerView file_type_recyclerview;
	private Button cancel;
	private FileTypeSelectListener fileTypeSelectListener;
	private LinkedHashMap<String,String> file_type_set=new LinkedHashMap<>();
	private List<String> file_type_list;
	private List<String> file_mime_list;
	
	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		// TODO: Implement this method
		super.onCreate(savedInstanceState);
		setRetainInstance(true);
		file_type_set.put("Text","text/*");
		file_type_set.put("Image","image/*");
		file_type_set.put("Audio","audio/*");
		file_type_set.put("Video","video/*");
		file_type_set.put("PDF","application/pdf");
		file_type_set.put("MS Word Document","application/msword");
		file_type_set.put("MS Excel","application/vnd.ms-excel");
		file_type_set.put("MS Powerpoint","application/vnd.ms-powerpoint");
		
		file_type_list=new ArrayList<>(file_type_set.keySet());
		file_mime_list=new ArrayList<>(file_type_set.values());
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
	{
		// TODO: Implement this method
		context=getContext();
		View v=inflater.inflate(R.layout.fragment_select_file_type,container,false);
		file_type_recyclerview=v.findViewById(R.id.fragment_file_type_RecyclerView);
		file_type_recyclerview.addItemDecoration(MainActivity.DIVIDERITEMDECORATION);
		file_type_recyclerview.setLayoutManager(new LinearLayoutManager(context));
		file_type_recyclerview.setAdapter(new FileTypeRecyclerViewAdapter());
		
		button_layout=v.findViewById(R.id.fragment_file_type_button_layout);
		button_layout.addView(new EquallyDistributedChildrenLayout(context,1));
		cancel=button_layout.findViewById(R.id.first_button);
		cancel.setText("Cancel");
		cancel.setOnClickListener(new View.OnClickListener()
		{
			public void onClick(View p1)
			{
				dismissAllowingStateLoss();
			}
		});
		return v;
	}
	

	@Override
	public void onResume()
	{
		// TODO: Implement this method
		super.onResume();
		Window window=getDialog().getWindow();
		WindowManager.LayoutParams params=window.getAttributes();
		int height=params.height;
		if(context.getResources().getBoolean(R.bool.is_land))
		{
			window.setLayout(Global.DIALOG_WIDTH,Global.DIALOG_WIDTH);

		}
		else
		{
			window.setLayout(Global.DIALOG_WIDTH,Math.min(height,Global.DIALOG_HEIGHT));
		
		}

		window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

	}

	@Override
	public void onDestroyView() {
		if (getDialog() != null && getRetainInstance()) {
			getDialog().setDismissMessage(null);
		}
		super.onDestroyView();

	}
	
	private class FileTypeRecyclerViewAdapter extends RecyclerView.Adapter<FileTypeRecyclerViewAdapter.VH>
	{

		@Override
		public FileTypeSelectDialog.FileTypeRecyclerViewAdapter.VH onCreateViewHolder(ViewGroup p1, int p2)
		{
			// TODO: Implement this method
			View v=LayoutInflater.from(context).inflate(R.layout.working_dir_recyclerview_layout,p1,false);
			return new VH(v);
		}

		@Override
		public void onBindViewHolder(FileTypeSelectDialog.FileTypeRecyclerViewAdapter.VH p1, int p2)
		{
			// TODO: Implement this method
			p1.file_type_tv.setText(file_type_list.get(p2));
		}

		@Override
		public int getItemCount()
		{
			// TODO: Implement this method
			return file_type_list.size();
		}


		
		
		private class VH extends RecyclerView.ViewHolder
		{
			View v;
			TextView file_type_tv;
			int pos;
			VH(View vi)
			{
				super(vi);
				v=vi;
				file_type_tv=v.findViewById(R.id.working_dir_name);
				
				vi.setOnClickListener(new View.OnClickListener()
				{
					public void onClick(View p1)
					{
						pos=getAdapterPosition();
						if(fileTypeSelectListener!=null)
						{
							fileTypeSelectListener.onSelectType(file_mime_list.get(pos));
						}
						dismissAllowingStateLoss();
					}
				});
			}
		}
		
	}
	
	
	interface FileTypeSelectListener
	{
		public void onSelectType(String type);
	}
	
	public void setFileTypeSelectListener(FileTypeSelectListener listener)
	{
		fileTypeSelectListener=listener;
	}

}
