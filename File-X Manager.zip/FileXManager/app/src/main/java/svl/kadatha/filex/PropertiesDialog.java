package svl.kadatha.filex;
import android.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import android.widget.TableRow.*;
import java.util.*;
import java.io.*;
import android.support.v7.app.*;
import java.text.*;

public class PropertiesDialog extends android.support.v4.app.DialogFragment
{
	private Context context;
	private final SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy hh:mm");
	private TextView filename,file_path,file_type,file_no,file_size,file_date,symbolic_link,readable,writable,hidden,permissions;
	private String filename_str,file_path_str,file_type_str,file_no_str,file_size_str,file_date_str,file_permissions_str,symbolic_link_str,readable_str,writable_str,hidden_str;
	private Button OKBtn;
	private int total_no_of_files;
	private String size_of_files_format;
	private List<String> files_selected_array=new ArrayList<>();
	private ArrayList<File> files_selected_for_properties=new ArrayList<>();
	private TableLayout rwh_layout;
	static final String FILE_PATH="file_path";
	static final String FILE_PERMMISSION="file_permission";
	private FileCountSize AsyncTaskFileCountSize;
	private ViewGroup buttons_layout;


	
	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		// TODO: Implement this method
		super.onCreate(savedInstanceState);
		setRetainInstance(true);
		files_selected_array.addAll(getArguments().getStringArrayList("files_selected_array"));
		for(String s : files_selected_array)
		{
			files_selected_for_properties.add(new File(s));
		}
		AsyncTaskFileCountSize=new FileCountSize(files_selected_for_properties,true);
		AsyncTaskFileCountSize.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
		if(files_selected_for_properties.size()==1)
		{
			File file=files_selected_for_properties.get(0);
			filename_str=file.getName();
			file_path_str=file.getAbsolutePath();
			file_date_str=sdf.format(file.lastModified());
			file_type_str=file.isDirectory() ? "Directory" : "File";
			getPermissions(file);
			
			readable_str=file.canRead() ? "Yes" : "No";
			writable_str=file.canWrite() ? "Yes" : "No";
			hidden_str=file.isHidden() ? "Yes" : "No";
			
		}
		else if(files_selected_for_properties.size()>1)
		{
			filename_str=files_selected_for_properties.size()+" files";
			file_path_str=files_selected_for_properties.get(0).getParent();
			file_date_str="NA";
			file_type_str="NA";
			symbolic_link_str="NA";
		}
		
	
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
	{
		// TODO: Implement this method
		context=getContext();
		View v=inflater.inflate(R.layout.fragment_properties,container,false);
		filename=v.findViewById(R.id.fragment_properties_filename_label);
		file_path=v.findViewById(R.id.fragment_properties_filepath_label);
		file_type=v.findViewById(R.id.fragment_properties_filetype_label);
		file_no=v.findViewById(R.id.fragment_properties_file_no_label);
		file_size=v.findViewById(R.id.fragment_properties_filesize_label);
		file_date=v.findViewById(R.id.fragment_properties_modifieddate_label);
		symbolic_link=v.findViewById(R.id.fragment_properties_symbolic_label);
		rwh_layout=v.findViewById(R.id.fragment_properties_rwh_tablelayout);
		readable=v.findViewById(R.id.fragment_properties_file_readable);
		writable=v.findViewById(R.id.fragment_properties_file_writable);
		hidden=v.findViewById(R.id.fragment_properties_file_hidden);
		permissions=v.findViewById(R.id.fragment_properties_file_permissions);
		permissions.setOnClickListener(new View.OnClickListener()
		{
			public void onClick(View v)
			{
				
				Bundle bundle=new Bundle();
				bundle.putString(FILE_PATH,file_path_str);
				bundle.putString(FILE_PERMMISSION,file_permissions_str);
				PermissionsDialog permissionsDialog=new PermissionsDialog();
				permissionsDialog.setPermissionChangeListener(new PermissionsDialog.PermissionChangeListener()
				{
						public void onPermissionChange(File file)
						{
							getPermissions(file);
						}
				});
				permissionsDialog.setArguments(bundle);
				permissionsDialog.show(((AppCompatActivity)context).getSupportFragmentManager().beginTransaction(),"permissions_dialog");
			}
		});
		
		rwh_layout.setVisibility(files_selected_for_properties.size()==1 ? View.VISIBLE : View.GONE);
	
		filename.setText(filename_str);
		file_path.setText(file_path_str);
		file_type.setText(file_type_str);
		file_no.setText(file_no_str);
		file_size.setText(file_size_str);
		file_date.setText(file_date_str);
		symbolic_link.setText(symbolic_link_str);
		
		readable.setText(readable_str);
		writable.setText(writable_str);
		hidden.setText(hidden_str);
		permissions.setText(file_permissions_str);
		buttons_layout=v.findViewById(R.id.fragment_properties_button_layout);
		buttons_layout.addView(new EquallyDistributedChildrenLayout(context,1));
		OKBtn=buttons_layout.findViewById(R.id.first_button);
		OKBtn.setText("Close");
		OKBtn.setOnClickListener(new View.OnClickListener()
		{
			public void onClick(View v)
			{
				dismissAllowingStateLoss();
			}
			
		});
		return v;
	}
	
	
	@Override
	public void onResume()
	{
		// TODO: Implement this method
		
		super.onResume();
		Window window=getDialog().getWindow();
		window.setLayout(Global.DIALOG_WIDTH,LayoutParams.WRAP_CONTENT);
		window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
		
	}
	

	

	@Override
	public void onDestroyView() 
	{
		if (getDialog() != null && getRetainInstance()) 
		{
			getDialog().setDismissMessage(null);
		}
		super.onDestroyView();
	
	}

	@Override
	public void onDismiss(DialogInterface dialog)
	{
		// TODO: Implement this method
		super.onDismiss(dialog);
		AsyncTaskFileCountSize.cancel(true);
	}

	
	
	public void getPermissions(File file)
	{
		// TODO: Implement this method
		BufferedReader buffered_reader=null;
		String exec;
		if(file.isDirectory())
		{
			exec="ls -d -l ";
		}
		else
		{
			exec="ls -l ";
		}
		try
		{
			java.lang.Process proc=Runtime.getRuntime().exec(exec+file.getAbsolutePath());
			buffered_reader=new BufferedReader(new InputStreamReader(proc.getInputStream()));
			String line;

			while((line=buffered_reader.readLine())!=null)
			{
				String [] line_split=line.split("\\s+");
				if(line_split.length>5)
				{
					file_permissions_str=line_split[0];
				}
				line_split=line.split("->");
				if(line_split.length>1)
				{
					symbolic_link_str="->"+line_split[1];
				}
				else
				{
					symbolic_link_str="-";
				}


			}
			proc.waitFor();
			buffered_reader.close();
		}
		catch(Exception e)
		{

		}
	}

	

	private class FileCountSize extends AsyncTask<Void,Void,Void>
	{


		long file_size_denominator;
		long TOTAL_SIZE_OF_FILES;
		List<File> source_list_files=new ArrayList<>();
		boolean include_folder;

		FileCountSize(ArrayList<File> source_list_files,boolean include_folder)
		{
			this.source_list_files=source_list_files;
			this.include_folder=include_folder;
		}

		@Override
		protected void onPreExecute()
		{
			// TODO: Implement this method
			super.onPreExecute();
		}
		@Override
		protected Void doInBackground(Void[] p1)
		{
			// TODO: Implement this method
			int size=source_list_files.size();
			File[] f_array=new File[size];
			for(int i=0;i<size;i++)
			{
				f_array[i]=source_list_files.get(i);
			}
			populate(f_array,include_folder);
			return null;

		}
		private void populate(File[] source_list_files,boolean include_folder)
		{
			int size=source_list_files.length;
			for(int i=0;i<size;i++)
			{
				File f=source_list_files[i];
				if(isCancelled())
				{
					return;
				}
				Integer no_of_files=0;
				Long size_of_files=0L;
				if(f.isDirectory())
				{

					if(f.list()!=null)
					{
						populate(f.listFiles(),include_folder);


					}
					if(include_folder)
					{
						no_of_files++;
					}

				}
				else
				{

					no_of_files++;
					size_of_files+=f.length();
				}
				total_no_of_files+=no_of_files;
				TOTAL_SIZE_OF_FILES+=size_of_files;
				size_of_files_format=FileUtil.humanReadableByteCount(TOTAL_SIZE_OF_FILES,Global.BYTE_COUNT_BLOCK_1000);
				publishProgress();

			}


		}
		

		@Override
		protected void onProgressUpdate(Void[] values)
		{
			// TODO: Implement this method
			super.onProgressUpdate(values);
			if(file_no!=null)
			{
				file_no.setText(file_no_str=total_no_of_files + (total_no_of_files==1 ? " file " : " files "));
				file_size.setText(file_size_str=size_of_files_format);

			}


		}

		@Override
		protected void onPostExecute(Void result)
		{
			// TODO: Implement this method
			super.onPostExecute(result);

		}

		@Override
		protected void onCancelled(Void result)
		{
			// TODO: Implement this method
			super.onCancelled(result);
		}


	}
	

	
	
	private void print(String msg)
	{
		Toast.makeText(context,msg,Toast.LENGTH_SHORT).show();
	}
	
}
