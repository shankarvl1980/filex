package svl.kadatha.filex;
import android.widget.*;
import android.support.v4.app.*;
import android.os.*;
import android.view.*;
import android.content.*;
import java.util.*;
import java.io.*;
import android.widget.AbsListView.*;
import android.graphics.drawable.*;
import android.graphics.*;
import android.net.*;

public class DeleteFileAlertDialog extends android.support.v4.app.DialogFragment
{
	
	private TextView dialog_heading_textview,dialog_message_textview,no_files_textview,size_files_textview;
	private EditText new_file_name_edittext;
	private Button okbutton,cancelbutton;
	private DetailFragment df;
	private ArrayList<String>files_selected_array=new ArrayList<>();
	private ArrayList<Integer> files_selected_index_array=new ArrayList<>();
	private ArrayList<File> files_selected_for_delete =new ArrayList<>();
	private FileCountSize fileCountSize;
	private int total_no_of_files;
	private String size_of_files_to_be_deleted;
	private Context context;
	private ViewGroup buttons_layout;
	private String baseFolder="";
	private Uri uri;
	private boolean permission_requested;
	private final int request_code=89;
	private int i=0,size=0;
	private boolean whether_native_file_exists;
	private boolean library_search;
	
	
	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		// TODO: Implement this method
		super.onCreate(savedInstanceState);
		this.setRetainInstance(true);
		Bundle bundle=getArguments();
		if(bundle!=null)
		{
			files_selected_array.addAll(bundle.getStringArrayList("files_selected_array"));
			files_selected_index_array.addAll(bundle.getIntegerArrayList("files_selected_index_array"));
			for(String s:files_selected_array)
			{
				files_selected_for_delete.add(new File(s));
			}

		}
		size=files_selected_for_delete.size();
		fileCountSize=new FileCountSize(files_selected_for_delete,true);
		fileCountSize.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
		
		
	}
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
	{
		// TODO: Implement this method
		//return super.onCreateView(inflater, container, savedInstanceState);
		context=getContext();
		View v=inflater.inflate(R.layout.fragment_create_rename_delete,container,false);
		df=(DetailFragment)MainActivity.FM.findFragmentById(R.id.detail_fragment);
		dialog_heading_textview=v.findViewById(R.id.dialog_fragment_rename_delete_title);
		dialog_message_textview=v.findViewById(R.id.dialog_fragment_rename_delete_message);
		if(files_selected_array.size()==1)
		{
			dialog_message_textview.setText("Are you sure to delete the selected file? '"+new File(files_selected_array.get(0)).getName()+"'");
		}
		else
		{
			dialog_message_textview.setText("Are you sure to delete the selected files? "+files_selected_array.size()+" files");
		}
		
		new_file_name_edittext=v.findViewById(R.id.dialog_fragment_rename_delete_newfilename);
		no_files_textview=v.findViewById(R.id.dialog_fragment_rename_delete_no_of_files);
		size_files_textview=v.findViewById(R.id.dialog_fragment_rename_delete_total_size);
		buttons_layout=v.findViewById(R.id.fragment_create_rename_delete_button_layout);
		buttons_layout.addView(new EquallyDistributedChildrenLayout(context,2));
		okbutton=buttons_layout.findViewById(R.id.first_button);
		okbutton.setText("OK");
		cancelbutton=buttons_layout.findViewById(R.id.second_button);
		cancelbutton.setText("Cancel");
		dialog_heading_textview.setText("Delete");
		new_file_name_edittext.setVisibility(View.GONE);

		okbutton.setOnClickListener(new View.OnClickListener()
			{
				public void onClick(View v)
				{
					df=(DetailFragment)MainActivity.FM.findFragmentById(R.id.detail_fragment);
					library_search=!new File(df.getTag()).exists();
					if(!library_search)
					{
						File f=files_selected_for_delete.get(i);
						if(!FileUtil.isWritable(f))
						{
							for(Map.Entry<Uri,String> entry : Global.URI_STRING_HASHMAP.entrySet())
							{
								if(f.getAbsolutePath().startsWith(entry.getValue()))
								{
									baseFolder=entry.getValue();
									uri=entry.getKey();
									break;
								}
							}

							if(baseFolder.equals(""))
							{

								permission_requested=true;
								SAFPermissionHelperDialog safpermissionhelper=new SAFPermissionHelperDialog();
								safpermissionhelper.set_safpermissionhelperlistener(new SAFPermissionHelperDialog.SafPermissionHelperListener()
									{
										public void onOKBtnClicked()
										{
											checkSAFPermission();
										}

										public void onCancelBtnClicked()
										{
											
											dismissAllowingStateLoss();
										}
									});
								safpermissionhelper.show(MainActivity.FM,"saf_permission_dialog");
								return;
							}
							
						}
						Class emptyService=MainActivity.getEmptyService();
						if(emptyService==null)
						{
							print("Maximum 3 services only be processed at a time");
							return;
						}
						start_delete_progress_activity(emptyService);
						dismissAllowingStateLoss();
					
					}
					else
					{
						ProgressBarFragment pbf=new ProgressBarFragment();
						pbf.show(MainActivity.FM,"");
						for(;i<size;i++)
						{
							File f=files_selected_for_delete.get(i);
							if(FileUtil.isFromInternal(f))
							{
								whether_native_file_exists=true;
							}
							else
							{
								for(Map.Entry<Uri,String> entry : Global.URI_STRING_HASHMAP.entrySet())
								{
									if(f.getAbsolutePath().startsWith(entry.getValue()))
									{
										baseFolder=entry.getValue();
										uri=entry.getKey();
										break;
									}
								}

								if(baseFolder.equals(""))
								{

									permission_requested=true;
									SAFPermissionHelperDialog safpermissionhelper=new SAFPermissionHelperDialog();
									safpermissionhelper.set_safpermissionhelperlistener(new SAFPermissionHelperDialog.SafPermissionHelperListener()
										{
											public void onOKBtnClicked()
											{
												checkSAFPermission();
												
											}

											public void onCancelBtnClicked()
											{
												/*
												 if(whether_native_file_exists || i>1)
												 {
												 start_delete_progress_activity();
												 dismissAllowingStateLoss();

												 }
												 else*/
												{
													dismissAllowingStateLoss();
												}
											}
										});
									safpermissionhelper.show(MainActivity.FM,"saf_permission_dialog");
									return;
								}
							}

						}
						pbf.dismissAllowingStateLoss();
						Class emptyService=MainActivity.getEmptyService();
						if(emptyService==null)
						{
							print("Maximum 3 services only be processed at a time");
							return;
						}
						start_delete_progress_activity(emptyService);
						dismissAllowingStateLoss();
						
						
					}
				
				}

			});

		cancelbutton.setOnClickListener(new View.OnClickListener()
			{
				public void onClick(View v)
				{
					dismissAllowingStateLoss();
					
				}

			});
			
		if(savedInstanceState!=null)
		{

			no_files_textview.setText("Contains: "+total_no_of_files+ (total_no_of_files<2 ? " file" : " files"));
			size_files_textview.setText("Size: "+size_of_files_to_be_deleted);
		}
		return v;
	}

	@Override
	public void onResume()
	{
		// TODO: Implement this method
		super.onResume();
		Window window=getDialog().getWindow();
		window.setLayout(Global.DIALOG_WIDTH,LayoutParams.WRAP_CONTENT);
		window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
		
		
	}
	
	private void start_delete_progress_activity(Class service)
	{
		Bundle bundle=new Bundle();
		bundle.putStringArrayList("files_selected_array",files_selected_array);
		bundle.putIntegerArrayList("files_selected_index_array",files_selected_index_array);
		bundle.putString("baseFolder",baseFolder);
		bundle.putParcelable("uri",uri);
		
		bundle.putBoolean("library_search",library_search);
		Intent intent=new Intent(context,service);
		intent.setAction("delete");
		intent.putExtra("bundle",bundle);
		context.startActivity(intent);
	}
	
	public void checkSAFPermission()
	{

		Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
		startActivityForResult(intent, request_code);

	}


	// @TargetApi(Build.VERSION_CODES.LOLLIPOP)
	@Override
	public final void onActivityResult(final int requestCode, final int resultCode, final Intent resultData) 
	{
	

		if (requestCode == this.request_code && resultCode==getActivity().RESULT_OK) 
		{
			Uri treeUri = null;
			// Get Uri from Storage Access Framework.
			treeUri = resultData.getData();
			String uri_file_path=FileUtil.getFullPathFromTreeUri(treeUri,context);
			Iterator<Map.Entry<Uri,String>> iterator=Global.URI_STRING_HASHMAP.entrySet().iterator();
			while(iterator.hasNext())
			{
				Map.Entry<Uri,String> entry=iterator.next();
				if(entry.getValue().startsWith(uri_file_path))
				{
		
					iterator.remove();
				}
			}


			Global.URI_STRING_HASHMAP.put(treeUri,uri_file_path);


			// Persist access permissions.
			final int takeFlags = resultData.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
			context.getContentResolver().takePersistableUriPermission(treeUri, takeFlags);
			
			permission_requested=false;
			df=(DetailFragment)MainActivity.FM.findFragmentById(R.id.detail_fragment);
			//i--;// check saf permisdion for library_sesrch
			okbutton.callOnClick();
		
		}
		else
		{
			/*
			if(whether_native_file_exists || i>1)
			{
				start_delete_progress_activity();
				dismissAllowingStateLoss();
				
			}
			else*/
			{
				dismissAllowingStateLoss();
			}
		}

	}
	

	@Override
	public void onDismiss(DialogInterface dialog)
	{
		// TODO: Implement this method
		super.onDismiss(dialog);
		fileCountSize.cancel(true);
	}

	
	@Override
	public void onDestroyView() {
		if (getDialog() != null && getRetainInstance()) {
			getDialog().setDismissMessage(null);
		}
		super.onDestroyView();

	}

	@Override
	public void onSaveInstanceState(Bundle outState)
	{
		// TODO: Implement this method
		super.onSaveInstanceState(outState);
		outState.putInt("total_no_of_files",total_no_of_files);
		outState.putString("size_of_files_format",size_of_files_to_be_deleted);
	}
	
	
	private void print(String msg)
	{
		Toast.makeText(context,msg,Toast.LENGTH_SHORT).show();
	}
	
	private class FileCountSize extends AsyncTask<Void,Void,Void>
	{


		long file_size_denominator;
		long TOTAL_SIZE_OF_FILES;
		List<File> source_list_files=new ArrayList<>();
		boolean include_folder;

		FileCountSize(ArrayList<File> source_list_files,boolean include_folder)
		{
			this.source_list_files=source_list_files;
			this.include_folder=include_folder;
		}

		@Override
		protected void onPreExecute()
		{
			// TODO: Implement this method
			super.onPreExecute();
		}

		@Override
		protected Void doInBackground(Void[] p1)
		{
			// TODO: Implement this method
			int size=source_list_files.size();
			File[] f_array=new File[size];
			for(int i=0;i<size;i++)
			{
				f_array[i]=source_list_files.get(i);
			}
			populate(f_array,include_folder);
			return null;

		}
		private void populate(File[] source_list_files,boolean include_folder)
		{
			int size=source_list_files.length;
			for(int i=0;i<size;i++)
			{
				File f=source_list_files[i];
				if(isCancelled())
				{
					return;
				}
				Integer no_of_files=0;
				Long size_of_files=0L;
				if(f.isDirectory())
				{

					if(f.list()!=null)
					{
						populate(f.listFiles(),include_folder);


					}
					if(include_folder)
					{
						no_of_files++;
					}

				}
				else
				{

					no_of_files++;
					size_of_files+=f.length();
				}
				total_no_of_files+=no_of_files;
				TOTAL_SIZE_OF_FILES+=size_of_files;
				size_of_files_to_be_deleted=FileUtil.humanReadableByteCount(TOTAL_SIZE_OF_FILES,Global.BYTE_COUNT_BLOCK_1000);
				publishProgress();

			}


		}

		@Override
		protected void onProgressUpdate(Void[] values)
		{
			// TODO: Implement this method
			super.onProgressUpdate(values);
			if(no_files_textview!=null)
			{
				no_files_textview.setText("Contains: "+total_no_of_files+ (total_no_of_files<2 ? " file" : " files"));
				size_files_textview.setText("Size: "+size_of_files_to_be_deleted);
			}

		}

		@Override
		protected void onPostExecute(Void result)
		{
			// TODO: Implement this method
			super.onPostExecute(result);

		}

		@Override
		protected void onCancelled(Void result)
		{
			// TODO: Implement this method
			super.onCancelled(result);
		}


	}
	
	
}
