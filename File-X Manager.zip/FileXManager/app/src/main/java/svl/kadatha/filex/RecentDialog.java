package svl.kadatha.filex;
import android.support.v4.app.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import android.content.*;
import java.util.*;
import android.support.v7.widget.*;
import android.widget.ActionMenuView.*;
import android.graphics.drawable.*;
import android.graphics.*;
import java.io.*;
import com.bumptech.glide.*;
import com.bumptech.glide.load.engine.*;
import android.content.pm.*;
import android.net.*;
import java.util.zip.*;
import android.icu.text.*;

public class RecentDialog extends DialogFragment
{

	private RecyclerView root_dir_recyclerview,recent_recyclerview;
	private Button recent_clear_button,close_button;
	private Context context;
	private LinkedList<FilePOJO> root_dir_linkedlist=new LinkedList<>();
	private RecentRecyclerAdapter rootdirrecycleradapter;
	public static final int RECENT_SIZE=30;
	private ViewGroup buttons_layout;
	
	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		// TODO: Implement this method
		super.onCreate(savedInstanceState);
		setRetainInstance(true);
		root_dir_linkedlist.addAll(MainActivity.STORAGE_DIR);
		
		
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
	{
		// TODO: Implement this method
		//return super.onCreateView(inflater, container, savedInstanceState);
		context=getContext();
		View v=inflater.inflate(R.layout.fragment_recent,container,false);
		root_dir_recyclerview=v.findViewById(R.id.dialog_recent_root_dir_RecyclerView);
		recent_recyclerview=v.findViewById(R.id.dialog_recent_RecyclerView);
		buttons_layout=v.findViewById(R.id.fragment_recent_button_layout);
		buttons_layout.addView(new EquallyDistributedChildrenLayout(context,2));
		recent_clear_button=buttons_layout.findViewById(R.id.first_button);
		recent_clear_button.setText("Clear");
		close_button=buttons_layout.findViewById(R.id.second_button);
		close_button.setText("Close");
		
		rootdirrecycleradapter=new RecentRecyclerAdapter(root_dir_linkedlist,true);
		root_dir_recyclerview.addItemDecoration(MainActivity.DIVIDERITEMDECORATION);
		root_dir_recyclerview.setAdapter(rootdirrecycleradapter);
		root_dir_recyclerview.setLayoutManager(new LinearLayoutManager(context));
		
		
		
		final RecentRecyclerAdapter recentRecyclerAdapter=new RecentRecyclerAdapter(MainActivity.RECENTS,false);
		recent_recyclerview.addItemDecoration(MainActivity.DIVIDERITEMDECORATION);
		recent_recyclerview.setAdapter(recentRecyclerAdapter);
		recent_recyclerview.setLayoutManager(new LinearLayoutManager(context));
		
		recent_clear_button.setOnClickListener(new View.OnClickListener()
		{
			public void onClick(View v)
			{
				recentRecyclerAdapter.clear_recents();
				MainActivity.RECENTS=new LinkedList<>();
			}
		});
		
		close_button.setOnClickListener(new View.OnClickListener()
		{
			public void onClick(View v)
			{
				dismissAllowingStateLoss();
			}
			
		});
		
		USBBroadcastReceiver.USBATTACHDETACHLISTENER=new USBBroadcastReceiver.USBAttachDetachListener()
		{
			public void onUSBAttachDetach()
			{
				root_dir_linkedlist=new LinkedList<>();
				root_dir_linkedlist.addAll(MainActivity.STORAGE_DIR);
				rootdirrecycleradapter.notifyDataSetChanged();

			}
		};
		return v;
		
	}
	
	@Override
	public void onResume()
	{
		// TODO: Implement this method
		super.onResume();
		Window window=getDialog().getWindow();
		if(context.getResources().getBoolean(R.bool.is_land))
		{
			window.setLayout(Global.DIALOG_WIDTH,Global.DIALOG_WIDTH);
			
		}
		else
		{
			window.setLayout(Global.DIALOG_WIDTH,Global.DIALOG_HEIGHT);
		}
		
		window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
		
	}
	
	@Override
	public void onDestroyView() {
		if (getDialog() != null && getRetainInstance()) {
			getDialog().setDismissMessage(null);
		}
		super.onDestroyView();

	}
	
	private void file_open_intent_despatch(final File file, String file_name)
	{
		int idx=file_name.lastIndexOf(".");
		String file_ext="";
		if(idx!=-1)
		{
			file_ext=file_name.substring(idx+1);
		}
		if(file_ext.matches("(?i)zip"))
		{
			Intent intent=new Intent(Intent.ACTION_VIEW);
			intent.setDataAndType(Uri.fromFile(file),"application/zip");
			intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
			if(intent.resolveActivity(MainActivity.PM)!=null)
			{

				context.startActivity(intent);
			}

		}
		else if(file_ext=="" || !MainActivity.whether_matched_recognised_files(file_ext))
		{
			FileTypeSelectDialog fileTypeSelectFragment=new FileTypeSelectDialog();
			fileTypeSelectFragment.setFileTypeSelectListener(new FileTypeSelectDialog.FileTypeSelectListener()
				{
					public void onSelectType(String type)
					{
						try
						{
							FileIntentDispatch.openFile(context,file,type);

						}
						catch(IOException e)
						{
							print("Exception thrown");
						}
					}
				});
			fileTypeSelectFragment.show(MainActivity.FM,"");
		}
		else
		{
			try
			{
				FileIntentDispatch.openFile(context,file,"");

			}
			catch(IOException e)
			{
				print("Exception thrown");
			}
		}
	}

	
	

	public class RecentRecyclerAdapter extends RecyclerView.Adapter<RecentRecyclerAdapter.ViewHolder>
	{
		//Context context;
		LinkedList<FilePOJO> dir_linkedlist;
		boolean storage_dir;
		PackageInfo pi;

		RecentRecyclerAdapter(LinkedList<FilePOJO> dir_linkedlist, boolean storage_dir)
		{
			this.dir_linkedlist=dir_linkedlist;
			this.storage_dir=storage_dir;
		}

		class ViewHolder extends RecyclerView.ViewHolder
		{
			View view;
			ImageView fileimageview;
			ImageView overlay_fileimageview;
			TextView textView_recent_dir;
			int pos;
			
			ViewHolder(View view)
			{
				super(view);
				this.view=view;
				fileimageview=view.findViewById(R.id.image_storage_dir);
				overlay_fileimageview=view.findViewById(R.id.overlay_image_storage_dir);
				textView_recent_dir=view.findViewById(R.id.text_storage_dir_name);
				
			
				this.view.setOnClickListener(new View.OnClickListener()
					{

						public void onClick(View p)
						{
							
							pos=getAdapterPosition();
							final FilePOJO file=dir_linkedlist.get(pos);
							File f=file.getFile();
							if(f.isDirectory())
							{
								((MainActivity)context).createFragmentTransaction(f,null);
							}
							else if(f.canRead())
							{
								file_open_intent_despatch(f,file.getName());
								

							}
							if(MainActivity.RECENTS.size()!=0)
							{
								if((!MainActivity.RECENTS.getFirst().getPath().equals(file.getPath()) && file.getFile().exists()))
								{
									if(MainActivity.RECENTS.size()>=RECENT_SIZE)
									{
										MainActivity.RECENTS.removeLast();
									}

									MainActivity.RECENTS.addFirst(file);
								}

							}
							else
							{
								MainActivity.RECENTS.addFirst(file);
							}
							
							
							dismissAllowingStateLoss();
							
						}

					});

			}

		}

		@Override
		public RecentRecyclerAdapter.ViewHolder onCreateViewHolder(ViewGroup p1, int p2)
		{
			// TODO: Implement this method
			//View v=LayoutInflater.from(p1.getContext()).inflate(android.R.layout.simple_list_item_1,p1,false);
			View itemview=LayoutInflater.from(context).inflate(R.layout.storage_dir_recyclerview_layout,p1,false);
			return new ViewHolder(itemview);
		}

		@Override
		public void onBindViewHolder(RecentRecyclerAdapter.ViewHolder p1, int p2)
		{
			// TODO: Implement this method
	
			
			if(storage_dir)
			{
				SpacePOJO spacePOJO=MainActivity.SPACE_ARRAY.getValueAtIndex(p2);
				String space=" ("+spacePOJO.getUsedSpaceReadable()+"/"+spacePOJO.getTotalSpaceReadable()+")";
				if(dir_linkedlist.get(p2).getPath().equals("/"))
				{
					p1.fileimageview.setImageResource(R.drawable.device_icon);
					p1.textView_recent_dir.setText("Root Directory");
					

				}
				
				else
				{
					p1.fileimageview.setImageResource(R.drawable.sdcard_icon);
					p1.textView_recent_dir.setText(dir_linkedlist.get(p2).getName()+space);
				}
				
			}
			else
			{
				FilePOJO file=dir_linkedlist.get(p2);
				File f=file.getFile();
				String name=file.getName();
				String path=file.getPath();
				String date=file.getDate();
				String size=file.getSize();
				Integer type=file.getType();
				String ext=file.getExt();
				int overlay_visible=file.getOverlayVisibility();
				RecyclerViewItem.setIcon(context,path,p1.fileimageview,p1.overlay_fileimageview,type,overlay_visible);
					
	
				p1.textView_recent_dir.setText(file.getPath());
			}
			

		}

		@Override
		public int getItemCount()
		{
			// TODO: Implement this method
			return dir_linkedlist.size();
		}
		
		public void clear_recents()
		{
			dir_linkedlist=new LinkedList<>();
			notifyDataSetChanged();
		}
	}
		
	
	private void print(String msg)
	{
		Toast.makeText(context,msg,Toast.LENGTH_SHORT).show();
	}
}
