package svl.kadatha.filex;
//import android.support.v4.app.*;
import android.view.*;
import android.os.*;
import android.widget.*;
import android.content.*;
import java.util.*;
import java.io.*;
import android.support.v7.app.*;
import android.widget.TableRow.*;
import android.graphics.*;
import android.support.v7.widget.*;
import android.support.v4.content.*;
import android.util.*;
import android.app.*;
import android.support.v4.app.*;
import android.graphics.drawable.*;
import com.bumptech.glide.*;
import com.bumptech.glide.load.engine.*;
import android.content.pm.*;
import java.text.*;
import java.util.zip.*;

public class FileSelectorDialog extends android.support.v4.app.DialogFragment
{

	private RecyclerView recycler_view;
	private TextView textview_heading,folder_empty_textview,folder_selected_textview;
	private Context context;
	private Button okbutton, cancelbutton,backbutton;
	static FileSelectorListener fileSelectorListener;
	private final SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy hh:mm");
	private ViewGroup buttons_layout;
	
	private FileSelectorAdapter fileSelectorAdapter;
	private Handler handler,h;
	private PackageInfo pi;
	private FileFilter file_filter;
	private AsyncTaskDirectoryList asyncTaskDirectoryList;
	private List<FilePOJO> filePOJO_list=new ArrayList<>();
	/*
	private List<File> file_list;
	private List<String> file_modified_date_list;
	private List<String> file_size_list;
	private List<Integer> file_type_list;
	*/
	private File ff;
	private AsyncTaskStatus asyncTaskStatus;
	
	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		// TODO: Implement this method
		super.onCreate(savedInstanceState);
		setRetainInstance(true);
		asyncTaskStatus=AsyncTaskStatus.NOT_YET_STARTED;
		
		/*
		file_list=new ArrayList<>();
		file_modified_date_list=new ArrayList<>();
		file_size_list=new ArrayList<>();
		file_type_list=new ArrayList<>();
		*/
		file_filter=new FileFilter()
		{

			public boolean accept(File p1)
			{
				if(MainActivity.SHOW_HIDDEN_FILE)
				{
					return true;
				}
				else
				{
					return !p1.isHidden();
				}

			}

		};
		ArchiveSetUpDialog.FOLDERCLICKSELECTED=getTag();
		ff=new File(getTag());
	
		if(ff.exists())
		{
			asyncTaskDirectoryList=new AsyncTaskDirectoryList(ff);
		}
		else
		{
			asyncTaskDirectoryList=new AsyncTaskDirectoryList(null);
		}

		asyncTaskDirectoryList.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);

		
	}
	
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
	{
		// TODO: Implement this method
		//return super.onCreateView(inflater, container, savedInstanceState);
		View v=inflater.inflate(R.layout.fragment_file_selector,container,false);
		context=getContext();
		handler=new Handler();
		h=new Handler();
		textview_heading=v.findViewById(R.id.file_selector_heading);
		folder_selected_textview=v.findViewById(R.id.file_selector_folder_selected);
		recycler_view=v.findViewById(R.id.file_selectorRecyclerView);
		//recycler_view.addItemDecoration(MainActivity.DIVIDERITEMDECORATION);
		folder_empty_textview=v.findViewById(R.id.file_selector_folder_empty);
		buttons_layout=v.findViewById(R.id.fragment_file_selector_button_layout);
		buttons_layout.addView(new EquallyDistributedChildrenLayout(context,3));
		okbutton=buttons_layout.findViewById(R.id.first_button);
		okbutton.setText("OK");
		cancelbutton=buttons_layout.findViewById(R.id.second_button);
		cancelbutton.setText("Cancel");
		backbutton=buttons_layout.findViewById(R.id.third_button);
		backbutton.setText("Back");
		okbutton.setOnClickListener(new View.OnClickListener()
			{
				public void onClick(View v)
				{
					if(fileSelectorListener!=null)
					{
						fileSelectorListener.file_selected("ok");
					}

				}
			});


		cancelbutton.setOnClickListener(new View.OnClickListener()
			{
				public void onClick(View v)
				{

					if(fileSelectorListener!=null)
					{
						fileSelectorListener.file_selected("cancel");
					}

				}
			});

		backbutton.setOnClickListener(new View.OnClickListener()
			{
				public void onClick(View v)
				{
					MainActivity.FM.popBackStackImmediate();

				}
			});


		LinearLayoutManager lm=new LinearLayoutManager(context);
		recycler_view.setLayoutManager(lm);

		ArchiveSetUpDialog.FOLDERCLICKSELECTED=getTag();
		ff=new File(ArchiveSetUpDialog.FOLDERCLICKSELECTED);
		folder_selected_textview.setText(ArchiveSetUpDialog.FOLDERCLICKSELECTED);
		
		USBBroadcastReceiver.USBATTACHDETACHLISTENER=new USBBroadcastReceiver.USBAttachDetachListener()
		{
			public void onUSBAttachDetach()
			{
				fileSelectorAdapter.notifyDataSetChanged();

			}
		};
		
		h.post(new Runnable()
		{
			public void run()
			{
				//if(ff.exists())
				{
					if(asyncTaskStatus==AsyncTaskStatus.STARTED && filePOJO_list.size()<1)
					{
						h.postDelayed(this,25);
					}
					else
					{
						fileSelectorAdapter=new FileSelectorAdapter();
						set_adapter();
						h.removeCallbacks(this);
					}
				}
				
			}
			
		});
		
	
		handler.post(new Runnable()
			{
				public void run()
				{
					if(asyncTaskStatus==AsyncTaskStatus.COMPLETED)
					{
						if(fileSelectorAdapter!=null)
						{
							fileSelectorAdapter.notifyDataSetChanged();
						}
						
						handler.removeCallbacks(this);
					}
					else
					{
						if(fileSelectorAdapter!=null)
						{
							fileSelectorAdapter.notifyDataSetChanged();
						}
						handler.postDelayed(this,100);
					}

				}
			});
		return v;
		
	}


	

	@Override
	public void onResume()
	{
		// TODO: Implement this method
		super.onResume();
		Window window=getDialog().getWindow();
		if(context.getResources().getBoolean(R.bool.is_land))
		{
			window.setLayout(Global.DIALOG_WIDTH,Global.DIALOG_WIDTH);
		}
		else
		{
			window.setLayout(Global.DIALOG_WIDTH,Global.DIALOG_HEIGHT);
		}
		window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
		
	}
	
	
	@Override
	public void onDestroyView() 
	{
		if (getDialog() != null && getRetainInstance()) 
		{
			getDialog().setDismissMessage(null);
		}
		super.onDestroyView();

	}
	
	public interface FileSelectorListener
	{
		public void file_selected(String action);
	}
	
	public void setListener(FileSelectorListener mfileSelectorListener)
	{
		this.fileSelectorListener=mfileSelectorListener;
	}
	
	private class AsyncTaskDirectoryList extends AsyncTask<Void,Void,Void>
	{


		File file;
	
		AsyncTaskDirectoryList(File f)
		{
			file=f;
		}

		@Override
		protected void onPreExecute()
		{
			// TODO: Implement this method
			super.onPreExecute();
			asyncTaskStatus=AsyncTaskStatus.STARTED;


		}

		@Override
		protected void onCancelled(Void result)
		{
			// TODO: Implement this method
			super.onCancelled(result);
			asyncTaskStatus=AsyncTaskStatus.COMPLETED;
			


		}


		@Override
		protected Void doInBackground(Void[] p1)
		{
			// TODO: Implement this method
			File[] file_array;
			if(file==null)
			{
				
				for(FilePOJO f : MainActivity.STORAGE_DIR)
				{
					filePOJO_list.add(f);
				}
			
			}

			else if((file_array=file.listFiles(file_filter))!=null)
			{
				
				Arrays.sort(file_array,FileComparator.FileComparate(Global.SORT));
				insert_filePOJO_list(file_array,true);


			}


			return null;
		}

		@Override
		protected void onPostExecute(Void result)
		{
			// TODO: Implement this method
			super.onPostExecute(result);
			asyncTaskStatus=AsyncTaskStatus.COMPLETED;
			
		}

	}

	private void insert_filePOJO_list(File[] f_l, boolean extracticon)
	{
		int size=f_l.length;
	
		for(int i=0;i<size;i++)
		{
			File f=f_l[i];
			String name=f.getName();
			String path=f.getAbsolutePath();
			String file_ext="";
			int overlay_visible=View.INVISIBLE;
			int alfa=225;
			int idx=name.lastIndexOf(".");
			if(idx!=-1)
			{
				file_ext=name.substring(idx+1);
			}

			if(file_ext.matches(Global.VIDEO_REGEX))
			{
				overlay_visible=View.VISIBLE;
			}
			if(MainActivity.SHOW_HIDDEN_FILE && f.isHidden())
			{
				alfa=100;
			}
			if(extracticon)
			{
				DetailFragment.extract_icon(path,file_ext);

			}

			String date=sdf.format(f.lastModified());
			String si=DetailFragment.getFileSize(f,false);
			Integer type=DetailFragment.getFileType(f,file_ext);
			filePOJO_list.add(new FilePOJO(f,name,path,date,si,type,file_ext,alfa,overlay_visible));

		}
	}
	
	
	
	private void set_adapter()
	{

		recycler_view.setAdapter(fileSelectorAdapter);
		if(filePOJO_list!=null && filePOJO_list.size()==0)
		{
			recycler_view.setVisibility(View.GONE);
			folder_empty_textview.setVisibility(View.VISIBLE);
		}
	}
	private class FileSelectorAdapter extends RecyclerView.Adapter<FileSelectorAdapter.ViewHolder>
	{

		PackageInfo pi;
			
		
		@Override
		public FileSelectorAdapter.ViewHolder onCreateViewHolder(ViewGroup p1, int p2)
		{
			// TODO: Implement this method
			return new FileSelectorAdapter.ViewHolder(new RecyclerViewItem(context));
		}

		
		
		@Override
		public void onBindViewHolder(final FileSelectorDialog.FileSelectorAdapter.ViewHolder p1, int p2)
		{
			// TODO: Implement this method
			FilePOJO file=filePOJO_list.get(p2);
			File f=file.getFile();
			String name=file.getName();
			String path=file.getPath();
			String date=file.getDate();
			String size=file.getSize();
			Integer type=file.getType();
			String ext=file.getExt();
			int alfa=file.getAlfa();
			int overlay_visible=file.getOverlayVisibility();
			p1.v.setTag(file.getPath());
			p1.v.setData(f,name,path,size,date,type,ext,alfa,overlay_visible);
			
			
		}

		
		@Override
		public int getItemCount()
		{
			// TODO: Implement this method
			return filePOJO_list.size();
		}

		class ViewHolder extends RecyclerView.ViewHolder
		{
			RecyclerViewItem v;
			
			ViewHolder(RecyclerViewItem v)
			{
				super(v);
				this.v=v;
				
				v.setBackground(context.getResources().getDrawable(R.drawable.select_color_storage_list));
				v.setOnClickListener(new View.OnClickListener()
				{

					public void onClick(View v)
					{

						ArchiveSetUpDialog.createFileSelectorFragmentTransaction(MainActivity.FM,v.getTag().toString());
					}
				});
				
				
			}

		}
		

		
	
	}
	
	

	/*
	private void createFileSelectorFragmentTransaction(final android.support.v4.app.FragmentManager fm,String file_clicked)
	{
		if(new File(file_clicked).isDirectory() || file_clicked.equals(""))
		{
			FileSelector ff=new FileSelector();
			
			ff.setListener(new FileSelector.FileSelectorListener()
			{
				public void file_selected(String action)
				{
					
					if(action.equals("ok"))
					{
						//customdir_edittext.setText(FOLDERCLICKSELECTED);
					}
					
					fm.popBackStack(ArchiveDialogBuilder.FF_TRANS,0);
						
				}

			});
				
			android.support.v4.app.FragmentTransaction ft=fm.beginTransaction();
			ft.addToBackStack(file_clicked);
			ft.setTransition(android.support.v4.app.FragmentTransaction.TRANSIT_FRAGMENT_FADE);
			ff.show(ft,file_clicked);
		}

	}
	*/
	

	private enum AsyncTaskStatus
	{
		NOT_YET_STARTED, STARTED, COMPLETED
		}
	
	private void print(String msg)
	{
		Toast.makeText(context,msg,Toast.LENGTH_SHORT).show();
	}
	
	
}



