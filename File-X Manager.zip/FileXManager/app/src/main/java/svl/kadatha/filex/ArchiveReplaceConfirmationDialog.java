package svl.kadatha.filex;
import android.os.*;
import android.view.*;
import android.widget.*;
import android.widget.RelativeLayout.*;
import android.content.*;
import java.util.*;
import android.graphics.drawable.*;
import android.graphics.*;

public class ArchiveReplaceConfirmationDialog extends android.support.v4.app.DialogFragment
{

	private TextView confirmation_message_textview;
	private Button yes_button,no_button;
	private String dest_folder,zip_file_path,zip_file_name;
	private ArrayList<String> files_selected_array=new ArrayList<>();
	private ArrayList<String> zipentry_selected_array=new ArrayList<>();
	private String action;
	private ArchiveReplaceDialogListener archiveReplaceDialogListener;
	private Context context;
	private ViewGroup buttons_layout;

	
	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		// TODO: Implement this method
		super.onCreate(savedInstanceState);
		setRetainInstance(true);
		setCancelable(false);
		
		
		Bundle bundle=getArguments();
		dest_folder=bundle.getString("dest_folder");
		zip_file_path=bundle.getString("zip_file_path");
		zip_file_name=bundle.getString("zip_file_name");
		files_selected_array.addAll(bundle.getStringArrayList("files_selected_array"));
		if(bundle.getStringArrayList("zipentry_selected_array")!=null)
		{
			zipentry_selected_array.addAll(bundle.getStringArrayList("zipentry_selected_array"));
		}
		action=bundle.getString("action");
		
	
		
		
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
	{
		// TODO: Implement this method
		//return super.onCreateView(inflater, container, savedInstanceState);
		context=getContext();
		View v=inflater.inflate(R.layout.fragment_archivereplace_confirmation,container,false);
		confirmation_message_textview=v.findViewById(R.id.dialog_fragment_archive_replace_message);
		buttons_layout=v.findViewById(R.id.fragment_archivereplace_confirmation_button_layout);
		buttons_layout.addView(new EquallyDistributedChildrenLayout(context,2));
		yes_button=buttons_layout.findViewById(R.id.first_button);
		yes_button.setText("Yes");
		no_button=buttons_layout.findViewById(R.id.second_button);
		no_button.setText("No");
		if(action.equals("archive"))
		{
			confirmation_message_textview.setText("A file with same name already exists. Do you want to replace it? '"+zip_file_name+".zip'");
		}
		else
		{
			confirmation_message_textview.setText("A folder with same name already exists. Do you want to overwrite it? '"+zip_file_name+"'");
		}
		yes_button.setOnClickListener(new View.OnClickListener()
		{
			public void onClick(View v)
			{
				/*
				android.support.v4.app.FragmentTransaction ft=MainActivity.FM.beginTransaction().addToBackStack(df_tag);
				Bundle bundle=new Bundle();
				bundle.putString("dest_folder",dest_folder);
				bundle.putString("zip_file_path",zip_file_path);
				bundle.putString("zip_file_name",zip_file_name);
				bundle.putString("action",action);
				bundle.putStringArrayList("files_selected_array",files_selected_array);
				bundle.putStringArrayList("zipentry_selected_array",zipentry_selected_array);
				ArchiveFileDialog archive=new ArchiveFileDialog();
				archive.setArguments(bundle);
				archive.show(MainActivity.FM,df_tag);
				*/
				if(archiveReplaceDialogListener!=null)
				{
					archiveReplaceDialogListener.onYes();
				}
				dismissAllowingStateLoss();
				
				
			}
			
		});
		
		no_button.setOnClickListener(new View.OnClickListener()
		{
			public void onClick(View v)
			{
				dismissAllowingStateLoss();
			}
			
		});
		return v;
	}

	@Override
	public void onResume()
	{
		// TODO: Implement this method
		super.onResume();
		Window window=getDialog().getWindow();
		window.setLayout(Global.DIALOG_WIDTH,LayoutParams.WRAP_CONTENT);
		window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
		
	}

	
	
	@Override
	public void onDestroyView() {
		if (getDialog() != null && getRetainInstance()) {
			getDialog().setDismissMessage(null);
		}
		super.onDestroyView();

	}
	
	public void setArchiveReplaceDialogListener(ArchiveReplaceDialogListener listener)
	{
		archiveReplaceDialogListener=listener;
	}
	
	interface ArchiveReplaceDialogListener
	{
		
		public void onYes();
	}
	
}
