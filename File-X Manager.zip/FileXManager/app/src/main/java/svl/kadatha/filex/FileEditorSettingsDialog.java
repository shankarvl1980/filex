package svl.kadatha.filex;
import android.support.v4.app.*;
import android.view.*;
import android.os.*;
import android.widget.RadioGroup.*;
import android.graphics.drawable.*;
import android.graphics.*;
import android.widget.*;
import android.app.*;
import android.support.v7.app.*;
import android.content.*;

public class FileEditorSettingsDialog extends android.support.v4.app.DialogFragment
{

	private Button ok_button,cancel_button;
	private RadioGroup eol_rg;
	private RadioButton unix_rb,mac_rb,wnd_rb;
	private ImageButton text_size_decrease_btn,text_size_increase_btn;
	private CheckBox wrap_check_box;
	private boolean not_wrap;
	private int selected_eol;
	private float selected_text_size=FileEditorActivity.FILE_EDITOR_TEXT_SIZE;
	private EditText sample_edittext;
	private TextView text_size_tv;
	private FileEditorActivity fe;
	private Context context;
	private ViewGroup buttons_layout;
	final static int MIN_TEXT_SIZE=10, MAX_TEXT_SIZE=20;
	private EOL_ChangeListener eol_changeListener;
	
	
	
	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		// TODO: Implement this method
		super.onCreate(savedInstanceState);
		setRetainInstance(true);
		context=getContext();
		selected_eol=((FileEditorActivity)context).eol;
		not_wrap=FileEditorActivity.NOT_WRAP;
		selected_text_size=FileEditorActivity.FILE_EDITOR_TEXT_SIZE;
		
	}

	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
	{
		// TODO: Implement this method
		context=getContext();
		View v=inflater.inflate(R.layout.fragment_file_editor_settings,container,false);
		fe=(FileEditorActivity)context;
		eol_rg=v.findViewById(R.id.eol_rg);

		
		eol_rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener()
		{
			public void onCheckedChanged(RadioGroup rg, int p1)
			{
				if(fe.file.exists() && !fe.isFileBig)
				{
					if(unix_rb.isChecked())
					{
						selected_eol=FileEditorActivity.EOL_N;
					}
					else if(mac_rb.isChecked())
					{
						selected_eol=FileEditorActivity.EOL_R;
					}
					else if(wnd_rb.isChecked())
					{
						selected_eol=FileEditorActivity.EOL_RN;
					}
				}
				else
				{
					switch(fe.eol)
					{
						case FileEditorActivity.EOL_N:
							unix_rb.setChecked(true);
							break;
						case FileEditorActivity.EOL_R:
							mac_rb.setChecked(true);
							break;
						case FileEditorActivity.EOL_RN:
							wnd_rb.setChecked(true);
							break;

					}
					print("can't edit this file");
				}

				
			}
			
		});
		
		unix_rb=v.findViewById(R.id.eol_rb_n);
		mac_rb=v.findViewById(R.id.eol_rb_r);
		wnd_rb=v.findViewById(R.id.eol_rb_rn);
		
		

		
		wrap_check_box=v.findViewById(R.id.file_editor_settings_wrap_checkbox);
		wrap_check_box.setChecked(!not_wrap);
		wrap_check_box.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener()
		{
			public void onCheckedChanged(CompoundButton b,boolean checked)
			{
				not_wrap=!checked;
			
			}
		});
		
		text_size_decrease_btn=v.findViewById(R.id.file_editor_text_size_decrease);
		text_size_increase_btn=v.findViewById(R.id.file_editor_text_size_increase);
		text_size_tv=v.findViewById(R.id.file_editor_settings_text_size);
		text_size_tv.setText("Text size: "+(int)selected_text_size);
		
		text_size_decrease_btn.setOnTouchListener(new RepeatListener(400,100,new View.OnClickListener()
		{
			public void onClick(View p1)
			{
				if(selected_text_size>MIN_TEXT_SIZE)
				{
					selected_text_size--;
					text_size_tv.setText("Text size: "+(int)selected_text_size);
					sample_edittext.setTextSize(selected_text_size);
					enable_disable_btns();
				}
				
				
			}
		}));
		
		text_size_increase_btn.setOnTouchListener(new RepeatListener(400,100,new View.OnClickListener()
		{
			public void onClick(View p1)
			{
				if(selected_text_size<MAX_TEXT_SIZE)
				{
					selected_text_size++;
					text_size_tv.setText("Text size: "+(int)selected_text_size);
					sample_edittext.setTextSize(selected_text_size);
					enable_disable_btns();
				}
			}
		}));
		
		
		sample_edittext=v.findViewById(R.id.file_editor_settings_sample_text);
		sample_edittext.setTextSize(selected_text_size);
		buttons_layout=v.findViewById(R.id.fragment_file_editor_settings_button_layout);
		buttons_layout.addView(new EquallyDistributedChildrenLayout(context,2));
		ok_button=buttons_layout.findViewById(R.id.first_button);
		ok_button.setText("OK");
		ok_button.setOnClickListener(new View.OnClickListener()
		{
			public void onClick(View view)
			{
				
				if(FileEditorActivity.NOT_WRAP!=not_wrap)
				{
					FileEditorActivity.NOT_WRAP=not_wrap;
					fe.tinyDB.putBoolean("file_editor_not_wrap",not_wrap);
					fe.recreate();
			
				}
				
				if(FileEditorActivity.FILE_EDITOR_TEXT_SIZE!=selected_text_size)
				{
				
					fe.filetext_container_edittext.setTextSize(selected_text_size);
					FileEditorActivity.FILE_EDITOR_TEXT_SIZE=selected_text_size;
					fe.tinyDB.putFloat("file_editor_text_size",FileEditorActivity.FILE_EDITOR_TEXT_SIZE);
		
				}
				
				((FileEditorActivity)context).altered_eol=selected_eol;
				if(eol_changeListener!=null)
				{
					eol_changeListener.onEOLchanged(selected_eol);
				}
				dismissAllowingStateLoss();
			}
		});
		
		cancel_button=buttons_layout.findViewById(R.id.second_button);
		cancel_button.setText("Cancel");
		cancel_button.setOnClickListener(new View.OnClickListener()
		{
			public void onClick(View view)
			{
				dismissAllowingStateLoss();
			}
		});
		
		switch(selected_eol)
		{
			case FileEditorActivity.EOL_N:
				unix_rb.setChecked(true);
				break;
			case FileEditorActivity.EOL_R:
				mac_rb.setChecked(true);
				break;
			case FileEditorActivity.EOL_RN:
				wnd_rb.setChecked(true);
				break;
			
		}
		
		enable_disable_btns();
		return v;
	}

	@Override
	public void onAttach(Activity activity)
	{
		// TODO: Implement this method
		super.onAttach(activity);
		
		eol_changeListener=(FileEditorActivity)activity;
	
	}
	
	private void enable_disable_btns()
	{
	
		if(selected_text_size==MIN_TEXT_SIZE)
		{
			text_size_decrease_btn.setEnabled(false);
			text_size_decrease_btn.setAlpha(100);
		}
		else if(selected_text_size==MAX_TEXT_SIZE)
		{
			text_size_increase_btn.setEnabled(false);
			text_size_increase_btn.setAlpha(100);
		}
		else if(selected_text_size>MIN_TEXT_SIZE && selected_text_size<MAX_TEXT_SIZE)
		{
			text_size_decrease_btn.setEnabled(true);
			text_size_decrease_btn.setAlpha(255);

			text_size_increase_btn.setEnabled(true);
			text_size_increase_btn.setAlpha(255);
		}
	}

	
	@Override
	public void onResume()
	{
		// TODO: Implement this method
		super.onResume();
		Window window=getDialog().getWindow();
		window.setLayout(Global.DIALOG_WIDTH,LayoutParams.WRAP_CONTENT);
		window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
	}

	@Override
	public void onDestroyView() 
	{
		if (getDialog() != null && getRetainInstance()) 
		{
			getDialog().setDismissMessage(null);
		}
		super.onDestroyView();
	}

	@Override
	public void onDestroy()
	{
		// TODO: Implement this method
		super.onDestroy();

	}
	
	interface EOL_ChangeListener
	{
		public void onEOLchanged(int eol);
	}
	
	private void print(String msg)
	{
		android.widget.Toast.makeText(context,msg,android.widget.Toast.LENGTH_LONG).show();
	}
}
