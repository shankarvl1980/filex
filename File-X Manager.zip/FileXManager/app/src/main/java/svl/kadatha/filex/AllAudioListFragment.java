package svl.kadatha.filex;
import android.support.v4.app.*;
import android.support.v4.content.*;
import android.database.*;
import android.os.*;
import android.net.*;
import android.view.*;
import android.content.Context;
import android.provider.*;
import java.util.*;
import android.support.v7.widget.*;
import java.util.concurrent.*;
import android.widget.*;
import java.io.*;
import android.content.Intent;
import android.util.*;
import android.graphics.*;
import android.media.*;
import android.icu.text.*;
import android.view.animation.*;
import android.view.View.*;
import android.database.sqlite.*;


public class AllAudioListFragment extends android.support.v4.app.Fragment //implements LoaderManager.LoaderCallbacks<Cursor>
{

	private Context context;
	private List<AudioPOJO> audio_list;
	private AudioListRecyclerViewAdapter audioListRecyclerViewAdapter;
	private RecyclerView recyclerview;
	private ImageButton delete_btn,play_btn,add_to_q_btn,save_btn,overflow_btn;
	private Button audio_select_btn;
	private AudioSelectListener audioSelectListener;
	private android.support.v7.widget.Toolbar bottom_toolbar;
	private ToolBarClickListener toolBarClickListener;
	private android.support.v7.widget.ListPopupWindow listPopWindow;
	private ArrayList<ListPopupWindowPOJO> list_popupwindowpojos;
	private List<AudioPOJO> audios_selected_for_delete;
	private ArrayList<AudioPOJO> deleted_audios=new ArrayList<>();
	private boolean permission_requested;
	private String baseFolder="";
	private Uri uri;
	private final int request_code=982;
	private DeleteFileAsyncTask delete_file_async_task;
	private boolean asynctask_running;
	public SparseBooleanArray mselecteditems=new SparseBooleanArray();
	public List<AudioPOJO> audio_selected_array=new ArrayList<>();
	private boolean toolbar_visible;
	private int scroll_distance;
	private AsyncTaskStatus asyncTaskStatus;
	private LocalBroadcastManager localBroadcastManager;
	static boolean FULLY_POPULATED;
	private ProgressBar progress_bar;
	private TextView empty_tv;
	private int num_all_audio;
	public boolean whether_audios_set_to_current_list;
	
	
	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		// TODO: Implement this method
		super.onCreate(savedInstanceState);
		setRetainInstance(true);
		asyncTaskStatus=AsyncTaskStatus.NOT_YET_STARTED;
		list_popupwindowpojos=new ArrayList<>();
		list_popupwindowpojos.add(new ListPopupWindowPOJO(R.drawable.send_icon,"Send"));
		list_popupwindowpojos.add(new ListPopupWindowPOJO(R.drawable.properties_icon,"Properties"));

		
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
	{
		// TODO: Implement this method
		context=getContext();
		localBroadcastManager=LocalBroadcastManager.getInstance(context);
		View v=inflater.inflate(R.layout.fragment_audio_list,container,false);
		bottom_toolbar=v.findViewById(R.id.audio_list_bottom_toolbar);
		bottom_toolbar.addView(new CustomToolbarLayout(context,R.layout.all_audio_toolbar_layout,Global.SCREEN_WIDTH,Global.SCREEN_HEIGHT));
		
		delete_btn=bottom_toolbar.findViewById(R.id.all_audio_delete);
		play_btn=bottom_toolbar.findViewById(R.id.all_audio_play);
		//add_to_q_btn=bottom_toolbar.findViewById(R.id.all_audio_add_q);
		save_btn=bottom_toolbar.findViewById(R.id.all_audio_save_list);
		overflow_btn=bottom_toolbar.findViewById(R.id.all_audio_overflow);
		audio_select_btn=bottom_toolbar.findViewById(R.id.all_audio_select);
	
		
		toolBarClickListener=new ToolBarClickListener();
		
		delete_btn.setOnClickListener(toolBarClickListener);
		play_btn.setOnClickListener(toolBarClickListener);
		//add_to_q_btn.setOnClickListener(toolBarClickListener);
		save_btn.setOnClickListener(toolBarClickListener);
		overflow_btn.setOnClickListener(toolBarClickListener);
		audio_select_btn.setOnClickListener(toolBarClickListener);
		
		
		listPopWindow=new android.support.v7.widget.ListPopupWindow(context);
		listPopWindow.setAdapter(new ListPopupWindowArrayAdapter(context,0,list_popupwindowpojos));
		listPopWindow.setAnchorView(overflow_btn);
		listPopWindow.setWidth(getResources().getDimensionPixelSize(R.dimen.list_popupwindow_width));
		listPopWindow.setModal(true);
		listPopWindow.setOnItemClickListener(new ListPopupWindowClickListener());
		
		recyclerview=v.findViewById(R.id.fragment_audio_list_container);
		recyclerview.setLayoutManager(new LinearLayoutManager(context));
		recyclerview.addOnScrollListener(new RecyclerView.OnScrollListener()
			{
		
			
				final int threshold=5;
				public void onScrolled(RecyclerView rv, int dx, int dy)
				{
					super.onScrolled(rv,dx,dy);
					if(scroll_distance>threshold && toolbar_visible)
					{
						
						bottom_toolbar.animate().translationY(bottom_toolbar.getHeight()).setInterpolator(new AccelerateInterpolator(1));
						toolbar_visible=false;
						scroll_distance=0;
					}
					else if(scroll_distance<-threshold && !toolbar_visible)
					{
						if(mselecteditems.size()>0)
						{
							bottom_toolbar.animate().translationY(0).setInterpolator(new DecelerateInterpolator(1));
							toolbar_visible=true;
							scroll_distance=0;
						}

	
					}

					if((toolbar_visible && dy>0) || (!toolbar_visible && dy<0))
					{
						scroll_distance+=dy;
					}

				}

			});
		
		empty_tv=v.findViewById(R.id.all_audio_list_empty);
		progress_bar=v.findViewById(R.id.all_audio_list_progressbar);
		
		
		if(mselecteditems.size()==0)
		{
			bottom_toolbar.setVisibility(View.GONE);
			bottom_toolbar.animate().translationY(bottom_toolbar.getHeight()).setInterpolator(new AccelerateInterpolator(1));
			toolbar_visible=false;
		}
		else
		{
			//bottom_toolbar.animate().translationY(0).setInterpolator(new DecelerateInterpolator(1));
			toolbar_visible=true;
			
		
		}
		
		
		if(asyncTaskStatus!=AsyncTaskStatus.STARTED)
		{
			new MediaExtractAsyncTask().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
		}
		audio_select_btn.setText(mselecteditems.size()+"/"+num_all_audio);

		return v;
	}


	private class MediaExtractAsyncTask extends AsyncTask<Void,Void,Void>
	{

		Uri media_uri=MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
		@Override
		protected void onPreExecute()
		{
			// TODO: Implement this method
			super.onPreExecute();
			asyncTaskStatus=AsyncTaskStatus.STARTED;
		
		}

		@Override
		protected Void doInBackground(Void[] p1)
		{
			// TODO: Implement this method
			if(audio_list!=null)
			{
				return null;
			}
			audio_list=new ArrayList<>();
			AudioPlayerActivity.EXISTING_AUDIOS_ID=new ArrayList<>();
			
			/*
			Cursor cursor=context.getContentResolver().query(media_uri,null,null,null,null);
			if(cursor!=null && cursor.getCount()>0)
			{
				while(cursor.moveToNext())
				{
					int id=cursor.getInt(cursor.getColumnIndex(MediaStore.Audio.Media._ID));
					String data=cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Media.DATA));
					String title=cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Media.TITLE));
					String album=cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Media.ALBUM));
					String artist=cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Media.ARTIST));
					String duration=cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Media.DURATION));
					Bitmap albumart=AudioPlayerActivity.getAlbumArt(context,data);

					if(new File(data).exists())
					{

						audio_list.add(new AudioPOJO(id,data,title,album,artist,duration,albumart));
						AudioPlayerActivity.EXISTING_AUDIOS_ID.add(id);
					}

				}
			}
			*/
			Cursor audio_cursor;
			Cursor cursor=context.getContentResolver().query(MediaStore.Audio.Albums.EXTERNAL_CONTENT_URI,null,null,null,null);
			if(cursor!=null && cursor.getCount()>0)
			{
				while(cursor.moveToNext())
				{

					String album_id=cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Albums._ID));
					
					//String album_name=cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Albums.ALBUM));
					//String artist=cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Albums.ARTIST));
					//String no_of_songs=cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Albums.NUMBER_OF_SONGS));
					String album_path=cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Albums.ALBUM_ART));
					Bitmap albumart=BitmapFactory.decodeFile(album_path);
					
					
					String where=MediaStore.Audio.Media.ALBUM_ID+"="+album_id;
					audio_cursor=context.getContentResolver().query(media_uri,null,where,null,null);
					if(audio_cursor!=null && audio_cursor.getCount()>0)
					{
						while(audio_cursor.moveToNext())
						{
							int id=audio_cursor.getInt(audio_cursor.getColumnIndex(MediaStore.Audio.Media._ID));
							String data=audio_cursor.getString(audio_cursor.getColumnIndex(MediaStore.Audio.Media.DATA));
							String title=audio_cursor.getString(audio_cursor.getColumnIndex(MediaStore.Audio.Media.TITLE));
							String album=audio_cursor.getString(audio_cursor.getColumnIndex(MediaStore.Audio.Media.ALBUM));
							String artist=audio_cursor.getString(audio_cursor.getColumnIndex(MediaStore.Audio.Media.ARTIST));
							String duration=audio_cursor.getString(audio_cursor.getColumnIndex(MediaStore.Audio.Media.DURATION));
				

							if(new File(data).exists())
							{
								audio_list.add(new AudioPOJO(id,data,title,album,artist,duration,albumart));
								AudioPlayerActivity.EXISTING_AUDIOS_ID.add(id);
							}
						}
					}
				}
			}
			
			return null;
		}

		@Override
		protected void onPostExecute(Void result)
		{
			// TODO: Implement this method
			super.onPostExecute(result);
			audioListRecyclerViewAdapter=new AudioListRecyclerViewAdapter();
			recyclerview.setAdapter(audioListRecyclerViewAdapter);
			num_all_audio=audio_list.size();
			if(num_all_audio<=0)
			{
				recyclerview.setVisibility(View.GONE);
				empty_tv.setVisibility(View.VISIBLE);
			}
			
			
			
			FULLY_POPULATED=true;
			audio_select_btn.setText(mselecteditems.size()+"/"+num_all_audio);
			progress_bar.setVisibility(View.GONE);
			asyncTaskStatus=AsyncTaskStatus.COMPLETED;
		}

		
		
	}
	
	public void checkSAFPermission()
	{

		Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
		startActivityForResult(intent, request_code);

	}


	// @TargetApi(Build.VERSION_CODES.LOLLIPOP)
	@Override
	public final void onActivityResult(final int requestCode, final int resultCode, final Intent resultData) 
	{
		super.onActivityResult(requestCode,resultCode,resultData);
		if (requestCode == this.request_code && resultCode==((AudioPlayerActivity)context).RESULT_OK) 
		{
			Uri treeUri = null;
			// Get Uri from Storage Access Framework.
			treeUri = resultData.getData();
			String uri_file_path=FileUtil.getFullPathFromTreeUri(treeUri,context);
			Iterator<Map.Entry<Uri,String>> iterator=Global.URI_STRING_HASHMAP.entrySet().iterator();
			while(iterator.hasNext())
			{
				Map.Entry<Uri,String> entry=iterator.next();
				if(entry.getValue().startsWith(uri_file_path))
				{
					iterator.remove();
				}
			}


			Global.URI_STRING_HASHMAP.put(treeUri,uri_file_path);


			// Persist access permissions.
			final int takeFlags = resultData.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
			context.getContentResolver().takePersistableUriPermission(treeUri, takeFlags);
			
			permission_requested=false;
			delete_file_async_task=new DeleteFileAsyncTask();
			delete_file_async_task.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);

		}
		else
		{
			
			print("Permission was not granted");
		}

	}

	
	interface AudioSelectListener
	{
		public void onAudioSelect(Uri data, AudioPOJO audio);
	}
	
	public void setAudioSelectListener(AudioSelectListener listener)
	{
		audioSelectListener=listener;
	}
	

	
	private class ToolBarClickListener implements View.OnClickListener
	{

		@Override
		public void onClick(View p1)
		{
			// TODO: Implement this method
			final Bundle bundle=new Bundle();
			final ArrayList<String> files_selected_array=new ArrayList<>();

			switch(p1.getId())
			{

				case R.id.all_audio_delete:
					if(audio_selected_array.size()<1)
					{
						break;
					}

					DeleteAudioAlertDialog deleteAudioAlertDialog=new DeleteAudioAlertDialog();
					audios_selected_for_delete=new ArrayList<>();
					for(AudioPOJO audio:audio_selected_array)
					{
						files_selected_array.add(audio.getData());
						audios_selected_for_delete.add(audio);

					}

					bundle.putStringArrayList("files_selected_array",files_selected_array);
					deleteAudioAlertDialog.setArguments(bundle);
					deleteAudioAlertDialog.setDeleteAudioDialogListener(new DeleteAudioAlertDialog.DeleteAudioAlertDialogListener()
						{
							public void onSelectOK()
							{

								final DeleteAudioDialog deleteAudioDialog=new DeleteAudioDialog();
								deleteAudioDialog.setDeleteAudioCompleteListener(new DeleteAudioDialog.DeleteAudioCompleteListener()
									{
										public void onDeleteComplete()
										{
											deleted_audios=new ArrayList<>();
											for(AudioPOJO audio : audios_selected_for_delete)
											{
												if(!new File(audio.getData()).exists())
												{
													deleted_audios.add(audio);
												}

											}
											remove_audio(deleted_audios);
											AudioPlayerService.AUDIO_QUEUED_ARRAY.removeAll(deleted_audios);
											((AudioPlayerActivity)context).trigger_enable_disable_previous_next_btns();
											send_broadcast(localBroadcastManager);
										}

									});
								deleteAudioDialog.setArguments(bundle);
								deleteAudioDialog.show(((AudioPlayerActivity)context).fm,"");

							}
						});
					deleteAudioAlertDialog.show(((AudioPlayerActivity)context).fm,"deletefilealertdialog");
					clear_selection();
					break;

				case R.id.all_audio_play:
					if(audio_selected_array.size()<1)
					{
						break;
					}
					AudioPlayerService.AUDIO_QUEUED_ARRAY=new ArrayList<>();
					AudioPlayerService.AUDIO_QUEUED_ARRAY.addAll(audio_selected_array);
					if(audioSelectListener!=null && AudioPlayerService.AUDIO_QUEUED_ARRAY.size()!=0)
					{
						AudioPlayerService.CURRENT_PLAY_NUMBER=0;
						AudioPOJO audio=AudioPlayerService.AUDIO_QUEUED_ARRAY.get(AudioPlayerService.CURRENT_PLAY_NUMBER);
						Uri uri=MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
						Uri data=Uri.withAppendedPath(uri,String.valueOf(audio.getId()));
						audioSelectListener.onAudioSelect(data,audio);
					}
					clear_selection();
					((AudioPlayerActivity)context).trigger_enable_disable_previous_next_btns();
					break;

				/*
				case R.id.all_audio_add_q:
					if(AUDIO_SELECTED_ARRAY.size()<1)
					{
						break;
					}
					AudioPlayerService.AUDIO_QUEUED_ARRAY.addAll(AUDIO_SELECTED_ARRAY);
					clear_selection();
					break;
				*/
				case R.id.all_audio_save_list:
					if(audio_selected_array.size()<1)
					{
						break;
					}
					final List<AudioPOJO> audio_selected_list_copy=new ArrayList<>();
					for(AudioPOJO audio:audio_selected_array)
					{

				
						audio_selected_list_copy.add(audio);

					}

					AudioSaveListDialog audioSaveListDialog=new AudioSaveListDialog();
					audioSaveListDialog.setSaveAudioListListener(new AudioSaveListDialog.SaveAudioListListener()
						{
							public void save_audio_list(String list_name)
							{
								if(list_name==null)
								{

									SaveNewAudioListDialog saveNewAudioListDialog=new SaveNewAudioListDialog();
									saveNewAudioListDialog.setOnSaveAudioListener(new SaveNewAudioListDialog.OnSaveAudioListListener()
										{
											public void save_audio_list(String list_name)
											{

												((AudioPlayerActivity)context).audioDatabaseHelper.createTable(list_name);
												((AudioPlayerActivity)context).audioDatabaseHelper.insert(list_name,audio_selected_list_copy);
												AudioPlayerActivity.AUDIO_SAVED_LIST.add(list_name);
												((AudioPlayerActivity)context).trigger_audio_list_saved_listener();

												
												

												print("'"+list_name+ "' audio list created");
												
											}

										});
									saveNewAudioListDialog.show(((AudioPlayerActivity)context).getSupportFragmentManager(),"saveaudiolist_dialog");

								}
								else if(list_name.equals(""))
								{
									AudioPlayerService.AUDIO_QUEUED_ARRAY.addAll(audio_selected_list_copy);
									
								}
								else
								{

									if(AudioPlayerActivity.AUDIO_SAVED_LIST.contains(list_name))
									{
										
										((AudioPlayerActivity)context).audioDatabaseHelper.insert(list_name,audio_selected_list_copy);
									}

								}
								((AudioPlayerActivity)context).trigger_enable_disable_previous_next_btns();
							}
						});


					audioSaveListDialog.show(((AudioPlayerActivity)context).getSupportFragmentManager(),"");
					clear_selection();
			
					break;
				case R.id.all_audio_overflow:
					if(audio_selected_array.size()<1)
					{
						break;
					}
					listPopWindow.show();
					break;
				case R.id.all_audio_select:
					if(mselecteditems.size()<num_all_audio)
					{
						mselecteditems=new SparseBooleanArray();
						audio_selected_array=new ArrayList<>();
						for(int i=0;i<num_all_audio;i++)
						{
							mselecteditems.put(i,true);
							audio_selected_array.add(audio_list.get(i));
						}
						
						audioListRecyclerViewAdapter.notifyDataSetChanged();
					}
					else
					{
						clear_selection();
					}
					audio_select_btn.setText(mselecteditems.size()+"/"+num_all_audio);
					break;
				default:
					clear_selection();
					break;

			}
			

		}
	
	}
	

	public void remove_audio(List<File> list)
	{
		for(File audio: list)
		{
			String path=audio.getAbsolutePath();
			for(AudioPOJO a:audio_list)
			{
				if(a.getData()==path)
				{
					audio_list.remove(a);
					break;
				}
			}
		}
		clear_selection();
	
	}
	
	
	public void remove_audio(ArrayList<AudioPOJO> list)
	{
		for(AudioPOJO audio: list)
		{
			int id=audio.getId();
			for(AudioPOJO a:audio_list)
			{
				if(a.getId()==id)
				{
					audio_list.remove(a);
					break;
				}
			}
		}
		clear_selection();
		
	}
	
	private void send_broadcast(LocalBroadcastManager manager)
	{

		Intent intent=new Intent();
		intent.setAction(MainActivity.FILE_DELETE_INTENT_ACTION);
		intent.putExtra("deleted",true);
		manager.sendBroadcast(intent);
	}
	
	public void clear_selection()
	{
		audio_selected_array=new ArrayList<>();
		mselecteditems=new SparseBooleanArray();
		audioListRecyclerViewAdapter.notifyDataSetChanged();
	
	
		bottom_toolbar.animate().translationY(bottom_toolbar.getHeight()).setInterpolator(new AccelerateInterpolator(1));
		toolbar_visible=false;
		scroll_distance=0;
		
		
	}

	
	private class ListPopupWindowClickListener implements AdapterView.OnItemClickListener
	{

		@Override
		public void onItemClick(AdapterView<?> p1, View p2, int p3, long p4)
		{
			// TODO: Implement this method
			final Bundle bundle=new Bundle();
			final ArrayList<String> files_selected_array=new ArrayList<>();
			
			switch(p3)
			{


				case 0:
					
					
					if(audio_selected_array.size()<1)
					{
						break;
					}
					ArrayList<File> file_list=new ArrayList<>();
					for(AudioPOJO audio:audio_selected_array)
					{
						file_list.add(new File(audio.getData()));
					}
					
					try
					{
						FileIntentDispatch.sendFile(((AudioPlayerActivity)context),file_list);
					}
					catch(IOException e){}
					break;
					
				case 1:
					
					
					if(audio_selected_array.size()<1)
					{
						break;
					}
					for(AudioPOJO audio:audio_selected_array)
					{
						files_selected_array.add(audio.getData());
					}
					bundle.putStringArrayList("files_selected_array",files_selected_array);
					PropertiesDialog propertiesDialog=new PropertiesDialog();
					propertiesDialog.setArguments(bundle);
					propertiesDialog.show(((AudioPlayerActivity)context).getSupportFragmentManager(),"properties_dialog");
					break;
					
		
				default:
					break;

			}
			clear_selection();
			listPopWindow.dismiss();
		}



	}

	public class AudioListRecyclerViewAdapter extends RecyclerView.Adapter <AudioListRecyclerViewAdapter.ViewHolder>
	{


		class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener, AdapterView.OnLongClickListener
		{
			AudioListRecyclerViewItem view;
			int pos;

			ViewHolder (AudioListRecyclerViewItem view)
			{

				super(view);
				this.view=view;

				view.setOnClickListener(this);
				view.setOnLongClickListener(this);

			}


			@Override
			public void onClick(View p1)
			{
				pos=getAdapterPosition();
				if(mselecteditems.size()>0)
				{

					onLongClickProcedure(p1);
					

				}
				else 
				{
					AudioPOJO audio=audio_list.get(pos);
					
					int id=audio.getId();
					Uri uri=MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
					Uri data=Uri.withAppendedPath(uri,String.valueOf(id));
					if(audioSelectListener!=null)
					{
						audioSelectListener.onAudioSelect(data,audio);
					}
					
					if(!whether_audios_set_to_current_list)
					{
						AudioPlayerService.AUDIO_QUEUED_ARRAY=new ArrayList<>();
						AudioPlayerService.AUDIO_QUEUED_ARRAY=audio_list;
						whether_audios_set_to_current_list=true;
					}
					
					
					AudioPlayerService.CURRENT_PLAY_NUMBER=pos;
					
					((AudioPlayerActivity)context).trigger_enable_disable_previous_next_btns();
					
				}

			}


			@Override
			public boolean onLongClick(View p1)
			{

				onLongClickProcedure(p1);
				return true;
			}

			private void onLongClickProcedure(View v)
			{
				pos=getAdapterPosition();

				if(mselecteditems.get(pos,false))
				{
					mselecteditems.delete(pos);
					
					v.setSelected(false);
					audio_selected_array.remove(audio_list.get(pos));
					if(mselecteditems.size()>=1)
					{
		
						bottom_toolbar.setVisibility(View.VISIBLE);
						bottom_toolbar.animate().translationY(0).setInterpolator(new DecelerateInterpolator(1));
						toolbar_visible=true;
						scroll_distance=0;
					}


					if(mselecteditems.size()==0)
					{

						bottom_toolbar.animate().translationY(bottom_toolbar.getHeight()).setInterpolator(new AccelerateInterpolator(1));
						toolbar_visible=false;
						scroll_distance=0;
					}
				}
				else
				{
					mselecteditems.put(pos,true);

					//mainActivity.num_selected_btn.setText(MSELECTEDITEMS.size()+"/"+file_list_size);
					v.setSelected(true);
					audio_selected_array.add(audio_list.get(pos));
					
					bottom_toolbar.setVisibility(View.VISIBLE);
					bottom_toolbar.animate().translationY(0).setInterpolator(new DecelerateInterpolator(1));
					toolbar_visible=true;
					scroll_distance=0;
				

					if(mselecteditems.size()>=1)
					{

				
					}

					

				}
				audio_select_btn.setText(mselecteditems.size()+"/"+num_all_audio);
			}
			
		}
		

		@Override
		public ViewHolder onCreateViewHolder(ViewGroup p1, int p2)
		{

			return new ViewHolder(new AudioListRecyclerViewItem(context));

		}

		@Override
		public void onBindViewHolder(AudioListRecyclerViewAdapter.ViewHolder p1, int p2)
		{

			AudioPOJO audio=audio_list.get(p2);
			String title=audio.getTitle();
			String album="Album: "+audio.getAlbum();
			long duration=Long.parseLong(audio.getDuration());
			String duration_str="Duration: "+ (String.format("%d:%02d",duration/1000/60,duration/1000%60));
			String artist="Artists: "+audio.getArtist();
			Bitmap art=audio.getAlbumArt();
			p1.view.setData(title,album,duration_str,artist,art);
			p1.view.setSelected(mselecteditems.get(p2,false));
		}


		@Override
		public int getItemCount()
		{	
			num_all_audio=audio_list.size();
			return num_all_audio;
		}
		
		
		

	}

	
	private class DeleteFileAsyncTask extends AsyncTask<Void,File,Boolean>
	{

		String file_src;
		List<AudioPOJO> src_audio_list=new ArrayList<>();
		int counter_no_files;
		long counter_size_files;
		String current_file_name,sd_uri;
		boolean isFromInternal;
		long file_size_denominator;
		String size_of_files_format;
		ProgressBarFragment pbf=new ProgressBarFragment();

		DeleteFileAsyncTask()
		{

			src_audio_list=audios_selected_for_delete;

		}


		@Override
		protected void onPreExecute()
		{
			// TODO: Implement this method
			pbf.show(((AudioPlayerActivity)context).getSupportFragmentManager(),"progressbar_dialog");

		}

		@Override
		protected void onCancelled(Boolean result)
		{
			// TODO: Implement this method
			super.onCancelled(result);

			if(deleted_audios.size()>0)
			{
				audio_list.removeAll(deleted_audios);
				audioListRecyclerViewAdapter.notifyDataSetChanged();
				Uri media_uri=MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
				android.content.ContentResolver cr=context.getContentResolver();
				for(AudioPOJO audio: deleted_audios)
				{
					cr.delete(media_uri,MediaStore.Audio.Media._ID+" = "+audio.getId(),null);
				}
				
			}

			pbf.dismissAllowingStateLoss();
			asynctask_running=false;

		}

		@Override
		protected Boolean doInBackground(Void...p)
		{
			// TODO: Implement this method
			boolean success=false;
			success=deleteFromLibrarySearch();
			return success;
		}

		private boolean deleteFromLibrarySearch()
		{

			boolean success=false;
			int iteration=0;
			for(AudioPOJO audio : src_audio_list)
			{
				File f=new File(audio.getData());
				if(FileUtil.isFromInternal(f))
				{
					current_file_name=f.getName();
					success=deleteNativeDirectory(f);
					if(success)
					{
						deleted_audios.add(audio);
					}
					audios_selected_for_delete.remove(audio);
				}
				else
				{

					for(Map.Entry<Uri,String> entry : Global.URI_STRING_HASHMAP.entrySet())
					{
						if(f.getAbsolutePath().startsWith(entry.getValue()))
						{
							baseFolder=entry.getValue();
							uri=entry.getKey();
							break;
						}
					}
					if(baseFolder.equals(""))
					{
						cancel(true);
						permission_requested=true;
						SAFPermissionHelperDialog safpermissionhelper=new SAFPermissionHelperDialog();
						safpermissionhelper.set_safpermissionhelperlistener(new SAFPermissionHelperDialog.SafPermissionHelperListener()
							{
								public void onOKBtnClicked()
								{
									checkSAFPermission();
								}

								public void onCancelBtnClicked()
								{
									//dismissAllowingStateLoss();
								}
							});
						safpermissionhelper.show(((AudioPlayerActivity)context).getSupportFragmentManager(),"saf_permission_dialog");

						return false;
					}

					if(isCancelled())
					{
						return false;
					}
					current_file_name=new File(src_audio_list.get(iteration).getData()).getName();
					publishProgress(f);
					success=FileUtil.deleteSAFFile(f,context,uri,baseFolder);
					if(success)
					{
						deleted_audios.add(audio);
					}
					audios_selected_for_delete.remove(audio);

				}
				iteration++;
			}

			return success;
		}


		private boolean deleteFromFolder()
		{
			boolean success=false;
			int iteration=0;
			if(isFromInternal)
			{
				for(AudioPOJO audio:src_audio_list)
				{
					File f=new File(audio.getData());
					current_file_name=f.getName();
					success=deleteNativeDirectory(f);
					if(success)
					{
						deleted_audios.add(audio);
					}
					audios_selected_for_delete.remove(audio);
				}

			}
			else
			{

				for(Map.Entry<Uri,String> entry : Global.URI_STRING_HASHMAP.entrySet())
				{
					if(audios_selected_for_delete.get(0).getData().startsWith(entry.getValue()))
					{
						baseFolder=entry.getValue();
						uri=entry.getKey();
						break;
					}
				}

				if(baseFolder.equals(""))
				{
					cancel(true);
					permission_requested=true;
					SAFPermissionHelperDialog safpermissionhelper=new SAFPermissionHelperDialog();
					safpermissionhelper.set_safpermissionhelperlistener(new SAFPermissionHelperDialog.SafPermissionHelperListener()
						{
							public void onOKBtnClicked()
							{
								checkSAFPermission();
							}

							public void onCancelBtnClicked()
							{
								//dismissAllowingStateLoss();
							}
						});
					safpermissionhelper.show(((AudioPlayerActivity)context).getSupportFragmentManager(),"saf_permission_dialog");
					return false;
				}

				for(AudioPOJO audio:src_audio_list)
				{
					File file=new File(audio.getData());
					if(isCancelled())
					{
					  	return false;
					}
					current_file_name=new File(src_audio_list.get(iteration).getData()).getName();
					publishProgress(file);
					success=FileUtil.deleteSAFFile(file,context,uri,baseFolder);
					if(success)
					{
					 	deleted_audios.add(audio);
					}
					audios_selected_for_delete.remove(audio);
					iteration++;

				}

			}
			return success;
		}


		public boolean deleteNativeDirectory(final File folder) 
		{     
			boolean success=false;

			if (folder.isDirectory())            //Check if folder file is a real folder
			{
				if(isCancelled())
				{
					return false;
				}

				File[] list = folder.listFiles(); //Storing all file name within array
				if (list != null)                //Checking list value is null or not to check folder containts atleast one file
				{
					for (int i = 0; i < list.length; i++)    
					{
						if(isCancelled())
						{
							return false;
						}

						File tmpF = list[i];
						if (tmpF.isDirectory())   //if folder  found within folder remove that folder using recursive method
						{
							success=deleteNativeDirectory(tmpF);
						}

						else
						{

							counter_no_files++;
							counter_size_files+=tmpF.length();
							size_of_files_format=FileUtil.humanReadableByteCount(counter_size_files,Global.BYTE_COUNT_BLOCK_1000);
							publishProgress(tmpF);
							success=tmpF.delete(); //else delete filr
						}

					}
				}

				if(folder.exists())  //delete empty folder
				{
					counter_no_files++;
					publishProgress(folder);
					success=folder.delete();
				}

			}
			else
			{
				if(isCancelled())
				{
					return false;
				}

				counter_no_files++;
				counter_size_files+=folder.length();
				size_of_files_format=FileUtil.humanReadableByteCount(counter_size_files,Global.BYTE_COUNT_BLOCK_1000);
				publishProgress(folder);
				success=folder.delete();
			}

			return success;
		}


		@Override
		protected void onPostExecute(Boolean result)
		{
			// TODO: Implement this method

			super.onPostExecute(result);
			if(deleted_audios.size()>0)
			{
				audio_list.removeAll(deleted_audios);
				audioListRecyclerViewAdapter.notifyDataSetChanged();
				Uri media_uri=MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
				android.content.ContentResolver cr=context.getContentResolver();
				for(AudioPOJO audio: deleted_audios)
				{
					cr.delete(media_uri,MediaStore.Audio.Media._ID+" = "+audio.getId(),null);
				}
				
			}
			pbf.dismissAllowingStateLoss();
			asynctask_running=false;

		}

	}
	
	private enum AsyncTaskStatus
	{
		NOT_YET_STARTED, STARTED, COMPLETED
	}

	
	private void print(String msg)
	{
		Toast.makeText(context,msg,Toast.LENGTH_SHORT).show();
	}
	
}
