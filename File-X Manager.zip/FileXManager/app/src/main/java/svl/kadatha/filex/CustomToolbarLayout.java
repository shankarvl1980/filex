package svl.kadatha.filex;
import android.view.*;
import android.content.*;
import android.util.*;
import android.view.ViewGroup.*;
import android.support.annotation.*;
import android.widget.*;

public class CustomToolbarLayout extends ViewGroup
{
	private Context context;
	private int resource_layout_id;
	private int actionbar_height;
	private int screen_width,screen_height;
	
	CustomToolbarLayout(Context context, @IdRes int layout_id,int screen_width,int screen_height)
	{
		super(context);
		this.context=context;
		resource_layout_id=layout_id;
		this.screen_width=screen_width;
		this.screen_height=screen_height;
		init();
	}
	CustomToolbarLayout(Context context,AttributeSet attr,@IdRes int layout_id,int screen_width,int screen_height)
	{
		super(context,attr);
		this.context=context;
		resource_layout_id=layout_id;
		this.screen_width=screen_width;
		this.screen_height=screen_height;
		init();
	}
	CustomToolbarLayout(Context context,AttributeSet attr,int defStyle, @IdRes int layout_id,int screen_width,int screen_height)
	{
		super(context,attr,defStyle);
		this.context=context;
		resource_layout_id=layout_id;
		this.screen_width=screen_width;
		this.screen_height=screen_height;
		init();
	}
	
	private void init()
	{
		setLayoutParams(new ViewGroup.MarginLayoutParams(ViewGroup.MarginLayoutParams.MATCH_PARENT,ViewGroup.MarginLayoutParams.WRAP_CONTENT));
		LayoutInflater.from(context).inflate(resource_layout_id,this,true);

		TypedValue tv = new TypedValue();
		
		if (context.getTheme().resolveAttribute(android.R.attr.actionBarSize, tv, true))
		{
			actionbar_height  = TypedValue.complexToDimensionPixelSize(tv.data,getResources().getDisplayMetrics());
		}
		
	}
	
	@Override
	protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec)
	{
		// TODO: Implement this method
		int widthUsed=0;
		int toolbar_width;
		int maxHeight=0;
		int icon_dimension=(int)TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP,30,getResources().getDisplayMetrics());
		
		
		if(context.getResources().getBoolean(R.bool.is_land))
		{
			toolbar_width=screen_height;
		}
		else
		{
			toolbar_width=screen_width;
		}
	
		int viewCount=getChildCount();
		
		int heightUsed=0;
		
		int w=toolbar_width/viewCount;
		int toppadding=(actionbar_height-icon_dimension)/2;
		for(int i=0; i<viewCount; i++)
		{
			View child=getChildAt(i);
			
			LinearLayout.LayoutParams params=new LinearLayout.LayoutParams(w,actionbar_height);
			child.setLayoutParams(params);
			child.setPadding(0,toppadding,0,toppadding);
			
			measureChildWithMargins(child,widthMeasureSpec,widthUsed,actionbar_height,heightUsed);
			widthUsed+=child.getMeasuredWidth()+child.getPaddingStart()+child.getPaddingEnd();
			heightUsed=child.getMeasuredHeight()+child.getPaddingTop()+child.getPaddingBottom();
			maxHeight=Math.max(maxHeight,heightUsed);
			
		
		}
		
		maxHeight+=getPaddingTop()+getPaddingBottom();
		setMeasuredDimension(widthMeasureSpec,actionbar_height);
		
	}
/*
	@Override
	protected void measureChildWithMargins(View child, int parentWidthMeasureSpec, int widthUsed, int parentHeightMeasureSpec, int heightUsed)
	{
		// TODO: Implement this method
		MarginLayoutParams lp=(MarginLayoutParams)child.getLayoutParams();
		widthUsed+=widthUsed+lp.leftMargin+lp.rightMargin;
		heightUsed+=heightUsed+lp.topMargin+lp.topMargin;
		int childWidthMeasureSpec=getChildMeasureSpec(parentWidthMeasureSpec,widthUsed,lp.width);
		int childHeightMeasureSpec=getChildMeasureSpec(parentHeightMeasureSpec,heightUsed,lp.height);
		measureChild(child,childWidthMeasureSpec,childHeightMeasureSpec);
		//super.measureChildWithMargins(child, parentWidthMeasureSpec, widthUsed, parentHeightMeasureSpec, heightUsed);
		
	}
	*/
	
	@Override
	protected void onLayout(boolean p1, int p2, int p3, int p4, int p5)
	{
		// TODO: Implement this method
		int child_count=getChildCount();
		int x=0,y=0;
		
		for(int i=0;i<child_count;i++)
		{
			View child=getChildAt(i);
			child.layout(x,y,x+child.getMeasuredWidth(),y+child.getMeasuredHeight());
			x+=child.getMeasuredWidth();
			child.setBackground(context.getResources().getDrawable(R.drawable.select_color2));

		}
		
	}
	
	
	@Override
	protected boolean checkLayoutParams(ViewGroup.LayoutParams p)
	{
		// TODO: Implement this method
		return p instanceof MarginLayoutParams;
	}

	@Override
	protected ViewGroup.LayoutParams generateDefaultLayoutParams()
	{
		// TODO: Implement this method
		return new MarginLayoutParams(MarginLayoutParams.WRAP_CONTENT,MarginLayoutParams.WRAP_CONTENT);
	}

	@Override
	protected ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams p)
	{
		// TODO: Implement this method
		return generateDefaultLayoutParams();
	}

	@Override
	public ViewGroup.LayoutParams generateLayoutParams(AttributeSet attrs)
	{
		// TODO: Implement this method
		return new MarginLayoutParams(context,attrs);
	}
	
	
	
	
}
