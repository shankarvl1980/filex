package svl.kadatha.filex;
import android.support.v4.app.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import android.content.*;
import java.util.*;
import android.widget.TableRow.*;
import android.graphics.drawable.*;
import android.graphics.*;
import android.support.v7.widget.*;
import android.util.*;

public class AudioSaveListDialog extends DialogFragment
{
	private RecyclerView create_list_view, audio_list_view;
	private ViewGroup button_layout;
	private Button cancel_buton;
	private Context context;
	private ArrayList<String> saved_audio_list=new ArrayList<>(), create_add_array=new ArrayList<>();
	private SaveAudioListListener saveAudioListListener;
	//private static SparseBooleanArray MSELECTEDITEMS;
	//private ArrayList<String> SAVED_AUDIO_LIST_SELECTED_ARRAY=new ArrayList<>();
	
	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		// TODO: Implement this method
		
		super.onCreate(savedInstanceState);
		saved_audio_list.addAll(AudioPlayerActivity.AUDIO_SAVED_LIST);
		setRetainInstance(true);
		create_add_array.add("Create new list");
		create_add_array.add("Add to current play list");
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
	{
		// TODO: Implement this method
		context=getContext();
		View v=inflater.inflate(R.layout.audio_save_list_dialog,container,false);
		create_list_view=v.findViewById(R.id.audio_save_list_create_add_recyclerview);
		create_list_view.setAdapter(new CreateAddListRecyclerAdapter(create_add_array));
		create_list_view.setLayoutManager(new LinearLayoutManager(context));
		create_list_view.addItemDecoration(AudioPlayerActivity.DIVIDERITEMDECORATION);
		audio_list_view=v.findViewById(R.id.audio_save_list_savedlist_recyclerview);
		audio_list_view.setAdapter(new AudioSavedListRecyclerAdapter(saved_audio_list));
		audio_list_view.setLayoutManager(new LinearLayoutManager(context));
		audio_list_view.addItemDecoration(AudioPlayerActivity.DIVIDERITEMDECORATION);

		button_layout=v.findViewById(R.id.dialog_audio_save_list_button_layout);
		button_layout.addView(new EquallyDistributedChildrenLayout(context,1));
		cancel_buton=button_layout.findViewById(R.id.first_button);
		cancel_buton.setText("Cancel");
		cancel_buton.setOnClickListener(new View.OnClickListener()
		{
			public void onClick(View vi)
			{
				dismissAllowingStateLoss();
			}
		});
		return v;
	}


	@Override
	public void onResume()
	{
		// TODO: Implement this method
		super.onResume();
		Window window=getDialog().getWindow();
		WindowManager.LayoutParams params=window.getAttributes();
		int height=params.height;
		if(context.getResources().getBoolean(R.bool.is_land))
		{
			window.setLayout(Global.DIALOG_WIDTH,Global.DIALOG_WIDTH);

		}
		else
		{
			window.setLayout(Global.DIALOG_WIDTH,Math.min(height,Global.DIALOG_HEIGHT));

		}

		window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
		
	}
	
	interface SaveAudioListListener
	{
		public void save_audio_list(String list_name);
		
	}
	
	public void setSaveAudioListListener(SaveAudioListListener listener)
	{
		saveAudioListListener=listener;
	}
	
	@Override
	public void onDestroyView()
	{
		// TODO: Implement this method
		if(getDialog()!=null && getRetainInstance())
		{
			getDialog().setDismissMessage(null);
		}
		super.onDestroyView();
	}
	
	private class CreateAddListRecyclerAdapter extends RecyclerView.Adapter<CreateAddListRecyclerAdapter.ViewHolder>
	{
		List<String> audio_list=new ArrayList<>();
		CreateAddListRecyclerAdapter(List<String>list)
		{
			audio_list=list;
		}
		class ViewHolder extends RecyclerView.ViewHolder
		{
			View view;
			TextView textView;
			Integer pos;

			ViewHolder(View v)
			{
				super(v);
				this.view=v;
				textView=view.findViewById(R.id.working_dir_name);
				textView.setGravity(Gravity.CENTER);
				view.setOnClickListener(new View.OnClickListener()
					{

						public void onClick(View p)
						{
							pos=getAdapterPosition();

							ProgressBarFragment pbf=new ProgressBarFragment();
							pbf.show(((AudioPlayerActivity)context).getSupportFragmentManager(),"");
							if(saveAudioListListener!=null)
							{
								if(pos==0)
								{
									saveAudioListListener.save_audio_list(null);
								}
								else if(pos==1)
								{
									saveAudioListListener.save_audio_list("");
								}


							}
							pbf.dismissAllowingStateLoss();
							dismissAllowingStateLoss();
							
						}

					});


				view.setOnLongClickListener(new View.OnLongClickListener()
					{
						public boolean onLongClick(View p)
						{
							pos=getAdapterPosition();
							return true;

						}
					});




			}

		}

		@Override
		public CreateAddListRecyclerAdapter.ViewHolder onCreateViewHolder(ViewGroup p1, int p2)
		{
			// TODO: Implement this method

			View itemview=LayoutInflater.from(p1.getContext()).inflate(R.layout.working_dir_recyclerview_layout,p1,false);
			return new ViewHolder(itemview);
		}

		@Override
		public void onBindViewHolder(CreateAddListRecyclerAdapter.ViewHolder p1, int p2)
		{
			// TODO: Implement this method
			p1.textView.setText(audio_list.get(p2));

		}

		@Override
		public int getItemCount()
		{
			// TODO: Implement this method
			return audio_list.size();
		}


	}
	
	private class AudioSavedListRecyclerAdapter extends RecyclerView.Adapter<AudioSavedListRecyclerAdapter.ViewHolder>
	{
		List<String> audio_list=new ArrayList<>();
		AudioSavedListRecyclerAdapter(List<String>list)
		{
			audio_list=list;
		}
		class ViewHolder extends RecyclerView.ViewHolder
		{
			View view;
			TextView textView;
			Integer pos;

			ViewHolder(View v)
			{
				super(v);
				this.view=v;
				textView=view.findViewById(R.id.working_dir_name);
				
				view.setOnClickListener(new View.OnClickListener()
					{

						public void onClick(View p)
						{
							pos=getAdapterPosition();
							ProgressBarFragment pbf=new ProgressBarFragment();
							pbf.show(((AudioPlayerActivity)context).getSupportFragmentManager(),"");
							if(saveAudioListListener!=null)
							{
								saveAudioListListener.save_audio_list(audio_list.get(pos));
							}
							pbf.dismissAllowingStateLoss();
							dismissAllowingStateLoss();
						}

					});
				
				
				view.setOnLongClickListener(new View.OnLongClickListener()
					{
						public boolean onLongClick(View p)
						{
							pos=getAdapterPosition();
							return true;

						}
					});




			}

		}

		@Override
		public AudioSavedListRecyclerAdapter.ViewHolder onCreateViewHolder(ViewGroup p1, int p2)
		{
			// TODO: Implement this method
			
			View itemview=LayoutInflater.from(p1.getContext()).inflate(R.layout.working_dir_recyclerview_layout,p1,false);
			return new ViewHolder(itemview);
		}

		@Override
		public void onBindViewHolder(AudioSavedListRecyclerAdapter.ViewHolder p1, int p2)
		{
			// TODO: Implement this method
			p1.textView.setText(audio_list.get(p2));

		}

		@Override
		public int getItemCount()
		{
			// TODO: Implement this method
			return audio_list.size();
		}


	}
	
}
