package svl.kadatha.filex;
import android.app.*;
import android.content.*;
import android.net.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.util.*;
import android.provider.*;
import android.graphics.*;
import android.media.*;
import com.bumptech.glide.*;
import com.bumptech.glide.load.engine.*;
import android.support.v4.content.*;

public class AudioPlayFragment extends android.support.v4.app.Fragment 
{
	private ImageView album_art_imageview,previous_btn,backward_btn,play_pause_btn,forward_btn,next_btn;
	private TextView audio_name_tv,total_time_tv,current_progress_tv;
	private SeekBar seekbar;
	private int total_duration;
	private Handler handler, onserviceconnection_handler,handler_for_art;
	private ServiceConnection service_connection;
	public AudioPlayerService audio_player_service;
	private boolean service_bound;
	private android.support.v7.widget.Toolbar top_toolbar,bottom_toolbar;
	private Context context;
	private ImageView overflow;
	private android.support.v7.widget.ListPopupWindow listPopWindow;
	private ArrayList<ListPopupWindowPOJO> list_popupwindowpojos;
	private List<File> files_selected_for_delete;
	private List<File> deleted_files=new ArrayList<>();
	private boolean permission_requested;
	private String baseFolder="";
	private Uri uri;
	private final int request_code=982;
	private DeleteFileAsyncTask delete_file_async_task;
	private boolean asynctask_running;
	public String audio_file_name="";
	public Bitmap album_art;
	private LocalBroadcastManager localBroadcastManager;
	private LinearLayout seekbar_layout;
	private AsyncTaskStatus asyncTaskStatus;
	
	
	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		// TODO: Implement this method
		super.onCreate(savedInstanceState);
		setRetainInstance(true);
		context=getContext();
		onserviceconnection_handler=new Handler();
		handler_for_art=new Handler();
	
		list_popupwindowpojos=new ArrayList<>();
		list_popupwindowpojos.add(new ListPopupWindowPOJO(R.drawable.delete_icon,"Delete"));
		list_popupwindowpojos.add(new ListPopupWindowPOJO(R.drawable.send_icon,"Send"));
		list_popupwindowpojos.add(new ListPopupWindowPOJO(R.drawable.properties_icon,"Properties"));
		
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
	{
		// TODO: Implement this method
		context=getContext();
		localBroadcastManager=LocalBroadcastManager.getInstance(context);
		View v=inflater.inflate(R.layout.fragment_current_play,container,false);
		handler=new Handler();
		
	
		service_connection=new ServiceConnection()
		{
			public void onServiceConnected(ComponentName component_name, IBinder binder)
			{
				audio_player_service=((AudioPlayerService.AudioBinder)binder).getService();
				audio_player_service.setMediaPlayerPrepareListener(new AudioPlayerService.MediaPlayerServicePrepareListener()
				{
					public void onMediaPrepare()
					{
						total_duration=audio_player_service.get_duration();
						total_time_tv.setText(String.format("%d:%02d",total_duration/1000/60,total_duration/1000%60));
						seekbar.setMax(total_duration);
						play_pause_btn.setImageResource(R.drawable.pause_icon);
					}
				});
				service_bound=true;
				
			}
			
			public void onServiceDisconnected(ComponentName component_nane)
			{
				audio_player_service=null;
				service_bound=false;
			}
		};
		top_toolbar=v.findViewById(R.id.current_play_top_toolbar);
		audio_name_tv=v.findViewById(R.id.current_play_audio_name);
		seekbar_layout=v.findViewById(R.id.audio_player_seekbar_layout);
		seekbar_layout.getLayoutParams().width=Global.SCREEN_WIDTH;
		
		overflow=v.findViewById(R.id.current_play_overflow);
		overflow.setOnClickListener(new View.OnClickListener()
			{
				public void onClick(View v)
				{
				
					listPopWindow.show();
				}
			});

		listPopWindow=new android.support.v7.widget.ListPopupWindow(context);
		listPopWindow.setAdapter(new ListPopupWindowArrayAdapter(context,0,list_popupwindowpojos));
		listPopWindow.setAnchorView(overflow);
		listPopWindow.setWidth(getResources().getDimensionPixelSize(R.dimen.list_popupwindow_width));
		listPopWindow.setModal(true);
		listPopWindow.setOnItemClickListener(new ListPopupWindowClickListener());
		
		
		EquallyDistributedImageButtonsLayout tb_layout =new EquallyDistributedImageButtonsLayout(context,5,Global.SCREEN_WIDTH,Global.SCREEN_HEIGHT);
		int drawables []={R.drawable.previous_icon,R.drawable.backward_icon,R.drawable.play_icon,R.drawable.forward_icon,R.drawable.next_icon};
		tb_layout.setResourceImageDrawables(drawables);
		
		bottom_toolbar=v.findViewById(R.id.current_play_bottom_toolbar);
		bottom_toolbar.addView(tb_layout);
		previous_btn=bottom_toolbar.findViewById(R.id.image_btn_1);
		backward_btn=bottom_toolbar.findViewById(R.id.image_btn_2);
		play_pause_btn=bottom_toolbar.findViewById(R.id.image_btn_3);
		forward_btn=bottom_toolbar.findViewById(R.id.image_btn_4);
		next_btn=bottom_toolbar.findViewById(R.id.image_btn_5);
		
		
		album_art_imageview=v.findViewById(R.id.fragment_current_play_albumart);
		
		total_time_tv=v.findViewById(R.id.audio_player_total_time);
		current_progress_tv=v.findViewById(R.id.audio_player_current_progress);
		seekbar=v.findViewById(R.id.audio_player_seekbar);


		seekbar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener()
			{
				public void onProgressChanged(SeekBar sb, int progress, boolean fromUser)
				{
					if(fromUser)
					{
						audio_player_service.seek_to(progress);
					}

				}

				public void onStartTrackingTouch(SeekBar sb)
				{

				}
				public void onStopTrackingTouch(SeekBar sb)
				{

				}

			});

		previous_btn.setOnClickListener(new View.OnClickListener()
		{
			public void onClick(View v)
			{
				audio_player_service.goto_previous();
			}
		});

		backward_btn.setOnClickListener(new View.OnClickListener()
			{
				public void onClick(View v)
				{
					audio_player_service.move_backward();
				}
			});

		play_pause_btn.setOnClickListener(new View.OnClickListener()
			{
				public void onClick(View v)
				{

					if(audio_player_service.prepared && !audio_player_service.playmode)
					{

						audio_player_service.start();
						play_pause_btn.setImageResource(R.drawable.pause_icon);
						update_position();

					}
					else if(audio_player_service.prepared && audio_player_service.playmode)
					{
						audio_player_service.pause();
						play_pause_btn.setImageResource(R.drawable.play_icon);


					}

				}
			});

		forward_btn.setOnClickListener(new View.OnClickListener()
			{
				public void onClick(View v)
				{
					audio_player_service.move_forward();
				}
			});
		
		next_btn.setOnClickListener(new View.OnClickListener()
		{
			public void onClick(View v)
			{
				audio_player_service.goto_next();
			}
		});

		enable_disable_previous_next_btn();
		
		return v;
	}
	
	

	private String update_position()
	{
		handler.post(new Runnable()
			{
				public void run()
				{
					int current_pos=audio_player_service.get_current_position();
					seekbar.setProgress(current_pos);
					current_progress_tv.setText(String.format("%d:%02d",current_pos/1000/60,current_pos/1000%60));
															 /* TimeUnit.MILLISECONDS.toMinutes((long)current_pos),
															  TimeUnit.MILLISECONDS.toSeconds((long)current_pos)-
															  TimeUnit.MILLISECONDS.toSeconds(TimeUnit.MILLISECONDS.toMinutes((long)current_pos))));
															*/
					
					if(audio_player_service.completed)
					{
						play_pause_btn.setImageResource(R.drawable.play_icon);
						current_progress_tv.setText(String.format("%d:%d",0,00));
						seekbar.setProgress(0);
						handler.removeCallbacks(this);
					}
					handler.postDelayed(this,1000);
					
					
				}

			});

		return null;
	}
	
	

	@Override
	public void onAttach(Activity activity)
	{
		// TODO: Implement this method
		super.onAttach(activity);
		((AudioPlayerActivity)activity).addBroadcastListener(new AudioPlayerActivity.BroadcastListener()
		{
			
			public void onBroadcastReceive(String action)
			{

				switch (action)
				{
					case "previous":
						if(audio_player_service.current_audio!=null)
						{
							setTitleArt(audio_player_service.current_audio.getTitle(),audio_player_service.current_audio.getData(),audio_player_service.current_audio.getAlbumArt());
		
						}
						break;
					case "start_pause":

						if(audio_player_service.prepared && !audio_player_service.playmode)
						{

							
							play_pause_btn.setImageResource(R.drawable.play_icon);
						

						}
						else if(audio_player_service.prepared && audio_player_service.playmode)
						{
				
							play_pause_btn.setImageResource(R.drawable.pause_icon);


						}
						break;
					case "next":
						if(audio_player_service.current_audio!=null)
						{
							setTitleArt(audio_player_service.current_audio.getTitle(),audio_player_service.current_audio.getData(),audio_player_service.current_audio.getAlbumArt());

						}
						break;
					case "stop":
						setTitleArt("",null,null);
						total_time_tv.setText("0.00");
						AudioPlayerActivity.AUDIO_FILE=null;
						break;
					default:
						break;
				}
				
				enable_disable_previous_next_btn();
			}
		});
		
	
	}
	
	public void enable_disable_previous_next_btn()
	{
	
		if(AudioPlayerService.AUDIO_QUEUED_ARRAY.size()==0)
		{
			previous_btn.setEnabled(false);
			previous_btn.setAlpha(100);
			next_btn.setEnabled(false);
			next_btn.setAlpha(100);
			
			return;
			
		}
		if(AudioPlayerService.CURRENT_PLAY_NUMBER<=0)
		{
			previous_btn.setEnabled(false);
			previous_btn.setAlpha(100);
		}
		else
		{
			previous_btn.setEnabled(true);
			previous_btn.setAlpha(255);
		}
		if(AudioPlayerService.CURRENT_PLAY_NUMBER>=AudioPlayerService.AUDIO_QUEUED_ARRAY.size()-1)
		{
			next_btn.setEnabled(false);
			next_btn.setAlpha(100);
		}
		else
		{
			next_btn.setEnabled(true);
			next_btn.setAlpha(255);
		}
		
		
	}

	@Override
	public void onStart()
	{
		// TODO: Implement this method
		super.onStart();
		Intent service_intent=new Intent(context,AudioPlayerService.class);
		service_bound=context.bindService(service_intent,service_connection,Context.BIND_AUTO_CREATE);
		Runnable runnable=new Runnable()
		{
			public void run()
			{
				if(audio_player_service==null)
				{

					onserviceconnection_handler.postDelayed(this,1000);
				}
				else
				{
					String path=AudioPlayerActivity.AUDIO_FILE.getAbsolutePath();
					setTitleArt(AudioPlayerActivity.AUDIO_FILE.getName(),path,((AudioPlayerActivity)context).getAlbumArt(context,path)); // dont try audio_player_service.current_audio, it may not have been instantiated.
					total_duration=audio_player_service.get_duration();
					current_progress_tv.setText(String.format("%d:%d",0,00));
					total_time_tv.setText(String.format("%d:%02d",total_duration/1000/60,total_duration/1000%60));
					
					seekbar.setMax(total_duration);
					if(audio_player_service.playmode)
					{
						play_pause_btn.setImageResource(R.drawable.pause_icon);
					}


					update_position();
					onserviceconnection_handler.removeCallbacks(this);
				}

			}
		};
		onserviceconnection_handler.post(runnable);
		
		
	}

	@Override
	public void onDestroy()
	{
		// TODO: Implement this method
		if(service_bound)
		{
			getActivity().unbindService(service_connection);
			service_bound=false;
		}
		
		super.onDestroy();
	}
	
	public void setTitleArt(String audiofilename,final String audiofilepath,Bitmap art)
	{
		audio_file_name=audiofilename;
		
		album_art=art;
		if(audio_name_tv!=null && album_art_imageview!=null)
		{
	
			set_title_art(audiofilepath);
		}
		else
		{
			handler_for_art.post(new Runnable()
			{
				public void run()
				{
					if(audio_name_tv!=null && album_art_imageview!=null)
					{
						set_title_art(audiofilepath);
						handler_for_art.removeCallbacks(this);
					}
					else
					{
						handler_for_art.postDelayed(this,1000);
					}
				}
			});
		}
	
	}
	
	private void set_title_art(String audiofilepath)
	{
		audio_name_tv.setText(audio_file_name);
		if(album_art==null)
		{
			album_art=((AudioPlayerActivity)context).getAlbumArt(context,audiofilepath);
			if(album_art==null)
			{
				album_art=BitmapFactory.decodeResource(context.getResources(),R.drawable.audio_file_icon);

			}
			album_art_imageview.setImageBitmap(album_art);
		}
		else
		{


			album_art_imageview.setImageBitmap(album_art);
		}
	}
	
	public void checkSAFPermission()
	{

		Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
		startActivityForResult(intent, request_code);

	}


	// @TargetApi(Build.VERSION_CODES.LOLLIPOP)
	@Override
	public final void onActivityResult(final int requestCode, final int resultCode, final Intent resultData) 
	{
		super.onActivityResult(requestCode,resultCode,resultData);
		if (requestCode == this.request_code && resultCode==((AudioPlayerActivity)context).RESULT_OK) 
		{
			Uri treeUri = null;
			// Get Uri from Storage Access Framework.
			treeUri = resultData.getData();
			String uri_file_path=FileUtil.getFullPathFromTreeUri(treeUri,context);
			Iterator<Map.Entry<Uri,String>> iterator=Global.URI_STRING_HASHMAP.entrySet().iterator();
			while(iterator.hasNext())
			{
				Map.Entry<Uri,String> entry=iterator.next();
				if(entry.getValue().startsWith(uri_file_path))
				{
					iterator.remove();
				}
			}


			Global.URI_STRING_HASHMAP.put(treeUri,uri_file_path);


			// Persist access permissions.
			final int takeFlags = resultData.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
			context.getContentResolver().takePersistableUriPermission(treeUri, takeFlags);
			
			permission_requested=false;
			delete_file_async_task=new DeleteFileAsyncTask();
			delete_file_async_task.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);

		}
		else
		{
			//cancel_button.callOnClick();
			print("Permission was not granted");
		}

	}
	
	
	private class ListPopupWindowClickListener implements AdapterView.OnItemClickListener
	{

		@Override
		public void onItemClick(AdapterView<?> p1, View p2, int p3, long p4)
		{
			// TODO: Implement this method
			final Bundle bundle=new Bundle();
			final ArrayList<String> files_selected_array=new ArrayList<>();
			switch(p3)
			{
				
				case 0:
					if(AudioPlayerActivity.AUDIO_FILE==null || !AudioPlayerActivity.AUDIO_FILE.exists())
					{
						print("not able to process");
						break;
					}
					if(!AllAudioListFragment.FULLY_POPULATED)
					{
						print("wait till all audios populated in All Songs tab");
						break;
					}
					DeleteFileAlertDialogOtherActivity deleteFileAlertDialogOtherActivity=new DeleteFileAlertDialogOtherActivity();

					files_selected_array.add(AudioPlayerActivity.AUDIO_FILE.getAbsolutePath());
					bundle.putStringArrayList("files_selected_array",files_selected_array);
					deleteFileAlertDialogOtherActivity.setArguments(bundle);
					deleteFileAlertDialogOtherActivity.setDeleteFileDialogListener(new DeleteFileAlertDialogOtherActivity.DeleteFileAlertDialogListener()
						{
							public void onSelectOK()
							{
								if(!asynctask_running)
								{
									asynctask_running=true;
									files_selected_for_delete=new ArrayList<>();
									deleted_files=new ArrayList<>();
									files_selected_for_delete.add(AudioPlayerActivity.AUDIO_FILE);
									delete_file_async_task=new DeleteFileAsyncTask();
									delete_file_async_task.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
								}

							}
						});
					deleteFileAlertDialogOtherActivity.show(((AudioPlayerActivity)context).getSupportFragmentManager(),"deletefilealertotheractivity");
					break;
				case 1:
					Uri src_uri;
					if(AudioPlayerActivity.AUDIO_FILE.exists())
					{
						src_uri=Uri.fromFile(AudioPlayerActivity.AUDIO_FILE);
					}
					else
					{
						src_uri=((AudioPlayerActivity)context).data;
					}
					if(src_uri==null)
					{
						print("not able to process");
						break;
					}
					ArrayList<Uri> uri_list=new ArrayList<>();
					uri_list.add(src_uri);
					try
					{
						FileIntentDispatch.sendUri(((AudioPlayerActivity)context),uri_list);
					}
					catch(IOException e){}
					break;
				case 2:
					if(AudioPlayerActivity.AUDIO_FILE==null || !AudioPlayerActivity.AUDIO_FILE.exists())
					{
						print("not able to process");
						break;
					}
					files_selected_array.add(AudioPlayerActivity.AUDIO_FILE.getAbsolutePath());
					bundle.putStringArrayList("files_selected_array",files_selected_array);
					PropertiesDialog propertiesDialog=new PropertiesDialog();
					propertiesDialog.setArguments(bundle);
					propertiesDialog.show(((AudioPlayerActivity)context).getSupportFragmentManager(),"properties_dialog");
					break;

				default:
					break;
				
			}
			listPopWindow.dismiss();
		}

	
		
	}
	

	private class DeleteFileAsyncTask extends AsyncTask<Void,File,Boolean>
	{

		String file_src;
		List<File> src_file_list=new ArrayList<>();
		int counter_no_files;
		long counter_size_files;
		String current_file_name,sd_uri;
		boolean isFromInternal;
		long file_size_denominator;
		String size_of_files_format;
		ProgressBarFragment pbf=new ProgressBarFragment();

		DeleteFileAsyncTask()
		{

			src_file_list.addAll(files_selected_for_delete);

		}


		@Override
		protected void onPreExecute()
		{
			// TODO: Implement this method
			pbf.show(((AudioPlayerActivity)context).getSupportFragmentManager(),"progressbar_dialog");

		}

		@Override
		protected void onCancelled(Boolean result)
		{
			// TODO: Implement this method
			super.onCancelled(result);
			
			if(deleted_files.size()>0)
			{
				if(audio_player_service!=null)
				{
					audio_player_service.stop();
				}
				((AudioPlayerActivity)context).trigger_audio_remove_on_delete(deleted_files);
				AudioPlayerActivity.AUDIO_FILE=null;
				for(AudioPOJO audio : AudioPlayerService.AUDIO_QUEUED_ARRAY)
				{
					if(audio.getData().equals(deleted_files.get(0).getAbsolutePath()))
					{
						AudioPlayerService.AUDIO_QUEUED_ARRAY.remove(audio);
						break;
					}
				}

				send_broadcast(localBroadcastManager);
				
			}
			pbf.dismissAllowingStateLoss();
			asynctask_running=false;

		}

		@Override
		protected Boolean doInBackground(Void...p)
		{
			// TODO: Implement this method
			boolean success=false;

			//if(new File(df.getTag()).exists())
			{
				isFromInternal=FileUtil.isFromInternal(files_selected_for_delete.get(0));
				success=deleteFromFolder();
			}
			/*
			 else
			 {
			 library_search=true;
			 success=deleteFromLibrarySearch();
			 }
			 */
			return success;
		}

		private boolean deleteFromLibrarySearch()
		{

			boolean success=false;
			int iteration=0;
			for(File f : src_file_list)
			{
				if(FileUtil.isFromInternal(f))
				{
					current_file_name=f.getName();
					success=deleteNativeDirectory(f);
					if(success)
					{
						deleted_files.add(f);
					}
					files_selected_for_delete.remove(f);
				}
				else
				{

					for(Map.Entry<Uri,String> entry : Global.URI_STRING_HASHMAP.entrySet())
					{
						if(f.getAbsolutePath().startsWith(entry.getValue()))
						{
							baseFolder=entry.getValue();
							uri=entry.getKey();
							break;
						}
					}
					if(baseFolder.equals(""))
					{
						cancel(true);
						permission_requested=true;
						SAFPermissionHelperDialog safpermissionhelper=new SAFPermissionHelperDialog();
						safpermissionhelper.set_safpermissionhelperlistener(new SAFPermissionHelperDialog.SafPermissionHelperListener()
							{
								public void onOKBtnClicked()
								{
									checkSAFPermission();
								}

								public void onCancelBtnClicked()
								{
									//dismissAllowingStateLoss();
								}
							});
						safpermissionhelper.show(((AudioPlayerActivity)context).getSupportFragmentManager(),"saf_permission_dialog");

						return false;
					}

					if(isCancelled())
					{
						return false;
					}
					current_file_name=src_file_list.get(iteration).getName();
					publishProgress(f);
					success=FileUtil.deleteSAFFile(f,context,uri,baseFolder);
					if(success)
					{
						deleted_files.add(f);
					}
					files_selected_for_delete.remove(f);

				}
				iteration++;
			}

			return success;
		}


		private boolean deleteFromFolder()
		{
			boolean success=false;
			int iteration=0;
			if(isFromInternal)
			{
				for(File f:src_file_list)
				{
					current_file_name=f.getName();
					success=deleteNativeDirectory(f);
					if(success)
					{
						deleted_files.add(f);
						
					}
					files_selected_for_delete.remove(f);
				}

			}
			else
			{

				for(Map.Entry<Uri,String> entry : Global.URI_STRING_HASHMAP.entrySet())
				{
					if(files_selected_for_delete.get(0).getAbsolutePath().startsWith(entry.getValue()))
					{
						baseFolder=entry.getValue();
						uri=entry.getKey();
						break;
					}
				}

				if(baseFolder.equals(""))
				{
					cancel(true);
					permission_requested=true;
					SAFPermissionHelperDialog safpermissionhelper=new SAFPermissionHelperDialog();
					safpermissionhelper.set_safpermissionhelperlistener(new SAFPermissionHelperDialog.SafPermissionHelperListener()
						{
							public void onOKBtnClicked()
							{
								checkSAFPermission();
							}

							public void onCancelBtnClicked()
							{
								//dismissAllowingStateLoss();
							}
						});
					safpermissionhelper.show(((AudioPlayerActivity)context).getSupportFragmentManager(),"saf_permission_dialog");
					return false;
				}

				for(File file:src_file_list)
				{
					if(isCancelled())
					{
					  	return false;
					}
					current_file_name=src_file_list.get(iteration).getName();
					publishProgress(file);
					success=FileUtil.deleteSAFFile(file,context,uri,baseFolder);
					if(success)
					{
					 	deleted_files.add(file);
					}
					files_selected_for_delete.remove(file);
					iteration++;

				}

			}
			/*
			if(success)
			{
				Uri media_uri=MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
				android.content.ContentResolver cr=context.getContentResolver();
				cr.delete(media_uri,MediaStore.Audio.Media.DATA+" = "+deleted_files.get(0).getAbsolutePath(),null);
			}
			*/
			return success;
		}


		public boolean deleteNativeDirectory(final File folder) 
		{     
			boolean success=false;

			if (folder.isDirectory())            //Check if folder file is a real folder
			{
				if(isCancelled())
				{
					return false;
				}

				File[] list = folder.listFiles(); //Storing all file name within array
				if (list != null)                //Checking list value is null or not to check folder containts atleast one file
				{
					for (int i = 0; i < list.length; i++)    
					{
						if(isCancelled())
						{
							return false;
						}

						File tmpF = list[i];
						if (tmpF.isDirectory())   //if folder  found within folder remove that folder using recursive method
						{
							success=deleteNativeDirectory(tmpF);
						}

						else
						{

							counter_no_files++;
							counter_size_files+=tmpF.length();
							size_of_files_format=FileUtil.humanReadableByteCount(counter_size_files,false);
							publishProgress(tmpF);
							success=tmpF.delete(); //else delete filr
						}

					}
				}

				if(folder.exists())  //delete empty folder
				{
					counter_no_files++;
					publishProgress(folder);
					success=folder.delete();
				}

			}
			else
			{
				if(isCancelled())
				{
					return false;
				}

				counter_no_files++;
				counter_size_files+=folder.length();
				size_of_files_format=FileUtil.humanReadableByteCount(counter_size_files,false);
				publishProgress(folder);
				success=folder.delete();
			}

			return success;
		}


		@Override
		protected void onPostExecute(Boolean result)
		{
			// TODO: Implement this method

			super.onPostExecute(result);
			if(deleted_files.size()>0)
			{
				if(audio_player_service!=null)
				{
					audio_player_service.stop();
				}
				((AudioPlayerActivity)context).trigger_audio_remove_on_delete(deleted_files);
				AudioPlayerActivity.AUDIO_FILE=null;
				for(AudioPOJO audio : AudioPlayerService.AUDIO_QUEUED_ARRAY)
				{
					if(audio.getData().equals(deleted_files.get(0).getAbsolutePath()))
					{
						AudioPlayerService.AUDIO_QUEUED_ARRAY.remove(audio);
						break;
					}
				}
				
				send_broadcast(localBroadcastManager);
				
			}
			pbf.dismissAllowingStateLoss();
			asynctask_running=false;
		
		}

	}
	
	
	
	private void send_broadcast(LocalBroadcastManager manager)
	{

		Intent intent=new Intent();
		intent.setAction(MainActivity.FILE_DELETE_INTENT_ACTION);
		intent.putExtra("deleted",true);
		manager.sendBroadcast(intent);
	}
	
	private enum AsyncTaskStatus
	{
		NOT_YET_STARTED, STARTED, COMPLETED
	}

	private void print(String msg)
	{
		Toast.makeText(context,msg,Toast.LENGTH_SHORT).show();
	}
}
