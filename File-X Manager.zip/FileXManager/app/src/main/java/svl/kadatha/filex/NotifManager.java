package svl.kadatha.filex;
import android.support.v4.app.*;
import android.app.*;
import android.content.*;
import android.os.*;

public class NotifManager
{
	
	private NotificationCompat.Builder notification_builder;
	private NotificationChannel notification_channel;
	private NotificationManager nm;
	private Context context;
	//int paste_notification_id,delete_notification_id,archive_notification_id;
	//NotificationCompat.InboxStyle inbox_style=new NotificationCompat.InboxStyle();
	
	NotifManager(Context context)
	{
		
		this.context=context;
		nm=(NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);
		notification_builder=new NotificationCompat.Builder(context);
		if(Build.VERSION.SDK_INT>=26)
		{
			notification_channel=new NotificationChannel("nc","notification_channel",2);
			notification_channel.enableLights(true);
			notification_channel.setDescription("nc");
			nm.createNotificationChannel(notification_channel);
		}
		notification_builder
			.setSmallIcon(R.drawable.ic_launcher)
			.setAutoCancel(true);
		
	}
	
	


	public void notify(String notification_content_line, int paste_notification_id)
	{
		/*
		 Intent intent=new Intent(context,BlankActivityForPaste.class);
		 intent.putExtra("tag",tag);
		 intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		 intent.setAction(Long.toString(System.currentTimeMillis()));
		 PendingIntent pi=PendingIntent.getActivity(context,paste_notification_id,intent,PendingIntent.FLAG_UPDATE_CURRENT);
		 notification_builder.setContentIntent(pi)
		 */
		notification_builder.setContentText(notification_content_line)
			.setContentIntent(null);
		nm.notify(paste_notification_id,notification_builder.build());
	}

	public Notification build1(String action,String notification_content_line, int notification_id)
	{
		Intent intent=new Intent(context,ArchiveDeletePasteProgressActivity1.class);
		intent.setAction(action);
		PendingIntent pi=PendingIntent.getActivity(context,notification_id,intent,PendingIntent.FLAG_CANCEL_CURRENT);
		notification_builder.setContentIntent(pi);
		notification_builder.setContentText(notification_content_line);
		return notification_builder.build();
	}
	
	public Notification build2(String action,String notification_content_line, int notification_id)
	{
		Intent intent=new Intent(context,ArchiveDeletePasteProgressActivity2.class);
		intent.setAction(action);
		PendingIntent pi=PendingIntent.getActivity(context,notification_id,intent,PendingIntent.FLAG_CANCEL_CURRENT);
		notification_builder.setContentIntent(pi);
		notification_builder.setContentText(notification_content_line);
		return notification_builder.build();
	}
	
	public Notification build3(String action,String notification_content_line, int notification_id)
	{
		Intent intent=new Intent(context,ArchiveDeletePasteProgressActivity3.class);
		intent.setAction(action);
		PendingIntent pi=PendingIntent.getActivity(context,notification_id,intent,PendingIntent.FLAG_CANCEL_CURRENT);
		notification_builder.setContentIntent(pi);
		notification_builder.setContentText(notification_content_line);
		return notification_builder.build();
	}
	
	public Notification build(String notification_content_line, int notification_id)
	{
		/*
		Intent intent=new Intent(context,ArchiveDeletePasteProgressActivity3.class);
		intent.setAction(action);
		PendingIntent pi=PendingIntent.getActivity(context,delete_notification_id,intent,PendingIntent.FLAG_CANCEL_CURRENT);
		notification_builder.setContentIntent(pi);
		*/
		notification_builder.setContentText(notification_content_line);
		return notification_builder.build();
	}
		
	
}
