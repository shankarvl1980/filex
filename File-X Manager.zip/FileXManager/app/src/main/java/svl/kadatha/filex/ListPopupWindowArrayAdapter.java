package svl.kadatha.filex;
import android.widget.*;
import java.util.*;
import android.view.*;
import android.content.*;

public class ListPopupWindowArrayAdapter extends ArrayAdapter<ListPopupWindowPOJO>
{
	private ArrayList<ListPopupWindowPOJO> listPopupWindowPojos;
	private Context context;

	
	ListPopupWindowArrayAdapter(Context c, int resources, ArrayList<ListPopupWindowPOJO> listPojos)
	{
		
		super(c,resources,listPojos);
		context=c;
		listPopupWindowPojos=listPojos;
		
	}
	
	@Override
	public int getCount()
	{
		// TODO: Implement this method
		return listPopupWindowPojos.size();
	}

	@Override
	public ListPopupWindowPOJO getItem(int position)
	{
		// TODO: Implement this method
		return super.getItem(position);
	}

	

	@Override
	public long getItemId(int p1)
	{
		// TODO: Implement this method
		return 0;
	}

	@Override
	public View getView(int p1, View p2, ViewGroup p3)
	{
		// TODO: Implement this method
		View row_view=p2;
		ViewHolder viewHolder=null;
		if(row_view==null)
		{
			row_view=LayoutInflater.from(context).inflate(R.layout.list_popupwindow_layout,p3,false);
			viewHolder=new ViewHolder();
			viewHolder.menu_icon=row_view.findViewById(R.id.list_popupwindow_layout_iv);
			viewHolder.menu_name=row_view.findViewById(R.id.list_popupwindow_tv);
			row_view.setTag(viewHolder);
		}
		
		else
		{
			viewHolder=(ViewHolder)row_view.getTag();
		}
		ListPopupWindowPOJO currentPojo=listPopupWindowPojos.get(p1);
		viewHolder.menu_icon.setImageDrawable(context.getDrawable(currentPojo.resource_id));
		viewHolder.menu_name.setText(currentPojo.menu_name);
		
		return row_view;
	}

	private static class ViewHolder
	{
		ImageView menu_icon;
		TextView menu_name;
	}

	
	
	
}
