package svl.kadatha.filex;
import android.app.*;
import android.os.*;
import android.content.*;
import java.util.*;
import java.io.*;
import java.util.zip.*;
import android.net.*;

public class ArchiveDeletePasteFileService2 extends Service
{

	String dest_folder,zip_file_path, zip_file_name,action;

	private Context context;
	private DetailFragment df;
	private ArrayList<String> files_selected_array=new ArrayList<>();
	private ArrayList<String> zipentry_selected_array=new ArrayList<>();
	private ArrayList<File> files_selected_for_archive=new ArrayList<>();
	private NotifManager nm;
	private final int notification_id=881;
	int total_no_of_files;
	long total_size_of_files;
	String size_of_files_to_be_archived_copied;
	String size_of_files_archived;
	int counter_no_files;
	long counter_size_files;
	String copied_file_name;
	List<Integer> total_folderwise_no_of_files=new ArrayList<>();
	List<Long> total_folderwise_size_of_files=new ArrayList<>();
	private FileCountSize fileCountSize;
	private ArchiveAsyncTask archiveAsyncTask;
	private UnarchiveAsyncTask unarchiveAsyncTask;
	private String baseFolder="",sourceFolder="";
	private Uri uri,sourceUri;
	private ArchiveDeletePasteBinder binder=new ArchiveDeletePasteBinder();
	private ServiceCompletionListener serviceCompletionListener;
	static boolean SERVICE_COMPLETED=true;
	private String intent_action;


	String parent_dir;
	private DeleteFileAsyncTask delete_file_async_task;
	private ArrayList<File> files_selected_for_delete =new ArrayList<>();
	private List<File> deleted_files=new ArrayList<>();
	private List<Integer> deleted_files_index=new ArrayList<>();
	private ArrayList<Integer> files_selected_index_array=new ArrayList<>();
	boolean isFromInternal;
	String current_file_name,sd_uri;
	long file_size_denominator;
	String size_of_files_format,deleted_file_name;
	private boolean library_search;


	String source_folder;
	boolean copy_result, cut,replace,apply_all;
	private FileIterationTask fileIterationTask;
	boolean permanent_cancel;
	private List<File> files_selected_for_cut_copy=new ArrayList<>();
	private List<File> copied_files=new ArrayList<>();
	//int request_code=103;
	String size_of_files_copied;
	int it;
	String copied_file;
	public static String REPLACE_ACTION="open replace file confirmation dialog";

	private boolean recursive_loop_path,isWritable;


	@Override
	public void onCreate()
	{
		// TODO: Implement this method
		SERVICE_COMPLETED=false;
		super.onCreate();
		context=this;
		nm=new NotifManager(context);
		df=(DetailFragment)MainActivity.FM.findFragmentById(R.id.detail_fragment);
	}

	@Override
	public int onStartCommand(Intent intent, int flags, int startId)
	{
		// TODO: Implement this method
		String notification_content="";
		Bundle bundle=intent.getBundleExtra("bundle");
		intent_action=intent.getAction();
		switch(intent_action)
		{

			case "archive-zip":
				if(bundle!=null)
				{
					dest_folder=bundle.getString("dest_folder");
					zip_file_path=bundle.getString("zip_file_path");
					zip_file_name=bundle.getString("zip_file_name");
					action=bundle.getString("action");
					baseFolder=bundle.getString("baseFolder");
					uri=bundle.getParcelable("uri");
					files_selected_array.addAll(bundle.getStringArrayList("files_selected_array"));
					for(String s:files_selected_array)
					{
						files_selected_for_archive.add(new File(s));
					}
					if(bundle.getStringArrayList("zipentry_selected_array")!=null)
					{
						zipentry_selected_array.addAll(bundle.getStringArrayList("zipentry_selected_array"));
					}


					fileCountSize=new FileCountSize(files_selected_for_archive,true);
					fileCountSize.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
					archiveAsyncTask=new ArchiveAsyncTask();
					archiveAsyncTask.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
					notification_content="Zipping "+zip_file_name+".zip at "+dest_folder;

					startForeground(notification_id,nm.build2(intent_action,notification_content,notification_id));
				}


				break;
			case "archive-unzip":
				if(bundle!=null)
				{
					dest_folder=bundle.getString("dest_folder");
					zip_file_path=bundle.getString("zip_file_path");
					zip_file_name=bundle.getString("zip_file_name");
					action=bundle.getString("action");
					baseFolder=bundle.getString("baseFolder");
					uri=bundle.getParcelable("uri");
					files_selected_array.addAll(bundle.getStringArrayList("files_selected_array"));
					for(String s:files_selected_array)
					{
						files_selected_for_archive.add(new File(s));
					}
					if(bundle.getStringArrayList("zipentry_selected_array")!=null)
					{
						zipentry_selected_array.addAll(bundle.getStringArrayList("zipentry_selected_array"));
					}



					unarchiveAsyncTask=new UnarchiveAsyncTask();
					unarchiveAsyncTask.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
					notification_content="Unzipping "+zip_file_path+" at "+dest_folder;

					startForeground(notification_id,nm.build2(intent_action,notification_content,notification_id));
				}

				break;

			case "delete":
				if(bundle!=null)
				{

					baseFolder=bundle.getString("baseFolder");
					uri=bundle.getParcelable("uri");
					library_search=bundle.getBoolean("library_search");
					files_selected_array.addAll(bundle.getStringArrayList("files_selected_array"));
					files_selected_index_array.addAll(bundle.getIntegerArrayList("files_selected_index_array"));
					for(String s:files_selected_array)
					{
						files_selected_for_delete.add(new File(s));
					}

					parent_dir=files_selected_for_delete.get(0).getParent();


					delete_file_async_task=new DeleteFileAsyncTask();
					delete_file_async_task.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);


					notification_content="Deleting file/s at "+parent_dir;
					startForeground(notification_id,nm.build2(intent_action,notification_content,notification_id));

				}

				break;

			case "paste-cut":
			case "paste-copy":
				if(bundle!=null)
				{
					files_selected_array.addAll(bundle.getStringArrayList("files_selected_array"));
					for(String s: files_selected_array)
					{
						files_selected_for_cut_copy.add(new File(s));
					}
					source_folder=files_selected_for_cut_copy.get(0).getParent();
					dest_folder=bundle.getString("dest_folder");
					baseFolder=bundle.getString("baseFolder");
					sourceFolder=bundle.getString("sourceFolder");
					uri=bundle.getParcelable("uri");
					sourceUri=bundle.getParcelable("sourceUri");
					cut=bundle.getBoolean("cut");
					isWritable=bundle.getBoolean("isWritable");


					fileCountSize=new FileCountSize(files_selected_for_cut_copy,true);
					fileCountSize.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
					fileIterationTask=new FileIterationTask(files_selected_for_cut_copy);
					fileIterationTask.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
					notification_content=(cut?"Moving file/s to "+dest_folder :"Copying file/s to "+dest_folder);
					startForeground(notification_id,nm.build2(intent_action,notification_content,notification_id));

				}
				
				break;

			default:

				stopSelf();
				SERVICE_COMPLETED=true;
				break;

		}


		return START_NOT_STICKY;
	}

	public void onReplaceSelection(boolean r,boolean a_all)
	{
		replace=r;
		apply_all=a_all;
		if(!replace && !apply_all)
		{
			files_selected_for_cut_copy.remove(0);
			files_selected_array.remove(0);
			counter_no_files+=total_folderwise_no_of_files.get(it);
			counter_size_files+=total_folderwise_size_of_files.get(it);
			it++;


		}

		fileIterationTask=new FileIterationTask(files_selected_for_cut_copy);
		fileIterationTask.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);

	}

	@Override
	public IBinder onBind(Intent p1)
	{
		// TODO: Implement this method
		if(binder==null)
		{
			binder=new ArchiveDeletePasteBinder();
		}
		return binder;
	}

	class ArchiveDeletePasteBinder extends Binder
	{
		public ArchiveDeletePasteFileService2 getService()
		{
			return ArchiveDeletePasteFileService2.this;
		}
	}

	public void cancelService()
	{
		switch(intent_action)
		{
			case "archive-zip":
				if(fileCountSize!=null && archiveAsyncTask!=null)
				{
					fileCountSize.cancel(true);
					archiveAsyncTask.cancel(true);
				}

				break;
			case "archive-unzip":
				if(unarchiveAsyncTask!=null)
				{
					unarchiveAsyncTask.cancel(true);
				}
				break;


			case "delete":
				if(delete_file_async_task!=null)
				{
					delete_file_async_task.cancel(true);

				}
				break;

			case "paste-cut":
			case "paste-copy":
				if(fileIterationTask!=null)
				{
					permanent_cancel=true;
					fileIterationTask.cancel(true);
				}
				break;

			default:
				stopSelf();
				break;
		}





	}

	@Override
	public void onDestroy()
	{
		// TODO: Implement this method
		super.onDestroy();
		SERVICE_COMPLETED=true;
	}


	public class ArchiveAsyncTask extends AsyncTask<Void, File,Boolean>
	{

		Iterate iterate=new Iterate();
		String sd_uri;

		@Override
		protected void onPreExecute()
		{

		}

		@Override
		protected void onCancelled(Boolean result)
		{
			// TODO: Implement this method
			super.onCancelled(result);
			df=(DetailFragment)MainActivity.FM.findFragmentById(R.id.detail_fragment);
			File f=new File(dest_folder,zip_file_name+".zip");
			if(f.exists())
			{

				if(FileUtil.isWritable(f))
				{
					FileUtil.deleteNativeFile(f);
				}
				else
				{
					if(baseFolder!="")
					{

						if(dest_folder.startsWith(baseFolder))
						{
							FileUtil.deleteSAFFile(f,context,uri,baseFolder);
						}
					}

				}


				if(df!=null && df.getTag().equals(dest_folder))
				{
					df.adapter.refresh(null);
				}

			}

			stopForeground(true);
			stopSelf();
			if(!ArchiveDeletePasteProgressActivity2.EXIST)
			{
				nm.notify("Could not create "+zip_file_name+".zip",notification_id);
			}


			SERVICE_COMPLETED=true;

		}

		@Override
		protected Boolean doInBackground(Void[] p1)
		{
			// TODO: Implement this method

			File f=new File(dest_folder,zip_file_name+".zip");
			try
			{

				List<File> file_array=new ArrayList<>();
				int size=files_selected_for_archive.size();
				File[] f_array=new File[size];
				for(int i=0;i<size;i++)
				{
					f_array[i]=files_selected_for_archive.get(i);
				}
				iterate.populate(f_array,file_array,false);

				OutputStream outStream=null;
				if(FileUtil.isWritable(f))
				{
					outStream=new FileOutputStream(f);
				}
				else
				{

					if (SystemUtil.isAndroid5()) 
					{
						// Storage Access Framework
						UsefulDocumentFile targetDocument = FileUtil.getDocumentFile1(f, false,context,uri,baseFolder);
						if (targetDocument != null) 
						{
							outStream = context.getContentResolver().openOutputStream(targetDocument.getUri());
						}
					}
					else if (SystemUtil.isKitkat()) 
					{
						// Workaround for Kitkat ext SD card
						Uri uri_= MediaStoreUtil.getUriFromFile(f.getAbsolutePath(),context);
						if (uri_!= null) 
						{
							outStream = context.getContentResolver().openOutputStream(uri_);
						}
					}
					else 
					{
						return false;
					}

				}

				if(outStream!=null)
				{
					BufferedOutputStream bufferedOutputStream=new BufferedOutputStream (outStream);
					ZipOutputStream zipOutputStream=new ZipOutputStream(bufferedOutputStream);
					int lengthParentPath=0;
					try
					{
						if(!zip_file_path.equals(""))
						{
							lengthParentPath=new File(zip_file_path).getParentFile().getCanonicalPath().length();
						}
						int size1=file_array.size();
						for(int i=0;i<size1;i++)
						{
							if(isCancelled())
							{
								return false;
							}
							File file=file_array.get(i);
							counter_no_files++;
							counter_size_files+=file.length();
							size_of_files_archived=FileUtil.humanReadableByteCount(counter_size_files,false);
							publishProgress(file);
							String zipFilePath=(lengthParentPath!=0) ? file.getCanonicalPath().substring(lengthParentPath+1):file.getCanonicalPath().substring(file.getParentFile().getCanonicalPath().length()+1);

							ZipEntry zipEntry;

							if(file.isDirectory())
							{
								zipEntry=new ZipEntry(zipFilePath+File.separator);
								zipOutputStream.putNextEntry(zipEntry);
							}
							else
							{
								zipEntry=new ZipEntry(zipFilePath);
								zipOutputStream.putNextEntry(zipEntry);
								BufferedInputStream bufferedInputStream=new BufferedInputStream(new FileInputStream(file));
								byte [] b=new byte[8192];
								int bytesread;
								while((bytesread=bufferedInputStream.read(b))!=-1)
								{
									zipOutputStream.write(b,0,bytesread);
								}
								bufferedInputStream.close();
							}

						}
						zipOutputStream.closeEntry();
						zipOutputStream.close();
						return true;
					}

					catch(IOException | FileNotFoundException e)
					{
						//print("Exception thrown");
					}
					finally 
					{
						try 
						{
							zipOutputStream.closeEntry();
							zipOutputStream.close();
						}
						catch (Exception e) 
						{
							// ignore exception
						}

					}

				}

			}
			catch(FileNotFoundException|IOException e)
			{
				//print("Exception thrown");
			}

			return false;
		}


		@Override
		protected void onProgressUpdate(File[] file)
		{
			// TODO: Implement this method
			copied_file_name=file[0].getName();

		}

		@Override
		protected void onPostExecute(Boolean result)
		{
			// TODO: Implement this method
			String notification_content;
			df=(DetailFragment)MainActivity.FM.findFragmentById(R.id.detail_fragment);
			if(result)
			{

				if(df!=null && df.getTag().equals(dest_folder))
				{
					File f=new File(dest_folder,zip_file_name+".zip");
					df.adapter.refresh(f);
				}

				notification_content="Created "+zip_file_name+".zip at "+dest_folder;


			}
			else
			{
				notification_content="Could not create "+zip_file_name+".zip";
			}

			stopForeground(true);
			stopSelf();

			if(!ArchiveDeletePasteProgressActivity2.EXIST)
			{
				nm.notify(notification_content,notification_id);
			}

			if(serviceCompletionListener!=null)
			{
				serviceCompletionListener.onServiceCompletion(intent_action,result,zip_file_name+".zip",dest_folder);
			}



			SERVICE_COMPLETED=true;
		}


	}

	public class UnarchiveAsyncTask extends AsyncTask<Void,String,Boolean>
	{

		File ZipDestFolder;
		ZipFile zipfile=null;
		String sd_uri;
		@Override
		protected void onPreExecute()
		{
			// TODO: Implement this method
			super.onPreExecute();
			if(zip_file_name!=null)
			{
				ZipDestFolder=new File(dest_folder,zip_file_name);
			}
			else
			{
				ZipDestFolder=new File(dest_folder);
			}
		}

		@Override
		protected void onCancelled(Boolean result)
		{
			// TODO: Implement this method
			super.onCancelled(result);
			df=(DetailFragment)MainActivity.FM.findFragmentById(R.id.detail_fragment);
			if(counter_no_files>0)
			{

				if(df!=null && df.getTag().equals(dest_folder))
				{


					df.adapter.refresh(ZipDestFolder);

				}


			}
			else
			{
				if(df!=null && df.archive_view)
				{
					df.clearSelection();
				}
			}

			stopForeground(true);
			stopSelf();

			if(!ArchiveDeletePasteProgressActivity2.EXIST)
			{
				nm.notify("Could not extract "+zip_file_name,notification_id);
			}


			SERVICE_COMPLETED=true;
		}

		@Override
		protected Boolean doInBackground(Void[] p)
		{

			boolean success=false, isWritable=false;

			isWritable=FileUtil.isWritable(ZipDestFolder);
			try
			{
				zipfile=new ZipFile(zip_file_path);
			}
			catch (IOException e)
			{
				return unzip(zip_file_path,ZipDestFolder,isWritable,uri,baseFolder);
			}


			if(zipentry_selected_array.size()!=0)
			{
				for(String s:zipentry_selected_array)
				{
					if(isCancelled())
					{
						return false;
					}
					ZipEntry zipEntry=zipfile.getEntry(s.substring(MainActivity.ARCHIVE_EXTRACT_DIR.getAbsolutePath().length()+1));
					success=read_zipentry(zipEntry,ZipDestFolder,isWritable,uri,baseFolder);

				}

				return success;
			}
			else
			{
				Enumeration zip_entries=zipfile.entries();
				while(zip_entries.hasMoreElements())
				{
					if(isCancelled())
					{
						return false;
					}
					ZipEntry zipEntry=(ZipEntry)zip_entries.nextElement();

					success=read_zipentry(zipEntry,ZipDestFolder,isWritable,uri,baseFolder);

				}


			}
			return success;
		}

		private boolean read_zipentry(ZipEntry zipEntry,File ZipDestFolder,boolean isWritable,Uri uri,String baseFolder)
		{
			InputStream inStream=null;

			try
			{
				inStream=zipfile.getInputStream(zipEntry);

				BufferedInputStream bufferedinStream=new BufferedInputStream(inStream);
				File dir=new File(ZipDestFolder.getAbsolutePath()+File.separator+zipEntry.getName());
				if(zipEntry.isDirectory() && !dir.exists())
				{
					if(isWritable)
					{
						return FileUtil.mkdirsNative(dir);
					}
					else
					{
						return FileUtil.mkdirsSAF(dir,context,uri,baseFolder);
					}

				}
				else if(zipEntry.isDirectory() && dir.exists())
				{
					return true;
				}
				else
				{
					File parent_dir=dir.getParentFile();
					if(!parent_dir.exists())
					{
						if(isWritable)
						{
							FileUtil.mkdirsNative(parent_dir);
						}
						else
						{
							FileUtil.mkdirsSAF(parent_dir,context,uri,baseFolder);
						}

					}
					OutputStream outStream=null;
					if(isWritable)
					{
						outStream=new FileOutputStream(dir);
					}

					else
					{
						if (SystemUtil.isAndroid5())
						{
							// Storage Access Framework
							UsefulDocumentFile targetDocument = FileUtil.getDocumentFile1(dir, false,context,uri,baseFolder);
							if (targetDocument != null) 
							{
								outStream = context.getContentResolver().openOutputStream(targetDocument.getUri());
							}
						}
						else if (SystemUtil.isKitkat()) 
						{
							// Workaround for Kitkat ext SD card
							Uri uri_ = MediaStoreUtil.getUriFromFile(dir.getAbsolutePath(),context);
							if (uri_ != null) 
							{
								outStream = context.getContentResolver().openOutputStream(uri);
							}
						}
						else
						{
							return false;
						}

					}

					if(outStream!=null)
					{

						BufferedOutputStream bufferedoutStream=new BufferedOutputStream(outStream);
						byte[] b=new byte[8192];
						int bytesread;
						while((bytesread=bufferedinStream.read(b))!=-1)
						{
							bufferedoutStream.write(b,0,bytesread);
						}

						bufferedoutStream.close();


					}
					counter_no_files++;
					counter_size_files+=zipEntry.getSize();
					size_of_files_archived=FileUtil.humanReadableByteCount(counter_size_files,false);
					publishProgress(zipEntry.getName());
					bufferedinStream.close();
					return true;
				}


			}
			catch(FileNotFoundException | IOException e)
			{
				return false;
			}

			finally
			{
				try
				{

					if(inStream!=null)
					{
						inStream.close();

					}

				}
				catch(Exception e)
				{
					return false;
				}

			}


		}


		private boolean unzip(String zip_file_path,File ZipDestFolder,boolean isWritable,Uri uri,String baseFolder)
		{
			// TODO: Implement this method
			File f=new File(zip_file_path);
			ZipInputStream zipInputStream=null;


			try
			{
				BufferedInputStream bufferedInputStream=new BufferedInputStream(new FileInputStream(f));
				zipInputStream=new ZipInputStream(bufferedInputStream);

				ZipEntry zipEntry=zipInputStream.getNextEntry();
				while(zipEntry!=null && !isCancelled())
				{
					File dir=new File(ZipDestFolder.getAbsolutePath()+File.separator+zipEntry.getName());
					if(zipEntry.isDirectory() && !dir.exists())
					{
						if(isWritable)
						{
							FileUtil.mkdirsNative(dir);
						}
						else
						{
							FileUtil.mkdirsSAF(dir,context,uri,baseFolder);
						}

					}

					else if(zipEntry.isDirectory() && dir.exists())
					{
						//don't do anything
					}

					else
					{

						File parent_dir=dir.getParentFile();
						if(!parent_dir.exists())
						{
							if(isWritable)
							{
								FileUtil.mkdirsNative(parent_dir);
							}
							else
							{
								FileUtil.mkdirsSAF(parent_dir,context,uri,baseFolder);
							}

						}
						OutputStream outStream=null;

						if(isWritable)
						{
							outStream=new FileOutputStream(dir);
						}

						else
						{
							if (SystemUtil.isAndroid5()) {
								// Storage Access Framework
								UsefulDocumentFile targetDocument = FileUtil.getDocumentFile1(dir, false,context,uri,baseFolder);
								if (targetDocument != null) {
									outStream = context.getContentResolver().openOutputStream(targetDocument.getUri());
								}
							}
							else if (SystemUtil.isKitkat()) {
								// Workaround for Kitkat ext SD card
								Uri uri_ = MediaStoreUtil.getUriFromFile(dir.getAbsolutePath(),context);
								if (uri_ != null) {
									outStream = context.getContentResolver().openOutputStream(uri);
								}
							}
							else {
								return false;
							}

						}

						if(outStream!=null)
						{
							BufferedOutputStream bufferedoutStream=new BufferedOutputStream(outStream);
							byte[] b=new byte[8192];
							int bytesread;
							while((bytesread=zipInputStream.read(b))!=-1)
							{
								bufferedoutStream.write(b,0,bytesread);
								counter_size_files+=bytesread;
							}

							bufferedoutStream.close();
						}


					}
					counter_no_files++;
					size_of_files_archived=FileUtil.humanReadableByteCount(counter_size_files,false);
					publishProgress(zipEntry.getName());
					zipEntry=zipInputStream.getNextEntry();
				}

				zipInputStream.close();
				bufferedInputStream.close();

				return true;

			}

			catch(FileNotFoundException | IOException e)
			{
				return false;
			}
			finally
			{
				try
				{
					if(zipInputStream!=null)
					{
						zipInputStream.close();

					}

				}
				catch(Exception e)
				{

				}
			}

			//return false;

		}


		@Override
		protected void onProgressUpdate(String[] values)
		{
			// TODO: Implement this method
			super.onProgressUpdate(values);
			copied_file_name=values[0];

		}

		@Override
		protected void onPostExecute(Boolean result)
		{
			// TODO: Implement this method
			super.onPostExecute(result);
			String notification_content;
			df=(DetailFragment)MainActivity.FM.findFragmentById(R.id.detail_fragment);
			if (counter_no_files>0)
			{
				//((MainActivity)context).archive_exit();
				//((MainActivity)context).createFragmentTransaction(new File(dest_folder),null);

				if(df!=null && df.getTag().equals(dest_folder))
				{
					df.adapter.refresh(ZipDestFolder);
				}

				notification_content="Unzipped "+zip_file_name+" at "+dest_folder;

			}
			else
			{

				notification_content="Could not extract "+zip_file_name;
			}

			stopForeground(true);
			stopSelf();

			if(!ArchiveDeletePasteProgressActivity2.EXIST)
			{
				nm.notify(notification_content,notification_id);
			}

			if(serviceCompletionListener!=null)
			{
				serviceCompletionListener.onServiceCompletion(intent_action,counter_no_files>0,zip_file_name,dest_folder);
			}


			SERVICE_COMPLETED=true;

		}

	}

	private class DeleteFileAsyncTask extends AsyncTask<Void,File,Boolean>
	{

		String file_src;
		List<File> src_file_list=new ArrayList<>();



		DeleteFileAsyncTask()
		{

			src_file_list.addAll(files_selected_for_delete);

		}


		@Override
		protected void onPreExecute()
		{
			// TODO: Implement this method

		}

		@Override
		protected void onCancelled(Boolean result)
		{
			// TODO: Implement this method
			super.onCancelled(result);

			if(deleted_files_index.size()>0)
			{
				//if(library_search)
				{
					df.adapter.remove_item(deleted_files_index);
					MainActivity.workout_availablespace();
				}
				//else
				{
					//df.adapter.refresh(null);
				}

			}

			stopForeground(true);
			stopSelf();

			if(!ArchiveDeletePasteProgressActivity2.EXIST)
			{
				nm.notify("Could not delete selected file/s at "+parent_dir,notification_id);
			}


			SERVICE_COMPLETED=true;

		}

		@Override
		protected Boolean doInBackground(Void...p)
		{
			// TODO: Implement this method
			boolean success=false;

			if(!library_search)
			{
				isFromInternal=FileUtil.isFromInternal(files_selected_for_delete.get(0));
				success=deleteFromFolder();
			}
			else
			{

				success=deleteFromLibrarySearch();
			}

			return success;
		}

		private boolean deleteFromLibrarySearch()
		{

			boolean success=false;
			int iteration=0;
			int size=src_file_list.size();
			for(int i=0;i<size;i++)
			{
				File f=src_file_list.get(i);
				if(FileUtil.isFromInternal(f))
				{
					current_file_name=f.getName();
					success=deleteNativeDirectory(f);
					if(success)
					{
						deleted_files.add(f);
						deleted_files_index.add(files_selected_index_array.get(i));
					}
					files_selected_for_delete.remove(f);
				}
				else
				{

					if(isCancelled())
					{
						return false;
					}
					current_file_name=src_file_list.get(iteration).getName();
					publishProgress(f);
					success=FileUtil.deleteSAFFile(f,context,uri,baseFolder);
					if(success)
					{
						deleted_files.add(f);
						deleted_files_index.add(files_selected_index_array.get(i));
					}
					files_selected_for_delete.remove(f);

				}
				iteration++;
			}

			return success;
		}


		private boolean deleteFromFolder()
		{
			boolean success=false;
			int iteration=0;
			if(isFromInternal)
			{
				int size=src_file_list.size();
				for(int i=0;i<size;i++)
				{
					File f=src_file_list.get(i);
					current_file_name=f.getName();
					success=deleteNativeDirectory(f);
					if(success)
					{
						deleted_files.add(f);
						deleted_files_index.add(files_selected_index_array.get(i));
					}
					files_selected_for_delete.remove(f);
				}

			}
			else
			{

				int size=src_file_list.size();
				for(int i=0;i<size;i++)
				{
					File file=src_file_list.get(i);
					if(isCancelled())
					{
					  	return false;
					}
					current_file_name=src_file_list.get(iteration).getName();
					publishProgress(file);
					success=FileUtil.deleteSAFFile(file,context,uri,baseFolder);
					if(success)
					{
					 	deleted_files.add(file);
						deleted_files_index.add(files_selected_index_array.get(i));
					}
					files_selected_for_delete.remove(file);
					iteration++;

				}

			}
			return success;
		}


		public boolean deleteNativeDirectory(final File folder) 
		{     
			boolean success=false;

			if (folder.isDirectory())            //Check if folder file is a real folder
			{
				if(isCancelled())
				{
					return false;
				}

				File[] list = folder.listFiles(); //Storing all file name within array
				int size=list.length;
				if (list != null)                //Checking list value is null or not to check folder containts atleast one file
				{
					for (int i = 0; i < size; i++)    
					{
						if(isCancelled())
						{
							return false;
						}

						File tmpF = list[i];
						if (tmpF.isDirectory())   //if folder  found within folder remove that folder using recursive method
						{
							success=deleteNativeDirectory(tmpF);
						}

						else
						{

							counter_no_files++;
							counter_size_files+=tmpF.length();
							size_of_files_format=FileUtil.humanReadableByteCount(counter_size_files,false);
							publishProgress(tmpF);
							success=tmpF.delete(); //else delete filr
						}

					}
				}

				if(folder.exists())  //delete empty folder
				{
					counter_no_files++;
					publishProgress(folder);
					success=folder.delete();
				}

			}
			else
			{
				if(isCancelled())
				{
					return false;
				}

				counter_no_files++;
				counter_size_files+=folder.length();
				size_of_files_format=FileUtil.humanReadableByteCount(counter_size_files,false);
				publishProgress(folder);
				success=folder.delete();
			}

			return success;
		}

		@Override
		protected void onProgressUpdate(File... file)
		{
			// TODO: Implement this method
			super.onProgressUpdate(file);
			deleted_file_name=file[0].getName();

		}

		@Override
		protected void onPostExecute(Boolean result)
		{
			// TODO: Implement this method

			super.onPostExecute(result);
			int s=deleted_files_index.size();
			String notification_content;

			if(s>0)
			{
				//if(library_search)
				{
					df.adapter.remove_item(deleted_files_index);
					MainActivity.workout_availablespace();
				}
				//else
				{
					//df.adapter.refresh(null);
				}
				//if(dialog_hidden)
				{
					notification_content="Deleted selected file/s at "+parent_dir;
				}

			}
			else
			{
				//if(dialog_hidden)
				{
					notification_content="Could not delete selected file/s at "+parent_dir;
				}

			}

			stopForeground(true);
			stopSelf();

			if(!ArchiveDeletePasteProgressActivity2.EXIST)
			{
				nm.notify(notification_content,notification_id);
			}


			if(serviceCompletionListener!=null)
			{
				if(library_search)
				{
					serviceCompletionListener.onServiceCompletion(intent_action,s>0,null,df.getTag());
				}
				else
				{
					serviceCompletionListener.onServiceCompletion(intent_action,s>0,null,parent_dir);
				}

			}


			SERVICE_COMPLETED=true;
		}

	}

	public class FileIterationTask extends AsyncTask<Void,File,Boolean>
	{

		List<File> src_file_list=new ArrayList<>();
		String duplicate_file_name,sd_uri;


		FileIterationTask(List<File> files_to_be_copied)
		{
			src_file_list.addAll(files_to_be_copied);
		}

		@Override
		protected void onPreExecute()
		{
			// TODO: Implement this method
			super.onPreExecute();
		}

		@Override
		protected void onCancelled(Boolean result)
		{
			// TODO: Implement this method
			super.onCancelled(result);

			if(counter_no_files>0)
			{
				int size=copied_files.size();
				if(size>0)
				{
					df.adapter.refresh(copied_files.get(size-1));
				}
				else
				{
					df.adapter.refresh(null);
				}
				if(cut)
				{
					DetailFragment det_frag=(DetailFragment)MainActivity.FM.findFragmentById(R.id.detail_fragment);
					if(det_frag!=null && det_frag.getTag().equals(source_folder))
					{
						det_frag.adapter.refresh(null);
					}
				}
			}



			if(permanent_cancel)
			{
				stopForeground(true);
				stopSelf();
				if(!ArchiveDeletePasteProgressActivity2.EXIST)
				{
					if(cut)
					{
						nm.notify("Could not move selected file/s to "+dest_folder,notification_id);
					}
					else
					{
						nm.notify("Could not copy selected file/s to "+dest_folder,notification_id);
					}
				}


				SERVICE_COMPLETED=true;
			}

		}


		@Override
		protected Boolean doInBackground(Void[] p1)
		{
			// TODO: Implement this method

			if(!new File(dest_folder).exists())
			{
				return false;
			}

			if(src_file_list.size()==0)
			{
				return copy_result;
			}

			String dest_file_names[]=new File(dest_folder).list();
			r:for(File file:src_file_list)
			{

				if(isCancelled()|| file==null)
				{
					return false;
				}
				if((dest_folder+File.separator).startsWith(file.getAbsolutePath()+File.separator))
				{
					recursive_loop_path=true;
					continue;
				}
				boolean duplicate_found=false;
				if(!replace) //dont replace, hence look for duplicate
				{
					for(String dest_file:dest_file_names)
					{
						if(isCancelled() || file==null)
						{
							return false;
						}
						if(dest_file.equals(file.getName()))
						{
							if(apply_all)
							{
								if(it<total_folderwise_size_of_files.size())
								{
									counter_no_files+=total_folderwise_no_of_files.get(it);
									counter_size_files+=total_folderwise_size_of_files.get(it);
									size_of_files_copied=FileUtil.humanReadableByteCount(counter_size_files,false);
								}
								publishProgress(file);
								copied_files.add(file);
								files_selected_for_cut_copy.remove(file);
								files_selected_array.remove(file.getAbsolutePath());
								it++;
								copy_result=true;
								continue r;
							}
							else
							{
								duplicate_found=true;
								duplicate_file_name=dest_file;
								break;
							}

						}
					}
				}

				if(duplicate_found && !replace)
				{
					Intent intent=new Intent(context,ArchiveDeletePasteProgressActivity1.class);
					intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
					intent.putExtra("cut",cut);
					intent.putExtra("REPLACE_ACTION", REPLACE_ACTION);
					intent.putExtra("duplicate_file_name",duplicate_file_name);
					startActivity(intent);

					cancel(true);

				}
				else
				{
					if(isCancelled())
					{
						return false;
					}
					replace=(apply_all) ? replace : false;
					current_file_name=file.getName();
					File destination_file=new File(dest_folder,file.getName());
					if(isWritable)
					{
						boolean isFromInternal=FileUtil.isFromInternal(file);
						if(isFromInternal&&cut)
						{
							if(it<total_folderwise_size_of_files.size())
							{
								counter_no_files+=total_folderwise_no_of_files.get(it);
								counter_size_files+=total_folderwise_size_of_files.get(it);
								size_of_files_copied=FileUtil.humanReadableByteCount(counter_size_files,false);
							}
							publishProgress(file);
							copy_result=copyNativeCutNativeDirectory(file,destination_file,cut);

						}
						else if(!cut)
						{
							copy_result=copyNativeDirectory(file,destination_file);
						}

						else if(!isFromInternal&&cut)
						{


							copy_result=copyNativeDirectory(file,destination_file);
							if(copy_result)
							{
								FileUtil.deleteSAFFile(file,context,sourceUri,sourceFolder);
							}


						}

					}

					else
					{

						boolean isFromInternal=FileUtil.isFromInternal(file);
						if(isFromInternal&&cut)
						{
							copy_result=copySAFCutNativeDirectory(file,destination_file,context,cut,uri,baseFolder);
						}
						else if(!isFromInternal&&cut)
						{
							copy_result=copySAFDirectory(file,destination_file,context,uri,baseFolder);
							if(copy_result)
							{
								FileUtil.deleteSAFFile(file,context,sourceUri,sourceFolder);
							}

						}
						else
						{
							copy_result=copySAFDirectory(file,destination_file,context,uri,baseFolder);

						}


					}
					if(copy_result)
					{
						copied_files.add(file);
					}

					files_selected_for_cut_copy.remove(file);
					files_selected_array.remove(file.getAbsolutePath());
					it++;

				}

			}
			return copy_result;

		}	


		@SuppressWarnings("null")
		public boolean copyNativeCutNativeDirectory(File source, File destination,boolean cut)
		{
			boolean success=false;
			if (source.isDirectory())
			{
				if(isCancelled())
				{
					return false;
				}
				if(!destination.exists() || !destination.isDirectory())
				{
					if(!(success=FileUtil.mkdirsNative(destination)))
					{
						return false;
					}
				}

				String files[] = source.list();
				int size=files.length;
				for (int i=0;i<size;i++)
				{
					String file=files[i];
					if(isCancelled())
					{
						return false;
					}
					File srcFile = new File(source, file);
					File destFile = new File(destination, file);
					success=copyNativeCutNativeDirectory(srcFile, destFile,cut);

				}
				counter_no_files++;

				if(success && cut)
				{
					FileUtil.deleteNativeFile(source);
				}

			}
			else
			{

				if(isCancelled())
				{
					return false;
				}

				counter_no_files++;
				counter_size_files+=source.length();
				size_of_files_copied=FileUtil.humanReadableByteCount(counter_size_files,false);
				publishProgress(source);
				success=FileUtil.copyNativeCutNativeFileNIO(source,destination,cut);
			}
			return success;
		}

		@SuppressWarnings("null")
		public boolean copyNativeDirectory(File source, File destination)
		{
			boolean success=false;
			if (source.isDirectory())
			{
				if(isCancelled())
				{
					return false;
				}
				if(!destination.exists() || !destination.isDirectory())
				{
					if(!(success=FileUtil.mkdirsNative(destination)))
					{
						return false;
					}
				}

				String files[] = source.list();
				int size=files.length;
				for (int i=0;i<size;i++)
				{
					String file=files[i];
					if(isCancelled())
					{
						return false;
					}
					File srcFile = new File(source, file);
					File destFile = new File(destination, file);
					success=copyNativeDirectory(srcFile, destFile);
				}
				counter_no_files++;

			}
			else
			{
				if(isCancelled())
				{
					return false;
				}

				counter_no_files++;
				counter_size_files+=source.length();
				size_of_files_copied=FileUtil.humanReadableByteCount(counter_size_files,false);
				publishProgress(source);
				success=FileUtil.copyNativeFileNIO(source,destination);
			}
			return success;
		}



		@SuppressWarnings("null")
		public boolean copySAFCutNativeDirectory(File source, File destination,Context context,boolean cut,Uri uri,String baseFolder)
		{
			boolean success=false;
			if (source.isDirectory())
			{
				if(isCancelled())
				{
					return false;
				}
				if(!destination.exists() || !destination.isDirectory())
				{
					if(!(success=FileUtil.mkdirSAF(destination,context,uri,baseFolder)))
					{
						return false;
					}

				}

				String files[] = source.list();
				int size=files.length;
				for (int i=0;i<size;i++)
				{
					String file=files[i];
					if(isCancelled())
					{
						return false;
					}
					File srcFile = new File(source, file);
					File destFile = new File(destination, file);
					success=copySAFCutNativeDirectory(srcFile,destFile,context,cut,uri,baseFolder);

				}
				counter_no_files++;

				if(success && cut)
				{
					FileUtil.deleteNativeFile(source);
				}

			}
			else
			{
				if(isCancelled())
				{
					return false;
				}
				counter_no_files++;
				counter_size_files+=source.length();
				size_of_files_copied=FileUtil.humanReadableByteCount(counter_size_files,false);
				publishProgress(source);
				success=FileUtil.copySAFCutNativeFileNIO(source,destination,context,cut,uri,baseFolder);

			}
			return success;
		}


		@SuppressWarnings("null")
		public boolean copySAFDirectory(File source, File destination,Context context,Uri uri,String baseFolder)
		{
			boolean success=false;
			if (source.isDirectory())
			{
				if(isCancelled())
				{
					return false;
				}
				if(!destination.exists() || !destination.isDirectory())
				{
					if(!(success=FileUtil.mkdirSAF(destination,context,uri,baseFolder)))
					{
						return false;
					}
				}

				String files[] = source.list();
				int size=files.length;
				for (int i=0;i<size;i++)
				{
					String file=files[i];
					if(isCancelled())
					{
						return false;
					}
					File srcFile = new File(source, file);
					File destFile = new File(destination, file);
					success=copySAFDirectory(srcFile,destFile,context,uri,baseFolder);
				}
				counter_no_files++;

			}
			else
			{
				if(isCancelled())
				{
					return false;
				}
				counter_no_files++;
				counter_size_files+=source.length();
				size_of_files_copied=FileUtil.humanReadableByteCount(counter_size_files,false);
				publishProgress(source);
				success=FileUtil.copySAFFileNIO(source,destination,context,uri,baseFolder);

			}
			return success;
		}


		@Override
		protected void onProgressUpdate(File[] file)
		{
			// TODO: Implement this method
			super.onProgressUpdate(file);
			copied_file=file[0].getName();

		}

		@Override
		protected void onPostExecute(Boolean result)
		{
			// TODO: Implement this method
			super.onPostExecute(result);
			String notification_content;
			if(counter_no_files>0)
			{
				int size=copied_files.size();
				if(size>0)
				{
					df.adapter.refresh(copied_files.get(size-1));
				}
				else
				{
					df.adapter.refresh(null);
				}
				if(cut)
				{
					DetailFragment det_frag=(DetailFragment)MainActivity.FM.findFragmentById(R.id.detail_fragment);
					if(det_frag!=null && det_frag.getTag().equals(source_folder))
					{
						det_frag.adapter.refresh(null);
					}
				}
				notification_content=(cut?"Moved selected file/s to "+dest_folder :"Copied selected file/s to "+dest_folder);
				if(recursive_loop_path)
				{

				}

			}
			else
			{
				//print(cut?"Selected file/s could not be moved.":"Selected file/s could not be copied.");
				//if(MainActivity.NM.isPasteNotificationVisible(notification_id))
				//if(dialog_hidden)
				{
					notification_content=(cut ? "Could not move selected file/s to "+dest_folder : "Could not copy selected file/s to "+dest_folder);

				}
			}

			stopForeground(true);
			stopSelf();

			if(!ArchiveDeletePasteProgressActivity2.EXIST)
			{
				nm.notify(notification_content,notification_id);
			}

			if(serviceCompletionListener!=null)
			{

				serviceCompletionListener.onServiceCompletion(intent_action,counter_no_files>0,null,dest_folder);

			}



			SERVICE_COMPLETED=true;
		}

	}


	private class FileCountSize extends AsyncTask<Void,Void,Void>
	{

		Integer no_of_files=0;
		Long size_of_files=0L;
		long file_size_denominator;
		List<File> source_list_files=new ArrayList<>();
		boolean include_folder;

		FileCountSize(List<File> source_list_files,boolean include_folder)
		{
			this.source_list_files=source_list_files;
			this.include_folder=include_folder;
		}

		@Override
		protected void onPreExecute()
		{
			// TODO: Implement this method
			super.onPreExecute();
		}

		@Override
		protected Void doInBackground(Void[] p1)
		{
			// TODO: Implement this method
			int size=source_list_files.size();
			for(int i=0;i<size;i++)
			{
				File f=source_list_files.get(i);
				populate(f,include_folder);
				total_folderwise_no_of_files.add(no_of_files);
				total_folderwise_size_of_files.add(size_of_files);

				total_no_of_files+=no_of_files;
				total_size_of_files+=size_of_files;
				size_of_files_to_be_archived_copied=FileUtil.humanReadableByteCount(total_size_of_files,false);
				publishProgress();
				no_of_files=0;
				size_of_files=0L;
			}


			return null;

		}
		private void populate(File f,boolean include_folder)
		{

			if(isCancelled())
			{
				return;
			}

			if(f.isDirectory())
			{

				File[] f_array=f.listFiles();
				if(f_array!=null)
				{
					int size=f_array.length;
					for(int i=0;i<size;i++)
					{

						populate(f_array[i],include_folder);

					}

					if(include_folder)
					{
						no_of_files++;
					}

				}

			}
			else
			{

				no_of_files++;
				size_of_files+=f.length();
			}

		}

		@Override
		protected void onProgressUpdate(Void[] values)
		{
			// TODO: Implement this method
			super.onProgressUpdate(values);


		}

		@Override
		protected void onPostExecute(Void result)
		{
			// TODO: Implement this method
			super.onPostExecute(result);



		}

		@Override
		protected void onCancelled(Void result)
		{
			// TODO: Implement this method
			super.onCancelled(result);
		}


	}

	interface ServiceCompletionListener
	{
		public void onServiceCompletion(String intent_action,boolean service_result,String target, String dest_folder);
	}

	public void setServiceCompletionListener(ServiceCompletionListener listener)
	{
		serviceCompletionListener=listener;
	}
}
