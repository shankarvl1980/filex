package svl.kadatha.filex;
import android.support.v7.app.*;
import android.os.*;
import android.content.*;
import android.widget.*;
import android.view.*;
import android.widget.AbsListView.*;
import java.io.*;

public class ArchiveDeletePasteProgressActivity1 extends AppCompatActivity
{

	private Handler h=new Handler();
	
	private TextView dialog_title,from_label,to_label, from_textview,to_textview,copied_textview;
	private TableRow to_table_row;
	private TextView no_files,size_files;
	private EditText current_file;
	private Button cancel_button,hide_button;
	private ViewGroup buttons_layout;
	private ServiceConnection serviceConnection;
	private ArchiveDeletePasteFileService1 archiveDeletePasteFileService;
	static boolean EXIST;
	private String intent_action;
	

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		// TODO: Implement this method
		
		super.onCreate(savedInstanceState);
		setContentView(R.layout.fragment_cut_copy_delete_archive_progress);
		setFinishOnTouchOutside(false);
		dialog_title=findViewById(R.id.dialog_fragment_cut_copy_title);
		to_table_row=findViewById(R.id.fragment_cut_copy_delete_archive_totablerow);
		from_label=findViewById(R.id.dialog_fragment_cut_copy_delete_from_label);
		to_label=findViewById(R.id.dialog_fragment_cut_copy_delete_to_label);
		from_textview=findViewById(R.id.dialog_fragment_cut_copy_from);
		to_textview=findViewById(R.id.dialog_fragment_cut_copy_to);
		current_file=findViewById(R.id.dialog_fragment_cut_copy_archive_current_file);
		copied_textview=findViewById(R.id.dialog_fragment_copied_file);
		no_files=findViewById(R.id.fragment_cut_copy_delete_archive_no_files);
		size_files=findViewById(R.id.fragment_cut_copy_delete_archive_size_files);
		buttons_layout=findViewById(R.id.fragment_cut_copy_delete_progress_button_layout);
		buttons_layout.addView(new EquallyDistributedChildrenLayout(this,2));
		hide_button=buttons_layout.findViewById(R.id.first_button);
		hide_button.setText("Hide");
		cancel_button=findViewById(R.id.second_button);
		cancel_button.setText("Cancel");
		
		hide_button.setOnClickListener(new View.OnClickListener()
		{
			public void onClick(View v)
			{
				EXIST=false;
				finish();
			}
			
		});
		
		cancel_button.setOnClickListener(new View.OnClickListener()
		{
			public void onClick(View v)
			{
				if(archiveDeletePasteFileService!=null)
				{
					archiveDeletePasteFileService.cancelService();
				}
				print("process cancelled");
				EXIST=false;
				finish();
				
			}
		});
		
		serviceConnection=new ServiceConnection()
		{
			public void onServiceConnected(ComponentName componentName,IBinder binder)
			{
				archiveDeletePasteFileService=((ArchiveDeletePasteFileService1.ArchiveDeletePasteBinder)binder).getService();
				archiveDeletePasteFileService.setServiceCompletionListener(new ArchiveDeletePasteFileService1.ServiceCompletionListener()
					{
						public void onServiceCompletion(String service_action,boolean result ,String target_file, String dest_folder)
						{
							switch(service_action)
							{
								case "archive-zip":
								 	print(result ? "Created "+target_file+" at "+dest_folder : "Could not create "+target_file);
									break;
								
								case "archive-unzip":
									print(result ? "Unzipped "+target_file+" at "+dest_folder : "Could not extract "+target_file);
									break;
									
								case "delete":
									print(result ? "Deleted selected file/s at "+dest_folder : "Could not delete selected file/s at "+dest_folder);
									break;
									
								case "paste-cut":
									print(result ? "Moved selected file/s to "+dest_folder : "Could not move selected file/s to "+dest_folder);
									break;
									
								case "paste-copy":
									print(result ? "Copied selected file/s to "+dest_folder : "Could not copy selected file/s to "+dest_folder);
									break;
							}
						
							finish();
						}

					});
			}

			public void onServiceDisconnected(ComponentName componentName)
			{
				archiveDeletePasteFileService=null;
			}

		};
		
		if(savedInstanceState==null)
		{
			Intent intent=getIntent();
			if(intent!=null)
			{
				intent_action=intent.getAction();
				Bundle bundle=intent.getBundleExtra("bundle");
				if(bundle!=null)
				{
					Intent adp_intent=new Intent(this,ArchiveDeletePasteFileService1.class);
					
					adp_intent.setAction(intent_action);
					adp_intent.putExtra("bundle",bundle);

					if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.O)
					{
						startForegroundService(adp_intent);
					}
					else
					{
						startService(adp_intent);
					}
				}

			}
		}
		else if(savedInstanceState!=null)
		{
			intent_action=savedInstanceState.getString("intent_action");
		}
		
		switch(intent_action)
		{
			case "archive-zip":
				dialog_title.setText("Archiving");
				to_label.setText("Archive File");
				break;
			case "archive-unzip":
				dialog_title.setText("Extracting");
				from_label.setText("Archive File");
				to_label.setText("Output Folder");
				break;
			case "delete":
				dialog_title.setText("Deleting");
				to_table_row.setVisibility(View.GONE);
				break;
			case "paste-cut":
				dialog_title.setText("Moving");
				break;
			case "paste-copy":
				dialog_title.setText("Copying");
				break;
		}
		
	}
	
	@Override
	protected void onNewIntent(Intent intent)
	{
		// TODO: Implement this method
		super.onNewIntent(intent);
		String action=intent.getStringExtra("REPLACE_ACTION");
		if(action!=null && action.equals(ArchiveDeletePasteFileService1.REPLACE_ACTION))
		{

			String duplicate_file_name=intent.getStringExtra("duplicate_file_name");
			FileReplaceConfirmationDialog replaceFileConfirmationDialog=new FileReplaceConfirmationDialog();
			replaceFileConfirmationDialog.setReplaceListener(new FileReplaceConfirmationDialog.FileReplaceListener()
				{
			 		public void onReplaceClick(boolean r, boolean a_all)
			 		{

						if(archiveDeletePasteFileService!=null)
						{
							archiveDeletePasteFileService.onReplaceSelection(r,a_all);
						}
					}

				});
			Bundle b=new Bundle();
			b.putString("duplicate_file_name",duplicate_file_name);

			replaceFileConfirmationDialog.setArguments(b);

			replaceFileConfirmationDialog.show(getSupportFragmentManager(),null);

		}
	}

	@Override
	protected void onStart()
	{
	// TODO: Implement this method
		super.onStart();
		getWindow().setLayout(Global.DIALOG_WIDTH,LayoutParams.WRAP_CONTENT);
		
	}

	
		
		
	@Override
	protected void onResume()
	{
		// TODO: Implement this method
		super.onResume();
		EXIST=true;
		Intent service_intent=new Intent(this,ArchiveDeletePasteFileService1.class);
		bindService(service_intent,serviceConnection,Context.BIND_AUTO_CREATE);

		
		h.post(new Runnable()
			{
				public void run()
				{

					switch(intent_action)
					{
						case "archive-zip":
							if(archiveDeletePasteFileService!=null && archiveDeletePasteFileService.action!=null)
							{
								current_file.setText(archiveDeletePasteFileService.zip_file_name);
								copied_textview.setText(archiveDeletePasteFileService.copied_file_name);

							
								from_textview.setText(archiveDeletePasteFileService.zip_file_path);
								to_textview.setText(archiveDeletePasteFileService.dest_folder+File.separator+archiveDeletePasteFileService.zip_file_name+".zip");

								no_files.setText(archiveDeletePasteFileService.counter_no_files+"/"+archiveDeletePasteFileService.total_no_of_files);
								size_files.setText(archiveDeletePasteFileService.size_of_files_archived+"/"+archiveDeletePasteFileService.size_of_files_to_be_archived_copied);



								
							}
							break;
						
						case "archive-unzip":

							if(archiveDeletePasteFileService!=null && archiveDeletePasteFileService.action!=null)
							{

							
									from_textview.setText(archiveDeletePasteFileService.zip_file_path);
									to_textview.setText(archiveDeletePasteFileService.zip_file_name!=null ? archiveDeletePasteFileService.dest_folder+File.separator+archiveDeletePasteFileService.zip_file_name : archiveDeletePasteFileService.dest_folder);


									no_files.setText("Extracted: "+archiveDeletePasteFileService.counter_no_files + (archiveDeletePasteFileService.counter_no_files<2 ? " file" : " files"));
									size_files.setText("Size: "+archiveDeletePasteFileService.size_of_files_archived);

							}
							break;
							
						case "delete":
							if(archiveDeletePasteFileService!=null && archiveDeletePasteFileService.current_file_name!=null)
							{
								
								from_textview.setText(archiveDeletePasteFileService.parent_dir);
								
								current_file.setText(archiveDeletePasteFileService.current_file_name);
								copied_textview.setText(archiveDeletePasteFileService.deleted_file_name);
								if(archiveDeletePasteFileService.isFromInternal)
								{
									no_files.setText("Deleted: "+archiveDeletePasteFileService.counter_no_files + (archiveDeletePasteFileService.counter_no_files<2 ? " file" : " files"));
									size_files.setText("Size: "+archiveDeletePasteFileService.size_of_files_format);
								}

							}
							
							break;
							
						case "paste-cut":
						case "paste-copy":
							
							if(archiveDeletePasteFileService!=null && archiveDeletePasteFileService.dest_folder!=null)
							{
								
								from_textview.setText(archiveDeletePasteFileService.source_folder);
								to_textview.setText(archiveDeletePasteFileService.dest_folder);

								current_file.setText(archiveDeletePasteFileService.current_file_name);
								copied_textview.setText(archiveDeletePasteFileService.copied_file);
								no_files.setText(archiveDeletePasteFileService.counter_no_files+"/"+archiveDeletePasteFileService.total_no_of_files);
								size_files.setText(archiveDeletePasteFileService.size_of_files_copied+"/"+archiveDeletePasteFileService.size_of_files_to_be_archived_copied);

								//no_files.setText(archiveDeletePasteFileService.counter_no_files+"/"+archiveDeletePasteFileService.total_no_of_files);
								//size_files.setText(archiveDeletePasteFileService.size_of_files_copied+"/"+archiveDeletePasteFileService.size_of_files_to_be_copied);
							}
							break;
							
					}
					
					

					
					if(ArchiveDeletePasteFileService1.SERVICE_COMPLETED)
					{
						h.removeCallbacks(this);
						
					
						finish();
					}
					
					h.postDelayed(this,500);
					
				}
			});
		
	}

	@Override
	protected void onSaveInstanceState(Bundle outState)
	{
		// TODO: Implement this method
		super.onSaveInstanceState(outState);
		outState.putString("intent_action",intent_action);
	}
	
	

	@Override
	protected void onPause()
	{
		// TODO: Implement this method
		super.onPause();
		unbindService(serviceConnection);
		EXIST=false;
		
		
	}

	private void print(String msg)
	{
		Toast.makeText(this,msg,Toast.LENGTH_SHORT).show();
	}
	
}
