package svl.kadatha.filex;
import android.widget.*;
import android.support.v4.app.*;
import android.os.*;
import android.view.*;
import android.content.*;
import java.util.*;
import java.io.*;
import android.widget.AbsListView.*;
import android.graphics.drawable.*;
import android.graphics.*;
import android.support.v7.app.*;

public class DeleteFileAlertDialogOtherActivity extends android.support.v4.app.DialogFragment
{
	
	private TextView dialog_heading_textview,dialog_message_textview,no_files_textview,size_files_textview;
	private EditText new_file_name_edittext;
	private Button okbutton,cancelbutton;

	private ArrayList<String>files_selected_array=new ArrayList<>();
	private ArrayList<File> files_selected_for_delete =new ArrayList<>();
	private FileCountSize fileCountSize;
	private int total_no_of_files;
	private String size_of_files_to_be_deleted;
	private Context context;
	private ViewGroup buttons_layout;
	private DeleteFileAlertDialogListener deleteFileAlertDialogListener;
	private TinyDB tinyDB;
	private int dialog_width;
	
	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		// TODO: Implement this method
		super.onCreate(savedInstanceState);
		this.setRetainInstance(true);
		
		files_selected_array.addAll(getArguments().getStringArrayList("files_selected_array"));
		for(String s:files_selected_array)
		{
			files_selected_for_delete.add(new File(s));
		}
		
		fileCountSize=new FileCountSize(files_selected_for_delete,true);
		fileCountSize.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
	}
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
	{
		// TODO: Implement this method
		//return super.onCreateView(inflater, container, savedInstanceState);
		context=getContext();
		tinyDB=new TinyDB(context);
		dialog_width=tinyDB.getInt("screen_width")*90/100;
		View v=inflater.inflate(R.layout.fragment_create_rename_delete,container,false);
		dialog_heading_textview=v.findViewById(R.id.dialog_fragment_rename_delete_title);
		dialog_message_textview=v.findViewById(R.id.dialog_fragment_rename_delete_message);
		if(files_selected_array.size()==1)
		{
			dialog_message_textview.setText("Are you sure to delete the selected file? '"+new File(files_selected_array.get(0)).getName()+"'");
		}
		else
		{
			dialog_message_textview.setText("Are you sure to delete the selected files? "+files_selected_array.size()+" files");
		}
		
		new_file_name_edittext=v.findViewById(R.id.dialog_fragment_rename_delete_newfilename);
		no_files_textview=v.findViewById(R.id.dialog_fragment_rename_delete_no_of_files);
		size_files_textview=v.findViewById(R.id.dialog_fragment_rename_delete_total_size);
		buttons_layout=v.findViewById(R.id.fragment_create_rename_delete_button_layout);
		buttons_layout.addView(new EquallyDistributedChildrenLayout(context,2));
		okbutton=buttons_layout.findViewById(R.id.first_button);
		okbutton.setText("OK");
		cancelbutton=buttons_layout.findViewById(R.id.second_button);
		cancelbutton.setText("Cancel");
		dialog_heading_textview.setText("Delete");
		new_file_name_edittext.setVisibility(View.GONE);

		okbutton.setOnClickListener(new View.OnClickListener()
			{
				public void onClick(View v)
				{
					/*
					DeleteAudioDialog deleteAudioDialog=new DeleteAudioDialog();
					Bundle bundle=new Bundle();
					bundle.putStringArrayList("files_selected_array",files_selected_array);
					deleteAudioDialog.setArguments(bundle);
					deleteAudioDialog.show(AudioPlayerActivity.FM,"");
					*/
					if(deleteFileAlertDialogListener!=null)
					{
						deleteFileAlertDialogListener.onSelectOK();
					}
					dismissAllowingStateLoss();
					

				}

			});

		cancelbutton.setOnClickListener(new View.OnClickListener()
			{
				public void onClick(View v)
				{
					dismissAllowingStateLoss();
					
				}

			});
			
		if(savedInstanceState!=null)
		{

			no_files_textview.setText("Contains: "+total_no_of_files+ (total_no_of_files<2 ? " file" : " files"));
			size_files_textview.setText("Size: "+size_of_files_to_be_deleted);
		}
		return v;
	}

	@Override
	public void onResume()
	{
		// TODO: Implement this method
		super.onResume();
		Window window=getDialog().getWindow();
		window.setLayout(Global.DIALOG_WIDTH,LayoutParams.WRAP_CONTENT);
		window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
		
	}

	@Override
	public void onDismiss(DialogInterface dialog)
	{
		// TODO: Implement this method
		super.onDismiss(dialog);
		//fileCountSize.cancel(true);
	}

	
	@Override
	public void onDestroyView() {
		if (getDialog() != null && getRetainInstance()) {
			getDialog().setDismissMessage(null);
		}
		super.onDestroyView();

	}

	@Override
	public void onSaveInstanceState(Bundle outState)
	{
		// TODO: Implement this method
		super.onSaveInstanceState(outState);
		outState.putInt("total_no_of_files",total_no_of_files);
		outState.putString("size_of_files_format",size_of_files_to_be_deleted);
	}
	
	public void setDeleteFileDialogListener(DeleteFileAlertDialogListener listener)
	{
		deleteFileAlertDialogListener=listener;
	}
	
	interface DeleteFileAlertDialogListener
	{
		public void onSelectOK();
	}
	
	private void print(String msg)
	{
		Toast.makeText(context,msg,Toast.LENGTH_SHORT).show();
	}
	
	private class FileCountSize extends AsyncTask<Void,Void,Void>
	{


		long file_size_denominator;
		long TOTAL_SIZE_OF_FILES;
		List<File> source_list_files=new ArrayList<>();
		boolean include_folder;

		FileCountSize(ArrayList<File> source_list_files,boolean include_folder)
		{
			this.source_list_files=source_list_files;
			this.include_folder=include_folder;
		}

		@Override
		protected void onPreExecute()
		{
			// TODO: Implement this method
			super.onPreExecute();
		}

		@Override
		protected Void doInBackground(Void[] p1)
		{
			// TODO: Implement this method
			int size=source_list_files.size();
			File[] f_array=new File[size];
			for(int i=0;i<size;i++)
			{
				f_array[i]=source_list_files.get(i);
			}
			populate(f_array,include_folder);
			return null;

		}
		private void populate(File[] source_list_files,boolean include_folder)
		{
			int size=source_list_files.length;
			for(int i=0;i<size;i++)
			{
				File f=source_list_files[i];
				if(isCancelled())
				{
					return;
				}
				Integer no_of_files=0;
				Long size_of_files=0L;
				if(f.isDirectory())
				{

					if(f.list()!=null)
					{
						populate(f.listFiles(),include_folder);


					}
					if(include_folder)
					{
						no_of_files++;
					}

				}
				else
				{

					no_of_files++;
					size_of_files+=f.length();
				}
				total_no_of_files+=no_of_files;
				TOTAL_SIZE_OF_FILES+=size_of_files;
				size_of_files_to_be_deleted=FileUtil.humanReadableByteCount(TOTAL_SIZE_OF_FILES,false);
				publishProgress();

			}


		}

		@Override
		protected void onProgressUpdate(Void[] values)
		{
			// TODO: Implement this method
			super.onProgressUpdate(values);
			if(no_files_textview!=null)
			{
				no_files_textview.setText("Contains: "+total_no_of_files+ (total_no_of_files<2 ? " file" : " files"));
				size_files_textview.setText("Size: "+size_of_files_to_be_deleted);
			}

		}

		@Override
		protected void onPostExecute(Void result)
		{
			// TODO: Implement this method
			super.onPostExecute(result);

		}

		@Override
		protected void onCancelled(Void result)
		{
			// TODO: Implement this method
			super.onCancelled(result);
		}


	}
	
	
}
