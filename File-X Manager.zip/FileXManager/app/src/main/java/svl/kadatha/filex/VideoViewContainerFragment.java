package svl.kadatha.filex;
import android.support.v4.app.*;
import android.os.*;
import android.view.*;
import android.support.v7.app.*;
import android.os.*;
import android.content.*;
import android.net.*;
import android.widget.*;
import android.media.*;
import android.view.animation.*;
import java.util.*;
import android.view.*;
import java.io.*;
import android.graphics.*;
import android.support.v4.view.*;
import com.bumptech.glide.*;
import com.bumptech.glide.load.engine.*;
import android.support.v4.app.*;
import android.util.*;
import android.support.v4.content.*;
import android.support.design.widget.*;

public class VideoViewContainerFragment extends Fragment
{
	private ViewPager viewpager;
	private Context context;

	private int file_selected_idx=0;
	private android.support.v7.widget.Toolbar toolbar;
	private TextView title;
	private ImageView overflow;
	private android.support.v7.widget.ListPopupWindow listPopWindow;
	private ArrayList<ListPopupWindowPOJO> list_popupwindowpojos;
	private List<File> files_selected_for_delete,deleted_files;
	private DeleteFileAsyncTask delete_file_async_task;
	private boolean permission_requested;
	private String baseFolder="";
	private Uri uri;
	private final int request_code=904;
	private Handler handler;
	private Runnable runnable;
	private boolean is_menu_opened;
	private final int delay=4000;
	private boolean asynctask_running;
	private IndexedLinkedHashMap<File,Integer> video_list;
	private Uri data;
	private File currently_shown_file;
	private VideoViewPagerAdapter adapter;
	private String file_path;
	private ProgressBarFragment pbf;
	private LocalBroadcastManager localBroadcastManager;
	private boolean firststart;
	private int floating_button_height;
	private FloatingActionButton floating_back_button;
	
	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		// TODO: Implement this method
		super.onCreate(savedInstanceState);
		setRetainInstance(true);
		context=getContext();
		firststart=true;
		data=((VideoViewActivity)getContext()).data;
		Bundle bundle=getArguments();
		file_path=bundle.getString("file_path");

		currently_shown_file=new File(file_path);

		video_list=new IndexedLinkedHashMap<>();

		File album_dir=currently_shown_file.getParentFile();
		if(album_dir!=null && album_dir.list()!=null)
		{

			File [] sub_files=album_dir.listFiles();
			Arrays.sort(sub_files,FileComparator.FileComparate(Global.SORT));
			pbf=new ProgressBarFragment();
			pbf.show(((VideoViewActivity)context).fm,"");
			int size=sub_files.length;
			for(int i=0; i<size;i++)
			{
				if(!sub_files[i].isDirectory())
				{
					String file_name=sub_files[i].getName();
					String file_ext="";
					int idx=file_name.lastIndexOf(".");
					if(idx!=-1)
					{
						file_ext=file_name.substring(idx+1);
						if(file_ext.matches(Global.VIDEO_REGEX))
						{
							video_list.put(sub_files[i],0);
					
						}
						else if(file_name.equals(currently_shown_file.getName()))
						{
							video_list.put(currently_shown_file,0);
					
						}

					}
					else if(file_name.equals(currently_shown_file.getName()))
					{
						video_list.put(currently_shown_file,0);
			
					}
				}
				

			}
			pbf.dismissAllowingStateLoss();

		}
		else
		{
			video_list.put(currently_shown_file,0);

		}
		file_selected_idx=video_list.getIndexOf(currently_shown_file);
		
		list_popupwindowpojos=new ArrayList<>();
		list_popupwindowpojos.add(new ListPopupWindowPOJO(R.drawable.delete_icon,"Delete"));
		list_popupwindowpojos.add(new ListPopupWindowPOJO(R.drawable.send_icon,"Send"));
		list_popupwindowpojos.add(new ListPopupWindowPOJO(R.drawable.properties_icon,"Properties"));
		
		floating_button_height=(int)TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP,146,context.getResources().getDisplayMetrics());
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
	{
		// TODO: Implement this method
		context=getContext();
		localBroadcastManager=LocalBroadcastManager.getInstance(context);
		View v;
		v=inflater.inflate(R.layout.fragment_video_view_container,container,false);
		
		handler=new Handler();
		viewpager=v.findViewById(R.id.activity_video_view_viewpager);
		toolbar=v.findViewById(R.id.activity_video_toolbar);
		title=v.findViewById(R.id.activity_video_name);
		overflow=v.findViewById(R.id.activity_video_overflow);
		overflow.setOnClickListener(new View.OnClickListener()
			{
				public void onClick(View v)
				{
					is_menu_opened=true;
					listPopWindow.show();
				}
			});
			
		
		listPopWindow=new android.support.v7.widget.ListPopupWindow(context);
		listPopWindow.setAdapter(new ListPopupWindowArrayAdapter(context,0,list_popupwindowpojos));
		listPopWindow.setAnchorView(overflow);
		listPopWindow.setWidth(getResources().getDimensionPixelSize(R.dimen.list_popupwindow_width));
		listPopWindow.setModal(true);
		listPopWindow.setOnItemClickListener(new AdapterView.OnItemClickListener()
			{
				public void onItemClick(AdapterView<?> adapterview, View v, int p1,long p2)
				{
					

					final Bundle bundle=new Bundle();
					final ArrayList<String> files_selected_array=new ArrayList<>();

					switch(p1)
					{
						case 0:
							if(!currently_shown_file.exists())
							{
								print("not able to process");
								break;
							}
							DeleteFileAlertDialogOtherActivity deleteFileAlertDialogOtherActivity=new DeleteFileAlertDialogOtherActivity();

							files_selected_array.add(currently_shown_file.getAbsolutePath());
							bundle.putStringArrayList("files_selected_array",files_selected_array);
							deleteFileAlertDialogOtherActivity.setArguments(bundle);
							deleteFileAlertDialogOtherActivity.setDeleteFileDialogListener(new DeleteFileAlertDialogOtherActivity.DeleteFileAlertDialogListener()
								{
									public void onSelectOK()
									{
										if(!asynctask_running)
										{
											asynctask_running=true;
											files_selected_for_delete=new ArrayList<>();
											deleted_files=new ArrayList<>();
											files_selected_for_delete.add(currently_shown_file);

											delete_file_async_task=new DeleteFileAsyncTask();
											delete_file_async_task.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
										}

									}
								});
							deleteFileAlertDialogOtherActivity.show(((VideoViewActivity)context).fm,"deletefilealertotheractivity");
							break;
						case 1:
							Uri src_uri;
							if(currently_shown_file.exists())
							{
								src_uri=Uri.fromFile(currently_shown_file);
							}
							else
							{
								src_uri=data;
							}
							if(src_uri==null)
							{
								print("not able to process");
								break;
							}
							ArrayList<Uri> uri_list=new ArrayList<>();
							uri_list.add(src_uri);
							try
							{
								FileIntentDispatch.sendUri(context,uri_list);
							}
							catch(IOException e){}
							break;
						case 2:
							if(!currently_shown_file.exists())
							{
								print("not able to process");
								break;
							}
							files_selected_array.add(currently_shown_file.getAbsolutePath());
							bundle.putStringArrayList("files_selected_array",files_selected_array);
							PropertiesDialog propertiesDialog=new PropertiesDialog();
							propertiesDialog.setArguments(bundle);
							propertiesDialog.show(((VideoViewActivity)context).fm,"properties_dialog");
							break;

						default:
							break;


					}

					listPopWindow.dismiss();

				}


			});
		listPopWindow.setOnDismissListener(new PopupWindow.OnDismissListener()
		{
			public void onDismiss()
			{
				is_menu_opened=false;
				handler.removeCallbacks(runnable);
				handler.postDelayed(runnable,delay);
			}

		});
		
		floating_back_button=v.findViewById(R.id.floating_button_video_fragment);
		floating_back_button.setOnClickListener(new View.OnClickListener()
		{
			public void onClick(View p)
			{
				((VideoViewActivity)context).onBackPressed();
			}
			
		});
		
		
		adapter=new VideoViewPagerAdapter(((VideoViewActivity)context).fm,video_list);
		viewpager.setAdapter(adapter);
		viewpager.addOnPageChangeListener(new ViewPager.OnPageChangeListener()
			{
				public void onPageSelected(int p)
				{

					
				}

				public void onPageScrollStateChanged(int p)
				{

				}

				public void onPageScrolled(int p1, float p2, int p3)
				{
					//print(""+p1);
					file_selected_idx=p1;
					currently_shown_file=video_list.getKeyAtIndex(p1);
					title.setText(currently_shown_file.getName());
					

				}
			});

		runnable=new Runnable()
		{
			public void run()
			{
				if(!is_menu_opened)
				{
					toolbar.animate().translationY(-toolbar.getHeight()).setInterpolator(new DecelerateInterpolator(1));
					floating_back_button.animate().translationY(floating_button_height).setInterpolator(new DecelerateInterpolator(1));

				}

			}
		};


		handler.postDelayed(runnable,delay);
		viewpager.setCurrentItem(file_selected_idx);
		
		return v;
	}
	

	public static VideoViewContainerFragment getNewInstance(String file_path)
	{
		VideoViewContainerFragment frag=new VideoViewContainerFragment();
		Bundle bundle=new Bundle();
		bundle.putString("file_path",file_path);
		frag.setArguments(bundle);
		return frag;
	}
	
	public void checkSAFPermission()
	{

		Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
		startActivityForResult(intent, request_code);

	}


	// @TargetApi(Build.VERSION_CODES.LOLLIPOP)
	@Override
	public final void onActivityResult(final int requestCode, final int resultCode, final Intent resultData) 
	{
		super.onActivityResult(requestCode,resultCode,resultData);
		if (requestCode == this.request_code && resultCode==getActivity().RESULT_OK) 
		{
			Uri treeUri = null;
			// Get Uri from Storage Access Framework.
			treeUri = resultData.getData();
			String uri_file_path=FileUtil.getFullPathFromTreeUri(treeUri,context);
			Iterator<Map.Entry<Uri,String>> iterator=Global.URI_STRING_HASHMAP.entrySet().iterator();
			while(iterator.hasNext())
			{
				Map.Entry<Uri,String> entry=iterator.next();
				if(entry.getValue().startsWith(uri_file_path))
				{
					iterator.remove();
				}
			}


			Global.URI_STRING_HASHMAP.put(treeUri,uri_file_path);


			// Persist access permissions.
			final int takeFlags = resultData.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
			context.getContentResolver().takePersistableUriPermission(treeUri, takeFlags);
			
			permission_requested=false;
			delete_file_async_task=new DeleteFileAsyncTask();
			delete_file_async_task.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);

		}
		else
		{
			//cancel_button.callOnClick();
			print("Permission was not granted");
		}

	}

	private class VideoViewPagerAdapter extends FragmentStatePagerAdapter
	{

		IndexedLinkedHashMap<File,Integer> list=new IndexedLinkedHashMap<>();
		

		VideoViewPagerAdapter(FragmentManager fm,IndexedLinkedHashMap<File,Integer> l)
		{
			super(fm);
			this.list=l;
			
			title.setText(currently_shown_file.getName());
		}

		@Override
		public Fragment getItem(int p1)
		{
			// TODO: Implement this method
			VideoViewFragment frag;
			boolean b=firststart;
			File f=video_list.getKeyAtIndex(p1);
			if(f.exists())
			{
				
				
				frag=VideoViewFragment.getNewInstance(f.getAbsolutePath(),video_list.get(f),p1,b);
				firststart=false;
			}
			else
			{
				frag=VideoViewFragment.getNewInstance("",0,p1,b);
				firststart=false;
			}
			frag.setVideoViewClickListener(new VideoViewFragment.VideoViewClickListener()
				{
					public void onVideoViewClick()
					{
						if(toolbar.getGlobalVisibleRect(new Rect()))
						{
							//disappear
							toolbar.animate().translationY(-toolbar.getHeight()).setInterpolator(new DecelerateInterpolator(1)); 
							floating_back_button.animate().translationY(floating_button_height).setInterpolator(new DecelerateInterpolator(1));
							handler.removeCallbacks(runnable);
						}
						else
						{
							//appear
							toolbar.animate().translationY(0).setInterpolator(new AccelerateInterpolator(1)); 
							floating_back_button.animate().translationY(0).setInterpolator(new AccelerateInterpolator(1));
							handler.postDelayed(runnable,delay);
						}
					}
				});
			frag.setVideoPositionListener(new VideoViewFragment.VideoPositionListener()
			{
				public void setPosition(Integer idx, Integer position)
				{
		
					if(video_list.size()>idx) // condition is required, otherwise app crashes, when last video is removed
					{
						
						video_list.put(video_list.getKeyAtIndex(idx),position);
						
					}
					
				}
			});
			
			return frag;
		}

		

		@Override
		public int getCount()
		{
			// TODO: Implement this method
			return list.size();

		}

		@Override
		public int getItemPosition(Object object)
		{
			// TODO: Implement this method
			return POSITION_NONE;
		}

	}
	
	private void send_broadcast(LocalBroadcastManager manager)
	{

		Intent intent=new Intent();
		intent.setAction(MainActivity.FILE_DELETE_INTENT_ACTION);
		intent.putExtra("deleted",true);
		manager.sendBroadcast(intent);
	}

	private class DeleteFileAsyncTask extends AsyncTask<Void,File,Boolean>
	{

		String file_src;
		List<File> src_file_list=new ArrayList<>();
		int counter_no_files;
		long counter_size_files;
		String current_file_name,sd_uri;
		boolean isFromInternal;
		long file_size_denominator;
		String size_of_files_format;
		ProgressBarFragment pbf=new ProgressBarFragment();

		DeleteFileAsyncTask()
		{

			src_file_list.addAll(files_selected_for_delete);

		}


		@Override
		protected void onPreExecute()
		{
			// TODO: Implement this method
			pbf.show(((VideoViewActivity)context).fm,"progressbar_dialog");

		}

		@Override
		protected void onCancelled(Boolean result)
		{
			// TODO: Implement this method
			super.onCancelled(result);
			
			if(deleted_files.size()>0)
			{

				Iterator<Map.Entry<File,Integer>> it=video_list.entrySet().iterator();
				while(it.hasNext())
				{
					Map.Entry<File,Integer> entry=it.next();
					for(File f:deleted_files)
					{
						if(f.getName().equals(entry.getKey().getName()))
						{
							video_list.removeIndex(f);
							it.remove();
						
						}
					}
				}
				adapter.notifyDataSetChanged();
				
				send_broadcast(localBroadcastManager);

			}

			
			
			pbf.dismissAllowingStateLoss();
			asynctask_running=false;

		}

		@Override
		protected Boolean doInBackground(Void...p)
		{
			// TODO: Implement this method
			boolean success=false;

			//if(new File(df.getTag()).exists())
			{
				isFromInternal=FileUtil.isFromInternal(files_selected_for_delete.get(0));
				success=deleteFromFolder();
			}
			/*
			 else
			 {
			 library_search=true;
			 success=deleteFromLibrarySearch();
			 }
			 */
			return success;
		}

		private boolean deleteFromLibrarySearch()
		{

			boolean success=false;
			int iteration=0;
			for(File f : src_file_list)
			{
				if(FileUtil.isFromInternal(f))
				{
					current_file_name=f.getName();
					success=deleteNativeDirectory(f);
					if(success)
					{
						deleted_files.add(f);
					}
					files_selected_for_delete.remove(f);
				}
				else
				{

					for(Map.Entry<Uri,String> entry : Global.URI_STRING_HASHMAP.entrySet())
					{
						if(f.getAbsolutePath().startsWith(entry.getValue()))
						{
							baseFolder=entry.getValue();
							uri=entry.getKey();
							break;
						}
					}
					if(baseFolder.equals(""))
					{
						cancel(true);
						permission_requested=true;
						SAFPermissionHelperDialog safpermissionhelper=new SAFPermissionHelperDialog();
						safpermissionhelper.set_safpermissionhelperlistener(new SAFPermissionHelperDialog.SafPermissionHelperListener()
							{
								public void onOKBtnClicked()
								{
									checkSAFPermission();
								}

								public void onCancelBtnClicked()
								{
									//dismissAllowingStateLoss();
								}
							});
						safpermissionhelper.show(((VideoViewActivity)context).fm,"saf_permission_dialog");

						return false;
					}

					if(isCancelled())
					{
						return false;
					}
					current_file_name=src_file_list.get(iteration).getName();
					publishProgress(f);
					success=FileUtil.deleteSAFFile(f,context,uri,baseFolder);
					if(success)
					{
						deleted_files.add(f);
					}
					files_selected_for_delete.remove(f);

				}
				iteration++;
			}

			return success;
		}


		private boolean deleteFromFolder()
		{
			boolean success=false;
			int iteration=0;
			if(isFromInternal)
			{
				for(File f:src_file_list)
				{
					current_file_name=f.getName();
					success=deleteNativeDirectory(f);
					if(success)
					{
						deleted_files.add(f);
					}
					files_selected_for_delete.remove(f);
				}

			}
			else
			{

				for(Map.Entry<Uri,String> entry : Global.URI_STRING_HASHMAP.entrySet())
				{
					if(files_selected_for_delete.get(0).getAbsolutePath().startsWith(entry.getValue()))
					{
						baseFolder=entry.getValue();
						uri=entry.getKey();
						break;
					}
				}

				if(baseFolder.equals(""))
				{
					cancel(true);
					permission_requested=true;
					SAFPermissionHelperDialog safpermissionhelper=new SAFPermissionHelperDialog();
					safpermissionhelper.set_safpermissionhelperlistener(new SAFPermissionHelperDialog.SafPermissionHelperListener()
						{
							public void onOKBtnClicked()
							{
								checkSAFPermission();
							}

							public void onCancelBtnClicked()
							{
								//dismissAllowingStateLoss();
							}
						});
					safpermissionhelper.show(((VideoViewActivity)context).fm,"saf_permission_dialog");
					return false;
				}

				for(File file:src_file_list)
				{
					if(isCancelled())
					{
					  	return false;
					}
					current_file_name=src_file_list.get(iteration).getName();
					publishProgress(file);
					success=FileUtil.deleteSAFFile(file,context,uri,baseFolder);
					if(success)
					{
					 	deleted_files.add(file);
					}
					files_selected_for_delete.remove(file);
					iteration++;

				}

			}
			return success;
		}


		public boolean deleteNativeDirectory(final File folder) 
		{     
			boolean success=false;

			if (folder.isDirectory())            //Check if folder file is a real folder
			{
				if(isCancelled())
				{
					return false;
				}

				File[] list = folder.listFiles(); //Storing all file name within array
				if (list != null)                //Checking list value is null or not to check folder containts atleast one file
				{
					for (int i = 0; i < list.length; i++)    
					{
						if(isCancelled())
						{
							return false;
						}

						File tmpF = list[i];
						if (tmpF.isDirectory())   //if folder  found within folder remove that folder using recursive method
						{
							success=deleteNativeDirectory(tmpF);
						}

						else
						{

							counter_no_files++;
							counter_size_files+=tmpF.length();
							size_of_files_format=FileUtil.humanReadableByteCount(counter_size_files,false);
							publishProgress(tmpF);
							success=tmpF.delete(); //else delete filr
						}

					}
				}

				if(folder.exists())  //delete empty folder
				{
					counter_no_files++;
					publishProgress(folder);
					success=folder.delete();
				}

			}
			else
			{
				if(isCancelled())
				{
					return false;
				}

				counter_no_files++;
				counter_size_files+=folder.length();
				size_of_files_format=FileUtil.humanReadableByteCount(counter_size_files,false);
				publishProgress(folder);
				success=folder.delete();
			}

			return success;
		}


		@Override
		protected void onPostExecute(Boolean result)
		{
			// TODO: Implement this method

			super.onPostExecute(result);
			if(deleted_files.size()>0)
			{

				
				Iterator<Map.Entry<File,Integer>> it=video_list.entrySet().iterator();
				while(it.hasNext())
				{
					Map.Entry<File,Integer> entry=it.next();
					for(File f:deleted_files)
					{
						if(f.getName().equals(entry.getKey().getName()))
						{
							video_list.removeIndex(f);
							it.remove();
						}
					}
				}
				
	
				adapter.notifyDataSetChanged();
				
				send_broadcast(localBroadcastManager);
				
				if(video_list.size()<1)
				{
					((VideoViewActivity)context).finish();
				}
			}
			pbf.dismissAllowingStateLoss();
			asynctask_running=false;

		}

	}
	

	private void print(String msg)
	{
		Toast.makeText(context,msg,Toast.LENGTH_SHORT).show();
	}
	
}
