package svl.kadatha.filex;
import android.os.*;
import android.view.*;
import android.widget.Gallery.*;
import android.graphics.drawable.*;
import android.graphics.*;
import android.widget.*;
import android.content.*;

public class SAFPermissionHelperDialog extends android.support.v4.app.DialogFragment
{

	private Button ok_button,cancel_button;
	private SafPermissionHelperListener safPermissionHelperListener;
	private ViewGroup buttons_layout;
	private Context context;
	
	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		// TODO: Implement this method
		super.onCreate(savedInstanceState);
		setRetainInstance(true);
		setCancelable(false);
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
	{
		// TODO: Implement this method
		//return super.onCreateView(inflater, container, savedInstanceState);
		context=getContext();
		View v=inflater.inflate(R.layout.fragment_saf_permission_helper,container,false);
		buttons_layout=v.findViewById(R.id.fragment_saf_permission_button_layout);
		buttons_layout.addView(new EquallyDistributedChildrenLayout(context,2));
		ok_button=buttons_layout.findViewById(R.id.first_button);
		ok_button.setText("OK");
		cancel_button=v.findViewById(R.id.second_button);
		cancel_button.setText("Cancel");
		ok_button.setOnClickListener(new View.OnClickListener()
		{
			public void onClick(View v)
			{
				if(safPermissionHelperListener!=null)
				{
					safPermissionHelperListener.onOKBtnClicked();
				}
				dismissAllowingStateLoss();
			}
		});
		
		cancel_button.setOnClickListener(new View.OnClickListener()
		{
			
			public void onClick(View v)
			{
				if(safPermissionHelperListener!=null)
				{
					safPermissionHelperListener.onCancelBtnClicked();
				}
				dismissAllowingStateLoss();
			}
		});
		
		return v;
	}
	
	
	@Override
	public void onResume()
	{
		// TODO: Implement this method
		super.onResume();
		Window window=getDialog().getWindow();
		window.setLayout(Global.DIALOG_WIDTH,LayoutParams.WRAP_CONTENT);
		window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
		
	}

	@Override
	public void onDestroyView() 
	{
		if (getDialog() != null && getRetainInstance()) 
		{
			getDialog().setDismissMessage(null);
		}
		super.onDestroyView();
	}
	
	public void set_safpermissionhelperlistener(SafPermissionHelperListener safpermissionlistener)
	{
		safPermissionHelperListener=safpermissionlistener;
	}
	
	interface SafPermissionHelperListener
	{
		public void onOKBtnClicked();
		public void onCancelBtnClicked();
	}
}
