package svl.kadatha.filex;
import android.widget.*;
import android.content.*;
import android.util.*;
import android.view.*;
import java.io.*;
import android.content.pm.*;
import com.bumptech.glide.*;
import com.bumptech.glide.load.engine.*;
import java.util.zip.*;
import java.text.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;

public class AudioListRecyclerViewItem extends ViewGroup
{
	private Context context;
	private View view;
	private ImageView audioimageview;
	private TextView titletextview, albumtextview, durationtextview,artisttextview;
	private int first_line_font_size,second_line_font_size,imageview_dimension;
	private int totalwidth;
	
	AudioListRecyclerViewItem(Context context)
	{
		super(context);
		this.context=context;
		init();
	}

	AudioListRecyclerViewItem(Context context, AttributeSet attr)
	{
		super(context,attr);
		this.context=context;
		init();
	}

	AudioListRecyclerViewItem(Context context, AttributeSet attr, int defStyle)
	{
		super(context,attr,defStyle);
		this.context=context;
		init();
	}

	private void init()
	{

		setBackground(context.getResources().getDrawable(R.drawable.select_color));

		view=LayoutInflater.from(context).inflate(R.layout.audiolist_recyclerview_layout,this,true);
		audioimageview=view.findViewById(R.id.audio_image);
		titletextview=view.findViewById(R.id.audio_file_title);
		albumtextview=view.findViewById(R.id.audio_file_album);
		durationtextview=view.findViewById(R.id.audio_file_duration);
		artisttextview=view.findViewById(R.id.audio_file_artist);


		if(Global.RECYCLER_VIEW_FONT_SIZE_FACTOR==0)
		{
			first_line_font_size=Global.FONT_SIZE_SMALL_FIRST_LINE;
			second_line_font_size=Global.FONT_SIZE_SMALL_DETAILS_LINE;
			
			imageview_dimension=Global.IMAGEVIEW_DIMENSION_SMALL;


		}
		else if(Global.RECYCLER_VIEW_FONT_SIZE_FACTOR==2)
		{
			first_line_font_size=Global.FONT_SIZE_LARGE_FIRST_LINE;
			second_line_font_size=Global.FONT_SIZE_LARGE_DETAILS_LINE;
			
			imageview_dimension=Global.IMAGEVIEW_DIMENSION_LARGE;
		}
		else
		{
			first_line_font_size=Global.FONT_SIZE_MEDIUM_FIRST_LINE;
			second_line_font_size=Global.FONT_SIZE_SMALL_DETAILS_LINE;
			
			imageview_dimension=Global.IMAGEVIEW_DIMENSION_MEDIUM;
		}

		titletextview.setTextSize(first_line_font_size);
		albumtextview.setTextSize(second_line_font_size);
		durationtextview.setTextSize(second_line_font_size);
		artisttextview.setTextSize(second_line_font_size);
		
		audioimageview.getLayoutParams().width=imageview_dimension;
		audioimageview.getLayoutParams().height=imageview_dimension;

	}


	@Override
	protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) 
	{

		int iconheight,maxHeight=0;
		int usedWidth=AudioPlayerActivity.RECYCLERVIEWITEM_MARGIN;

		if(context.getResources().getBoolean(R.bool.is_land))
		{
			totalwidth=Global.SCREEN_HEIGHT;
		}
		else
		{
			totalwidth=Global.SCREEN_WIDTH;
		}


		measureChildWithMargins(audioimageview,widthMeasureSpec,usedWidth,heightMeasureSpec,0);
		usedWidth+=audioimageview.getMeasuredWidth();
		iconheight=audioimageview.getMeasuredHeight();

		measureChildWithMargins(titletextview,widthMeasureSpec,usedWidth+AudioPlayerActivity.RECYCLERVIEWITEM_MARGIN*2,heightMeasureSpec,0);
		maxHeight+=titletextview.getMeasuredHeight();

		measureChildWithMargins(albumtextview,widthMeasureSpec,usedWidth+AudioPlayerActivity.RECYCLERVIEWITEM_MARGIN*2,heightMeasureSpec,0);
		maxHeight+=albumtextview.getMeasuredHeight();

		measureChildWithMargins(durationtextview,widthMeasureSpec,usedWidth+AudioPlayerActivity.RECYCLERVIEWITEM_MARGIN*2,heightMeasureSpec,0);
		maxHeight+=durationtextview.getMeasuredHeight();
		
		
		measureChildWithMargins(artisttextview,widthMeasureSpec,usedWidth+AudioPlayerActivity.RECYCLERVIEWITEM_MARGIN*2,heightMeasureSpec,0);
		maxHeight+=artisttextview.getMeasuredHeight();

		maxHeight=Math.max(iconheight,maxHeight);
		maxHeight+=AudioPlayerActivity.RECYCLERVIEWITEM_MARGIN*2;

		setMeasuredDimension(widthMeasureSpec,maxHeight);

	}

	@Override
	protected void onLayout(boolean p1, int l, int t, int r, int b)
	{
		// TODO: Implement this method
		int layoutpadding=AudioPlayerActivity.RECYCLERVIEWITEM_MARGIN;
		int x=AudioPlayerActivity.RECYCLERVIEWITEM_MARGIN,y;

		View v=audioimageview;
		y=layoutpadding;
		v.layout(x,y,x+v.getMeasuredWidth(),y+v.getMeasuredHeight());
		x+=v.getMeasuredWidth()+layoutpadding;

		
		v=titletextview;
		y=0;
		v.layout(x,y,x+v.getMeasuredWidth(),y+v.getMeasuredHeight());
		y+=v.getMeasuredHeight();


		v=albumtextview;
		v.layout(x,y,x+v.getMeasuredWidth(),y+v.getMeasuredHeight());
		y+=v.getMeasuredHeight();

		v=durationtextview;
		v.layout(x,y,x+v.getMeasuredWidth(),y+v.getMeasuredHeight());
		y+=v.getMeasuredHeight();
		
		v=artisttextview;
		v.layout(x,y,x+v.getMeasuredWidth(),y+v.getMeasuredHeight());

	}

	public void set_background_color(int color)
	{
		titletextview.setBackgroundColor(color);
		albumtextview.setBackgroundColor(color);
		durationtextview.setBackgroundColor(color);
		artisttextview.setBackgroundColor(color);
	}
	
	
	@Override
	protected boolean checkLayoutParams(ViewGroup.LayoutParams p) {
		return p instanceof MarginLayoutParams;
	}

	/**
	 * @return A set of default layout parameters when given a child with no layout parameters.
	 */
	@Override
	protected LayoutParams generateDefaultLayoutParams() {
		return new MarginLayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
	}

	/**
	 * @return A set of layout parameters created from attributes passed in XML.
	 */
	@Override
	public LayoutParams generateLayoutParams(AttributeSet attrs) {
		return new MarginLayoutParams(context, attrs);
	}

	/**
	 * Called when {@link #checkLayoutParams(LayoutParams)} fails.
	 *
	 * @return A set of valid layout parameters for this ViewGroup that copies appropriate/valid
	 * attributes from the supplied, not-so-good-parameters.
	 */
	@Override
	protected LayoutParams generateLayoutParams(ViewGroup.LayoutParams p) {
		return generateDefaultLayoutParams();
	}


	public void setData(String title,String album,String duration,String artist,Bitmap art)
	{
		/*
		titletextview.setTextColor(R.color.text_color);
		albumtextview.setTextColor(R.color.text_color);
		durationtextview.setTextColor(R.color.text_color);
		artisttextview.setTextColor(R.color.text_color);
		*/
		titletextview.setText(title);
		albumtextview.setText(album);
		durationtextview.setText(duration);
		artisttextview.setText(artist);
		if(art==null)
		{
			audioimageview.setImageDrawable(context.getDrawable(R.drawable.audio_file_icon));
		}
		else
		{
			audioimageview.setImageBitmap(art);
		}
		
	}
	
	

}
