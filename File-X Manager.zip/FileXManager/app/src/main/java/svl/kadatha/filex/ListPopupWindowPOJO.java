package svl.kadatha.filex;

public class ListPopupWindowPOJO
{
	int resource_id;
	String menu_name;
	
	ListPopupWindowPOJO(int resource_id, String menu_name)
	{
		this.resource_id=resource_id;
		this.menu_name=menu_name;
	}
}
