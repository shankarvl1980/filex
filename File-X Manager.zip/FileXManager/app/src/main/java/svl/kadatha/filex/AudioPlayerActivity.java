package svl.kadatha.filex;
import android.content.*;
import android.content.res.*;
import android.database.sqlite.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.support.design.widget.*;
import android.support.v4.app.*;
import android.support.v4.content.*;
import android.support.v4.view.*;
import android.support.v7.app.*;
import android.support.v7.widget.*;
import android.util.*;
import android.widget.*;
import java.io.*;
import java.util.*;
import android.view.View.*;
import android.view.*;


public class AudioPlayerActivity extends AppCompatActivity
{
	
	private Intent intent;
	private ServiceConnection service_connection;
	private boolean service_bound;
	private AudioPlayerService audio_player_service;
	private ViewPager view_pager;
	private List<BroadcastListener> broadcastListeners=new ArrayList<>();
	private TabLayout tab_layout;
	TinyDB tinyDB;
	static File AUDIO_FILE;
	FragmentManager fm;
	private FloatingActionButton floating_back_button;
	static final String AUDIO_LIST_PREFERENCE_NAME="AudioList";
	static ArrayList<String> AUDIO_SAVED_LIST=new ArrayList<>();
	private Context context;
	private AudioPlayFragment apf;
	private AllAudioListFragment aalf;
	private AlbumListFragment albumlf;
	private AudioSavedListFragment aslf;
	static int RECYCLERVIEWITEM_MARGIN;
	static String AUDIO_NOTIFICATION_INTENT_ACTION;
	private AudioCompleteBroadcastReceiver audioCompleteBroadcastReceiver;
	public static String CURRENT_PLAY_LIST="Current play list";
	public static List<Integer> EXISTING_AUDIOS_ID;
	static DividerItemDecoration DIVIDERITEMDECORATION;
	private ViewPagerFragmentAdapter adapter;
	AudioDatabaseHelper audioDatabaseHelper;
	SQLiteDatabase db;
	Uri data;
	

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
 		// TODO: Implement this method
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_audio_player);
		context=this;
		
		DIVIDERITEMDECORATION=new DividerItemDecoration(context,DividerItemDecoration.VERTICAL);
		
		AUDIO_NOTIFICATION_INTENT_ACTION=getPackageName()+".AUDIO_NOTIFICATION";
		audioCompleteBroadcastReceiver=new AudioCompleteBroadcastReceiver();
		IntentFilter intent_filter=new IntentFilter();
		intent_filter.addAction(AUDIO_NOTIFICATION_INTENT_ACTION);
		
		audioDatabaseHelper=new AudioDatabaseHelper(context);
		db=audioDatabaseHelper.getDatabase();
		LocalBroadcastManager.getInstance(context).registerReceiver(audioCompleteBroadcastReceiver,intent_filter);
		fm=getSupportFragmentManager();
		tab_layout=findViewById(R.id.activity_audio_player_tab_layout);
		view_pager=findViewById(R.id.activity_audio_player_viewpager);
		floating_back_button=findViewById(R.id.floating_action_audio_player);
		floating_back_button.setOnClickListener(new View.OnClickListener()
		{
			public void onClick(View p)
			{
				onBackPressed();
			}
		});
		adapter=new ViewPagerFragmentAdapter(fm);
		view_pager.setAdapter(adapter);
		view_pager.setOffscreenPageLimit(4);
		
		view_pager.addOnPageChangeListener(new ViewPager.OnPageChangeListener()
		{
			
			public void onPageSelected(int p1)
			{
				if(p1==1)
				{
					aalf.whether_audios_set_to_current_list=false;
					//print(""+aalf.whether_audios_set_to_current_list);
				}
					
			}
			
			public void onPageScrolled(int p1, float p2, int p3)
			{
				
			}
			
			public void onPageScrollStateChanged(int p1)
			{
				
			}
		});
		
		adapter.startUpdate(view_pager);
		apf=(AudioPlayFragment)adapter.instantiateItem(view_pager,0);
		aalf=(AllAudioListFragment)adapter.instantiateItem(view_pager,1);
		albumlf=(AlbumListFragment)adapter.instantiateItem(view_pager,2);
		aslf=(AudioSavedListFragment)adapter.instantiateItem(view_pager,3);
		adapter.finishUpdate(view_pager);
		
		
		tab_layout.setupWithViewPager(view_pager);
		tinyDB=new TinyDB(context);
	
		Global.GET_SCREEN_DIMENSIONS(context);
		Global.GET_URI_PERMISSIONS_LIST(context);
		RECYCLERVIEWITEM_MARGIN=Global.GET_RECYCLERVIEWMARGIN(context);
		Global.GET_IMAGEVIEW_DIMENSIONS(context);
		Global.GET_SORT(tinyDB);
	
		StatusBarTint.darkenStatusBar(this,R.color.toolbar_background);
		
		Global.RECYCLER_VIEW_FONT_SIZE_FACTOR=tinyDB.getInt("recycler_view_font_size_factor");
		if(!tinyDB.getBoolean("not_first_run"))
		{
			Global.RECYCLER_VIEW_FONT_SIZE_FACTOR=1;
			tinyDB.putBoolean("not_first_run",true);
			tinyDB.putInt("recycler_view_font_size_factor",Global.RECYCLER_VIEW_FONT_SIZE_FACTOR);
		}
		
		AUDIO_SAVED_LIST=audioDatabaseHelper.getTables();
		audio_player_service=new AudioPlayerService();
		service_connection=new ServiceConnection()
		{
			public void onServiceConnected(ComponentName service,IBinder binder)
			{
				audio_player_service=((AudioPlayerService.AudioBinder)binder).getService();
				service_bound=true;
			}

			public void onServiceDisconnected(ComponentName service)
			{
				audio_player_service=null;
				service_bound=false;
			}
		};
		
		if(savedInstanceState==null)
		{
			
			if((intent=getIntent())!=null)
			{
				data=intent.getData();
				if(data!=null && intent.getType().startsWith("audio") && intent.getAction().equals(Intent.ACTION_VIEW))
				{

					Intent service_intent=new Intent(this,AudioPlayerService.class);
					service_intent.setData(data);
					if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) 
					{
						startForegroundService(service_intent);
					}
					else 
					{
						startService(service_intent);
					}
				
					
					String path=PathUtil.getPath(context,data);
					if(path==null || !new File(path).exists())
					{
						path=data.getPath();
					}
					AUDIO_FILE=new File(path);
					apf.setTitleArt(AUDIO_FILE.getName(),AUDIO_FILE.getAbsolutePath(),getAlbumArt(context,path));
					populateAudioPOJOs(AUDIO_FILE);
						
				}
				
			}
		}
		else
		{
			service_bound=savedInstanceState.getBoolean("service_bound");
		}
		
		aalf.setAudioSelectListener(new AllAudioListFragment.AudioSelectListener()
		{
				public void onAudioSelect(Uri data, AudioPOJO audio)
				{
					android.content.Intent service_intent=new android.content.Intent(context,AudioPlayerService.class);
					service_intent.setData(data);
					if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) 
					{
						startForegroundService(service_intent);
					}
					else 
					{
						startService(service_intent);
					}

					if(apf!=null)
					{
						apf.setTitleArt(audio.getTitle(),audio.getData(),audio.getAlbumArt());
						apf.audio_player_service.current_audio=audio;

					}

					AUDIO_FILE=new File(audio.getData());

				}
		});
		
		albumlf.setAudioSelectListener(new AlbumListFragment.AudioSelectListener()
		{
				public void onAudioSelect(Uri data, AudioPOJO audio)
				{
					android.content.Intent service_intent=new android.content.Intent(context,AudioPlayerService.class);
					service_intent.setData(data);
					if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) 
					{
						startForegroundService(service_intent);
					}
					else 
					{
						startService(service_intent);
					}
					
					if(apf!=null)
					{
						apf.setTitleArt(audio.getTitle(),audio.getData(),audio.getAlbumArt());
						apf.audio_player_service.current_audio=audio;
			
					}

					AUDIO_FILE=new File(audio.getData());
				
				}
		});
		
		aslf.setAudioSelectListener(new AudioSavedListFragment.AudioSelectListener()
			{
				public void onAudioSelect(Uri data, AudioPOJO audio)
				{
					if(data==null)
					{
						data=AudioPlayerActivity.this.data;
					}
					android.content.Intent service_intent=new android.content.Intent(context,AudioPlayerService.class);
					service_intent.setData(data);
					if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) 
					{
						startForegroundService(service_intent);
					}
					else 
					{
						startService(service_intent);
					}

					if(apf!=null)
					{
						apf.setTitleArt(audio.getTitle(),audio.getData(),audio.getAlbumArt());
						apf.audio_player_service.current_audio=audio;

					}

					AUDIO_FILE=new File(audio.getData());

				}
			});
			
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data)
	{
		// TODO: Implement this method
		super.onActivityResult(requestCode, resultCode, data);
	}


	
	@Override
	protected void onStart()
	{
		// TODO: Implement this method
		super.onStart();
		Intent service_intent=new Intent(this,AudioPlayerService.class);
		service_bound=bindService(service_intent,service_connection,Context.BIND_AUTO_CREATE);
	
	}

	@Override
	protected void onStop()
	{
		// TODO: Implement this method
		super.onStop();
		unbindService(service_connection);
		service_bound=false;
	}

	
	@Override
	protected void onSaveInstanceState(Bundle outState)
	{
		// TODO: Implement this method
		super.onSaveInstanceState(outState);
		outState.putBoolean("service_bound",service_bound);
		
	}

	@Override
	protected void onDestroy()
	{
		// TODO: Implement this method
		LocalBroadcastManager.getInstance(context).unregisterReceiver(audioCompleteBroadcastReceiver);
		super.onDestroy();
		
	}

	
	private void populateAudioPOJOs(File file)
	{
		File album_dir=file.getParentFile();
		
		AudioPlayerService.AUDIO_QUEUED_ARRAY=new ArrayList<>();
		ProgressBarFragment pbf=new ProgressBarFragment();
		pbf.show(fm,"");
		if(album_dir!=null && album_dir.list()!=null)
		{

			File [] sub_files=album_dir.listFiles();
			
			Arrays.sort(sub_files,FileComparator.FileComparate(Global.SORT));
			int size=sub_files.length;
			int count=0;
			for(int i=0; i<size;i++)
			{
				if(!sub_files[i].isDirectory())
				{
					String file_name=sub_files[i].getName();
					String file_ext="";
					int idx=file_name.lastIndexOf(".");
					if(idx!=-1)
					{
						file_ext=file_name.substring(idx+1);
						if(file_ext.matches(Global.AUDIO_REGEX))
						{

							File f=sub_files[i];
							String data=f.getAbsolutePath();
							String title=f.getName();
							/*
							 MediaMetadataRetriever mmr=new MediaMetadataRetriever();
							 mmr.setDataSource(data);
							 int id=cursor.getInt(cursor.getColumnIndex(MediaStore.Audio.Media._ID));

							 String title=mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE);
							 String album=mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM);
							 String artist=mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST);
							 String duration=mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
							 
							Bitmap albumart=BitmapFactory.decodeResource(context.getResources(),R.drawable.audio_file_icon);
							*/
							AudioPOJO audio=new AudioPOJO(0,data,title,null,null,"0",null);
							AudioPlayerService.AUDIO_QUEUED_ARRAY.add(audio);
							
							if(AudioPlayerActivity.AUDIO_FILE.getName().equals(title))
							{
								AudioPlayerService.CURRENT_PLAY_NUMBER=count;
								if(audio_player_service!=null)
								{
									audio_player_service.current_audio=audio;
								}
								
							}
							count++;

						}
						else
						{
							
						}

					}

				}
				
			}
			
			
		}
		else
		{
	
			String data=file.getAbsolutePath();
			String title=file.getName();
			
			AudioPOJO audio=new AudioPOJO(0,data,title,null,null,"0",null);
			AudioPlayerService.AUDIO_QUEUED_ARRAY.add(audio);
			AudioPlayerService.CURRENT_PLAY_NUMBER=0;
			if(audio_player_service!=null)
			{
				audio_player_service.current_audio=audio;
			}
			
			
		}
		pbf.dismissAllowingStateLoss();
	}
	
	
	public static Bitmap getAlbumArt(Context context,String data)
	{


		Bitmap albumart=null;
		if(new File(data).exists())
		{
			MediaMetadataRetriever mmr=new MediaMetadataRetriever();
			try
			{
				mmr.setDataSource(data);
				byte [] art_array=mmr.getEmbeddedPicture();
				if(art_array!=null)
				{

					albumart=BitmapFactory.decodeByteArray(art_array,0,art_array.length);
				}

			}
			catch(Exception e)
			{

			}
			finally
			{
				mmr.release();
				return albumart;
			}
		}
		else
		{
		
			return albumart;
		}

	}
	
	private class ViewPagerFragmentAdapter extends FragmentPagerAdapter
	{
		ViewPagerFragmentAdapter(FragmentManager fm)
		{
			super(fm);
		}

		@Override
		public Fragment getItem(int p1)
		{
			// TODO: Implement this method
			
			switch(p1)
			{
				case 0:
			
					return new AudioPlayFragment();
					
					
				case 1:
	
					return new AllAudioListFragment();
					
				case 2:
					return new AlbumListFragment();
				
				case 3:
				
					return new AudioSavedListFragment();
				
				
				default:
					return new AllAudioListFragment();
					
			}
			
		}

		
		
		

		@Override
		public int getCount()
		{
			// TODO: Implement this method
			return 4;
		}

		@Override
		public CharSequence getPageTitle(int position)
		{
			// TODO: Implement this method
			
			switch(position)
			{
				case 0:
					return "Current Play";
					
				case 1:
					return "All songs";
					
				case 2:
					return "Album";
					
				case 3:
					return "Audio list";
				
				default:
					return "All songs";
			}
			
		}
		
		
	}

	@Override
	public void onBackPressed()
	{
		// TODO: Implement this method
		//super.onBackPressed();
		
		
			int current_item=view_pager.getCurrentItem();
			switch (current_item)
			{
				case 0:
					aalf.clear_selection();
					albumlf.clear_selection();
					aslf.clear_selection();
					finish();
					break;
				case 1:
					if(aalf.mselecteditems.size()>0)
					{
						aalf.clear_selection();
						albumlf.clear_selection();
						aslf.clear_selection();
					}
					else
					{
						aalf.clear_selection();
						albumlf.clear_selection();
						aslf.clear_selection();
						
						finish();
					}
					break;
				case 2:
					if(albumlf.mselecteditems.size()>0)
					{
						aalf.clear_selection();
						albumlf.clear_selection();
						aslf.clear_selection();
				
					}
					else
					{
					
						aalf.clear_selection();
						albumlf.clear_selection();
						aslf.clear_selection();
						finish();
					}
					break;
				case 3:
					if(aslf.mselecteditems.size()>0)
					{
						aalf.clear_selection();
						albumlf.clear_selection();
						aslf.clear_selection();
						
					}
					else
					{
						aalf.clear_selection();
						albumlf.clear_selection();
						aslf.clear_selection();
						
						finish();
					}
					
					break;
				default:
				
					aalf.clear_selection();
					albumlf.clear_selection();
					aslf.clear_selection();
					finish();
				break;
			}
	
	
	}

	
	interface BroadcastListener
	{
		public void onBroadcastReceive(String action);
	}
	
	public void addBroadcastListener(BroadcastListener listener)
	{
		broadcastListeners.add(listener);
	}
	
	private class AudioCompleteBroadcastReceiver extends BroadcastReceiver
	{

		@Override
		public void onReceive(Context p1, Intent p2)
		{
			// TODO: Implement this method
			
			String action=p2.getStringExtra("action");
			if(broadcastListeners.size()>0)
			{
				for(BroadcastListener listener:broadcastListeners)
				{
					if(listener!=null)
					{
						listener.onBroadcastReceive(action);
					}
					
				}
			}

			
		}

		
	}
	
	
	public void trigger_audio_list_saved_listener()
	{
		aslf.onSaveAudioList();
		
	}
	
	
	public void trigger_enable_disable_previous_next_btns()
	{
		apf.enable_disable_previous_next_btn();
		
	}
	
	public void trigger_audio_remove_on_delete(ArrayList<AudioPOJO> list)
	{
		aalf.remove_audio(list);
		
	}
	
	public void trigger_audio_remove_on_delete(List<File> list)
	{
		aalf.remove_audio(list);

	}


	
	private void print(String msg)
	{
		Toast.makeText(context,msg,Toast.LENGTH_SHORT).show();
	}
	
	    

}
