package svl.kadatha.filex;
import android.support.v4.app.*;
import android.support.v4.content.*;
import android.database.*;
import android.os.*;
import android.net.*;
import android.view.*;
import android.content.Context;
import android.provider.*;
import java.util.*;
import android.support.v7.widget.*;
import java.util.concurrent.*;
import android.graphics.*;
import java.text.*;
import android.util.*;
import android.widget.*;
import java.io.*;
import android.view.animation.*;
import android.view.View.*;



public class AlbumListFragment extends android.support.v4.app.Fragment //implements LoaderManager.LoaderCallbacks<Cursor>
{

	private Context context;
	private List<AlbumPOJO> album_list;
	private ImageView play_btn,save_btn;
	private Button album_select_btn;
	private AlbumListRecyclerViewAdapter albumListRecyclerViewAdapter;
	private RecyclerView recyclerview;
	private android.support.v7.widget.Toolbar bottom_toolbar;
	private LoaderManager loaderManager;
	private Handler handler;
	private AudioSelectListener audioSelectListener;
	private final SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy hh:mm");
	
	public SparseBooleanArray mselecteditems=new SparseBooleanArray();
	public List<AlbumPOJO> album_selected_array=new ArrayList<>();
	public static Bitmap SELECTED_ALBUM_ART;
	private ToolbarClickListener toolbarClickListener;
	private List<AlbumPOJO> album_selected_pojo_copy;
	private boolean toolbar_visible;
	private int scroll_distance;
	private AsyncTaskStatus asyncTaskStatus;
	private ProgressBar progress_bar;
	private TextView empty_tv;
	private int num_all_album;
	
	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		// TODO: Implement this method
		super.onCreate(savedInstanceState);
		setRetainInstance(true);
		asyncTaskStatus=AsyncTaskStatus.NOT_YET_STARTED;
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
	{
		// TODO: Implement this method
		context=getContext();
		handler=new Handler();
		loaderManager=getLoaderManager();

		View v=inflater.inflate(R.layout.fragment_album_list,container,false);
		bottom_toolbar=v.findViewById(R.id.album_list_bottom_toolbar);
		bottom_toolbar.addView(new CustomToolbarLayout(context,R.layout.album_toolbar_layout,Global.SCREEN_WIDTH,Global.SCREEN_HEIGHT));
		play_btn=bottom_toolbar.findViewById(R.id.album_play);
		//add_to_q_btn=bottom_toolbar.findViewById(R.id.album_add_q);
		save_btn=bottom_toolbar.findViewById(R.id.album_save_list);
		album_select_btn=bottom_toolbar.findViewById(R.id.all_album_select);
		
		toolbarClickListener=new ToolbarClickListener();
		play_btn.setOnClickListener(toolbarClickListener);
		//add_to_q_btn.setOnClickListener(toolbarClickListener);
		save_btn.setOnClickListener(toolbarClickListener);
		album_select_btn.setOnClickListener(toolbarClickListener);
		
		recyclerview=v.findViewById(R.id.fragment_album_list_container);
		recyclerview.setLayoutManager(new LinearLayoutManager(context));
		recyclerview.addOnScrollListener(new RecyclerView.OnScrollListener()
			{
		
				final int threshold=5;
				public void onScrolled(RecyclerView rv, int dx, int dy)
				{
					super.onScrolled(rv,dx,dy);
					if(scroll_distance>threshold && toolbar_visible)
					{
						bottom_toolbar.animate().translationY(bottom_toolbar.getHeight()).setInterpolator(new AccelerateInterpolator(1));
						toolbar_visible=false;
						scroll_distance=0;
					}
					else if(scroll_distance<-threshold && !toolbar_visible)
					{
						if(mselecteditems.size()>0)
						{
							bottom_toolbar.animate().translationY(0).setInterpolator(new DecelerateInterpolator(1));
							toolbar_visible=true;
							scroll_distance=0;
						}
	
					}

					if((toolbar_visible && dy>0) || (!toolbar_visible && dy<0))
					{
						scroll_distance+=dy;
					}

				}

			});
		empty_tv=v.findViewById(R.id.album_list_empty);
		progress_bar=v.findViewById(R.id.album_list_progressbar);
		

		if(mselecteditems.size()==0)
		{
			bottom_toolbar.setVisibility(View.GONE);
			bottom_toolbar.animate().translationY(bottom_toolbar.getHeight()).setInterpolator(new AccelerateInterpolator(1));
			toolbar_visible=false;
		}
		else
		{
			//bottom_toolbar.animate().translationY(0).setInterpolator(new DecelerateInterpolator(1));
			toolbar_visible=true;
		}
		
		if(asyncTaskStatus!=AsyncTaskStatus.STARTED)
		{
			new AlbumListExtractor().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
		}

		album_select_btn.setText(mselecteditems.size()+"/"+num_all_album);
		
		return v;
	}

	public void toolbarSlideDown()
	{
		if(mselecteditems.size()==0)
		{
			
			bottom_toolbar.animate().translationY(bottom_toolbar.getHeight()).setInterpolator(new AccelerateInterpolator(1));
			toolbar_visible=false;
			scroll_distance=0;
		}
	}
	private class AlbumListExtractor extends AsyncTask<Void,Void,Void>
	{
	
		Uri album_uri=MediaStore.Audio.Albums.EXTERNAL_CONTENT_URI;
		
		@Override
		protected void onPreExecute()
		{
			// TODO: Implement this method
			super.onPreExecute();
			asyncTaskStatus=AsyncTaskStatus.STARTED;

			
		}

		@Override
		protected Void doInBackground(Void[] p1)
		{
			// TODO: Implement this method
			
			if(album_list!=null)
			{
				return null;
			}
			album_list=new ArrayList<>();
			
			Cursor cursor=context.getContentResolver().query(album_uri,null,null,null,null);
			if(cursor!=null && cursor.getCount()>0)
			{
				while(cursor.moveToNext())
				{

					String id=cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Albums._ID));
					String album_name=cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Albums.ALBUM));
					String artist=cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Albums.ARTIST));
					String no_of_songs=cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Albums.NUMBER_OF_SONGS));
					String album_path=cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Albums.ALBUM_ART));
					Bitmap art=BitmapFactory.decodeFile(album_path);
					
					album_list.add(new AlbumPOJO(id,album_name,artist,no_of_songs,art));
				}
			}
			return null;
		}

		@Override
		protected void onPostExecute(Void result)
		{
			// TODO: Implement this method
			super.onPostExecute(result);
			albumListRecyclerViewAdapter=new AlbumListRecyclerViewAdapter();
			recyclerview.setAdapter(albumListRecyclerViewAdapter);
			num_all_album=album_list.size();
			if(num_all_album<=0)
			{
				recyclerview.setVisibility(View.GONE);
				empty_tv.setVisibility(View.VISIBLE);
			}
			
			album_select_btn.setText(mselecteditems.size()+"/"+num_all_album);
			progress_bar.setVisibility(View.GONE);
			asyncTaskStatus=AsyncTaskStatus.COMPLETED;
		}

		
		
	}
	
	private class ToolbarClickListener implements View.OnClickListener
	{

		@Override
		public void onClick(View p1)
		{
			
			// TODO: Implement this method
			switch(p1.getId())
			{

				case R.id.album_play:
					if(album_selected_array.size()<1)
					{
						break;
					}
					
					new AlbumListDetailsExtractor(album_selected_array,'p',"").executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
					clear_selection();
					break;
				/*
				case R.id.album_add_q:

					if(ALBUM_SELECTED_ARRAY.size()<1)
					{
						break;
					}
					new AlbumListDetailsExtractor(ALBUM_SELECTED_ARRAY,'q',"").executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);


					break;
				*/
				case R.id.album_save_list:
					if(album_selected_array.size()<1)
					{
						break;
					}
					album_selected_pojo_copy=new ArrayList<>();
					album_selected_pojo_copy.addAll(album_selected_array);
					AudioSaveListDialog audioSaveListDialog=new AudioSaveListDialog();
					audioSaveListDialog.setSaveAudioListListener(new AudioSaveListDialog.SaveAudioListListener()
						{
							public void save_audio_list(String list_name)
							{
								if(list_name==null)
								{
									
									SaveNewAudioListDialog saveNewAudioListDialog=new SaveNewAudioListDialog();
									saveNewAudioListDialog.setOnSaveAudioListener(new SaveNewAudioListDialog.OnSaveAudioListListener()
										{
											public void save_audio_list(String list_name)
											{

												new AlbumListDetailsExtractor(album_selected_pojo_copy,'s',list_name).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);

											}

										});
									saveNewAudioListDialog.show(((AudioPlayerActivity)context).getSupportFragmentManager(),"saveaudiolist_dialog");

								}
								else if(list_name.equals(""))
								{
									new AlbumListDetailsExtractor(album_selected_pojo_copy,'q',"").executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
								}
								else
								{

									new AlbumListDetailsExtractor(album_selected_pojo_copy,'s',list_name).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);


								}
							}
						});
					audioSaveListDialog.show(((AudioPlayerActivity)context).getSupportFragmentManager(),"");
					clear_selection();
					break;
				case R.id.all_album_select:
					if(mselecteditems.size()<num_all_album)
					{
						mselecteditems=new SparseBooleanArray();
						album_selected_array=new ArrayList<>();
						for(int i=0;i<num_all_album;i++)
						{
							mselecteditems.put(i,true);
							album_selected_array.add(album_list.get(i));
						}
						
						albumListRecyclerViewAdapter.notifyDataSetChanged();
					}
					else
					{
						clear_selection();
					}
					album_select_btn.setText(mselecteditems.size()+"/"+num_all_album);
					break;
				default:
					clear_selection();
					break;

			}
			
		
			
		}

		
	}

	public void clear_selection()
	{
		album_selected_array=new ArrayList<>();
		mselecteditems=new SparseBooleanArray();
		albumListRecyclerViewAdapter.notifyDataSetChanged();
		
		bottom_toolbar.animate().translationY(bottom_toolbar.getHeight()).setInterpolator(new AccelerateInterpolator(1));
		toolbar_visible=false;
		scroll_distance=0;
		
	} 
	
	
	private class AlbumListDetailsExtractor extends AsyncTask<Void,Void,Void>
	{
		char action;
		String list_name;
		ArrayList<String> files_selected_array=new ArrayList<>();
		List<AudioPOJO> extracted_audio_list=new ArrayList<>();
		List<AlbumPOJO> albumList=new ArrayList<>();
		ProgressBarFragment pbf=new ProgressBarFragment();
		boolean list_created;
		
		AlbumListDetailsExtractor(List<AlbumPOJO> list,char action, String list_name)
		{
			this.action=action;
			this.list_name=list_name;
			this.albumList=list;
		}
		@Override
		protected void onPreExecute()
		{
			// TODO: Implement this method
			super.onPreExecute();
			pbf.show(((AudioPlayerActivity)context).fm,"");
		}

		@Override
		protected Void doInBackground(Void[] p1)
		{
			// TODO: Implement this method
			for(AlbumPOJO Album:albumList)
			{
				String album_id=Album.getId();
				Uri uri=MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
				String where=MediaStore.Audio.Media.ALBUM_ID+"="+album_id;
				Cursor cursor=context.getContentResolver().query(uri,null,where,null,null);
				if(cursor!=null && cursor.getCount()>0)
				{
					while(cursor.moveToNext())
					{
						int id=cursor.getInt(cursor.getColumnIndex(MediaStore.Audio.Media._ID));
						String data=cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Media.DATA));
						String title=cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Media.TITLE));
						String album=cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Media.ALBUM));
						String artist=cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Media.ARTIST));
						String duration=cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Media.DURATION));
						Bitmap albumart=null;

						if(new File(data).exists())
						{
							extracted_audio_list.add(new AudioPOJO(id,data,title,album,artist,duration,albumart));
						}
					}
				}
			}
			if(action=='q')
			{
				AudioPlayerService.AUDIO_QUEUED_ARRAY.addAll(extracted_audio_list);
				
			}
			else if(action=='s')
			{
				
				if(AudioPlayerActivity.AUDIO_SAVED_LIST.contains(list_name))
				{
					((AudioPlayerActivity)context).audioDatabaseHelper.insert(list_name,extracted_audio_list);
				}
				else
				{
					((AudioPlayerActivity)context).audioDatabaseHelper.createTable(list_name);
					((AudioPlayerActivity)context).audioDatabaseHelper.insert(list_name,extracted_audio_list);
					AudioPlayerActivity.AUDIO_SAVED_LIST.add(list_name);
					list_created=true;
				}

				
			}
			else
			{
				AudioPlayerService.AUDIO_QUEUED_ARRAY=new ArrayList<>();
				AudioPlayerService.AUDIO_QUEUED_ARRAY=extracted_audio_list;
			}
					
			return null;
		}

		@Override
		protected void onProgressUpdate(Void[] values)
		{
			// TODO: Implement this method
			super.onProgressUpdate(values);
		}

		@Override
		protected void onPostExecute(Void result)
		{
			// TODO: Implement this method
			super.onPostExecute(result);
			if(action=='p')
			{
				if(audioSelectListener!=null && AudioPlayerService.AUDIO_QUEUED_ARRAY.size()!=0)
				{
					AudioPlayerService.CURRENT_PLAY_NUMBER=0;
					AudioPOJO audio=AudioPlayerService.AUDIO_QUEUED_ARRAY.get(AudioPlayerService.CURRENT_PLAY_NUMBER);
					Uri uri=MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
					Uri data=Uri.withAppendedPath(uri,String.valueOf(audio.getId()));
					audioSelectListener.onAudioSelect(data,audio);
				}
			}
			else if(action=='s')
			{
				
				if(list_created)
				{
					print("'"+list_name+ "' audio list created");
				}
				
				((AudioPlayerActivity)context).trigger_audio_list_saved_listener();
			}
			pbf.dismissAllowingStateLoss();
			((AudioPlayerActivity)context).trigger_enable_disable_previous_next_btns();
		
		}

		
		
	}


	private class AlbumListRecyclerViewAdapter extends RecyclerView.Adapter <AlbumListRecyclerViewAdapter.ViewHolder>
	{


		class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener, AdapterView.OnLongClickListener
		{
			AlbumListRecyclerViewItem view;
			int pos;

			ViewHolder (AlbumListRecyclerViewItem view)
			{

				super(view);
				this.view=view;

				view.setOnClickListener(this);
				view.setOnLongClickListener(this);

			}


			@Override
			public void onClick(View p1)
			{
				pos=getAdapterPosition();
				if(mselecteditems.size()>0)
				{

					onLongClickProcedure(p1);
				}
				else 
				{

					AlbumPOJO album=album_list.get(pos);

					SELECTED_ALBUM_ART=null;
					SELECTED_ALBUM_ART=album.getAlbumArt();
					/*
					if(SELECTED_ALBUM_ART==null)
					{
						SELECTED_ALBUM_ART=BitmapFactory.decodeResource(context.getResources(),R.drawable.audio_file_icon);
					}
					*/
					Bundle bundle=new Bundle();
					bundle.putString("albumID",album.getId());
					bundle.putString("album_name",album.getAlbumName());
				
					AlbumDetailsDialog albumDetailsDialog=new AlbumDetailsDialog();
					albumDetailsDialog.setAudioSelectListener(new AlbumDetailsDialog.AudioSelectListener()
						{
							public void onAudioSelect(Uri data, AudioPOJO audio)
							{
								if(audioSelectListener!=null)
								{
									audioSelectListener.onAudioSelect(data,audio);
								}
							}
						});
					
					albumDetailsDialog.setArguments(bundle);
					albumDetailsDialog.show(((AudioPlayerActivity)context).fm,"");
					
				}

			}


			@Override
			public boolean onLongClick(View p1)
			{
				onLongClickProcedure(p1);
	
				return true;
			}

			
			private void onLongClickProcedure(View v)
			{
				pos=getAdapterPosition();

				if(mselecteditems.get(pos,false))
				{
					mselecteditems.delete(pos);
					
					v.setSelected(false);
					album_selected_array.remove(album_list.get(pos));
					if(mselecteditems.size()>=1)
					{
						bottom_toolbar.setVisibility(View.VISIBLE);
						bottom_toolbar.animate().translationY(0).setInterpolator(new DecelerateInterpolator(1));
						toolbar_visible=true;
						scroll_distance=0;
						
					}


					if(mselecteditems.size()==0)
					{

						bottom_toolbar.animate().translationY(bottom_toolbar.getHeight()).setInterpolator(new AccelerateInterpolator(1));
						toolbar_visible=false;
						scroll_distance=0;
		
					}
				}
				else
				{
					//selection_mode=true;
					mselecteditems.put(pos,true);
					v.setSelected(true);
					album_selected_array.add(album_list.get(pos));
			
					bottom_toolbar.setVisibility(View.VISIBLE);
					bottom_toolbar.animate().translationY(0).setInterpolator(new DecelerateInterpolator(1));
					toolbar_visible=true;
					scroll_distance=0;
				


					if(mselecteditems.size()==1)
					{
						
					}

					else if(mselecteditems.size()>1)
					{
				

					}

				}
				album_select_btn.setText(mselecteditems.size()+"/"+num_all_album);
			}
		}
		
	

		@Override
		public ViewHolder onCreateViewHolder(ViewGroup p1, int p2)
		{

			return new ViewHolder(new AlbumListRecyclerViewItem(context));

		}

		@Override
		public void onBindViewHolder(AlbumListRecyclerViewAdapter.ViewHolder p1, int p2)
		{

			AlbumPOJO album=album_list.get(p2);
			String album_name=album.getAlbumName();
			String no_of_songs="Tracks: "+album.getNoOfSongs();
			String artist="Artists: "+album.getArtist();
			Bitmap album_art=album.getAlbumArt();

			p1.view.setData(album_art,album_name,no_of_songs,artist);

		
			p1.view.setSelected(mselecteditems.get(p2,false));

		
		}


		@Override
		public int getItemCount()
		{	
			num_all_album=album_list.size();
			return num_all_album;
		}
		
		
	}
	

	interface AudioSelectListener
	{
		public void onAudioSelect(Uri data, AudioPOJO audio);
	}

	public void setAudioSelectListener(AudioSelectListener listener)
	{
		audioSelectListener=listener;
	}
	

	private void print(String msg)
	{
		Toast.makeText(context,msg,Toast.LENGTH_SHORT).show();
	}
		
	private class AlbumListRecyclerViewItem extends ViewGroup
	{
		private Context context;
		private View view;
		private ImageView albumimageview;
		private TextView albumtextview, no_of_songs_textview,artisttextview;
		private int first_line_font_size,second_line_font_size,imageview_dimension;
		private int totalwidth;

		AlbumListRecyclerViewItem(Context context)
		{
			super(context);
			this.context=context;
			init();
		}

		AlbumListRecyclerViewItem(Context context, AttributeSet attr)
		{
			super(context,attr);
			this.context=context;
			init();
		}

		AlbumListRecyclerViewItem(Context context, AttributeSet attr, int defStyle)
		{
			super(context,attr,defStyle);
			this.context=context;
			init();
		}

		private void init()
		{

			setBackground(context.getResources().getDrawable(R.drawable.select_color));

			view=LayoutInflater.from(context).inflate(R.layout.audiolist_recyclerview_layout,this,true);
			albumimageview=view.findViewById(R.id.audio_image);
			albumtextview=view.findViewById(R.id.audio_file_title);
			no_of_songs_textview=view.findViewById(R.id.audio_file_duration);
			artisttextview=view.findViewById(R.id.audio_file_artist);
			

			if(Global.RECYCLER_VIEW_FONT_SIZE_FACTOR==0)
			{
				first_line_font_size=Global.FONT_SIZE_SMALL_FIRST_LINE;
				second_line_font_size=Global.FONT_SIZE_SMALL_DETAILS_LINE;

				imageview_dimension=Global.IMAGEVIEW_DIMENSION_SMALL;


			}
			else if(Global.RECYCLER_VIEW_FONT_SIZE_FACTOR==2)
			{
				first_line_font_size=Global.FONT_SIZE_LARGE_FIRST_LINE;
				second_line_font_size=Global.FONT_SIZE_LARGE_DETAILS_LINE;

				imageview_dimension=Global.IMAGEVIEW_DIMENSION_LARGE;
			}
			else
			{
				first_line_font_size=Global.FONT_SIZE_MEDIUM_FIRST_LINE;
				second_line_font_size=Global.FONT_SIZE_SMALL_DETAILS_LINE;

				imageview_dimension=Global.IMAGEVIEW_DIMENSION_MEDIUM;
			}
	
			albumtextview.setTextSize(first_line_font_size);
			no_of_songs_textview.setTextSize(second_line_font_size);
			artisttextview.setTextSize(second_line_font_size);
			
			albumimageview.getLayoutParams().width=imageview_dimension;
			albumimageview.getLayoutParams().height=imageview_dimension;

		}


		@Override
		protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) 
		{

			int iconheight,maxHeight=0;
			int usedWidth=AudioPlayerActivity.RECYCLERVIEWITEM_MARGIN;

			if(context.getResources().getBoolean(R.bool.is_land))
			{
				totalwidth=Global.SCREEN_HEIGHT;
			}
			else
			{
				totalwidth=Global.SCREEN_WIDTH;
			}


			measureChildWithMargins(albumimageview,widthMeasureSpec,usedWidth,heightMeasureSpec,0);
			usedWidth+=albumimageview.getMeasuredWidth();
			iconheight=albumimageview.getMeasuredHeight();


			measureChildWithMargins(albumtextview,widthMeasureSpec,usedWidth+AudioPlayerActivity.RECYCLERVIEWITEM_MARGIN*2,heightMeasureSpec,0);
			maxHeight+=albumtextview.getMeasuredHeight();

			measureChildWithMargins(no_of_songs_textview,widthMeasureSpec,usedWidth+AudioPlayerActivity.RECYCLERVIEWITEM_MARGIN*2,heightMeasureSpec,0);
			maxHeight+=no_of_songs_textview.getMeasuredHeight();


			measureChildWithMargins(artisttextview,widthMeasureSpec,usedWidth+AudioPlayerActivity.RECYCLERVIEWITEM_MARGIN*2,heightMeasureSpec,0);
			maxHeight+=artisttextview.getMeasuredHeight();

			maxHeight=Math.max(iconheight,maxHeight);
			maxHeight+=AudioPlayerActivity.RECYCLERVIEWITEM_MARGIN*2;

			setMeasuredDimension(widthMeasureSpec,maxHeight);

		}

		@Override
		protected void onLayout(boolean p1, int l, int t, int r, int b)
		{
			// TODO: Implement this method
			int layoutpadding=AudioPlayerActivity.RECYCLERVIEWITEM_MARGIN;
			int x=AudioPlayerActivity.RECYCLERVIEWITEM_MARGIN,y;

			View v=albumimageview;
			y=layoutpadding;
			v.layout(x,y,x+v.getMeasuredWidth(),y+v.getMeasuredHeight());
			x+=v.getMeasuredWidth()+layoutpadding;

			v=albumtextview;
			y=0;
			v.layout(x,y,x+v.getMeasuredWidth(),y+v.getMeasuredHeight());
			y+=v.getMeasuredHeight();


			v=no_of_songs_textview;
			v.layout(x,y,x+v.getMeasuredWidth(),y+v.getMeasuredHeight());
			y+=v.getMeasuredHeight();

			v=artisttextview;
			v.layout(x,y,x+v.getMeasuredWidth(),y+v.getMeasuredHeight());

		}


		@Override
		protected boolean checkLayoutParams(ViewGroup.LayoutParams p) {
			return p instanceof MarginLayoutParams;
		}

		/**
		 * @return A set of default layout parameters when given a child with no layout parameters.
		 */
		@Override
		protected LayoutParams generateDefaultLayoutParams() {
			return new MarginLayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
		}

		/**
		 * @return A set of layout parameters created from attributes passed in XML.
		 */
		@Override
		public LayoutParams generateLayoutParams(AttributeSet attrs) {
			return new MarginLayoutParams(context, attrs);
		}

		/**
		 * Called when {@link #checkLayoutParams(LayoutParams)} fails.
		 *
		 * @return A set of valid layout parameters for this ViewGroup that copies appropriate/valid
		 * attributes from the supplied, not-so-good-parameters.
		 */
		@Override
		protected LayoutParams generateLayoutParams(ViewGroup.LayoutParams p) {
			return generateDefaultLayoutParams();
		}


		public void setData(Bitmap art,String album,String duration,String artist)
		{
			if(art==null)
			{
				albumimageview.setImageDrawable(context.getDrawable(R.drawable.audio_file_icon));
			}
			else
			{
				albumimageview.setImageBitmap(art);
			}
			
			albumtextview.setText(album);
			no_of_songs_textview.setText(duration);
			artisttextview.setText(artist);
		}

		

	}
	
	
	private enum AsyncTaskStatus
	{
		NOT_YET_STARTED, STARTED, COMPLETED
	}

}
