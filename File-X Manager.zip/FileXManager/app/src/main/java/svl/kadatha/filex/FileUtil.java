package svl.kadatha.filex;

import android.app.*;
import android.content.*;
import android.net.*;
import android.os.*;
import android.os.Build.*;
import android.os.storage.*;
import android.provider.*;
import android.support.annotation.*;
import android.support.v4.provider.*;
import android.widget.*;
import java.io.*;
import java.lang.reflect.*;
import java.nio.*;
import java.nio.channels.*;
import java.util.*;
import java.nio.file.*;
	 
	/**
	 * Utility class for helping parsing file systems.
	 */
	public final class FileUtil 
	{
		//public static File CUTCOPYFILE;
		
		/**
		 * The name of the primary volume (LOLLIPOP).
		 */
		private static final String PRIMARY_VOLUME_NAME = "primary";

		/**
		 * Hide default constructor.
		 */
		private FileUtil() 
		{
			
			throw new UnsupportedOperationException();
		}

	
	
	/**
	 * Get a DocumentFile corresponding to the given file (for writing on ExtSdCard on Android 5). If the file is not
	 * existing, it is created.
	 *
	 * @param file              The file.
	 * @param isDirectory       flag indicating if the file should be a directory.
	 * @param createDirectories flag indicating if intermediate path directories should be created if not existing.
	 * @return The DocumentFile
	 */
	 
	 /*
	@RequiresApi(api = VERSION_CODES.LOLLIPOP)
	public static UsefulDocumentFile getDocumentFile(@NonNull final File file, final boolean isDirectory,
										   final boolean createDirectories,Context context,String uri_string,String baseFolder) 
	{
		
		Uri treeUri = null;
		treeUri = Uri.parse(uri_string);

		if(treeUri==null)
		{
			return null;
		}

		String fullPath;
		try {
			fullPath = file.getCanonicalPath();
		}
		catch (IOException e) 
		{
			return null;
		}

		if (baseFolder == null) 
		{
			return null;
		}

		if(!fullPath.startsWith(baseFolder))
		{
			return null;
			
		}
		String relativePath = fullPath.substring(baseFolder.length() + 1);
		

		// start with root of SD card and then parse through document tree.
		UsefulDocumentFile document = UsefulDocumentFile.fromUri(context, treeUri);
	
		String[] parts = relativePath.split("\\/");
		for (int i = 0; i < parts.length; i++) 
		{
			UsefulDocumentFile nextDocument = document.findFile(parts[i]);
			if (nextDocument == null) 
			{
				if (i < parts.length - 1) 
				{
					if (createDirectories) 
					{
						nextDocument = document.createDirectory(parts[i]);
						
					}
					else 
					{
						return null;
					}
				}
				else if (isDirectory) 
				{
					nextDocument = document.createDirectory(parts[i]);
				
				}
				else 
				{
					nextDocument = document.createFile("text", parts[i]);
				}
			}
			document = nextDocument;
		}

		return document;
	}
	*/

	@RequiresApi(api = VERSION_CODES.LOLLIPOP)
	public static UsefulDocumentFile getDocumentFile1(@NonNull final File file, final boolean isDirectory,
														@NonNull Context context,Uri treeUri,@NonNull  String baseFolder) 
	{
	
		if(treeUri==null)
		{
			return null;
		}

		String fullPath;
		try 
		{
			fullPath = file.getParentFile().getCanonicalPath();
		}
		catch (IOException e) 
		{
			return null;
		}
/*
		if (baseFolder == null) 
		{
			return null;
		}

		if(!fullPath.startsWith(baseFolder))
		{
			return null;
		}
*/
		String relativePathForCopyFile="";
		if(!fullPath.equals(baseFolder))
		{
			relativePathForCopyFile = fullPath.substring(baseFolder.length() + 1);
		}
		// start with root of SD card and then parse through document tree.
		UsefulDocumentFile parent_document=null;
		UsefulDocumentFile child_document=null;

		//String[] parts = relativePathForCopyFile.split(File.separator);
		String file_name=file.getName();
		//int index=relativePathForCopyFile.lastIndexOf(File.separator);
		//String relativePathParent=relativePathForCopyFile.substring(0,index!=-1 ? index : 0);
		
		String child_uri_id=DocumentsContract.getTreeDocumentId(treeUri);
		if(!child_uri_id.endsWith(File.separator))
		{
			child_uri_id=child_uri_id+File.separator;
		}
		child_uri_id=child_uri_id+relativePathForCopyFile;
		

		
		if(file.exists())
		{
			child_document=UsefulDocumentFile.fromUri(context,DocumentsContract.buildChildDocumentsUriUsingTree(treeUri,child_uri_id+File.separator+file_name));
			return child_document;
		}
		else
		{
			Uri i=DocumentsContract.buildChildDocumentsUriUsingTree(treeUri,child_uri_id);
			parent_document=UsefulDocumentFile.fromUri(context,i);
			
			if (isDirectory) 
			{
				child_document = parent_document.createDirectory(file_name);
			}
			else 
			{

				child_document = parent_document.createFile("text", file_name);

			}

			return child_document;
			
		}
		
  		 	
	}
	
	@RequiresApi(api = VERSION_CODES.LOLLIPOP)
	public static DocumentFile getDocumentFile2(@NonNull final File file, final boolean isDirectory,
													  final boolean createDirectories,Context context,String uri_string,String baseFolder) 
	{
		
		Uri treeUri = null;
		treeUri = Uri.parse(uri_string);
		if(treeUri==null)
		{
			return null;
		}

		String fullPath;
		try 
		{
			fullPath = file.getParentFile().getCanonicalPath();
		}
		catch (IOException e) 
		{
			return null;
		}

		if (baseFolder == null) {
			return null;
		}

		if(!fullPath.startsWith(baseFolder))
		{
			return null;
		}

		String relativePathForCopyFile="";
		if(!fullPath.equals(baseFolder))
		{
			relativePathForCopyFile = fullPath.substring(baseFolder.length() + 1);
		}
		// start with root of SD card and then parse through document tree.
		DocumentFile parent_document=null;
		DocumentFile child_document=null;

		//String[] parts = relativePathForCopyFile.split(File.separator);
		String file_name=file.getName();
		//int index=relativePathForCopyFile.lastIndexOf(File.separator);
		//String relativePathParent=relativePathForCopyFile.substring(0,index!=-1 ? index : 0);

		String child_uri_id=DocumentsContract.getTreeDocumentId(treeUri);
		if(!child_uri_id.endsWith(File.separator))
		{
			child_uri_id=child_uri_id+File.separator;
		}
		child_uri_id=child_uri_id+relativePathForCopyFile;

		Uri i=DocumentsContract.buildChildDocumentsUriUsingTree(treeUri,child_uri_id);
		parent_document=DocumentFile.fromSingleUri(context,i);

		if(file.exists())
		{
			child_document=DocumentFile.fromSingleUri(context,DocumentsContract.buildChildDocumentsUriUsingTree(treeUri,child_uri_id+File.separator+file_name));
			return child_document;
		}
		else
		{

			if (isDirectory) 
			{
				child_document = parent_document.createDirectory(file_name);
			}
			else 
			{

				child_document = parent_document.createFile("text", file_name);

			}

			return child_document;

		}
		
	}
	

	@SuppressWarnings("null")
	public static boolean copyNativeFileNIO(@NonNull final File source, @NonNull final File target) 
	{
		FileInputStream fileInStream = null;
		FileOutputStream fileOutStream=null;

		try 
		{

			fileInStream = new FileInputStream(source);
			fileOutStream = new FileOutputStream(target);
			FileChannel inputChannel = fileInStream.getChannel();
			FileChannel outputChannel = fileOutStream.getChannel();
			channelCopy(inputChannel,outputChannel);


		}
		catch (Exception e) 
		{
			//Log.e(Application.TAG,
			//  "Error when copying file from " + source.getAbsolutePath() + " to " + target.getAbsolutePath(), e);
			return false;
		}
		finally 
		{
			try 
			{
				fileInStream.close();
			}
			catch (Exception e) 
			{
				// ignore exception
			}
			try 
			{
				fileOutStream.close();
			}
			catch (Exception e) 
			{
				// ignore exception
			}

		}
		return true;
	}
		
		
		/**
		 * Copy a file. The target file may even be on external SD card for Kitkat.
		 *
		 * @param source The source file
		 * @param target The target file
		 * @return true if the copying was successful.
		 */
		@SuppressWarnings("null")
		public static boolean copyNativeCutNativeFileNIO(@NonNull final File source, @NonNull final File target, boolean cut) 
		{
			FileInputStream fileInStream = null;
			FileOutputStream fileOutStream=null;

			try
			{

				fileInStream = new FileInputStream(source);
				fileOutStream = new FileOutputStream(target);
				FileChannel inputChannel = fileInStream.getChannel();
				FileChannel outputChannel = fileOutStream.getChannel();
				channelCopy(inputChannel,outputChannel);
				if(cut)
				{
					deleteNativeFile(source);
				}
				
			}
			
			catch (Exception e) 
			{
				//Log.e(Application.TAG,
					//  "Error when copying file from " + source.getAbsolutePath() + " to " + target.getAbsolutePath(), e);
				return false;
			}
			finally 
			{
				try 
				{
					fileInStream.close();
				}
				catch (Exception e) 
				{
					// ignore exception
				}
				try 
				{
					fileOutStream.close();
				}
				catch (Exception e) 
				{
					// ignore exception
				}
				
			}
			return true;
		}

		
	@SuppressWarnings("null")
	public static boolean copySAFFileNIO(@NonNull final File source, @NonNull final File target,Context context,Uri treeUri,String baseFolder) 
	{
		FileInputStream fileInStream = null;
		//FileOutputStream fileOutStream=null;
		OutputStream outStream=null;

		try 
		{

			fileInStream = new FileInputStream(source);

			if (SystemUtil.isAndroid5()) 
			{
				// Storage Access Framework
				UsefulDocumentFile targetDocument = getDocumentFile1(target, false,context,treeUri,baseFolder);
				if (targetDocument != null) 
				{
					outStream = context.getContentResolver().openOutputStream(targetDocument.getUri());
				}
			}
			else if (SystemUtil.isKitkat()) 
			{
				// Workaround for Kitkat ext SD card
				Uri uri = MediaStoreUtil.getUriFromFile(target.getAbsolutePath(),context);
				if (uri != null) 
				{
					outStream = context.getContentResolver().openOutputStream(uri);
				}
			}
			else 
			{
				return false;
			}

			if (outStream != null) 
			{
				// Both for SAF and for Kitkat, write to output stream.
				/*
					fileInStream = new FileInputStream(source);
					//fileOutStream = new FileOutputStream(outStream));
					FileChannel inputChannel = fileInStream.getChannel();
					FileChannel outputChannel = Channels.newChannel(outStream);
					int maxCount=1024*16;
					long size=inputChannel.size();
					long position=0;
					while(position<size)
					{
						position+=inputChannel.transferTo(position, maxCount, outputChannel);
					}
				*/
				final ReadableByteChannel inputChannel=Channels.newChannel(fileInStream);
				final WritableByteChannel outputChannel=Channels.newChannel(outStream);

				fastChannelCopy(inputChannel,outputChannel);
				

				inputChannel.close();
				outputChannel.close();
				
			}

		}
		catch (Exception e) {
			//Log.e(Application.TAG,
			//  "Error when copying file from " + source.getAbsolutePath() + " to " + target.getAbsolutePath(), e);
			return false;
		}
		finally 
		{
			try 
			{
				fileInStream.close();
			}
			catch (Exception e) 
			{
				// ignore exception
			}
		
			try {
				outStream.close();
			}
			catch (Exception e) 
			{
				// ignore exception
			}

		}
		return true;
	}

	@SuppressWarnings("null")
	public static boolean copySAFCutNativeFileNIO(@NonNull final File source, @NonNull final File target,Context context, boolean cut,Uri treeUri,String baseFolder) 
	{
		FileInputStream fileInStream = null;
		//FileOutputStream fileoutStream=null;
		OutputStream outStream=null;

		try 
		{

			fileInStream = new FileInputStream(source);
			if (SystemUtil.isAndroid5()) 
			{
				// Storage Access Framework
				UsefulDocumentFile targetDocument = getDocumentFile1(target, false,context,treeUri,baseFolder);
				if (targetDocument != null) 
				{
					outStream = context.getContentResolver().openOutputStream(targetDocument.getUri());
				}
			}
			else if (SystemUtil.isKitkat()) 
			{
				// Workaround for Kitkat ext SD card
				Uri uri = MediaStoreUtil.getUriFromFile(target.getAbsolutePath(),context);
				if (uri != null) 
				{
					outStream = context.getContentResolver().openOutputStream(uri);
				}
			}
			else 
			{
				return false;
			}

			if (outStream != null) 
			{
				// Both for SAF and for Kitkat, write to output stream.
				final ReadableByteChannel inputChannel=Channels.newChannel(fileInStream);
				final WritableByteChannel outputChannel=Channels.newChannel(outStream);

				fastChannelCopy(inputChannel,outputChannel);

				inputChannel.close();
				outputChannel.close();
			}

			if(cut)
			{
				deleteNativeFile(source);
			}


		}
		catch (Exception e) 
		{
			//Log.e(Application.TAG,
			//  "Error when copying file from " + source.getAbsolutePath() + " to " + target.getAbsolutePath(), e);
			return false;
		}
		finally 
		{
			try 
			{
				fileInStream.close();
			}
			catch (Exception e) 
			{
				// ignore exception
			}
			
			try 
			{
				outStream.close();
			}
			catch (Exception e) 
			{
				// ignore exception
			}

		}
		return true;
	}
		
	
	@SuppressWarnings("null")
	public static boolean copyNativeCutNativeFile(@NonNull final File source, @NonNull final File target, boolean cut) 
	{
		FileInputStream fileInStream = null;
		BufferedInputStream bufferedInStream=null;
		FileOutputStream fileOutStream = null;
		BufferedOutputStream bufferedOutStream=null;
		FileChannel inChannel = null;
		FileChannel outChannel = null;

		try 
		{

			fileInStream = new FileInputStream(source);
			inChannel=fileInStream.getChannel();

			fileOutStream = new FileOutputStream(target);
			outChannel=fileOutStream.getChannel();
			
			channelCopy(inChannel,outChannel);
	
			if(cut)
			{
				deleteNativeFile(source);
			}


		}
		catch (Exception e) 
		{
			//Log.e(Application.TAG,
			//  "Error when copying file from " + source.getAbsolutePath() + " to " + target.getAbsolutePath(), e);
			return false;
		}
		finally 
		{
			try 
			{
				fileInStream.close();
			}
			catch (Exception e) 
			{
				// ignore exception
			}

			try 
			{
				fileOutStream.close();
			}
			catch (Exception e) 
			{
				// ignore exception
			}


			
			
			try {
				inChannel.close();
			}
			catch (Exception e) {
				// ignore exception
			}
			try {
				outChannel.close();
			}
			catch (Exception e) {
				// ignore exception
			}
			
		}
		return true;
	}


	@SuppressWarnings("null")
	public static boolean copySAFCutNativeFile(@NonNull final File source, @NonNull final File target,Context context, boolean cut,Uri treeUri,String baseFolder) 
	{
		FileInputStream fileInStream = null;
		BufferedInputStream bufferedInStream=null;
		OutputStream outStream = null;
		BufferedOutputStream bufferedOutStream=null;


		try 
		{

			fileInStream = new FileInputStream(source);
			bufferedInStream=new BufferedInputStream(fileInStream);

			if (SystemUtil.isAndroid5()) 
			{
				// Storage Access Framework
				UsefulDocumentFile targetDocument = getDocumentFile1(target, false,context,treeUri,baseFolder);
				if (targetDocument != null) 
				{
					outStream = context.getContentResolver().openOutputStream(targetDocument.getUri());
				}
			}
			else if (SystemUtil.isKitkat()) 
			{
				// Workaround for Kitkat ext SD card
				Uri uri = MediaStoreUtil.getUriFromFile(target.getAbsolutePath(),context);
				if (uri != null) 
				{
					outStream = context.getContentResolver().openOutputStream(uri);
				}
			}
			else 
			{
				return false;
			}

			if (outStream != null) 
			{
				// Both for SAF and for Kitkat, write to output stream.
				final ReadableByteChannel inputChannel=Channels.newChannel(fileInStream);
				final WritableByteChannel outputChannel=Channels.newChannel(outStream);

				fastChannelCopy(inputChannel,outputChannel);

				inputChannel.close();
				outputChannel.close();
			}
			
			if(cut)
			{
				deleteNativeFile(source);
			}


		}
		catch (Exception e) 
		{
			//Log.e(Application.TAG,
			//  "Error when copying file from " + source.getAbsolutePath() + " to " + target.getAbsolutePath(), e);
			return false;
		}
		finally 
		{
			try 
			{
				fileInStream.close();
			}
			catch (Exception e) 
			{
				// ignore exception
			}
			try 
			{
				bufferedInStream.close();
			}
			catch (Exception e) 
			{
				// ignore exception
			}

			try 
			{
				outStream.close();
			}
			catch (Exception e) 
			{
				// ignore exception
			}
			try 
			{
				bufferedOutStream.close();
			}
			catch (Exception e) 
			{
				// ignore exception
			}
			
			/*
			 try {
			 inChannel.close();
			 }
			 catch (Exception e) {
			 // ignore exception
			 }
			 try {
			 outChannel.close();
			 }
			 catch (Exception e) {
			 // ignore exception
			 }
			 */
		}
		return true;
	}
	

	@SuppressWarnings("null")
	public static boolean copyNativeCutNativeDirectory(File source, File destination,boolean cut,String baseFolder,String currentFolder)
	{
		boolean success=false;
		if (source.isDirectory())
		{
			if(!destination.exists())
			{
				success=mkdirsNative(destination);
			}

			String files[] = source.list();

			for (String file : files)
			{
				File srcFile = new File(source, file);
				File destFile = new File(destination, file);
				success=copyNativeCutNativeDirectory(srcFile, destFile,cut,baseFolder,currentFolder);

			}

			if(success && cut)
			{
				deleteNativeFile(source);
			}

		}
		else
		{
			success=copyNativeCutNativeFileNIO(source,destination,cut);
		}
		return success;
	}


	@SuppressWarnings("null")
	public static boolean copySAFCutNativeDirectory(File source, File destination,Context context,boolean cut,Uri treeUri,String baseFolder)
	{
		boolean success=false;
		if (source.isDirectory())
		{
			if(!destination.exists())
			{
				success=mkdirsSAF(destination,context,treeUri,baseFolder);
			}

			String files[] = source.list();

			for (String file : files)
			{
				File srcFile = new File(source, file);
				File destFile = new File(destination, file);
				success=copySAFCutNativeDirectory(srcFile, destFile,context,cut,treeUri,baseFolder);

			}

			if(success && cut)
			{
				deleteNativeFile(source);
			}

		}
		else
		{
			success=copySAFCutNativeFileNIO(source,destination,context,cut,treeUri,baseFolder);
		}
		return success;
	}
	
	


	@SuppressWarnings("null")
	public static FileOutputStream get_fileoutputstream(@NonNull final File target,Context context,Uri treeUri,String baseFolder) 
	{
		FileOutputStream fileOutStream=null;

		try 
		{

			if (SystemUtil.isAndroid5()) 
			{
				// Storage Access Framework
				UsefulDocumentFile targetDocument = getDocumentFile1(target, false,context,treeUri,baseFolder);
				if (targetDocument != null) 
				{
					ParcelFileDescriptor pfd = context.getContentResolver().openFileDescriptor(targetDocument.getUri(),"rw");
					fileOutStream=new FileOutputStream(pfd.getFileDescriptor());
					
				}
			}
			else if (SystemUtil.isKitkat()) 
			{
				// Workaround for Kitkat ext SD card
				Uri uri = MediaStoreUtil.getUriFromFile(target.getAbsolutePath(),context);
				if (uri != null) 
				{
					
					ParcelFileDescriptor pfd=context.getContentResolver().openFileDescriptor(uri,"rw");
					fileOutStream = new FileOutputStream(pfd.getFileDescriptor());
				}
			}
			
			return fileOutStream;

		}
		catch (Exception e) {
			//Log.e(Application.TAG,
			//  "Error when copying file from " + source.getAbsolutePath() + " to " + target.getAbsolutePath(), e);
			return null;
		}

	}
	
	

	/**
	 * Delete a file. May be even on external SD card.
	 *
	 * @param file the file to be deleted.
	 * @return True if successfully deleted.
	 */
	public static boolean deleteNativeFile(@NonNull final File file) 
	{

		// First try the normal deletion.
		if(file.delete())
		{
			return true;
		}


		return !file.exists();
	}
	
	
	public static boolean deleteSAFFile(@NonNull final File file, Context context,Uri treeUri,String baseFolder) 
	{

	
		// Try with Storage Access Framework.
		if (SystemUtil.isAndroid5()) 
		{
			UsefulDocumentFile document = getDocumentFile1(file, false,context,treeUri,baseFolder);
			return document != null && document.delete();
		}

		// Try the Kitkat workaround.
		if (SystemUtil.isKitkat()) 
		{
			ContentResolver resolver = context.getContentResolver();

			try 
			{
				Uri uri = MediaStoreUtil.getUriFromFile(file.getAbsolutePath(),context);
				if (uri != null) 
				{
					resolver.delete(uri, null, null);
				}
				return !file.exists();
			}
			catch (Exception e) 
			{
				//Log.e(Application.TAG, "Error when deleting file " + file.getAbsolutePath(), e);
				return false;
			}
		}

		return !file.exists();
	}
	
	
	public static boolean deleteNativeDirectory(final File folder) 
	{     
		boolean success=false;
		
		if (folder.isDirectory())            //Check if folder file is a real folder
		{
			File[] list = folder.listFiles(); //Storing all file name within array
			if (list != null)                //Checking list value is null or not to check folder containts atlest one file
			{
				for (int i = 0; i < list.length; i++)    
				{
					File tmpF = list[i];
					if (tmpF.isDirectory())   //if folder  found within folder remove that folder using recursive method
					{
						success=deleteNativeDirectory(tmpF);
					}
					else
					{
						success=deleteNativeFile(tmpF); //else delete filr
					}

				}
			}

			if(folder.exists())  //delete empty folder
			{
				success=deleteNativeFile(folder);
			}

		}
		else
		{
			success=deleteNativeFile(folder);
		}
		
		return success;
	}

/*

	 //This method is not useful because we can directly delete entire directory through deleteSAFFile(@NonNull final File file, Context context,String baseFolder) method without resorting to any recursive method.
	public static boolean deleteSAFDirectory(final File folder, Context context,String baseFolder) {     
		boolean success=false;

		if (folder.isDirectory())            //Check if folder file is a real folder
		{
			File[] list = folder.listFiles(); //Storing all file name within array
			if (list != null)                //Checking list value is null or not to check folder containts atlest one file
			{
				for (int i = 0; i < list.length; i++)    
				{
					File tmpF = list[i];
					if (tmpF.isDirectory())   //if folder  found within folder remove that folder using recursive method
					{
						success=deleteSAFDirectory(tmpF,context,baseFolder);
					}
					else
					{
						success=deleteSAFFile(tmpF,context,baseFolder); //else delete filr
					}

				}
			}

			if(folder.exists())  //delete empty folder
			{
				success=deleteSAFFile(folder,context,baseFolder);
			}


		}
		else
		{
			success=deleteSAFFile(folder,context,baseFolder);
		}
		
		return success;
	}

	*/
		
		/**
		 * Rename a folder. In case of extSdCard in Kitkat, the old folder stays in place, but files are moved.
		 *
		 * @param source The source folder.
		 * @param target The target folder.
		 * @return true if the renaming was successful.
		 */
		public static boolean renameNativeFile(@NonNull final File source, @NonNull final File target) 
		{
			// First try the normal rename.
		
		
			if (source.renameTo(target)) 
			{
				return true;
			}
			
			if (target.exists()) 
			{
				return false;
			}

			
/*
			// Try the manual way, moving files individually.
			if (!mkdir(target,context)) {
				return false;
			}

			File[] sourceFiles = source.listFiles();

			if (sourceFiles == null) {
				return true;
			}

			for (File sourceFile : sourceFiles) {
				String fileName = sourceFile.getName();
				File targetFile = new File(target, fileName);
				if (!copyFile(sourceFile, targetFile,context,false)) {
					// stop on first error
					return false;
				}
			}
			// Only after successfully copying all files, delete files on source folder.
			for (File sourceFile : sourceFiles) {
				if (!deleteFile(sourceFile,context)) {
					// stop on first error
					return false;
				}
			}
			*/
			return false;
		}



	/**
	 * Rename a folder. In case of extSdCard in Kitkat, the old folder stays in place, but files are moved.
	 *
	 * @param source The source folder.
	 * @param target The target folder.
	 * @return true if the renaming was successful.
	 (@NonNull final File source, @NonNull final File target,Context context,String uri_string,String baseFolder)
	 */
	public static boolean renameSAFFile(@NonNull final File source, @NonNull final File target,Context context,Uri treeUri,String baseFolder) 
	{
	
		// Try the Storage Access Framework if it is just a rename within the same parent folder.
		if (SystemUtil.isAndroid5()) 
		{
			UsefulDocumentFile document = getDocumentFile1(source,false,context,treeUri,baseFolder);
			if (document != null && document.renameTo(target.getName()))
			{
				return true;

			}
		}

		
		return false;
	}
	
		

	public static boolean createNativeNewFile(@NonNull final File file) 
	{
		
		if (file.exists()) 
		{
			// nothing to create.
			return false;
		}
		
		// Try the normal way
		try
		{
			
			if (file.createNewFile()) 
			{
				return true;
			}
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}

		return false;
	}



	public static boolean createSAFNewFile(@NonNull final File file,Context context,Uri treeUri,String baseFolder) 
	{

		if (file.exists()) 
		{
			// nothing to create.
			return false;
		}

	
		// Try with Storage Access Framework.

		if (SystemUtil.isAndroid5()) 
		{
			UsefulDocumentFile document = getDocumentFile1(file, false,context,treeUri,baseFolder);
			// getDocumentFile implicitly creates the directory.
			return document != null && document.exists();
		}

		// Try the Kitkat workaround.
		if (SystemUtil.isKitkat()) 
		{
			File tempFile = new File(file, "dummyImage.jpg");

			File dummySong = copyDummyFiles(context);
			if (dummySong == null) {
				return false;
			}
			int albumId = MediaStoreUtil.getAlbumIdFromAudioFile(dummySong,context);
			Uri albumArtUri = Uri.parse("content://media/external/audio/albumart/" + albumId);

			ContentValues contentValues = new ContentValues();
			contentValues.put(MediaStore.MediaColumns.DATA, tempFile.getAbsolutePath());
			contentValues.put(MediaStore.Audio.AlbumColumns.ALBUM_ID, albumId);

			ContentResolver resolver = context.getContentResolver();
			if (resolver.update(albumArtUri, contentValues, null, null) == 0) {
				resolver.insert(Uri.parse("content://media/external/audio/albumart"), contentValues);
			}
			try 
			{
				ParcelFileDescriptor fd = resolver.openFileDescriptor(albumArtUri, "r");
				if (fd != null) 
				{
					fd.close();
				}
			}
			catch (Exception e) 
			{
				//Log.e(Application.TAG, "Could not open file", e);
				return false;
			}
			finally 
			{
				FileUtil.deleteSAFFile(tempFile,context,treeUri,baseFolder);
			}

			return true;
		}
		return false;
	}
	


		/**
		 * Create a folder. The folder may even be on external SD card for Kitkat.
		 *
		 * @param file The folder to be created.
		 * @return True if creation was successful.
		 */
		public static boolean mkdirNative(@NonNull final File file) 
		{
			if (file.exists()) 
			{
				// nothing to create.
				return true;
			}

			// Try the normal way
			if (file.mkdir()) 
			{
				return true;
			}
			return false;
		}

	public static boolean mkdirSAF(@NonNull final File file,Context context,Uri treeUri,String baseFolder) 
	{
		if (file.exists()) 
		{
			// nothing to create.
			return true;
		}


		// Try with Storage Access Framework.
		if (SystemUtil.isAndroid5()) 
		{
			UsefulDocumentFile document = getDocumentFile1(file, true,context,treeUri,baseFolder);
			// getDocumentFile implicitly creates the directory.
			return document != null && document.exists();
		}

		// Try the Kitkat workaround.
		if (SystemUtil.isKitkat()) 
		{
			File tempFile = new File(file, "dummyImage.jpg");

			File dummySong = copyDummyFiles(context);
			if (dummySong == null) 
			{
				return false;
			}
			int albumId = MediaStoreUtil.getAlbumIdFromAudioFile(dummySong,context);
			Uri albumArtUri = Uri.parse("content://media/external/audio/albumart/" + albumId);

			ContentValues contentValues = new ContentValues();
			contentValues.put(MediaStore.MediaColumns.DATA, tempFile.getAbsolutePath());
			contentValues.put(MediaStore.Audio.AlbumColumns.ALBUM_ID, albumId);

			ContentResolver resolver = context.getContentResolver();
			if (resolver.update(albumArtUri, contentValues, null, null) == 0) 
			{
				resolver.insert(Uri.parse("content://media/external/audio/albumart"), contentValues);
			}
			try 
			{
				ParcelFileDescriptor fd = resolver.openFileDescriptor(albumArtUri, "r");
				if (fd != null) 
				{
					fd.close();
				}
			}
			catch (Exception e) 
			{
				//Log.e(Application.TAG, "Could not open file", e);
				return false;
			}
			finally 
			{
				FileUtil.deleteSAFFile(tempFile,context,treeUri,baseFolder);
			}

			return true;
		}

		return false;
	}
	
		
		
	public static boolean mkdirsNative(@NonNull final File file) 
	{
		if (file.exists()) 
		{
			// nothing to create.
			//return file.isDirectory();
			return true;
		}

		// Try the normal way
		if (file.mkdirs()) 
		{
			return true;
		}

	

		return false;
	}
	
	

	public static boolean mkdirsSAF(@NonNull final File file,Context context,Uri treeUri,String baseFolder) 
	{
		if (file.exists()) 
		{
			// nothing to create.
			//return file.isDirectory();
			return true;
		}
	boolean success=true;
	String basefolder_copy=baseFolder;
		String [] file_path_substring=file.getAbsolutePath().substring(baseFolder.length()+1).split("\\/");
		for (int i=0; i< file_path_substring.length;i++)
		{
			basefolder_copy=basefolder_copy+File.separator+file_path_substring[i];
			File f=new File(basefolder_copy);
			if(!f.exists())
			{
				success=mkdirSAF(f,context,treeUri,baseFolder);
				if(!success)
				{
					return false;
				}
				
			}
	
		}
		return success;
	}
	
	
		
		/**
		 * Delete a folder.
		 *
		 * @param file The folder name.
		 * @return true if successful.
		 */
		public static boolean rmdirNative(@NonNull final File file) 
		{
			if (!file.exists()) 
			{
				return true;
			}
			if (!file.isDirectory()) 
			{
				return false;
			}
			String[] fileList = file.list();
			if (fileList != null && fileList.length > 0) 
			{
				// Delete only empty folder.
				return false;
			}

			// Try the normal way
			if (file.delete()) 
			{
				return true;
			}
			return !file.exists();
		}


	public static boolean rmdirSAF(@NonNull final File file,Context context,Uri treeUri,String baseFolder) 
	{
		if (!file.exists()) 
		{
			return true;
		}
		if (!file.isDirectory()) 
		{
			return false;
		}
		
		// Try with Storage Access Framework.
		if (SystemUtil.isAndroid5()) 
		{
			UsefulDocumentFile document = getDocumentFile1(file, true,context,treeUri,baseFolder);
			return document != null && document.delete();
		}

		// Try the Kitkat workaround.
		if (SystemUtil.isKitkat()) 
		{
			ContentResolver resolver = context.getContentResolver();
			ContentValues values = new ContentValues();
			values.put(MediaStore.MediaColumns.DATA, file.getAbsolutePath());
			resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);

			// Delete the created entry, such that content provider will delete the file.
			resolver.delete(MediaStore.Files.getContentUri("external"), MediaStore.MediaColumns.DATA + "=?",
							new String[]{file.getAbsolutePath()});
		}

		return !file.exists();
	}
		
		
		/**
		 * Delete all files in a folder.
		 *
		 * @param folder the folder
		 * @return true if successful.
		 */
		public static boolean deleteNativeFilesInFolder(@NonNull final File folder) 
		{
			boolean totalSuccess = true;

			String[] children = folder.list();
			if (children != null) 
			{
				for (String child : children) 
				{
					File file = new File(folder, child);
					if (!file.isDirectory()) 
					{
						boolean success =FileUtil.deleteNativeFile(file);
						if (!success) 
						{
							//Log.w(Application.TAG, "Failed to delete file" + child);
							totalSuccess = false;
						}
					}
				}
			}
			return totalSuccess;
		}

	public static boolean deleteSAFFilesInFolder(@NonNull final File folder,Context context,Uri treeUri,String baseFolder) 
	{
		boolean totalSuccess = true;

		String[] children = folder.list();
		if (children != null) {
			for (String child : children) 
			{
				File file = new File(folder, child);
				if (!file.isDirectory()) 
				{
					boolean success = FileUtil.deleteSAFFile(file,context,treeUri,baseFolder);
					if (!success) 
					{
						//Log.w(Application.TAG, "Failed to delete file" + child);
						totalSuccess = false;
					}
				}
			}
		}
		return totalSuccess;
	}
		
		/**
		 * Delete a directory asynchronously.
		 *
		 * @param activity    The activity calling this method.
		 * @param file        The folder name.
		 * @param postActions Commands to be executed after success.
		 */
		public static void rmdirNativeAsynchronously(@NonNull final Activity activity, @NonNull final File file, final Runnable postActions) 
		{
			new Thread() 
			{
				@Override
				public void run() 
				{
					int retryCounter = 5; // MAGIC_NUMBER
					while (!FileUtil.rmdirNative(file) && retryCounter > 0) 
					{
						try 
						{
							Thread.sleep(100); // MAGIC_NUMBER
						}
						catch (InterruptedException e) 
						{
							// do nothing
						}
						retryCounter--;
					}
					if (file.exists()) 
					{
						//DialogUtil.displayError(activity, R.string.message_dialog_failed_to_delete_folder, false,
												//file.getAbsolutePath());
					}
					else 
					{
						activity.runOnUiThread(postActions);
					}

				}
			}.start();
		}


	public static void rmdirSAFAsynchronously(@NonNull final Activity activity, @NonNull final File file, final Runnable postActions,final Context context,final Uri treeUri,final String baseFolder) 
	{
		new Thread() 
		{
			@Override
			public void run() 
			{
				int retryCounter = 5; // MAGIC_NUMBER
				while (!FileUtil.rmdirSAF(file,context,treeUri,baseFolder) && retryCounter > 0) {
					try 
					{
						Thread.sleep(100); // MAGIC_NUMBER
					}
					catch (InterruptedException e) 
					{
						// do nothing
					}
					retryCounter--;
				}
				if (file.exists()) 
				{
					//DialogUtil.displayError(activity, R.string.message_dialog_failed_to_delete_folder, false,
					//file.getAbsolutePath());
				}
				else 
				{
					activity.runOnUiThread(postActions);
				}

			}
		}.start();
	}
		
		
	public static boolean isFromInternal(@NonNull final File file) 
	{
		//boolean isExisting = file.exists();
		
		return file.getAbsolutePath().startsWith(Global.INTERNAL_STORAGE_PATH);
		/*
		boolean fromInternal=true;
	
		
		if(file.isDirectory())
		{
			try
			{
				File dummy_file=new File(file,"dummy");
				FileOutputStream output=new FileOutputStream(dummy_file);
				try 
				{
					output.close();
				}
				catch (IOException e) 
				{
					// do nothing.
				}
				if(dummy_file.exists())
				{
					dummy_file.delete();
				}
			}
			catch(FileNotFoundException e)
			{
				return false;
			}
			
		}
		else
		{
			try 
			{
				FileOutputStream output = new FileOutputStream(file,true);
				try 
				{
					output.close();
				}
				catch (IOException e) 
				{
					// do nothing.
				}
			}
			catch (FileNotFoundException e) 
			{
				return false;
			}
		}
		

		return fromInternal;
		*/
	}
	
		
		
		/**
		 * Check is a file is writable. Detects write issues on external SD card.
		 *
		 * @param file The file
		 * @return true if the file is writable.
		 */
		public static boolean isWritable(@NonNull final File file) 
		{
			return file.getAbsolutePath().startsWith(Global.INTERNAL_STORAGE_PATH);
			/*
			boolean isExisting = file.exists();
			
			boolean result=true;
		
			
			if(file.isDirectory())
			{
				try
				{
					File dummy_file=new File(file,"dummy");
					FileOutputStream output=new FileOutputStream(dummy_file);
					try 
					{
						output.close();
					}
					catch (IOException e) 
					{
						// do nothing.
					}
					if(dummy_file.exists())
					{
						dummy_file.delete();
					}
				}
				catch(FileNotFoundException e)
				{
					return false;
				}
			}
			else
			{
				try 
				{
					FileOutputStream output = new FileOutputStream(file, true);
					try 
					{
						output.close();
					}
					catch (IOException e) 
					{
						// do nothing.
					}
				}
				catch (FileNotFoundException e) 
				{
					return false;
				}
			}


			result = file.canWrite();

			// Ensure that file is not created during this process.
			if (!isExisting) 
			{
				// noinspection ResultOfMethodCallIgnored
				file.delete();
			}

			return result;
			*/
		}

		// Utility methods for Android 5

		/**
		 * Check for a directory if it is possible to create files within this directory, either via normal writing or via
		 * Storage Access Framework.
		 *
		 * @param folder The directory
		 * @return true if it is possible to write in this directory.
		 */
		@RequiresApi(api = VERSION_CODES.LOLLIPOP)
		public static boolean isWritableNormalOrSaf(@Nullable final File folder,Context context,Uri treeUri,String baseFolder) 
		{
			// Verify that this is a directory.
			if (folder == null || !folder.exists() || !folder.isDirectory()) 
			{
				return false;
			}

			// Find a non-existing file in this directory.
			int i = 0;
			File file;
			do 
			{
				String fileName = "AugendiagnoseDummyFile" + (++i);
				file = new File(folder, fileName);
			}
			while (file.exists());

			// First check regular writability
			if (isWritable(file)) 
			{
				return true;
			}

			// Next check SAF writability.
			UsefulDocumentFile document;
			try 
			{
				document = getDocumentFile1(file, false,context,treeUri,baseFolder);
			}
			catch (Exception e) 
			{
				return false;
			}

			if (document == null) 
			{
				return false;
			}

			// This should have created the file - otherwise something is wrong with access URL.
			boolean result = document.canWrite() && file.exists();

			// Ensure that the dummy file is not remaining.
			document.delete();

			return result;
		}
		

	public static String humanReadableByteCount(long bytes, boolean si) 
	{
		int unit = si ? 1000 : 1024;
		if (bytes < unit) return bytes + " B";
		int exp = (int) (Math.log(bytes) / Math.log(unit));
		String pre = (si ? "kMGTPE" : "KMGTPE").charAt(exp-1) + (si ? "" : "i");
		//return (long)(bytes/Math.pow(unit,exp)*100+0.5)/100.0 + " "+pre+"B";
		return String.format("%.2f %sB", bytes / Math.pow(unit, exp), pre);
	}
	
		/**
		 * Get the SD card directory.
		 *
		 * @return The SD card directory.
		 */
		@NonNull
		public static String getSdCardPath() 
		{
			String sdCardDirectory = Environment.getExternalStorageDirectory().getAbsolutePath();

			try 
			{
				sdCardDirectory = new File(sdCardDirectory).getCanonicalPath();
			}
			catch (IOException ioe) 
			{
				//Log.e(Application.TAG, "Could not get SD directory", ioe);
			}
			return sdCardDirectory;
		}

		/**
		 * Get a list of external SD card paths. (Kitkat or higher.)
		 *
		 * @return A list of external SD card paths.
		 */
		@RequiresApi(Build.VERSION_CODES.KITKAT)
		public static String[] getExtSdCardPaths(Context context) 
		{
			List<String> paths = new ArrayList<>();
			for (File file : context.getExternalFilesDirs("external")) 
			{
				if (file != null && !file.equals(context.getExternalFilesDir("external"))) 
				{
					int index = file.getAbsolutePath().lastIndexOf("/Android/data");
					if (index < 0) 
					{
						//.Log.w(Application.TAG, "Unexpected external file dir: " + file.getAbsolutePath());
					}
					else 
					{
						String path = file.getAbsolutePath().substring(0, index);
						try 
						{
							path = new File(path).getCanonicalPath();
						}
						catch (IOException e) 
						{
							// Keep non-canonical path.
						}
						paths.add(path);
					}
				}
			}
			return paths.toArray(new String[paths.size()]);
		}

		/**
		 * Determine the main folder of the external SD card containing the given file.
		 *
		 * @param file the file.
		 * @return The main folder of the external SD card containing this file, if the file is on an SD card. Otherwise,
		 * null is returned.
		 */
		@RequiresApi(Build.VERSION_CODES.KITKAT)
		public static String getExtSdCardFolder(@NonNull final File file,Context context) 
		{
			String[] extSdPaths = getExtSdCardPaths(context);
			try 
			{
				for (String extSdPath : extSdPaths) 
				{
					if (file.getCanonicalPath().startsWith(extSdPath)) 
					{
						return extSdPath;
					}
				}
			}
			catch (IOException e) 
			{
				return null;
			}
			return null;
		}

		/**
		 * Determine if a file is on external sd card. (Kitkat or higher.)
		 *
		 * @param file The file.
		 * @return true if on external sd card.
		 */
		@RequiresApi(Build.VERSION_CODES.KITKAT)
		public static boolean isOnExtSdCard(@NonNull final File file,Context context) 
		{
			return getExtSdCardFolder(file,context) != null;
		}



		/**
		 * Get the full path of a document from its tree URI.
		 *
		 * @param treeUri The tree RI.
		 * @return The path (without trailing file separator).
		 */
		@RequiresApi(api = VERSION_CODES.LOLLIPOP)
		@Nullable
		public static String getFullPathFromTreeUri(@Nullable final Uri treeUri,Context context) 
		{
			if (treeUri == null) 
			{
				return null;
			}
			String volumePath = FileUtil.getVolumePath(FileUtil.getVolumeIdFromTreeUri(treeUri),context);
			if (volumePath == null) 
			{
				return File.separator;
			}
			if (volumePath.endsWith(File.separator)) 
			{
				volumePath = volumePath.substring(0, volumePath.length() - 1);
			}

			String documentPath = FileUtil.getDocumentPathFromTreeUri(treeUri);
			if (documentPath.endsWith(File.separator)) 
			{
				documentPath = documentPath.substring(0, documentPath.length() - 1);
			}

			if (documentPath.length() > 0) 
			{
				if (documentPath.startsWith(File.separator)) 
				{
					return volumePath + documentPath;
				}
				else 
				{
					return volumePath + File.separator + documentPath;
				}
			}
			else 
			{
				return volumePath;
			}
		}

		/**
		 * Get the path of a certain volume.
		 *
		 * @param volumeId The volume id.
		 * @return The path.
		 */
		private static String getVolumePath(final String volumeId,Context context) 
		{
			if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) 
			{
				return null;
			}

			try 
			{
				StorageManager mStorageManager =
					(StorageManager) context.getSystemService(Context.STORAGE_SERVICE);

				Class<?> storageVolumeClazz = Class.forName("android.os.storage.StorageVolume");

				Method getVolumeList = mStorageManager.getClass().getMethod("getVolumeList");
				Method getUuid = storageVolumeClazz.getMethod("getUuid");
				Method getPath = storageVolumeClazz.getMethod("getPath");
				Method isPrimary = storageVolumeClazz.getMethod("isPrimary");
				Object result = getVolumeList.invoke(mStorageManager);

				final int length = Array.getLength(result);
				for (int i = 0; i < length; i++) 
				{
					Object storageVolumeElement = Array.get(result, i);
					String uuid = (String) getUuid.invoke(storageVolumeElement);
					Boolean primary = (Boolean) isPrimary.invoke(storageVolumeElement);

					// primary volume?
					if (primary && PRIMARY_VOLUME_NAME.equals(volumeId)) 
					{
						return (String) getPath.invoke(storageVolumeElement);
					}

					// other volumes?
					if (uuid != null) 
					{
						if (uuid.equals(volumeId))
						{
							return (String) getPath.invoke(storageVolumeElement);
						}
					}
				}

				// not found.
				return null;
			}
			catch (Exception ex) 
			{
				return null;
			}
		}

		/**
		 * Get the volume ID from the tree URI.
		 *
		 * @param treeUri The tree URI.
		 * @return The volume ID.
		 */
		@RequiresApi(Build.VERSION_CODES.LOLLIPOP)
		private static String getVolumeIdFromTreeUri(final Uri treeUri) 
		{
			final String docId = DocumentsContract.getTreeDocumentId(treeUri);
			final String[] split = docId.split(":");

			if (split.length > 0) 
			{
				return split[0];
			}
			else 
			{
				return null;
			}
		}

		/**
		 * Get the document path (relative to volume name) for a tree URI (LOLLIPOP).
		 *
		 * @param treeUri The tree URI.
		 * @return the document path.
		 */
		@RequiresApi(Build.VERSION_CODES.LOLLIPOP)
		private static String getDocumentPathFromTreeUri(final Uri treeUri) 
		{
			final String docId = DocumentsContract.getTreeDocumentId(treeUri);
			final String[] split = docId.split(":");
			if ((split.length >= 2) && (split[1] != null)) 
			{
				return split[1];
			}
			else 
			{
				return File.separator;
			}
		}

		// Utility methods for Kitkat

		/**
		 * Copy a resource file into a private target directory, if the target does not yet exist. Required for the Kitkat
		 * workaround.
		 *
		 * @param resource   The resource file.
		 * @param folderName The folder below app folder where the file is copied to.
		 * @param targetName The name of the target file.
		 * @return the dummy file.
		 * @throws IOException thrown if there are issues while copying.
		 */
		private static File copyDummyFile(final int resource, final String folderName, @NonNull final String targetName,Context context)
		throws IOException 
		{
			File externalFilesDir = context.getExternalFilesDir(folderName);
			if (externalFilesDir == null) 
			{
				return null;
			}
			File targetFile = new File(externalFilesDir, targetName);

			if (!targetFile.exists()) 
			{
				InputStream in = null;
				OutputStream out = null;
				try {
					in = context.getResources().openRawResource(resource);
					out = new FileOutputStream(targetFile);
					byte[] buffer = new byte[4096]; // MAGIC_NUMBER
					int bytesRead;
					while ((bytesRead = in.read(buffer)) != -1) 
					{
						out.write(buffer, 0, bytesRead);
					}
				}
				finally 
				{
					if (in != null) 
					{
						try 
						{
							in.close();
						}
						catch (IOException ex) 
						{
							// do nothing
						}
					}
					if (out != null) 
						{
						try 
						{
							out.close();
						}
						catch (IOException ex) 
						{
							// do nothing
						}
					}
				}
			}
			return targetFile;
		}

		/**
		 * Copy the dummy image and dummy mp3 into the private folder, if not yet there. Required for the Kitkat workaround.
		 *
		 * @return the dummy mp3.
		 */
		private static File copyDummyFiles(Context context) 
		{
			try 
			{
				copyDummyFile(R.raw.albumart, "mkdirFiles", "albumart.jpg",context);
				return copyDummyFile(R.raw.silence, "mkdirFiles", "silence.mp3",context);

			}
			catch (IOException e) 
			{
				//Log.e(Application.TAG, "Could not copy dummy files.", e);
				return null;
			}
		}
		
	
	public static void fastChannelCopy(final ReadableByteChannel src, final WritableByteChannel dest) throws IOException 
	{
		final ByteBuffer buffer = ByteBuffer.allocateDirect(16 * 1024);
		while (src.read(buffer) != -1) 
		{
			// prepare the buffer to be drained
			buffer.flip();
			// write to the channel, may block
			dest.write(buffer);
			// If partial transfer, shift remainder down
			// If buffer is empty, same as doing clear()
			buffer.compact();
		}
		// EOF will leave buffer in fill state
		buffer.flip();
		// make sure the buffer is fully drained.
		while (buffer.hasRemaining()) 
		{
			dest.write(buffer);
		}
	}

	public static void channelCopy(FileChannel srcChannel, FileChannel destChannel)
	{
		try
		{
			//int maxCount=1024*16;
			long size=srcChannel.size();
			long position=0;
			//while(position<size)
			{
				position+=srcChannel.transferTo(position,size,destChannel);
			}
		}
		catch(IOException e){}
	
		finally
		{
			
			try
			{
				if(srcChannel!=null)
				{
					srcChannel.close();
				}
				if(destChannel!=null)
				{
					destChannel.close();
				}
			}
			catch(IOException e){}
			
		}
	
	}
}
	
