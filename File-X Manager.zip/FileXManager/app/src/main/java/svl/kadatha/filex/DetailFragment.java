package svl.kadatha.filex;
import android.content.*;
import android.content.pm.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.net.*;
import android.os.*;
import android.support.v4.os.*;
import android.support.v7.widget.*;
import android.util.*;
import android.view.*;
import android.view.animation.*;
import android.widget.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.regex.*;
import java.util.zip.*;




public class DetailFragment extends android.support.v4.app.Fragment
{
	
	private List<FilePOJO> filePOJO_list;
	static private final SimpleDateFormat SDF=new SimpleDateFormat("dd-MM-yyyy hh:mm");
	RecyclerView filepath_recyclerview, recyclerView;
	LinearLayoutManager lm;
	TextView folder_empty;
	DetailRecyclerViewAdapter adapter;
	private FilePathRecyclerViewAdapter filepath_adapter;
	public File fileclickselected=null;
	private String file_click_selected_name=null;
	public static boolean CUT_SELECTED;
	public static boolean COPY_SELECTED;
	
	public static ArrayList<File> FILE_SELECTED_FOR_CUT_COPY=new ArrayList<>();
	public static String SEARCH_FILE_NAME;
	public static List<FilePOJO> SEARCH_IN_DIR=new ArrayList<>();
	public static String SEARCH_FILE_TYPE;
	public static boolean SEARCH_WHOLEWORD,SEARCH_CASESENSITIVE,SEARCH_REGEX;
	
	static final String SEARCH_RESULT="Search result";
	public SparseBooleanArray mselecteditems=new SparseBooleanArray();
	public ArrayList<File> file_selected_array=new ArrayList<>();
	private MainActivity mainActivity;
	private Context context;
	AsyncTaskDirectoryList asyncTaskDirectoryList;
	AsyncTaskLibrarySearch asyncTaskLibrarySearch;
	
	public boolean archive_view;
	private FileFilter file_filter;
	private static FilenameFilter FILE_NAME_FILTER;
	
	private AsyncTaskStatus asynctask_status;
	private Handler handler,h;
	public String index_file;
	private int file_index;
	public int file_list_size;
	int s=0; int t=0;
	//ViewPager viewPager;
	boolean is_toolbar_visible=true;
	private static PackageInfo PI;
	
	
	
	
	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		// TODO: Implement this method
		super.onCreate(savedInstanceState);
		setRetainInstance(true);
		asynctask_status=AsyncTaskStatus.NOT_YET_STARTED;
		Bundle bundle=getArguments();
		index_file=bundle.getString("index_file");
		//search_file_name=bundle.getString("search_file_name");
		//search_file_type=bundle.getString("search_file_type");
	
		
	}
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
	{

		View v=inflater.inflate(R.layout.fragment_detail,container,false);
		context=getContext();
		mainActivity=(MainActivity)getActivity();
		handler=new Handler();
		h=new Handler();
	
		filepath_recyclerview=v.findViewById(R.id.fragment_detail_filepath_container);
		recyclerView=v.findViewById(R.id.fragment_detail_container);
		DividerItemDecoration itemdecor=new DividerItemDecoration(context,DividerItemDecoration.HORIZONTAL);
		
		filepath_recyclerview.addItemDecoration(itemdecor );
		
		LinearLayoutManager file_path_lm=new LinearLayoutManager(context,LinearLayoutManager.HORIZONTAL,false);
		filepath_recyclerview.setLayoutManager(file_path_lm);
		lm=new LinearLayoutManager(context);
		recyclerView.setLayoutManager(lm);
		

		recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener()
		{
			
			int scroll_distance=0;
			final int threshold=5;
		
			public void onScrolled(RecyclerView rv, int dx, int dy)
			{
				
				super.onScrolled(rv,dx,dy);
				
				if(scroll_distance>threshold && is_toolbar_visible)
				{
					if(MainActivity.TOOLBAR_SHOWN.equals("bottom"))
					{
						mainActivity.bottom_toolbar.animate().translationY(mainActivity.bottom_toolbar.getHeight()).setInterpolator(new AccelerateInterpolator(1));

					}
					else if(MainActivity.TOOLBAR_SHOWN.equals("actionmode"))
					{

						mainActivity.actionmode_toolbar.animate().translationY(mainActivity.actionmode_toolbar.getHeight()).setInterpolator(new AccelerateInterpolator(1));
					}
					else if(MainActivity.TOOLBAR_SHOWN.equals("paste"))
					{

						mainActivity.paste_toolbar.animate().translationY(mainActivity.paste_toolbar.getHeight()).setInterpolator(new AccelerateInterpolator(1));
					}
					else if(MainActivity.TOOLBAR_SHOWN.equals("extract"))
					{

						mainActivity.extract_toolbar.animate().translationY(mainActivity.extract_toolbar.getHeight()).setInterpolator(new AccelerateInterpolator(1));
					}

					is_toolbar_visible=false;
					scroll_distance=0;
				}
				else if(scroll_distance<-threshold && !is_toolbar_visible)
				{

					if(MainActivity.TOOLBAR_SHOWN.equals("bottom"))
					{
						mainActivity.bottom_toolbar.animate().translationY(0).setInterpolator(new DecelerateInterpolator(1));

					}
					else if(MainActivity.TOOLBAR_SHOWN.equals("actionmode"))
					{

						mainActivity.actionmode_toolbar.animate().translationY(0).setInterpolator(new DecelerateInterpolator(1));
					}
					else if(MainActivity.TOOLBAR_SHOWN.equals("paste"))
					{

						mainActivity.paste_toolbar.animate().translationY(0).setInterpolator(new DecelerateInterpolator(1));
					}
					else if(MainActivity.TOOLBAR_SHOWN.equals("extract"))
					{

						mainActivity.extract_toolbar.animate().translationY(0).setInterpolator(new DecelerateInterpolator(1));
					}

					is_toolbar_visible=true;
					scroll_distance=0;
				}

				if((is_toolbar_visible && dy>0) || (!is_toolbar_visible && dy<0))
				{
					scroll_distance+=dy;
				}

			}

		});

		folder_empty=v.findViewById(R.id.empty_folder);
		fileclickselected=new File(getTag());
		file_click_selected_name=fileclickselected.toString();
		if(file_click_selected_name.startsWith(MainActivity.ARCHIVE_EXTRACT_DIR.getAbsolutePath()) && MainActivity.ARCHIVE_VIEW)
		{
			archive_view=true;
		}
		else
		{
			archive_view=false;
		}
		file_filter=new FileFilter()
		{
			public boolean accept(File file)
			{
				if(MainActivity.SHOW_HIDDEN_FILE)
				{
					return true;
				}
				else
				{
					return !file.isHidden();
				}
			}
		};
		
		FILE_NAME_FILTER=new FilenameFilter()
		{
			public boolean accept(File fi, String na)
			{
				if(MainActivity.SHOW_HIDDEN_FILE)
				{
					return true;
				}
				else
				{
					return !na.startsWith(".");
				}
			}
		};
		//if(asynctask_status==AsyncTaskStatus.NOT_YET_STARTED || asynctask_status==AsyncTaskStatus.COMPLETED)
		if(asynctask_status!=AsyncTaskStatus.STARTED)
		{

			if(fileclickselected.exists())
			{
				
				asyncTaskDirectoryList=new AsyncTaskDirectoryList();
				asyncTaskDirectoryList.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
			}
			else if(MainActivity.LIBRARY_CATEGORIES.contains(file_click_selected_name)|| file_click_selected_name.equals(SEARCH_RESULT))
			{
					
				asyncTaskLibrarySearch=new AsyncTaskLibrarySearch(file_click_selected_name);
				asyncTaskLibrarySearch.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);

			}
		}
		
		
			h.post(new Runnable()
				{
					public void run()
					{
						
						if(asynctask_status==AsyncTaskStatus.STARTED && filePOJO_list.size()<1)
						{
							h.postDelayed(this,25);
							
						}
						else
						{
				
							filepath_adapter=new FilePathRecyclerViewAdapter(file_click_selected_name);
							adapter=new DetailRecyclerViewAdapter(filePOJO_list,context,archive_view);
							set_adapter();
							h.removeCallbacks(this);
						}
					}

				});
				
				
			
			handler.post(new Runnable()
				{
				
					public void run()
					{
						if(asynctask_status==AsyncTaskStatus.COMPLETED)
						{

							if(adapter!=null)
							{
								adapter.notifyDataSetChanged();

							
							}
							
							if( file_index!=0)
							{
								
								
								lm.scrollToPositionWithOffset(file_index,0);
								file_index=0;

							}
							handler.removeCallbacks(this);
						}
						else
						{
							if(adapter!=null)
							{
								
								adapter.notifyDataSetChanged();
								
							}
							if( file_index!=0)
							{
						
								lm.scrollToPositionWithOffset(file_index,0);
								file_index=0;

							}
							handler.postDelayed(this,100);

						}
						
					}
				});
		
		return v;
	}
	
	public static DetailFragment getNewInstance(String index_file)
	{
		DetailFragment df=new DetailFragment();
		Bundle bundle=new Bundle();
		bundle.putString("index_file",index_file);
		//bundle.putString("search_file_name",search_file_name);
		//bundle.putString("search_file_type",search_file_type);
		df.setArguments(bundle);
		return df;
	}
	
	public void refresh_data()
	{
		file_filter=new FileFilter()
		{
			public boolean accept(File file)
			{
				if(MainActivity.SHOW_HIDDEN_FILE)
				{
					return true;
				}
				else
				{
					return !file.isHidden();
				}
			}
		};
		//if(asynctask_status==AsyncTaskStatus.NOT_YET_STARTED || asynctask_status==AsyncTaskStatus.COMPLETED)
		if(asynctask_status!=AsyncTaskStatus.STARTED)
		{

			if(fileclickselected.exists())
			{

				asyncTaskDirectoryList=new AsyncTaskDirectoryList();
				asyncTaskDirectoryList.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
			}
			else if(MainActivity.LIBRARY_CATEGORIES.contains(file_click_selected_name)|| file_click_selected_name.equals(SEARCH_RESULT))
			{

				asyncTaskLibrarySearch=new AsyncTaskLibrarySearch(file_click_selected_name);
				asyncTaskLibrarySearch.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);

			}
		}


		h.post(new Runnable()
			{
				public void run()
				{

					if(asynctask_status==AsyncTaskStatus.STARTED && filePOJO_list.size()<1)
					{
						h.postDelayed(this,25);

					}
					else
					{

						//filepath_adapter=new FilePathRecyclerViewAdapter(file_click_selected_name);
						//adapter=new DetailRecyclerViewAdapter(filePOJO_list,context,archive_view);
						//set_adapter();
						
						adapter.update(filePOJO_list);
						mainActivity.num_selected_btn.setText(mselecteditems.size()+"/"+file_list_size);
						h.removeCallbacks(this);
					}
				}

			});



		handler.post(new Runnable()
			{
				public void run()
				{
					
					if(asynctask_status==AsyncTaskStatus.COMPLETED)
					{

						if(adapter!=null)
						{
					
							//s=filePOJO_list.size();
							//adapter.notifyItemRangeChanged(0,s);
							
							adapter.notifyDataSetChanged();

						}

						if( file_index!=0)
						{


							lm.scrollToPositionWithOffset(file_index,0);
							file_index=0;

						}
						handler.removeCallbacks(this);
					}
					else
					{
						if(adapter!=null)
						{
						
							//s=filePOJO_list.size();
							//adapter.notifyItemRangeChanged(0,s);
							adapter.notifyDataSetChanged();
							
						}
						if( file_index!=0)
						{

							lm.scrollToPositionWithOffset(file_index,0);
							file_index=0;

						}
						handler.postDelayed(this,100);

					}

				}
			});
		
	}


	
	private void insert_filePOJO_list(File[] f_l, boolean extracticon)
	{
		int size=f_l.length;
		file_list_size=size;
		for(int i=0;i<size;i++)
		{
			File f=f_l[i];
			String name=f.getName();
			String path=f.getAbsolutePath();
			String file_ext="";
			int overlay_visible=View.INVISIBLE;
			int alfa=225;
			int idx=name.lastIndexOf(".");
			if(idx!=-1)
			{
				file_ext=name.substring(idx+1);
			}
			
			if(file_ext.matches(Global.VIDEO_REGEX))
			{
				overlay_visible=View.VISIBLE;
			}
			if(MainActivity.SHOW_HIDDEN_FILE && f.isHidden())
			{
				alfa=100;
			}
			if(extracticon)
			{
				extract_icon(path,file_ext);

			}
			
			String date=SDF.format(f.lastModified());
			String si=getFileSize(f,archive_view);
			Integer type=getFileType(f,file_ext);
			filePOJO_list.add(new FilePOJO(f,name,path,date,si,type,file_ext,alfa,overlay_visible));
			if(index_file!=null && name.equals(index_file))
			{

				file_index=i;
				index_file=null;

			}

		}
	}
	/*
	private void insert_filePOJO_list(List<File> f_l, boolean extracticon)
	{
		int size=f_l.size();
		file_list_size=size;
		for(int i=0;i<size;i++)
		{
			File f=f_l.get(i);
			String name=f.getName();
			String path=f.getAbsolutePath();
			String file_ext="";
			int idx=name.lastIndexOf(".");
			if(idx!=-1)
			{
				file_ext=name.substring(idx+1);
			}
			if(extracticon)
			{
				extract_icon(path,file_ext);

			}

			String date=sdf.format(f.lastModified());
			String si=getFileSize(f,archive_view);
			Integer type=getFileType(f,file_ext);
			filePOJO_list.add(new FilePOJO(f,name,path,date,si,type));
			if(index_file!=null && name.equals(index_file))
			{

				file_index=i;
				index_file=null;

			}

		}
	}
	*/

	private void file_open_intent_despatch(final File file, String file_name)
	{
		int idx=file_name.lastIndexOf(".");
		String file_ext="";
		if(idx!=-1)
		{
			file_ext=file_name.substring(idx+1);
		}
		if(file_ext.matches("(?i)zip"))
		{
			Intent intent=new Intent(Intent.ACTION_VIEW);
			intent.setDataAndType(Uri.fromFile(file),"application/zip");
			intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
			if(intent.resolveActivity(MainActivity.PM)!=null)
			{

				context.startActivity(intent);
			}

		}
		else if(file_ext=="" || !MainActivity.whether_matched_recognised_files(file_ext))
		{
			FileTypeSelectDialog fileTypeSelectFragment=new FileTypeSelectDialog();
			fileTypeSelectFragment.setFileTypeSelectListener(new FileTypeSelectDialog.FileTypeSelectListener()
				{
					public void onSelectType(String type)
					{
						try
						{
							FileIntentDispatch.openFile(context,file,type);

						}
						catch(IOException e)
						{
							print("Exception thrown");
						}
					}
				});
			fileTypeSelectFragment.show(MainActivity.FM,"");
		}
		else
		{
			try
			{
				FileIntentDispatch.openFile(context,file,"");

			}
			catch(IOException e)
			{
				print("Exception thrown");
			}
		}
	}
	

	

	public void set_adapter()
	{
		
		filepath_recyclerview.setAdapter(filepath_adapter);
		filepath_recyclerview.scrollToPosition(filepath_adapter.getItemCount()-1);
		if(adapter==null) return;
		recyclerView.setAdapter(adapter);
		
		if(filePOJO_list!=null && filePOJO_list.size()==0)
		{
				recyclerView.setVisibility(View.GONE);
				folder_empty.setVisibility(View.VISIBLE);
	
		}
		adapter.setCardViewClickListener(new DetailRecyclerViewAdapter.CardViewClickListener()
			{
				public void onClick(int pos, View v, File f, String name)
				{
					final File file=f;
					if(file.isDirectory())
					{
						mainActivity.createFragmentTransaction(file,null);
					}
					else if(file.canRead())
					{

						if(archive_view)
						{

							int idx=name.lastIndexOf(".");
							if(idx!=-1)
							{
								String file_ext=name.substring(idx+1);
								if(file_ext.matches("(?i)zip"))
								{
									print("can't open file");
									return;
								}
							}

							ZipFile zipfile=null;
							try
							{
								zipfile=new ZipFile(MainActivity.ZIP_FILE);
							}
							catch(IOException e){}
							ZipEntry zip_entry=zipfile.getEntry(file.getAbsolutePath().substring(MainActivity.ARCHIVE_CACHE_DIR_LENGTH+1));
							if(zip_entry==null)
							{
								print("can't open file");
								return;
							}
							try
							{
								if(!ExtractZipFile.read_zipentry(context,zipfile,zip_entry,MainActivity.ARCHIVE_EXTRACT_DIR))
								{
									return;
								}
							}
							catch(FileNotFoundException | IOException e){}


						}
						file_open_intent_despatch(file,name);
					

					}
					if(MainActivity.RECENTS.size()!=0)
					{
						if((!MainActivity.RECENTS.getFirst().equals(file.getAbsolutePath())&& !(archive_view)))
						{
							if(MainActivity.RECENTS.size()>=RecentDialog.RECENT_SIZE)
							{
								MainActivity.RECENTS.removeLast();
							}

							MainActivity.RECENTS.addFirst(make_filePOJO(file,false,false));
						}

					}
					else
					{
						MainActivity.RECENTS.addFirst(make_filePOJO(file,false,false));
					}


				}

				public void onLongClick(int pos, View v)
				{

					if(!MainActivity.TOOLBAR_SHOWN.equals("paste") && !mainActivity.TOOLBAR_SHOWN.equals("extract"))
					{
						mainActivity.actionmode_toolbar.setVisibility(View.VISIBLE);
						mainActivity.paste_toolbar.setVisibility(View.GONE);
						mainActivity.bottom_toolbar.setVisibility(View.GONE);
						mainActivity.TOOLBAR_SHOWN="actionmode";
						mainActivity.actionmode_toolbar.animate().translationY(0).setInterpolator(new DecelerateInterpolator(1));
					}
					else if(MainActivity.TOOLBAR_SHOWN.equals("paste"))
					{
						
						mainActivity.paste_toolbar.animate().translationY(0).setInterpolator(new DecelerateInterpolator(1));
					}
					else if(MainActivity.TOOLBAR_SHOWN.equals("extract"))
					{
						mainActivity.extract_toolbar.animate().translationY(0).setInterpolator(new DecelerateInterpolator(1));
					}
					is_toolbar_visible=true;
				}
			});

		
	}
	
	
	public void clearSelection()
	{
		
		mselecteditems=new SparseBooleanArray();
		file_selected_array=new ArrayList<>();
		
		if(adapter!=null)
		{
			adapter.notifyDataSetChanged();
			mainActivity.num_selected_btn.setText(mselecteditems.size()+"/"+file_list_size);
			/*
			if(MainActivity.TOOLBAR_SHOWN.equals("bottom"))
			{
				mainActivity.bottom_toolbar.animate().translationY(0).setInterpolator(new DecelerateInterpolator(1));
				visible=true;
			}
			*/
		}
		
	}
	
	private class AsyncTaskDirectoryList extends AsyncTask<Void,Void,Void>
	{
		

	
		AsyncTaskDirectoryList()
		{
			filePOJO_list=new ArrayList<>();
			
		}
		
		@Override
		protected void onPreExecute()
		{
			// TODO: Implement this method
			super.onPreExecute();
			asynctask_status=AsyncTaskStatus.STARTED;
			
	
		}

		@Override
		protected void onCancelled(Void result)
		{
			// TODO: Implement this method
			super.onCancelled(result);
			asynctask_status=AsyncTaskStatus.COMPLETED;
			
		}
		
		
		@Override
		protected Void doInBackground(Void[] p1)
		{
			// TODO: Implement this method
			
			File[] file_array;
			
			if((file_array=fileclickselected.listFiles(file_filter))!=null)
			{

				Arrays.sort(file_array,FileComparator.FileComparate(Global.SORT));
				insert_filePOJO_list(file_array,true);
				
			}
			
			//ListFiles.List(fileclickselected.getAbsolutePath(),filePOJO_list,true,archive_view);
			
			return null;
		}

		@Override
		protected void onPostExecute(Void result)
		{
			// TODO: Implement this method
		
			super.onPostExecute(result);
			asynctask_status=AsyncTaskStatus.COMPLETED;
		}

	}
	

	
	private class AsyncTaskLibrarySearch extends AsyncTask<Void, Void,Void>
	{

		String library_or_search;
		String what_to_find=null;
		List<FilePOJO> path=new ArrayList<>();
		String file_type="f";
		int count=0;
		ProgressBarFragment pbf=new ProgressBarFragment();
		
		AsyncTaskLibrarySearch(String library_or_search)
		{
			this.library_or_search=library_or_search;
		
		}
		
		@Override
		protected void onPreExecute()
		{
			// TODO: Implement this method
			super.onPreExecute();
			asynctask_status=AsyncTaskStatus.STARTED;
			pbf.show(MainActivity.FM,"progressbar_dialog");
			
			
		}

		@Override
		protected void onCancelled(Void result)
		{
			// TODO: Implement this method
			super.onCancelled(result);
			pbf.dismissAllowingStateLoss();
			asynctask_status=AsyncTaskStatus.COMPLETED;
			
			
		}
		
		

		@Override
		protected Void doInBackground(Void[] p1)
		{
			// TODO: Implement this method
		
			if(filePOJO_list!=null)
			{
				file_list_size=filePOJO_list.size();
				Collections.sort(filePOJO_list,FileComparator.FilePOJOComparate(Global.SORT));
				return null;
			}

			filePOJO_list=new ArrayList<>();
			
			
			if(library_or_search.equals(DetailFragment.SEARCH_RESULT))
			{
				
				for(FilePOJO f : SEARCH_IN_DIR)
				{
					if(!f.getPath().equals("/") && Environment.MEDIA_MOUNTED.equals(EnvironmentCompat.getStorageState(f.getFile())))
					{
						{
							path.add(f);
						}
					}

				}
				if(SEARCH_REGEX)
				{
					what_to_find=SEARCH_FILE_NAME;
				}
				else if(SEARCH_WHOLEWORD)
				{
					what_to_find="\\Q"+SEARCH_FILE_NAME+"\\E";
					if(!SEARCH_CASESENSITIVE)
					{
						what_to_find="(?i)\\Q"+SEARCH_FILE_NAME+"\\E";
					}
				}
				else
				{
					what_to_find=".*(\\Q"+SEARCH_FILE_NAME+"\\E).*";
					if(!SEARCH_CASESENSITIVE)
					{
						what_to_find=".*((?i)\\Q"+SEARCH_FILE_NAME+"\\E).*";
					}
				}
				
				file_type=SEARCH_FILE_TYPE;


			}
			else
			{
				for(FilePOJO f : MainActivity.STORAGE_DIR)
				{
					if(!f.getPath().equals("/") && Environment.MEDIA_MOUNTED.equals(EnvironmentCompat.getStorageState(f.getFile())))
					{
						{
							path.add(f);
						}
					}
				}
				switch (library_or_search)
				{
					case "Document":
						what_to_find=".*((?i)\\.doc|\\.docx|\\.txt|\\.pdf|\\.java|\\.xml|\\.rtf|\\.cpp|\\.c|\\.h)$";
						
						break;

					case "Picture":
						what_to_find=".*((?i)\\.png|\\.jpg|\\.jpeg|\\.gif|\\.tif|\\.svg|\\.webp)$";
						
						break;

					case "Audio":
						what_to_find=".*((?i)\\.mp3|\\.ogg|\\.wav|\\.aac|\\.wma)$";
						
						
						break;

					case "Video":
						what_to_find=".*((?i)\\.3gp|\\.mp4|\\.avi|\\.mov|\\.flv|\\.wmv|\\.webm)$";
						
						break;

					case "Archive":
						what_to_find=".*((?i)\\.zip|\\.rar|\\.tar|\\.gz|\\.gzip)$";
						
						break;

					case "APK":
						what_to_find=".*(?i)\\.apk$";
						
						break;

					default:
						break;

				}
				


			}
			for(FilePOJO f : path)
			{
				search_file(what_to_find,file_type,f.getFile(),filePOJO_list);

			}
			Collections.sort(filePOJO_list,FileComparator.FilePOJOComparate((Global.SORT)));
			
	
			return null;
		}
		

		private void search_file(String search_name,String file_type, File search_dir, List<FilePOJO> search_result) throws PatternSyntaxException
		{
			File[] list=search_dir.listFiles();
			int size=list.length;
			for(int i=0;i<size;i++)
			{
				File f=list[i];
				if(isCancelled())
				{
					return;
				}
				try
				{
					if(f.isDirectory())
					{
						if(Pattern.matches(search_name,f.getName()) && (file_type.equals("d")|| file_type.equals("fd")))
						{
							search_result.add(make_filePOJO(f,true,false));
							count++;

						}
						search_file(search_name,file_type,f,search_result);

					}
					else
					{
						if(Pattern.matches(search_name,f.getName()) && (file_type.equals("f")||file_type.equals("fd")))
						{
							search_result.add(make_filePOJO(f,true,false));
							count++;
						}
					}
				
					mainActivity.num_selected_btn.setText(mselecteditems.size()+"/"+(file_list_size=count));
					
				}
				catch(PatternSyntaxException e)
				{
					//print("Pattern Syntax Exception thrown");
					
				}

			}
			
		}
		

		@Override
		protected void onPostExecute(Void result)
		{
			// TODO: Implement this method
			
			super.onPostExecute(result);
			pbf.dismissAllowingStateLoss();
			asynctask_status=AsyncTaskStatus.COMPLETED;
			
		}

	}
	
	private class FilePathRecyclerViewAdapter extends RecyclerView.Adapter<FilePathRecyclerViewAdapter.ViewHolder>
	{
		List<String> filepath_string_array=new ArrayList<>();
		String path;
		String truncated_path;

		FilePathRecyclerViewAdapter(String p)
		{
			truncated_path=p;
			path=p;
			if(archive_view)
			{
				path=path.substring(MainActivity.ARCHIVE_CACHE_DIR_LENGTH);
				path="Archive"+path;
				truncated_path=truncated_path.substring(0,MainActivity.ARCHIVE_CACHE_DIR_LENGTH-"Archive/".length());//number added to archive_cache_dir_length is length of "Archive/"
				
			}
			filepath_string_array=Arrays.asList(path.split(File.separator));
			
		}
		
		
		class ViewHolder extends RecyclerView.ViewHolder
		{
			LinearLayout ll;
			TextView file_path_string_tv;
			ViewHolder(LinearLayout ll)
			{
				super(ll);
				this.ll=ll;
				file_path_string_tv=ll.findViewById(R.id.filepath_recyclerview_TextView);
				this.ll.setOnClickListener(new View.OnClickListener()
				{
					public void onClick(View v)
					{
						File f=new File(v.getTag().toString());
						if(f.exists())
						{
							((MainActivity)context).createFragmentTransaction(f,null);
						}
						
					}
				});
			}
		}

		@Override
		public DetailFragment.FilePathRecyclerViewAdapter.ViewHolder onCreateViewHolder(ViewGroup p1, int p2)
		{
			// TODO: Implement this method
			return new ViewHolder((LinearLayout)LayoutInflater.from(context).inflate(R.layout.filepath_recyclerview_layout,p1,false));
			
		}

		@Override
		public void onBindViewHolder(DetailFragment.FilePathRecyclerViewAdapter.ViewHolder p1, int p2)
		{
			// TODO: Implement this method
			
			if(filepath_string_array.get(p2).equals(""))
			{
				
				p1.file_path_string_tv.setText(File.separator);
				p1.ll.setTag(File.separator);
				
			}
			else
			{
				p1.file_path_string_tv.setText(filepath_string_array.get(p2));
				if(archive_view)
				{
					
					String filepath=truncated_path;
					for(int i=0; i<=p2 ; i++)
					{
						filepath+=File.separator+filepath_string_array.get(i);

					}
					p1.ll.setTag(filepath);
					
				}
				else
				{
					
					String filepath=new String();
					for(int i=1; i<=p2 ; i++)
					{
						filepath+=File.separator+filepath_string_array.get(i);

					}
					p1.ll.setTag(filepath);
				}
			
			}
			
			
		}

		@Override
		public int getItemCount()
		{
			// TODO: Implement this method
			return filepath_string_array.size();
		}

	}
	
	static FilePOJO make_filePOJO(File f, boolean extracticon,boolean archive_view)
	{

		String name=f.getName();
		String path=f.getAbsolutePath();
		String file_ext="";
		int overlay_visible=View.INVISIBLE;
		int alfa=225;
		int idx=name.lastIndexOf(".");
		if(idx!=-1)
		{
			file_ext=name.substring(idx+1);
		}
		if(file_ext.matches(Global.VIDEO_REGEX))
		{
			overlay_visible=View.VISIBLE;
		}
		if(MainActivity.SHOW_HIDDEN_FILE && f.isHidden())
		{
			alfa=100;
		}
		if(extracticon)
		{
			DetailFragment.extract_icon(path,file_ext);

		}

		String date=SDF.format(f.lastModified());
		String si=DetailFragment.getFileSize(f,archive_view);
		Integer type=DetailFragment.getFileType(f,file_ext);

		return new FilePOJO(f,name,path,date,si,type,file_ext,alfa,overlay_visible);
	}
	
	
	static Bitmap extract_icon(String file_path, String file_ext)
	{
		Bitmap bm=null;
		if(file_ext.matches(Global.APK_REGEX) && !MainActivity.APK_ICON_HASHMAP.containsKey(file_path))
		{

			PI = MainActivity.PM.getPackageArchiveInfo(file_path, 0);
			if(PI!=null)
			{

				PI.applicationInfo.publicSourceDir = file_path;
				Drawable APKicon = PI.applicationInfo.loadIcon(MainActivity.PM);
				if(APKicon instanceof BitmapDrawable)
				{
					bm=((BitmapDrawable)APKicon).getBitmap();
				}
				MainActivity.APK_ICON_HASHMAP.put(file_path,bm);


			}

		}
		return bm;
	}

	static String getFileSize(File f,boolean archive_view)
	{
		if(f.isDirectory())
		{
			String [] file_string_list;
			if((file_string_list=f.list(FILE_NAME_FILTER))!=null)

			{
				return "("+file_string_list.length+")";

			}
			else
			{
				return "";
			}

		}
		else
		{

			long file_size=0L;
			file_size=f.length();

			if(archive_view)
			{
				ZipFile zipfile=null;
				try
				{
					zipfile=new ZipFile(MainActivity.ZIP_FILE);
				}
				catch(IOException e){}
				ZipEntry zip_entry=zipfile.getEntry(f.getAbsolutePath().substring(MainActivity.ARCHIVE_CACHE_DIR_LENGTH+1));
				if(zip_entry!=null)
				{
					file_size=zip_entry.getSize();
				}
			}

			return FileUtil.humanReadableByteCount(file_size,Global.BYTE_COUNT_BLOCK_1000);

		}
	}

	static Integer getFileType(File f, String file_ext)
	{

		if(f.isDirectory())
		{
			return R.drawable.folder_icon;
		}

		else if(file_ext.matches(Global.AUDIO_REGEX))
		{
			return R.drawable.audio_file_icon;
		}

		else if(file_ext.matches(Global.PDF_REGEX))
		{
			return R.drawable.pdf_file_icon;
		}

		else if(file_ext.matches(Global.APK_REGEX))
		{
			return null;
		}

		else if(file_ext.matches(Global.ZIP_REGEX)|| file_ext.matches(Global.UNIX_ARCHIVE_REGEX))
		{
			return R.drawable.archive_file_icon;
		}

		else if(file_ext.matches(Global.IMAGE_REGEX))
		{
			return 0;
		}

		else if(file_ext.matches(Global.VIDEO_REGEX))
		{
			return 0;
		}

		else if(file_ext.matches(Global.OTHER_TEXT_REGEX) || file_ext.matches( Global.RTF_REGEX))
		{
			return R.drawable.text_file_icon;
		}

		else if(file_ext.matches(Global.DOC_REGEX))
		{
			return R.drawable.word_file_icon;
		}

		else if(file_ext.matches(Global.XLS_REGEX))
		{
			return R.drawable.xls_file_icon;
		}

		else if(file_ext.matches(Global.PPT_REGEX))
		{
			return R.drawable.ppt_file_icon;
		}

		else
		{
			return R.drawable.unknown_file_icon;
		}

	}
	
	

	public enum AsyncTaskStatus
	{
		NOT_YET_STARTED, STARTED, COMPLETED
	}
	private void print(String msg)
	{
		Toast.makeText(context,msg,Toast.LENGTH_SHORT).show();
	}
	
}
