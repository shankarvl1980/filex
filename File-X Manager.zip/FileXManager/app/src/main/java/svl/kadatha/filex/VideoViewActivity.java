package svl.kadatha.filex;
import android.support.v7.app.*;
import android.os.*;
import android.content.*;
import android.net.*;
import android.widget.*;
import android.media.*;
import android.view.animation.*;
import java.util.*;
import android.view.*;
import java.io.*;
import android.graphics.*;
import android.support.v4.view.*;
import com.bumptech.glide.*;
import com.bumptech.glide.load.engine.*;
import android.support.v4.app.*;
import android.content.res.*;

public class VideoViewActivity extends AppCompatActivity
{
	
	public Uri data;
	public FragmentManager fm;
	private Context context;
	TinyDB tinyDB;
	private VideoViewContainerFragment videoViewContainerFragment;
	


	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
 		// TODO: Implement this method
		super.onCreate(savedInstanceState);
		context=this;
		fm=getSupportFragmentManager();
		setContentView(R.layout.activity_video_view);
		tinyDB=new TinyDB(context);
		Global.GET_SCREEN_DIMENSIONS(context);
		Global.GET_URI_PERMISSIONS_LIST(context);
		
		Global.GET_SORT(tinyDB);
		
		StatusBarTint.darkenStatusBar(this,R.color.toolbar_background);
		Intent intent=getIntent();
		String receivedAction="";
		String receivedType="";
		
		if(intent!=null)
		{
			receivedAction=intent.getAction();
			receivedType=intent.getType();
			data=intent.getData();
		}

		if(savedInstanceState==null)
		{
	
			if(receivedAction.equals(Intent.ACTION_VIEW) && receivedType.startsWith("video/") && data!=null)
			{
		
				String path=PathUtil.getPath(context,data);
				if(path==null || !new File(path).exists())
				{
					path=data.getPath();
				}
				fm.beginTransaction().replace(R.id.activity_video_view_container,VideoViewContainerFragment.getNewInstance(path),"video_fragment").commit();
			}
			
		}
		
		//videoViewContainerFragment=(VideoViewContainerFragment)FM.findFragmentById(R.id.activity_video_view_container);

	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data)
	{
		// TODO: Implement this method
		super.onActivityResult(requestCode, resultCode, data);
	}
/*
	@Override
	public void onBackPressed()
	{
		// TODO: Implement this method
		super.onBackPressed();
		finish();
	}

	@Override
	public boolean onKeyUp(int keyCode, KeyEvent event)
	{
		// TODO: Implement this method
		if(keyCode==KeyEvent.KEYCODE_BACK)
		{
			onBackPressed();
			return true;
		}
		return super.onKeyUp(keyCode, event);
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event)
	{
		// TODO: Implement this method
		if(keyCode==KeyEvent.KEYCODE_BACK)
		{
			onBackPressed();
			return true;
		}
		return super.onKeyDown(keyCode, event);
	}
	
	
*/

}
