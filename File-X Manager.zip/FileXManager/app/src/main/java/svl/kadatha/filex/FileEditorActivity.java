package svl.kadatha.filex;
import android.support.v7.app.AppCompatActivity;
import android.os.*;
import java.io.*;
import android.content.*;
import android.support.v7.widget.*;
import android.view.*;
import java.util.*;
import android.view.View.*;
import android.widget.*;
import android.text.*;
import android.net.*;
import android.text.method.*;
import java.util.zip.*;
import android.view.inputmethod.*;
import android.graphics.*;
import android.preference.*;
import android.support.v4.widget.*;
import android.view.animation.*;
import android.animation.*;
import android.content.res.*;
import android.util.*;
import java.nio.channels.*;
import java.nio.*;
import java.nio.charset.*;
import android.support.v4.content.*;
import android.support.design.widget.*;



public class FileEditorActivity extends AppCompatActivity implements FileEditorSettingsDialog.EOL_ChangeListener
{
	private android.support.v7.widget.Toolbar bottom_toolbar;
	File file;
	FileSaveServiceConnection serviceConnection;
	private boolean fileServiceBound;
	EditText filetext_container_edittext;
	private ImageButton edit_button,undo_button,redo_button,save_button,up_button,down_button;
	private ImageButton settings_btn;
	private BottomToolbarListener bottomToolbarListener;
	private boolean edit_mode;
	static boolean NOT_WRAP=true;
	static final int EOL_N = 0;
	static final int EOL_R = 1;
	static final int EOL_RN = 2;
	int eol,altered_eol;
	static float FILE_EDITOR_TEXT_SIZE;
	private TextViewUndoRedoBatch textViewUndoRedo;
	private TextView file_name;
	private int request_code=876;
	private final String preference_name="undoredo";
	private SaveFileConfirmationDialog saveConfirmationAlertDialog;
	private final int buffersize=8*1024;
	private svl.kadatha.filex.ObservableScrollView scrollview;
	private FileEditorSettingsDialog fileEditorSettingsDialog;
	private FileOpenAsyncTask fileOpenAsyncTask;
	private boolean updated=true,to_be_closed_after_save;
	private Context context;
	private Uri data;
	private String receivedAction,receivedType,action_after_save="";
	static int LINE_NUMBER_SIZE;
	TinyDB tinyDB;
	private CancelableProgressBarDialog cpbf;
	private LinkedHashMap<Integer, Long> page_pointer_hashmap=new LinkedHashMap<>();
	private int current_page=0;
	private long current_page_end_point=0L;
	private boolean file_start,file_end;
	boolean isWritable,isFileBig;
	static ArrayList<FilePOJO> STORAGE_DIR=new ArrayList<>();
	private File temporary_file_for_save;
	private LocalBroadcastManager localBroadcastManager;
	private ProgressBarFragment pbf;
	private Class emptyService;
	private FloatingActionButton floating_back_button;
	private final int max_lines_to_dusplay=200;
	//private FileSaveBroadcastReceiver fileSaveBroadcastReceiver=new FileSaveBroadcastReceiver();
	//private String FILE_SAVE_ACTION="saved";
	
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		// TODO: Implement this method
		super.onCreate(savedInstanceState);
		
		context=this;
		localBroadcastManager=LocalBroadcastManager.getInstance(context);
		
		
		Global.GET_SCREEN_DIMENSIONS(context);
		Global.GET_URI_PERMISSIONS_LIST(context);
		
		
		
		tinyDB=new TinyDB(context);
		NOT_WRAP=tinyDB.getBoolean("file_editor_not_wrap");
		if(NOT_WRAP)
		{
			setContentView(R.layout.activity_file_editor_horizontal_scroll);
		}
		else
		{
			setContentView(R.layout.activity_file_editor);
		}
		
	
		
		
		StatusBarTint.darkenStatusBar(this,R.color.toolbar_background);
		eol=altered_eol=EOL_N;
		FILE_EDITOR_TEXT_SIZE=tinyDB.getFloat("file_editor_text_size");
		if(FILE_EDITOR_TEXT_SIZE<=0 || FILE_EDITOR_TEXT_SIZE>fileEditorSettingsDialog.MAX_TEXT_SIZE)
		{
			FILE_EDITOR_TEXT_SIZE=14F;
			tinyDB.putFloat("file_editor_text_size",FILE_EDITOR_TEXT_SIZE);
		}
		getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
		LINE_NUMBER_SIZE=(int)TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP,10,getResources().getDisplayMetrics());
		fileEditorSettingsDialog=new FileEditorSettingsDialog();
		
		
		floating_back_button=findViewById(R.id.file_editor_floating_action_button_back);
		floating_back_button.setOnClickListener(new View.OnClickListener()
		{
			public void onClick(View v)
			{
				file_close_procedure();
			}
		});
		
		EquallyDistributedImageButtonsLayout tb_layout =new EquallyDistributedImageButtonsLayout(this,6,Global.SCREEN_WIDTH,Global.SCREEN_HEIGHT);
		int bottom_drawables []={R.drawable.edit_icon,R.drawable.undo_icon,R.drawable.redo_icon,R.drawable.save_icon,R.drawable.up_caret_icon,R.drawable.down_caret_icon};
		tb_layout.setResourceImageDrawables(bottom_drawables);
		
		bottom_toolbar=findViewById(R.id.file_editor_bottom_toolbar);
		bottom_toolbar.addView(tb_layout);
		edit_button=bottom_toolbar.findViewById(R.id.image_btn_1);
		undo_button=bottom_toolbar.findViewById(R.id.image_btn_2);
		redo_button=bottom_toolbar.findViewById(R.id.image_btn_3);
		save_button=bottom_toolbar.findViewById(R.id.image_btn_4);
		up_button=bottom_toolbar.findViewById(R.id.image_btn_5);
		down_button=bottom_toolbar.findViewById(R.id.image_btn_6);
		file_name=findViewById(R.id.file_editor_file_name_textview);
		settings_btn=findViewById(R.id.file_editor_settings_btn);
		settings_btn.setOnClickListener(new View.OnClickListener()
		{
			public void onClick(View p1)
			{
				fileEditorSettingsDialog.show(getSupportFragmentManager(),"file_editor_settings");
			}
		});
		scrollview=findViewById(R.id.file_editor_scrollview);
		
		Intent intent=getIntent();
		if(intent!=null)
		{
			receivedAction=intent.getAction();
			receivedType=intent.getType();
			data=intent.getData();
			String path=PathUtil.getPath(context,data);
			if(path==null || !new File(path).exists())
			{
				path=data.getPath();
			}
			file=new File(path);
			isWritable=FileUtil.isWritable(file);
			if(file.exists())
			{
				long internal_available_space,external_available_space,file_size;
				file_size=file.length();
				STORAGE_DIR=StorageUtil.getSdCardPaths(this,true);
				for(FilePOJO filePOJO:STORAGE_DIR)
				{
					if(filePOJO.getPath().equals(File.separator))
					{
						continue;
					}
					
					if(filePOJO.getPath().endsWith("/0"))
					{
						
						internal_available_space=filePOJO.getFile().getUsableSpace();
						if(file_size*2.5>internal_available_space)
						{
							isFileBig=true;
						}
						else
						{
							temporary_file_for_save=getExternalFilesDir("temp");
							isFileBig=false;
							break;
						}
							
						
					}
					else if(isFileBig==true)
					{
						for(Map.Entry<Uri,String> entry : Global.URI_STRING_HASHMAP.entrySet())
						{
							if(filePOJO.getPath().startsWith(entry.getValue()))
							{
								external_available_space=filePOJO.getFile().getUsableSpace();
								if(file_size*2.5>external_available_space)
								{
									isFileBig=true;
								}
								else
								{
									File[] external_volumes=ContextCompat.getExternalFilesDirs(context,null);
									if(external_volumes.length>=2)
									{
										temporary_file_for_save=external_volumes[1];
										isFileBig=false;
										break;
									}
									else
									{
										isFileBig=true;
									}
									
								}
							}
						}
					}
					
				}
			}
	
		}
		
		
		
		//ObjectAnimator.ofInt(scrollview, "scrollY",  10).setDuration(500).start();

		scrollview.setScrollViewListener(new ObservableScrollView.ScrollViewListener()
		{
			boolean visible=true;
			final int threshold=5;
			int scroll_distance=0;
			int dy=0;
			public void onScrollChange(ObservableScrollView v, int old_scrollX, int old_scrollY, int scrollX, int scrollY)
			{
				dy=scrollY-old_scrollY;

				if(scroll_distance>threshold && !visible)
				{
					//file_name.animate().translationY(-file_name.getHeight()).setInterpolator(new AccelerateInterpolator(1));
					visible=true;
					scroll_distance=0;
				}
				else if(scroll_distance<-threshold && visible)
				{
					
					//file_name.animate().translationY(0).setInterpolator(new DecelerateInterpolator(1));
					visible=false;
					scroll_distance=0;
				}
				if((visible && dy<0) || (!visible && dy>0))
				{
					scroll_distance+=dy;
				}
				/*
				if(!file_end && filetext_container_edittext.getBottom()<=(scrollview.getHeight()+scrollY))
				{
					//scroll reached bottom
	
			
				}
				else
				{
				
				}
				
				if(!file_start && old_scrollY==0)
				{
					//scroll reached top
		
				
				}
				else
				{
					
				}
				*/
			}
			
		});

		bottomToolbarListener=new BottomToolbarListener();
		edit_button.setOnClickListener(bottomToolbarListener);
		undo_button.setOnTouchListener(new RepeatListener(400,100,bottomToolbarListener));
		redo_button.setOnTouchListener(new RepeatListener(400,100,bottomToolbarListener));
		save_button.setOnClickListener(bottomToolbarListener);
		up_button.setOnClickListener(bottomToolbarListener);
		down_button.setOnClickListener(bottomToolbarListener);
		

		filetext_container_edittext=findViewById(R.id.textfile_edittext);
		filetext_container_edittext.setTextSize(FILE_EDITOR_TEXT_SIZE);

		textViewUndoRedo=new TextViewUndoRedoBatch(filetext_container_edittext,context);
		textViewUndoRedo.setEditTextUndoRedoListener(new TextViewUndoRedoBatch.EditTextRedoUndoListener()
		{
			public void onEditTextChange()
			{
				
				undo_button.setEnabled(true);
				undo_button.setAlpha(225);
				save_button.setEnabled(true);
				save_button.setAlpha(225);
				updated=false;
			
				redo_button.setEnabled(false);
				redo_button.setAlpha(100);
				
				
			}
		});
		
		onClick_edit_button();
		cpbf=new CancelableProgressBarDialog("Opening the file");
		cpbf.setProgressBarCancelListener(new CancelableProgressBarDialog.ProgresBarFragmentCancelListener()
			{
				public void on_cancel_progress()
				{
					if(fileOpenAsyncTask!=null)
					{
						fileOpenAsyncTask.cancel(true);
					}
					cpbf.dismissAllowingStateLoss();
				}
			});
		
		if(savedInstanceState==null)
		{
			
				if(receivedAction.equals(Intent.ACTION_VIEW) && data!=null && receivedType.startsWith("text/"))
				{
					file=new File(data.getPath());
					if(file!=null)
					{
						file_name.setText(file.getName());
		
					}
					eol=altered_eol=getEOL(data);
					
					if(!openFile(current_page_end_point,false))
					{
						finish();
					}

				}
		}
	
		
	}

	@Override
	protected void onStart()
	{
		// TODO: Implement this method
		super.onStart();
		
		if(emptyService!=null && serviceConnection!=null)
		{
			Intent file_save_service_intent=new Intent(context,emptyService);
			bindService(file_save_service_intent,serviceConnection,Context.BIND_AUTO_CREATE);
			fileServiceBound=true;
		}
		
	}

	@Override
	protected void onStop()
	{
		// TODO: Implement this method
		super.onStop();
		if(serviceConnection!=null)
		{
			unbindService(serviceConnection);
			fileServiceBound=false;
		}
		
	}
	
	
	private void go_previous()
	{

		if(file_start)
		{
			return;
		}
		if(receivedAction.equals(Intent.ACTION_VIEW) && data!=null && receivedType.startsWith("text/"))
		{
			file=new File(data.getPath());
			
			long prev_page_end_point=0L;

			current_page=current_page-2;

			if(current_page<=0)
			{
				current_page=0;


			}
			else
			{
				prev_page_end_point=page_pointer_hashmap.get(current_page);
				current_page--;
			}
			openFile(prev_page_end_point,false);
			
		}
	}
	
	private void go_next()
	{

		if(file_end)
		{
			return;
		}
		
		if(receivedAction.equals(Intent.ACTION_VIEW) && data!=null && receivedType.startsWith("text/"))
		{
			file=new File(data.getPath());
		

			current_page_end_point=page_pointer_hashmap.get(current_page);
			openFile(current_page_end_point,false);


		}
	}
	
	private boolean openFile(long pointer, boolean go_back)
	{
		try
		{
			ParcelFileDescriptor pdf=getContentResolver().openFileDescriptor(data,"r");
			FileDescriptor fd=pdf.getFileDescriptor();
			fileOpenAsyncTask=new FileOpenAsyncTask(new FileInputStream(fd),pointer,go_back);
			fileOpenAsyncTask.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
			return true;
			
			
		}
		catch(FileNotFoundException e)
		{
			print("File not found");
			return false;
		}
	}

	@Override
	public void onEOLchanged(int eol)
	{
		// TODO: Implement this method
		if(this.eol!=eol)
		{
			save_button.setEnabled(true);
			save_button.setAlpha(225);
			updated=false;
		}

	}

	
	@Override
	public void onBackPressed()
	{
		// TODO: Implement this method
		file_close_procedure();
	}

	private class BottomToolbarListener implements View.OnClickListener
	{

		@Override
		public void onClick(View p1)
		{
			// TODO: Implement this method
			switch(p1.getId())
			{
				case R.id.image_btn_1:
					if(file==null || !file.exists() )
					{
						print("can't edit this file");
						break;
					}
					
					if(isFileBig)
					{
						print("File is big,can't edit this file");
						break;
					}
					
					onClick_edit_button();
					
					break;
				case R.id.image_btn_2:
					if(textViewUndoRedo.getCanUndo())
					{
						textViewUndoRedo.undo();
						save_button.setEnabled(true);
						save_button.setAlpha(225);
						updated=false;
						if(!textViewUndoRedo.getCanUndo())
						{
							undo_button.setEnabled(false);
							undo_button.setAlpha(100);
							
							save_button.setEnabled(false);
							save_button.setAlpha(100);
							updated=true;
							
							
						}
						
						if(textViewUndoRedo.getCanRedo())
						{
							redo_button.setEnabled(true);
							redo_button.setAlpha(255);
							

						}
						
					}
					
					break;
					
				case R.id.image_btn_3:
					if(textViewUndoRedo.getCanRedo())
					{
						textViewUndoRedo.redo();
						updated=false;
						if(!textViewUndoRedo.getCanRedo())
						{
							redo_button.setEnabled(false);
							redo_button.setAlpha(100);
						}
						
						if(textViewUndoRedo.getCanUndo())
						{
							undo_button.setEnabled(true);
							undo_button.setAlpha(255);
							save_button.setEnabled(true);
							save_button.setAlpha(255);
						}
						
					}
					break;
				case R.id.image_btn_4:
					
					edit_mode=false;
					start_file_save_service();
					break;
					
				case R.id.image_btn_5:
					if(!updated)
					{

						saveConfirmationAlertDialog=SaveFileConfirmationDialog.getInstance(false);
						saveConfirmationAlertDialog.setSaveFileListener(new SaveFileConfirmationDialog.SaveFileListener()
							{
								public void next_action(boolean save)
								{
									if(save)
									{

										start_file_save_service();
									}
									else
									{
										updated=true;
										go_previous();
									}
								}
							});
						saveConfirmationAlertDialog.show(getSupportFragmentManager(),"saveconfirmationalert_dialog");

					}
					else
					{
						go_previous();
					}
					
					
					//file_close_procedure();
					
					break;
					
				case R.id.image_btn_6:
					if(!updated)
					{

						saveConfirmationAlertDialog=SaveFileConfirmationDialog.getInstance(false);
						saveConfirmationAlertDialog.setSaveFileListener(new SaveFileConfirmationDialog.SaveFileListener()
							{
								public void next_action(boolean save)
								{
									if(save)
									{
										start_file_save_service();
									}
									else
									{
										updated=true;
										go_next();
									}
								}
							});
						saveConfirmationAlertDialog.show(getSupportFragmentManager(),"saveconfirmationalert_dialog");

					}
					else
					{
						go_next();
					}
					
					break;
					
				default:
					break;
					
			}
		}

		
	}

	private void file_close_procedure()
	{
		if(!updated)
		{
			
			saveConfirmationAlertDialog=SaveFileConfirmationDialog.getInstance(true);
			saveConfirmationAlertDialog.setSaveFileListener(new SaveFileConfirmationDialog.SaveFileListener()
				{
					public void next_action(boolean to_close_after_save)
					{
						if(to_close_after_save)
						{
							to_be_closed_after_save=to_close_after_save;
							start_file_save_service();
						}
						else
						{
							finish();
						}
					}
				});
			saveConfirmationAlertDialog.show(getSupportFragmentManager(),"saveconfirmationalert_dialog");

		}
		else
		{
			textViewUndoRedo.disconnect();
			finish();
		}
	}
	
	@Override
	public void onSaveInstanceState(Bundle outState)
	{
		// TODO: Implement this method
		super.onSaveInstanceState(outState);
		outState.putBoolean("edit_mode",edit_button.isSelected());
		outState.putString("file_name",file_name.getText().toString());
		outState.putBoolean("updated",updated);
		outState.putBoolean("to_be_closed_after_save",to_be_closed_after_save);
		outState.putInt("eol",eol);
		outState.putInt("altered_eol",altered_eol);
		outState.putSerializable("page_pointer_hashmap",page_pointer_hashmap);
		outState.putInt("current_page",current_page);
		outState.putLong("current_page_end_point",current_page_end_point);
		outState.putBoolean("file_start",file_start);
		outState.putBoolean("file_end",file_end);
		//outState.putInt("prev_btn_visibility", prev_btn.getVisibility());
		//outState.putInt("next_btn_visibility",next_btn.getVisibility());
		outState.putString("action_after_save",action_after_save);
		textViewUndoRedo.storePersistentState(outState,preference_name);
		
	}

	@Override
	protected void onRestoreInstanceState(Bundle savedInstanceState)
	{
		// TODO: Implement this method
		super.onRestoreInstanceState(savedInstanceState);
		edit_mode=savedInstanceState.getBoolean("edit_mode");
		file_name.setText(savedInstanceState.getString("file_name"));
		updated=savedInstanceState.getBoolean("updated");
		to_be_closed_after_save=savedInstanceState.getBoolean("to_be_closed_after_save");
		eol=savedInstanceState.getInt("eol");
		altered_eol=savedInstanceState.getInt("altered_eol");
		page_pointer_hashmap=(LinkedHashMap<Integer,Long>)savedInstanceState.getSerializable("page_pointer_hashmap");
		current_page=savedInstanceState.getInt("current_page");
		current_page_end_point=savedInstanceState.getLong("current_page_end_point");
		file_start=savedInstanceState.getBoolean("file_start");
		file_end=savedInstanceState.getBoolean("file_end");
	
		//prev_btn.setVisibility(savedInstanceState.getInt("prev_btn_visibility"));
		//next_btn.setVisibility(savedInstanceState.getInt("next_btn_visibility"));
		action_after_save=savedInstanceState.getString("action_after_save");
		textViewUndoRedo.restorePersistentState(savedInstanceState,preference_name);
		textViewUndoRedo.startListening();
		onClick_edit_button();
		if(file_start)
		{
			up_button.setEnabled(false);
			up_button.setAlpha(100);
		}
		if(file_end)
		{
			down_button.setEnabled(false);
			down_button.setAlpha(100);
		}
		
	}
	public void checkSAFPermission()
	{

		Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
		startActivityForResult(intent, request_code);

	}



	// @TargetApi(Build.VERSION_CODES.LOLLIPOP)
	@Override
	public final void onActivityResult(final int requestCode, final int resultCode, final Intent resultData) 
	{
		super.onActivityResult(requestCode,resultCode,resultData);
		if (requestCode == this.request_code && resultCode==this.RESULT_OK) 
		{
			Uri treeUri = null;
			// Get Uri from Storage Access Framework.
			treeUri = resultData.getData();
			String uri_file_path=FileUtil.getFullPathFromTreeUri(treeUri,context);
			Iterator<Map.Entry<Uri,String>> iterator=Global.URI_STRING_HASHMAP.entrySet().iterator();
			while(iterator.hasNext())
			{
				Map.Entry<Uri,String> entry=iterator.next();
				if(entry.getValue().startsWith(uri_file_path))
				{
					iterator.remove();
				}
			}


			Global.URI_STRING_HASHMAP.put(treeUri,uri_file_path);


			// Persist access permissions.
			final int takeFlags = resultData.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
			context.getContentResolver().takePersistableUriPermission(treeUri, takeFlags);
			
			start_file_save_service();
		}
		else
		{
			print("Permission was not granted");
		}
	}
	
	private void onClick_edit_button()
	{
		if(edit_mode)
		{
			
			
			if(textViewUndoRedo.getCanUndo())
			{
				undo_button.setEnabled(true);
				save_button.setEnabled(updated ? false : true);
			}
			if(textViewUndoRedo.getCanRedo())
			{
				redo_button.setEnabled(true);
			
			}


			if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) 
			{ // API 21
				filetext_container_edittext.setShowSoftInputOnFocus(true);
				
			} 
			else 
			{ // API 11-20
				filetext_container_edittext.setTextIsSelectable(false);
				filetext_container_edittext.setFocusable(true);
				filetext_container_edittext.setFocusableInTouchMode(true);
				filetext_container_edittext.setClickable(true);
				filetext_container_edittext.setLongClickable(true);
				filetext_container_edittext.setMovementMethod(ArrowKeyMovementMethod.getInstance());

			}
			
			((InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE)).showSoftInput(filetext_container_edittext,0);
		}

		else
		{
			
			filetext_container_edittext.clearFocus();
			save_button.setEnabled(false);
			undo_button.setEnabled(false);
			redo_button.setEnabled(false);


			if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) 
			{ // API 21
				filetext_container_edittext.setShowSoftInputOnFocus(false);
				
			} 
			else 
			{ // API 11-20
				filetext_container_edittext.setTextIsSelectable(true);
			}
			
			((InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(filetext_container_edittext.getWindowToken(),0);
			
		}
		edit_button.setSelected(edit_mode);
		setAlfaFileEditMenuItem();
		edit_mode=!edit_mode;
		filetext_container_edittext.setLongClickable(!edit_mode);
		filetext_container_edittext.setOnTouchListener(new View.OnTouchListener()
		{
			public boolean onTouch(View v, MotionEvent me)
			{
				return edit_mode;
			}
		});

	}
	
	private void setAlfaFileEditMenuItem()
	{
		
		edit_button.setAlpha(edit_button.isEnabled() ? 255:100);
		save_button.setAlpha(save_button.isEnabled() ? 255:100);
		undo_button.setAlpha(undo_button.isEnabled() ? 255:100);
		redo_button.setAlpha(redo_button.isEnabled() ? 255:100);

	}

	private void send_broadcast(LocalBroadcastManager manager)
	{

		Intent intent=new Intent();
		intent.setAction(MainActivity.FILE_DELETE_INTENT_ACTION);
		intent.putExtra("deleted",true);
		manager.sendBroadcast(intent);
	}
	
	private void start_file_save_service()
	{
		
		if(!file.exists())
		{
			return;
		}
		emptyService=getEmptyService();
		if(emptyService==null)
		{
			print("Maximum 2 services only be processed at a time");
			return;
		}
		serviceConnection=new FileSaveServiceConnection(emptyService);
		Intent file_save_service_intent=new Intent(context,emptyService);
		bindService(file_save_service_intent,serviceConnection,Context.BIND_AUTO_CREATE);

		String baseFolder="";
		Uri uri=null;
		long prev_page_end_point=0L;
		if(current_page>1)
		{
			prev_page_end_point=page_pointer_hashmap.get(current_page-1);
		}
		Bundle bundle=new Bundle();
		bundle.putBoolean("isWritable",isWritable);
		bundle.putString("file_path",file.getAbsolutePath());
		bundle.putString("content",filetext_container_edittext.getText().toString());
		bundle.putString("baseFolder",baseFolder);
		bundle.putParcelable("uri",uri);
		bundle.putInt("eol",eol);
		bundle.putInt("altered_eol",altered_eol);
		bundle.putLong("prev_page_end_point",prev_page_end_point);
		bundle.putLong("current_page_end_point",current_page_end_point);
		bundle.putSerializable("page_pointer_hashmap",page_pointer_hashmap);
		bundle.putString("temporary_file_path",temporary_file_for_save.getAbsolutePath());
		bundle.putInt("current_page",current_page);
		
		
	
		if(isWritable)
		{
			
			
		}
		else
		{
			
			for(Map.Entry<Uri,String> entry : Global.URI_STRING_HASHMAP.entrySet())
			{
				if(file.getAbsolutePath().startsWith(entry.getValue()))
				{
					baseFolder=entry.getValue();
					uri=entry.getKey();
					break;
				}
			}


			if(baseFolder.equals(""))
			{

				SAFPermissionHelperDialog safpermissionhelper=new SAFPermissionHelperDialog();
				safpermissionhelper.set_safpermissionhelperlistener(new SAFPermissionHelperDialog.SafPermissionHelperListener()
					{
						public void onOKBtnClicked()
						{
							checkSAFPermission();
						}

						public void onCancelBtnClicked()
						{

						}
					});
				safpermissionhelper.show(getSupportFragmentManager(),"saf_permission_dialog");
				return;
			}
			else
			{
				bundle.putString("baseFolder",baseFolder);
				bundle.putParcelable("uri",uri);
			}
		}
		pbf=new ProgressBarFragment();
		pbf.show(getSupportFragmentManager(),"");
		file_save_service_intent.putExtra("bundle",bundle);
		if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.O)
		{
			startForegroundService(file_save_service_intent);
		}
		else
		{
			startService(file_save_service_intent);
		}

	}
	
	private void print(String msg)
	{
		android.widget.Toast.makeText(this,msg,android.widget.Toast.LENGTH_LONG).show();
	}

	private class FileSaveServiceConnection implements ServiceConnection
	{

		Class service;
		FileSaveServiceConnection(Class service)
		{
			this.service=service;
			
	
		}
		
		
		
		@Override
		public void onServiceConnected(ComponentName p1, IBinder binder)
		{
			// TODO: Implement this method
			switch(service.getName())
			{
				case "com.mycompany.explorer.FileSaveService1":
					final FileSaveService1 fileSaveService1=((FileSaveService1.FileSaveServiceBinder)binder).getService();
					if(fileSaveService1!=null)
					{
						fileSaveService1.setServiceCompletionListener(new FileSaveService1.FileSaveServiceCompletionListener()
						{
								public void onServiceCompletion(boolean result)
								{
									save_button.setEnabled(false);
									save_button.setAlpha(100);
									current_page_end_point=fileSaveService1.current_page_end_point;
									page_pointer_hashmap=fileSaveService1.page_pointer_hashmap;
									updated=result;

									if(result)
									{
										eol=altered_eol;
										send_broadcast(localBroadcastManager);
									}
									else
									{
										print("File could not be saved");
									}

									if(to_be_closed_after_save)
									{
										finish();
									}
									else if(action_after_save.equals("go_previous"))
									{
										go_previous();
									}
									else if(action_after_save.equals("go_next"))
									{
										go_next();
									}

									if(pbf!=null)
									{
										pbf.dismissAllowingStateLoss();
									}
								}
						});
						fileServiceBound=true;
					}

					
					break;
				
				case "com.mycompany.explorer.FileSaveService2":
					final FileSaveService2 fileSaveService2=((FileSaveService2.FileSaveServiceBinder)binder).getService();
					if(fileSaveService2!=null)
					{
						fileSaveService2.setServiceCompletionListener(new FileSaveService2.FileSaveServiceCompletionListener()
							{
								public void onServiceCompletion(boolean result)
								{
									save_button.setEnabled(false);
									save_button.setAlpha(100);
									current_page_end_point=fileSaveService2.current_page_end_point;
									page_pointer_hashmap=fileSaveService2.page_pointer_hashmap;
									updated=result;

									if(result)
									{
										eol=altered_eol;
										send_broadcast(localBroadcastManager);
									}
									else
									{
										print("File could not be saved");
									}

									if(to_be_closed_after_save)
									{
										finish();
									}
									else if(action_after_save.equals("go_previous"))
									{
										go_previous();
									}
									else if(action_after_save.equals("go_next"))
									{
										go_next();
									}

									if(pbf!=null)
									{
										pbf.dismissAllowingStateLoss();
									}
								}
							});
						fileServiceBound=true;
					}

					
					break;
				default:
					fileServiceBound=false;
					break;
				
			}
		}

		@Override
		public void onServiceDisconnected(ComponentName p1)
		{
			// TODO: Implement this method
			fileServiceBound=false;
		}


		
		
	}

	private class FileOpenAsyncTask extends AsyncTask<Void,StringBuilder,Boolean>
	{
		
		BufferedReader bufferedReader;
		StringBuilder stringBuilder=new StringBuilder();
		long file_pointer;
		FileInputStream fileInputStream;
		boolean go_back;
	
		FileOpenAsyncTask (FileInputStream fileInputStream,long file_pointer, boolean go_back)
		{
			this.fileInputStream=fileInputStream;
			this.file_pointer=file_pointer;
			this.go_back=go_back;
	
		}
		
		@Override
		protected void onPreExecute()
		{
			// TODO: Implement this method
			super.onPreExecute();
			//cpbf.set_title("Opening the file");
			
			
			cpbf.show(getSupportFragmentManager(),"progress_dialog");
			
			
		}

		@Override
		protected void onCancelled(Boolean result)
		{
			// TODO: Implement this method
			super.onCancelled(result);
			cpbf.dismissAllowingStateLoss();
			finish();
			
		}
		
		

		@Override
		protected Boolean doInBackground(Void...f)
		{
			// TODO: Implement this method
			

			if(file_pointer==0L)
			{
				file_start=true;
				up_button.setEnabled(false);
				up_button.setAlpha(100);

			}
			else
			{
				file_start=false;
				up_button.setEnabled(true);
				up_button.setAlpha(255);
			}
			
			
			try
			{
	
				FileChannel fc=fileInputStream.getChannel();
				fc.position(file_pointer);
				
				ByteBuffer buf=ByteBuffer.allocate(1024*8);
				int bytes_read=0;
				if(file_pointer!=0L)
				{
					boolean to_break=false;
					while((bytes_read=fc.read(buf))!=-1)
					{
						buf.flip();
						for(int i=0;i<bytes_read;i++)
						{
							char m=(char)buf.get(i);
							char n=0;
							if(i+1<bytes_read)
							{
								n=(char)buf.get(i+1);
							}
							
							file_pointer++;
							if(m==10)
							{
								to_break=true;
								eol=altered_eol=EOL_N;
								break;
							}
							else if(m==13)
							{
								if(n==10)
								{
									file_pointer++;
									eol=altered_eol=EOL_RN;
									
								}
								else
								{
									eol=altered_eol=EOL_R;
								}
								to_break=true;
								break;
							}
						}
						
						if(to_break)
						{
							break;
						}
					}
					page_pointer_hashmap.put(current_page,file_pointer);
				}
				
				
				buf.clear();
				fc.position(file_pointer);
				
				
				bufferedReader=new BufferedReader(Channels.newReader(fc,"UTF-8"));
				String line;
				int count=0;
				long br=0,total_bytes_read=0;
				int eol_len=(eol==EOL_RN) ? 2 :1 ;
				while((line=bufferedReader.readLine())!=null)
				{
					br+=line.getBytes().length+eol_len;
					stringBuilder.append(line+"\n");
					count++;
					if(count>=max_lines_to_dusplay)
					{
						file_end=false;
						total_bytes_read=file_pointer+br;
						down_button.setEnabled(true);
						down_button.setAlpha(255);
						break;
					}
					
				}
				if(count<max_lines_to_dusplay)
				{
					file_end=true;
					total_bytes_read=file.length();
					down_button.setEnabled(false);
					down_button.setAlpha(100);
				}
		
				publishProgress(stringBuilder);

				current_page++;
				current_page_end_point=total_bytes_read;


				page_pointer_hashmap.put(current_page,current_page_end_point);
				return true;
				
			}
				
	
			catch(UnsupportedEncodingException e)
			{
				return false;
			}
		
			catch(IOException e)
			{
				return false;
			}
			
			finally
			{
				try
				{
					fileInputStream.close();
					bufferedReader.close();
					//raf.close();
				}
				catch(IOException e){}
			}

		}

		@Override
		protected void onProgressUpdate(StringBuilder[] values)
		{
			// TODO: Implement this method
			super.onProgressUpdate(values);
			textViewUndoRedo.stopListening();
			textViewUndoRedo.clearHistory();
			undo_button.setEnabled(false);
			undo_button.setAlpha(100);
			redo_button.setEnabled(false);
			redo_button.setAlpha(100);
			
			if(go_back)
			{
				filetext_container_edittext.setText("");
				filetext_container_edittext.append(values[0].toString());
			}
			else
			{
				filetext_container_edittext.setText(values[0].toString());
			}
			
			textViewUndoRedo.startListening();
			cpbf.dismissAllowingStateLoss();
		
		}

		@Override
		protected void onPostExecute(Boolean result)
		{
			// TODO: Implement this method

		}
		
	}
	

	static Class getEmptyService()
	{
		Class emptyService=null;
		if(FileSaveService1.SERVICE_COMPLETED)
		{
			emptyService=FileSaveService1.class;
		}
		else if(FileSaveService2.SERVICE_COMPLETED)
		{
			emptyService=FileSaveService2.class;
		}

		return emptyService;
	}
	
	
	private int getEOL(Uri data)
	{
		int eol=EOL_N;
		BufferedReader bufferedReader=null;
		try
		{
			bufferedReader=new BufferedReader(new InputStreamReader(getContentResolver().openInputStream(data),"UTF-8"), buffersize);
			String line;
			line=bufferedReader.readLine();
			bufferedReader.close();
			if(line!=null)
			{
				bufferedReader=new BufferedReader(new InputStreamReader(getContentResolver().openInputStream(data),"UTF-8"), buffersize);
				int length=line.length();
				char [] c=new char[2];
				bufferedReader.skip(length);
				bufferedReader.read(c);
				int i=c[0];
				int o=c[1];
				if(i==10)
				{
					eol=EOL_N;
				}
				else if(i==13)
				{
					if(o==10)
					{
						eol=EOL_RN;
					}
					else
					{
						eol=EOL_R;
					}
				}
			}
			bufferedReader.close();
		}
		catch(UnsupportedEncodingException | IOException e)
		{
			
		}
		finally
		{
			try
			{
				bufferedReader.close();
			}
			catch(IOException e){}
			return eol;
		}
		
	}
	
	private class FileSaveBroadcastReceiver extends BroadcastReceiver
	{

		@Override
		public void onReceive(Context p1, Intent p2)
		{
			// TODO: Implement this method
			
		}

		
		
	}
	
}
