package svl.kadatha.filex;

import java.util.ArrayList;
import java.util.LinkedHashMap;

public class IndexedLinkedHashMap<K,V> extends LinkedHashMap<K,V> {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    ArrayList<K> al_Index = new ArrayList<K>();

    @Override
    public V put(K key,V val) 
	{
        if (!super.containsKey(key)) al_Index.add(key);
        V returnValue = super.put(key,val);
        return returnValue;
    }

    public V getValueAtIndex(int i)
	{
        return (V) super.get(al_Index.get(i));
    }

    public K getKeyAtIndex(int i) 
	{
        return (K) al_Index.get(i);
    }

    public int getIndexOf(K key) 
	{
        return al_Index.indexOf(key);
    }

	@Override
	public boolean replace(K key, V oldValue, V newValue)
	{
		// TODO: Implement this method
		return super.replace(key, oldValue, newValue);
	}

	@Override
	public V replace(K key, V value)
	{
		// TODO: Implement this method
		return super.replace(key, value);
	}

	
	
	
	@Override
	public V remove(K key)
	{
		// TODO: Implement this method
		if(al_Index.remove(key))
		return (V) super.remove(key);
		return null;
	}

	@Override
	public boolean remove(K key, V value)
	{
		// TODO: Implement this method
		if( super.remove(key, value))
		return al_Index.remove(key);
		return false;
	}
	
	public V removeKeyAtIndex(int i) 
	{
        return remove(al_Index.get(i));
    }
	
	public boolean removeIndex(K key)
	{
		return al_Index.remove(key);
	}
	

	@Override
	public void clear()
	{
		// TODO: Implement this method
		al_Index.clear();
		super.clear();
	}
	

}
