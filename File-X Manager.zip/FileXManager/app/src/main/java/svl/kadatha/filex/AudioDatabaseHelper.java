package svl.kadatha.filex;
import android.content.*;
import android.database.sqlite.*;
import android.database.*;
import java.util.*;
import android.graphics.*;
import android.widget.*;

public class AudioDatabaseHelper
{
	private Context context;
	private SQLiteDatabase db;
	
	static final String DATABASE="AudioSavedLists.db";
	
	AudioDatabaseHelper(Context context)
	{
		this.context=context;
		db=context.openOrCreateDatabase(DATABASE,context.MODE_PRIVATE,null);

	}
	
	public void createTable(String table)
	{
		try
		{
			db.execSQL("CREATE TABLE IF NOT EXISTS "+table+" (id INTEGER PRIMARY KEY, data TEXT, title TEXT, album TEXT,artist TEXT,duration TEXT)");
		}
		catch(SQLiteException e)
		{

		}
	}
	
	
	public long insert(String table,AudioPOJO audio)
	{
		
		ContentValues contentValues=new ContentValues();
		contentValues.put("id",audio.getId());
		contentValues.put("data",audio.getData());
		contentValues.put("title",audio.getTitle());
		contentValues.put("album",audio.getAlbum());
		contentValues.put("artist",audio.getArtist());
		contentValues.put("duration",audio.getDuration());
		
		return db.insert(table,null,contentValues);
	}
	

	public void insert(String table,List<AudioPOJO> audio_list)
	{
		
		int size=audio_list.size();
		for(int i=0;i<size;i++)
		{
			AudioPOJO audio=audio_list.get(i);
			ContentValues contentValues=new ContentValues();
			contentValues.put("id",audio.getId());
			contentValues.put("data",audio.getData());
			contentValues.put("title",audio.getTitle());
			contentValues.put("album",audio.getAlbum());
			contentValues.put("artist",audio.getArtist());
			contentValues.put("duration",audio.getDuration());
			db.insert(table,null,contentValues);
		}
		
	}
	
	public int delete(String table,int id)
	{
		return db.delete(table,"id=?",new String [] {new Integer(id).toString()});
		
	}
	
	public void delete(String table,List<AudioPOJO> audio_list)
	{
		
		int size=audio_list.size();
		for(int i=0;i<size;i++)
		{
			AudioPOJO audio=audio_list.get(i);
			db.delete(table,"id=?",new String [] {new Integer(audio.getId()).toString()});
			
		}
		
		

	}
	
	
	public SQLiteDatabase getDatabase()
	{
		return db;
	}
	
	public void deleteTable(String table)
	{
		db.execSQL("DROP TABLE IF EXISTS "+table);
	
	}
	
	public ArrayList<String> getTables()
	{
		ArrayList<String>l=new ArrayList<>();
		try
		{
			Cursor c=db.rawQuery("SELECT name FROM sqlite_master WHERE TYPE='table' AND name!='android_metadata'",null);
			if(c.moveToFirst())
			{
				while(!c.isAfterLast())
				{

					l.add(c.getString(c.getColumnIndex("name")));
					c.moveToNext();
				}
			}
		}
		catch(SQLiteException e)
		{
			print("Exception thrown: could not extract entries");
		}
		return l;
	}
	
	public ArrayList<AudioPOJO> getAudioList(String table)
	{
		ArrayList<AudioPOJO> audio_list=new ArrayList<>();
		try
		{
			Cursor c=db.rawQuery("SELECT * FROM "+table,null);
			if(c.moveToFirst())
			{
				while(!c.isAfterLast())
				{

					int id=c.getInt(c.getColumnIndex("id"));
					String data=c.getString(c.getColumnIndex("data"));
					String title=c.getString(c.getColumnIndex("title"));
					String album=c.getString(c.getColumnIndex("album"));
					String artist=c.getString(c.getColumnIndex("artist"));
					String duration=c.getString(c.getColumnIndex("duration"));
					Bitmap albumart=null;
					AudioPOJO audio=new AudioPOJO(id, data, title, album, artist, duration,albumart);
					audio.setAlbumArt(AudioPlayerActivity.getAlbumArt(context,data));
					audio_list.add(audio);
					c.moveToNext();

				}
			}
		}
		catch(SQLiteException e)
		{
			print("Exception thrown: could not extract entries");
		}
		
		 return audio_list;
		
	}

	private void print(String msg)
	{
		Toast.makeText(context,msg,Toast.LENGTH_SHORT).show();
	}
}
