package svl.kadatha.filex;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.net.*;
import android.os.*;
import android.support.v4.view.*;
import android.support.v7.app.*;
import android.support.v7.widget.*;
import android.util.*;
import android.view.*;
import android.view.animation.*;
import android.widget.*;
import com.bumptech.glide.*;
import com.bumptech.glide.load.engine.*;
import java.io.*;
import java.util.*;
import android.support.v4.app.*;
import android.support.v4.content.*;
import android.support.design.widget.*;


public class PictureViewActivity extends AppCompatActivity 
{
	
	public Uri data;
	public FragmentManager fm;
	private Context context;
	TinyDB tinyDB;
	public File CacheDir;
	

	
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
 		// TODO: Implement this method
		super.onCreate(savedInstanceState);
		context=this;
		fm=getSupportFragmentManager();
		CacheDir=getExternalCacheDir();
		setContentView(R.layout.activity_picture_view);
		tinyDB=new TinyDB(context);
	
		Global.GET_SCREEN_DIMENSIONS(context);
		Global.GET_URI_PERMISSIONS_LIST(context);
		
		
		Global.GET_SORT(tinyDB);
		StatusBarTint.darkenStatusBar(this,R.color.toolbar_background);
	
		if(savedInstanceState==null)
		{
			Intent intent=getIntent();
			if(intent!=null)
			{
				String receivedAction=intent.getAction();
				String receivedType=intent.getType();
				data=intent.getData();
				if(receivedAction.equals(Intent.ACTION_VIEW) && receivedType.startsWith("image/") && data!=null)
				{
					String path=PathUtil.getPath(context,data);
					if(path==null || !new File(path).exists())
					{
						path=data.getPath();
					}
					fm.beginTransaction().replace(R.id.activity_picture_view_fragment,PictureViewFragment.getNewInstance(path),"picture_fragment").commit();
				}
			}
		}
		
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data)
	{
		// TODO: Implement this method
		super.onActivityResult(requestCode, resultCode, data);
	}
	
	
	private void print(String msg)
	{
		Toast.makeText(context,msg,Toast.LENGTH_SHORT).show();
	}
	
}
