package svl.kadatha.filex;
import android.support.v7.widget.*;
import android.widget.*;
import android.view.*;
import android.content.*;
import java.util.*;
import java.io.*;
import android.graphics.*;
import android.util.*;

public class WorkingDirRecyclerAdapter extends RecyclerView.Adapter<WorkingDirRecyclerAdapter.ViewHolder>
{
	private Context context;
	private List<String> working_dir_arraylist;
	static List<String> CUSTOMDIRSELECTEDDIRS=new ArrayList<>();
	static SparseBooleanArray CUSTOM_DIR_SELECTED_DIRS_BOOLEAN_ARRAY=new SparseBooleanArray();
	private ItemClickListener itemClickListener;
	WorkingDirRecyclerAdapter(Context context,List<String> working_dir_arraylist)
	{
		this.context=context;
		this.working_dir_arraylist=working_dir_arraylist;
		
	}
	
	class ViewHolder extends RecyclerView.ViewHolder
	{
		View view;
		TextView textView_working_dir;
		Integer pos;
		
		ViewHolder(View view)
		{
			super(view);
			this.view=view;
			textView_working_dir=view.findViewById(R.id.working_dir_name);
			view.setOnLongClickListener(new View.OnLongClickListener()
				{
					public boolean onLongClick(View p)
					{
						pos=getAdapterPosition();
						if(CUSTOM_DIR_SELECTED_DIRS_BOOLEAN_ARRAY.get(pos,false))
						{
							p.setSelected(false);
							CUSTOMDIRSELECTEDDIRS.remove(textView_working_dir.getText());
							CUSTOM_DIR_SELECTED_DIRS_BOOLEAN_ARRAY.delete(pos);
							
							
						}
						else
						{
							p.setSelected(true);
							CUSTOMDIRSELECTEDDIRS.add(textView_working_dir.getText().toString());
							CUSTOM_DIR_SELECTED_DIRS_BOOLEAN_ARRAY.put(pos,true);
							if(itemClickListener!=null)
							{
								itemClickListener.onItemLongClick(pos,working_dir_arraylist.get(pos));
							}
							
							
						}
						return true;

					}
				});

			view.setOnClickListener(new View.OnClickListener()
				{

					public void onClick(View p)
					{
						pos=getAdapterPosition();
						if(CUSTOMDIRSELECTEDDIRS.size()>0)
						{
						
							if(CUSTOM_DIR_SELECTED_DIRS_BOOLEAN_ARRAY.get(pos,false))
							{
								p.setSelected(false);
								CUSTOMDIRSELECTEDDIRS.remove(textView_working_dir.getText());
								CUSTOM_DIR_SELECTED_DIRS_BOOLEAN_ARRAY.delete(pos);

							}
							else
							{

								p.setSelected(true);
								CUSTOMDIRSELECTEDDIRS.add(textView_working_dir.getText().toString());
								CUSTOM_DIR_SELECTED_DIRS_BOOLEAN_ARRAY.put(pos,true);
							}
						}
						else
						{
							if(itemClickListener!=null)
							{
								itemClickListener.onItemClick(pos,working_dir_arraylist.get(pos));
							}
							
							
							
							CUSTOMDIRSELECTEDDIRS=new ArrayList<>();
							CUSTOM_DIR_SELECTED_DIRS_BOOLEAN_ARRAY=new SparseBooleanArray();
							
						}
					}

				});
			
			
		}
		
	}

	@Override
	public WorkingDirRecyclerAdapter.ViewHolder onCreateViewHolder(ViewGroup p1, int p2)
	{
		// TODO: Implement this method
		//View v=LayoutInflater.from(p1.getContext()).inflate(android.R.layout.simple_list_item_1,p1,false);
		View itemview=LayoutInflater.from(context).inflate(R.layout.working_dir_recyclerview_layout,p1,false);
		return new ViewHolder(itemview);
	}

	@Override
	public void onBindViewHolder(WorkingDirRecyclerAdapter.ViewHolder p1, int p2)
	{
		// TODO: Implement this method
		p1.textView_working_dir.setText(working_dir_arraylist.get(p2));
		
	
			
		p1.view.setSelected(CUSTOM_DIR_SELECTED_DIRS_BOOLEAN_ARRAY.get(p2,false));

	}

	@Override
	public int getItemCount()
	{
		// TODO: Implement this method
		return working_dir_arraylist.size();
	}

	
	public int insert(String f)
	{
		
		CUSTOMDIRSELECTEDDIRS=new ArrayList<>();
		CUSTOM_DIR_SELECTED_DIRS_BOOLEAN_ARRAY=new SparseBooleanArray();
		notifyDataSetChanged();
		working_dir_arraylist.add(f);
		int i=working_dir_arraylist.indexOf(f);
		notifyItemInserted(i);
		return i;
		
	}

	public int remove(List<String> selectedDirs)
	{
		
		int i=0;
		for(String s:selectedDirs)
		{
			i=working_dir_arraylist.indexOf(s);
			working_dir_arraylist.remove(s);
		}
		
		CUSTOMDIRSELECTEDDIRS=new ArrayList<>();
		CUSTOM_DIR_SELECTED_DIRS_BOOLEAN_ARRAY=new SparseBooleanArray();
		notifyDataSetChanged();
		return i;
		
	}
	
	public void setOnItemClickListener(ItemClickListener listener)
	{
		itemClickListener=listener;
	}

	interface ItemClickListener
	{
		public void onItemClick(int position, String name);
		public void onItemLongClick(int position, String name);
	}
	

}
