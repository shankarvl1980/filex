package svl.kadatha.filex;
import android.widget.*;
import android.view.*;
import android.os.*;
import android.widget.Gallery.*;
import android.graphics.drawable.*;
import android.graphics.*;
import android.content.*;

public class SaveFileConfirmationDialog extends android.support.v4.app.DialogFragment
{
	private TextView dialog_heading_textview,dialog_message_textview,no_files_textview,size_files_textview;
	private EditText new_file_name_edittext;
	private Button okbutton,cancelbutton;
	private View v;
	private SaveFileListener saveFileListener;
	private Context context;
	private ViewGroup buttons_layout;
	private boolean whether_closing;

	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		// TODO: Implement this method
		super.onCreate(savedInstanceState);
		Bundle bundle=getArguments();
		whether_closing=bundle.getBoolean("whether_closing");
		setRetainInstance(true);
	}

	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
	{
		// TODO: Implement this method
		context=getContext();
		v=inflater.inflate(R.layout.fragment_create_rename_delete,container,false);
		dialog_heading_textview=v.findViewById(R.id.dialog_fragment_rename_delete_title);
		dialog_message_textview=v.findViewById(R.id.dialog_fragment_rename_delete_message);
	
		
		new_file_name_edittext=v.findViewById(R.id.dialog_fragment_rename_delete_newfilename);
		no_files_textview=v.findViewById(R.id.dialog_fragment_rename_delete_no_of_files);
		size_files_textview=v.findViewById(R.id.dialog_fragment_rename_delete_total_size);
		buttons_layout=v.findViewById((R.id.fragment_create_rename_delete_button_layout));
		buttons_layout.addView(new EquallyDistributedChildrenLayout(context,2));
		okbutton=v.findViewById(R.id.first_button);
		okbutton.setText("Yes");
		cancelbutton=v.findViewById(R.id.second_button);
		cancelbutton.setText("No");

		dialog_heading_textview.setText("Save");
		dialog_message_textview.setText("File has been modified. Do you want to save the file?");
		new_file_name_edittext.setVisibility(View.GONE);
		no_files_textview.setVisibility(View.GONE);
		size_files_textview.setVisibility(View.GONE);
		
		okbutton.setOnClickListener(new View.OnClickListener()
		{
			public void onClick(View v)
			{
				if(saveFileListener!=null)
				{
					saveFileListener.next_action(true);
				}
				dismissAllowingStateLoss();
			}
		});
		
		cancelbutton.setOnClickListener(new View.OnClickListener()
		{
			public void onClick(View v)
			{
				if(saveFileListener!=null)
				{
					saveFileListener.next_action(false);
				}
				dismissAllowingStateLoss();
			}
		});
		
		
		
		return v;
	}
	
	public static SaveFileConfirmationDialog getInstance(boolean whether_closing)
	{
		SaveFileConfirmationDialog dialog=new SaveFileConfirmationDialog();
		Bundle bundle=new Bundle();
		bundle.putBoolean("whether_closing",whether_closing);
		dialog.setArguments(bundle);
		return dialog;
	}
	

	@Override
	public void onResume()
	{
		// TODO: Implement this method
		super.onResume();
		Window window=getDialog().getWindow();
		window.setLayout(Global.DIALOG_WIDTH,LayoutParams.WRAP_CONTENT);
		window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
		
	}
	

	@Override
	public void onDestroyView() 
	{
		if (getDialog() != null && getRetainInstance()) 
		{
			getDialog().setDismissMessage(null);
		}
		super.onDestroyView();

	}
	
	public void setSaveFileListener(SaveFileListener listener)
	{
		saveFileListener=listener;
	}
	
	interface SaveFileListener
	{
		
		public void next_action(boolean save);
	}
	
	
	
}
