package svl.kadatha.filex;
import java.io.*;
import java.util.*;
import android.content.*;
import android.app.*;
import java.nio.channels.*;
import android.widget.*;
import android.os.*;
import android.support.v4.app.*;
import android.util.*;
import android.support.v4.view.*;
import android.view.*;
import android.widget.AbsListView.*;
import android.icu.text.*;
import android.graphics.drawable.*;
import android.graphics.*;
import android.net.*;

public class DeleteAudioDialog extends android.support.v4.app.DialogFragment
{

	private Context context;
	private String parent_dir;
	private TextView dialog_title,from_textview,copied_textview;
	private TextView no_files_textview,size_files_textview;
	private EditText current_file;
	private TableRow to_table_row;
	private Button cancel_button,hide_button;
	private DeleteFileAsyncTask delete_file_async_task;
	private ArrayList<File> files_selected_for_delete =new ArrayList<>();
	public List<Integer> deleted_files=new ArrayList<>();
	private ArrayList<String> files_selected_array =new ArrayList<>();
	private final int request_code=8079;
	private boolean permission_requested;
	private String baseFolder="";
	private Uri uri;
	private NotifManager nm;
	private boolean dialog_hidden;
	private final int notification_id=(int)System.currentTimeMillis();
	private ViewGroup buttons_layout;
	private boolean library_search;
	private DeleteAudioCompleteListener deleteAudioCompleteListener;


	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		// TODO: Implement this method
		super.onCreate(savedInstanceState);
		this.setRetainInstance(true);
		setCancelable(false);
		files_selected_array.addAll(getArguments().getStringArrayList("files_selected_array"));
		for(String s:files_selected_array)
		{
			files_selected_for_delete.add(new File(s));
		}

		parent_dir=files_selected_for_delete.get(0).getParent();

		delete_file_async_task=new DeleteFileAsyncTask();
		delete_file_async_task.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);

	}


	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
	{
		context=getContext();
		nm=new NotifManager(context);
		View v=inflater.inflate(R.layout.fragment_cut_copy_delete_archive_progress,container,false);
		dialog_title=v.findViewById(R.id.dialog_fragment_cut_copy_title);
		from_textview=v.findViewById(R.id.dialog_fragment_cut_copy_from);
		to_table_row=v.findViewById(R.id.fragment_cut_copy_delete_archive_totablerow);
		current_file=v.findViewById(R.id.dialog_fragment_cut_copy_archive_current_file);
		copied_textview=v.findViewById(R.id.dialog_fragment_copied_file);
		no_files_textview=v.findViewById(R.id.fragment_cut_copy_delete_archive_no_files);
		size_files_textview=v.findViewById(R.id.fragment_cut_copy_delete_archive_size_files);
		buttons_layout=v.findViewById(R.id.fragment_cut_copy_delete_progress_button_layout);
		buttons_layout.addView(new EquallyDistributedChildrenLayout(context,2));
		hide_button=buttons_layout.findViewById(R.id.first_button);
		hide_button.setText("Hide");
		cancel_button=buttons_layout.findViewById(R.id.second_button);
		cancel_button.setText("Cancel");
		dialog_title.setText("Deleting");
		to_table_row.setVisibility(View.GONE);
		from_textview.setText(parent_dir);
		cancel_button.setOnClickListener(new View.OnClickListener()
			{
				public void onClick(View v)
				{
					if(delete_file_async_task!=null)
					{
						delete_file_async_task.cancel(true);

					}
					dismissAllowingStateLoss();

				}
			});
		hide_button.setOnClickListener(new View.OnClickListener()
			{

				public void onClick(View v)
				{

					getDialog().hide();
					dialog_hidden=true;
					nm.notify(parent_dir,notification_id);
				}
			});

		return v;
	}

	@Override
	public void onResume()
	{

		// TODO: Implement this method
		super.onResume();
		Window window=getDialog().getWindow();
		window.setLayout(Global.DIALOG_WIDTH,LayoutParams.WRAP_CONTENT);
		window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
		dialog_hidden=false;

	}

	public void checkSAFPermission()
	{

		Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
		startActivityForResult(intent, request_code);

	}


	// @TargetApi(Build.VERSION_CODES.LOLLIPOP)
	@Override
	public final void onActivityResult(final int requestCode, final int resultCode, final Intent resultData) 
	{

		if (requestCode == this.request_code && resultCode==getActivity().RESULT_OK) 
		{
			Uri treeUri = null;
			// Get Uri from Storage Access Framework.
			treeUri = resultData.getData();
			String uri_file_path=FileUtil.getFullPathFromTreeUri(treeUri,context);
			Iterator<Map.Entry<Uri,String>> iterator=Global.URI_STRING_HASHMAP.entrySet().iterator();
			while(iterator.hasNext())
			{
				Map.Entry<Uri,String> entry=iterator.next();
				if(entry.getValue().startsWith(uri_file_path))
				{
					iterator.remove();
				}
			}


			Global.URI_STRING_HASHMAP.put(treeUri,uri_file_path);


			// Persist access permissions.
			final int takeFlags = resultData.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
			context.getContentResolver().takePersistableUriPermission(treeUri, takeFlags);
			
			permission_requested=false;
			//df=(DetailFragment)MainActivity.FM.findFragmentById(R.id.detail_fragment);
			delete_file_async_task=new DeleteFileAsyncTask();
			delete_file_async_task.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);

		}
		else
		{
			cancel_button.callOnClick();
		}

	}

	public void setDeleteAudioCompleteListener(DeleteAudioCompleteListener listener)
	{
		deleteAudioCompleteListener=listener;
	}

	interface DeleteAudioCompleteListener
	{
		public void onDeleteComplete();
	}

	private class DeleteFileAsyncTask extends AsyncTask<Void,File,Boolean>
	{

		String file_src;
		List<File> src_file_list=new ArrayList<>();
		int counter_no_files;
		long counter_size_files;
		String current_file_name,sd_uri;
		boolean isFromInternal;
		long file_size_denominator;
		String size_of_files_format;

		DeleteFileAsyncTask()
		{

			src_file_list.addAll(files_selected_for_delete);

		}


		@Override
		protected void onPreExecute()
		{
			// TODO: Implement this method

		}

		@Override
		protected void onCancelled(Boolean result)
		{
			// TODO: Implement this method
			super.onCancelled(result);

			if(deleted_files.size()>0)
			{
				
				if(deleteAudioCompleteListener!=null)
				{
					deleteAudioCompleteListener.onDeleteComplete();
				}
				

			}
			if(!permission_requested)
			{
				dismissAllowingStateLoss();
			}

		}

		@Override
		protected Boolean doInBackground(Void...p)
		{
			// TODO: Implement this method
			boolean success=false;

			{
				library_search=true;
				success=deleteFromLibrarySearch();
			}

			return success;
		}

		private boolean deleteFromLibrarySearch()
		{

			boolean success=false;
			int iteration=0;
			int size=src_file_list.size();
			for(int i=0;i<size;i++)
			{
				File f=src_file_list.get(i);
				if(FileUtil.isFromInternal(f))
				{
					current_file_name=f.getName();
					success=deleteNativeDirectory(f);
					if(success)
					{
						deleted_files.add(src_file_list.indexOf(f));
					}
					files_selected_for_delete.remove(f);
				}
				else
				{

					for(Map.Entry<Uri,String> entry : Global.URI_STRING_HASHMAP.entrySet())
					{
						if(f.getAbsolutePath().startsWith(entry.getValue()))
						{
							baseFolder=entry.getValue();
							uri=entry.getKey();
							break;
						}
					}
					if(baseFolder.equals(""))
					{
						cancel(true);
						permission_requested=true;
						SAFPermissionHelperDialog safpermissionhelper=new SAFPermissionHelperDialog();
						safpermissionhelper.set_safpermissionhelperlistener(new SAFPermissionHelperDialog.SafPermissionHelperListener()
							{
								public void onOKBtnClicked()
								{
									checkSAFPermission();
								}

								public void onCancelBtnClicked()
								{
									dismissAllowingStateLoss();
								}
							});
						safpermissionhelper.show(MainActivity.FM,"saf_permission_dialog");

						return false;
					}

					if(isCancelled())
					{
						return false;
					}
					current_file_name=src_file_list.get(iteration).getName();
					publishProgress(f);
					success=FileUtil.deleteSAFFile(f,context,uri,baseFolder);
					if(success)
					{
						deleted_files.add(src_file_list.indexOf(f));
					}
					files_selected_for_delete.remove(f);

				}
				iteration++;
			}

			return success;
		}


		private boolean deleteFromFolder()
		{
			boolean success=false;
			int iteration=0;
			if(isFromInternal)
			{
				int size=src_file_list.size();
				for(int i=0;i<size;i++)
				{
					File f=src_file_list.get(i);
					current_file_name=f.getName();
					success=deleteNativeDirectory(f);
					if(success)
					{
						deleted_files.add(src_file_list.indexOf(f));
					}
					files_selected_for_delete.remove(f);
				}

			}
			else
			{

				for(Map.Entry<Uri,String> entry : Global.URI_STRING_HASHMAP.entrySet())
				{
					if(files_selected_for_delete.get(0).getAbsolutePath().startsWith(entry.getValue()))
					{
						baseFolder=entry.getValue();
						uri=entry.getKey();
						break;
					}
				}

				if(baseFolder.equals(""))
				{
					cancel(true);
					permission_requested=true;
					SAFPermissionHelperDialog safpermissionhelper=new SAFPermissionHelperDialog();
					safpermissionhelper.set_safpermissionhelperlistener(new SAFPermissionHelperDialog.SafPermissionHelperListener()
						{
							public void onOKBtnClicked()
							{
								checkSAFPermission();
							}

							public void onCancelBtnClicked()
							{
								dismissAllowingStateLoss();
							}
						});
					safpermissionhelper.show(MainActivity.FM,"saf_permission_dialog");
					return false;
				}

				int size=src_file_list.size();
				for(int i=0;i<size;i++)
				{
					File file=src_file_list.get(i);
					if(isCancelled())
					{
					  	return false;
					}
					current_file_name=src_file_list.get(iteration).getName();
					publishProgress(file);
					success=FileUtil.deleteSAFFile(file,context,uri,baseFolder);
					if(success)
					{
					 	deleted_files.add(src_file_list.indexOf(file));
					}
					files_selected_for_delete.remove(file);
					iteration++;

				}

			}
			return success;
		}


		public boolean deleteNativeDirectory(final File folder) 
		{     
			boolean success=false;

			if (folder.isDirectory())            //Check if folder file is a real folder
			{
				if(isCancelled())
				{
					return false;
				}

				File[] list = folder.listFiles(); //Storing all file name within array
				int size=list.length;
				if (list != null)                //Checking list value is null or not to check folder containts atleast one file
				{
					for (int i = 0; i < size; i++)    
					{
						if(isCancelled())
						{
							return false;
						}

						File tmpF = list[i];
						if (tmpF.isDirectory())   //if folder  found within folder remove that folder using recursive method
						{
							success=deleteNativeDirectory(tmpF);
						}

						else
						{

							counter_no_files++;
							counter_size_files+=tmpF.length();
							size_of_files_format=FileUtil.humanReadableByteCount(counter_size_files,Global.BYTE_COUNT_BLOCK_1000);
							publishProgress(tmpF);
							success=tmpF.delete(); //else delete filr
						}

					}
				}

				if(folder.exists())  //delete empty folder
				{
					counter_no_files++;
					publishProgress(folder);
					success=folder.delete();
				}

			}
			else
			{
				if(isCancelled())
				{
					return false;
				}

				counter_no_files++;
				counter_size_files+=folder.length();
				size_of_files_format=FileUtil.humanReadableByteCount(counter_size_files,Global.BYTE_COUNT_BLOCK_1000);
				publishProgress(folder);
				success=folder.delete();
			}

			return success;
		}

		@Override
		protected void onProgressUpdate(File... file)
		{
			// TODO: Implement this method
			//super.onProgressUpdate(values);
			if(copied_textview!=null)
			{
				current_file.setText(current_file_name);
				copied_textview.setText(file[0].getName());
				if(isFromInternal)
				{
					no_files_textview.setText("Deleted: "+counter_no_files + (counter_no_files<2 ? " file" : " files"));
					size_files_textview.setText("Size: "+size_of_files_format);
				}

			}

		}

		@Override
		protected void onPostExecute(Boolean result)
		{
			// TODO: Implement this method

			super.onPostExecute(result);

			if(deleted_files.size()>0)
			{
				if(deleteAudioCompleteListener!=null)
				{
					deleteAudioCompleteListener.onDeleteComplete();
				}
	
				print("Selected files/folders deleted");
				//if(MainActivity.NM.isDeleteNotificationVisible(notification_id))
				if(dialog_hidden)
				{
					nm.notify("Selected files/folders deleted",notification_id);
				}

			}
			else
			{
				print("Selected files/folders could not be deleted");
				//if(MainActivity.NM.isDeleteNotificationVisible(notification_id))
				if(dialog_hidden)
				{
					nm.notify("Selected files/folders could not be deleted",notification_id);
				}

			}

			dismissAllowingStateLoss();
		}

	}

	@Override
	public void onDestroyView() 
	{
		if (getDialog() != null && getRetainInstance()) 
		{
			getDialog().setDismissMessage(null);
		}
		super.onDestroyView();
	}
	
	private void print(String msg)
	{
		Toast.makeText(context,msg,Toast.LENGTH_SHORT).show();
	}


}
