package svl.kadatha.filex;
import java.util.*;
import java.io.*;

public class Iterate
{
	
	private static int TOTAL_NO_OF_FILES;
	private static long TOTAL_SIZE_OF_FILES;
	private static  List<Integer> FOLDERWISE_NO_OF_FILES=new ArrayList<>();
	private static List<Long> FOLDERWISE_SIZE_OF_FILES=new ArrayList<>();
	
	public static List<File> populate(File[] source_list_files,List<File> target_list_files, boolean include_folder)
	{
		int size=source_list_files.length;
		for(int i=0;i<size;i++)
		{
			File f=source_list_files[i];
			Integer no_of_files=0;
			Long size_of_files=0L;
			if(f.isDirectory())
			{

				if(f.list().length==0)
				{
					target_list_files.add(f);
				}
				else
				{
					populate(f.listFiles(),target_list_files,include_folder);
					target_list_files.add(f);

				}
				if(include_folder)
				{
					
					no_of_files++;
				}

			}
			else
			{

				target_list_files.add(f);
				no_of_files++;
				size_of_files+=f.length();
			}
			FOLDERWISE_NO_OF_FILES.add(no_of_files);
			FOLDERWISE_SIZE_OF_FILES.add(size_of_files);
			
			TOTAL_NO_OF_FILES+=no_of_files;
			TOTAL_SIZE_OF_FILES+=size_of_files;

		}
		

		return target_list_files;
	}
	
	public static List<File>[] populate_folderwise(File [] source_list_files,List<File>[] target_file_list_array,boolean include_folder)
	{
		int size=source_list_files.length;
		for(int i=0;i<size;i++)
		{

			target_file_list_array[i]=new ArrayList<>();
			populate(source_list_files,target_file_list_array[i],include_folder);
			//TOTAL_NO_OF_FILES+=TOTAL_NO_OF_FILES;
			//TOTAL_SIZE_OF_FILES+=TOTAL_SIZE_OF_FILES;
		}
		
		return target_file_list_array;
	}
}
