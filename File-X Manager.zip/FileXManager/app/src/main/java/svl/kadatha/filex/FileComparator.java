package svl.kadatha.filex;
import java.io.*;
import java.util.*;

public class FileComparator
{

	public static Comparator<File> FileComparate(String SORT)
	{
		switch(SORT)
		{

			case "d_name_asc":
				return new SORTFOLDERFILENAMEASC();
				
			case "d_name_desc":
				return new SORTFOLDERFILENAMEDESC();
				
			case "d_date_asc":
				return new SORTFOLDERFILETIMEASC();
				
			case "d_date_desc":
				return new SORTFOLDERFILETIMEDESC();
				
			case "f_name_asc":
				return new SORTFILEFOLDERNAMEASC();

			case "f_name_desc":
				return new SORTFILEFOLDERNAMEDESC();

			case "f_date_asc":
				return new SORTFILEFOLDERTIMEASC();

			case "f_date_desc":
				return new SORTFILEFOLDERTIMEDESC();
				
			default:
				return new SORTFOLDERFILENAMEASC();
				
		}
		
	}
	

	private static class SORTFOLDERFILENAMEASC implements Comparator<File> 
	{
		@Override
		public int compare(File f1, File f2) 
		{
		
			if (f1.isDirectory() && !f2.isDirectory())
				return -1;
				
			else if(!f1.isDirectory() && f2.isDirectory())
				return 1;
			else
				return f1.getName().toLowerCase().compareTo(f2.getName().toLowerCase());
				
		}
	}
	
	private static class SORTFILEFOLDERNAMEASC implements Comparator<File> 
	{
		@Override
		public int compare(File f1, File f2) 
		{

			if (!f1.isDirectory() && f2.isDirectory())
				return -1;

			else if(f1.isDirectory() && !f2.isDirectory())
				return 1;
			else
				return f1.getName().toLowerCase().compareTo(f2.getName().toLowerCase());

		}
	}
	
	
	private static class SORTFOLDERFILENAMEDESC implements Comparator<File> 
	{
		@Override
		public int compare(File f1, File f2) 
		{
		
			if (f1.isDirectory() && !f2.isDirectory())
				return -1;

			else if(!f1.isDirectory() && f2.isDirectory())
				return 1;
			else
			{
				int i=f1.getName().toLowerCase().compareTo(f2.getName().toLowerCase());
				
				return -(i);
				
			}
		}
	}
	
	
	private static class SORTFILEFOLDERNAMEDESC implements Comparator<File> 
	{
		@Override
		public int compare(File f1, File f2) 
		{

			if (!f1.isDirectory() && f2.isDirectory())
				return -1;

			else if(f1.isDirectory() && !f2.isDirectory())
				return 1;
			else
			{
				int i=f1.getName().toLowerCase().compareTo(f2.getName().toLowerCase());

				return -(i);

			}
		}
	}
	
	private static class SORTFOLDERFILETIMEASC implements Comparator<File>
	{

		@Override
		public int compare(File f1, File f2)
		{
			// TODO: Implement this method
			
	
			if (f1.isDirectory() && !f2.isDirectory())
				return -1;

			else if(!f1.isDirectory() && f2.isDirectory())
				return 1;
			else
				return ((Long) f1.lastModified()).compareTo( (Long)f2.lastModified());
			
			
		}

		
	}
	
	private static class SORTFILEFOLDERTIMEASC implements Comparator<File>
	{

		@Override
		public int compare(File f1, File f2)
		{
			// TODO: Implement this method


			if (!f1.isDirectory() && f2.isDirectory())
				return -1;

			else if(f1.isDirectory() && !f2.isDirectory())
				return 1;
			else
				return ((Long) f1.lastModified()).compareTo( (Long)f2.lastModified());

		}

	}
	
	
	
	private static class SORTFOLDERFILETIMEDESC implements Comparator<File>
	{

		@Override
		public int compare(File f1, File f2)
		{
			// TODO: Implement this method


			if (f1.isDirectory() && !f2.isDirectory())
				return -1;

			else if(!f1.isDirectory() && f2.isDirectory())
				return 1;
			else
			{
				int i=((Long) f1.lastModified()).compareTo( (Long)f2.lastModified());
				return -(i);
			}
				
		}
	}

	private static class SORTFILEFOLDERTIMEDESC implements Comparator<File>
	{

		@Override
		public int compare(File f1, File f2)
		{
			// TODO: Implement this method


			if (!f1.isDirectory() && f2.isDirectory())
				return -1;

			else if(f1.isDirectory() && !f2.isDirectory())
				return 1;
			else
			{
				int i=((Long) f1.lastModified()).compareTo( (Long)f2.lastModified());
				return -(i);
			}

		}
	}
	

	public static Comparator<FilePOJO> FilePOJOComparate(String SORT)
	{
		switch(SORT)
		{

			case "d_name_asc":
				return new SORTDFILEPOJONAMEASC();

			case "d_name_desc":
				return new SORTDFILEPOJONAMEDESC();

			case "d_date_asc":
				return new SORTDFILEPOJOTIMEASC();

			case "d_date_desc":
				return new SORTDFILEPOJOTIMEDESC();

			case "f_name_asc":
				return new SORTFFILEPOJONAMEASC();

			case "f_name_desc":
				return new SORTFFILEPOJONAMEDESC();

			case "f_date_asc":
				return new SORTFFILEPOJOTIMEASC();

			case "f_date_desc":
				return new SORTFFILEPOJOTIMEDESC();
				
			default:
				return new SORTDFILEPOJONAMEASC();

		}

	}
	
	

	private static class SORTDFILEPOJONAMEASC implements Comparator<FilePOJO> 
	{
		@Override
		public int compare(FilePOJO f1, FilePOJO f2) 
		{

			if (f1.getFile().isDirectory() && !f2.getFile().isDirectory())
				return -1;

			else if(!f1.getFile().isDirectory() && f2.getFile().isDirectory())
				return 1;
			else
				return f1.getName().toLowerCase().compareTo(f2.getName().toLowerCase());

		}
	}

	private static class SORTFFILEPOJONAMEASC implements Comparator<FilePOJO> 
	{
		@Override
		public int compare(FilePOJO f1, FilePOJO f2) 
		{

			if (!f1.getFile().isDirectory() && f2.getFile().isDirectory())
				return -1;

			else if(f1.getFile().isDirectory() && !f2.getFile().isDirectory())
				return 1;
			else
				return f1.getName().toLowerCase().compareTo(f2.getName().toLowerCase());

		}
	}

	private static class SORTDFILEPOJONAMEDESC implements Comparator<FilePOJO> 
	{
		@Override
		public int compare(FilePOJO f1, FilePOJO f2) 
		{
	
			if (f1.getFile().isDirectory() && !f2.getFile().isDirectory())
				return -1;

			else if(!f1.getFile().isDirectory() && f2.getFile().isDirectory())
				return 1;
			else
			{
				int i=f1.getName().toLowerCase().compareTo(f2.getName().toLowerCase());

				return -(i);

			}
		}
	}
	
	private static class SORTFFILEPOJONAMEDESC implements Comparator<FilePOJO> 
	{
		@Override
		public int compare(FilePOJO f1, FilePOJO f2) 
		{

			if (!f1.getFile().isDirectory() && f2.getFile().isDirectory())
				return -1;

			else if(f1.getFile().isDirectory() && !f2.getFile().isDirectory())
				return 1;
			else
			{
				int i=f1.getName().toLowerCase().compareTo(f2.getName().toLowerCase());

				return -(i);

			}
		}
	}

	private static class SORTDFILEPOJOTIMEASC implements Comparator<FilePOJO>
	{

		@Override
		public int compare(FilePOJO f1, FilePOJO f2)
		{
			// TODO: Implement this method


			if (f1.getFile().isDirectory() && !f2.getFile().isDirectory())
				return -1;

			else if(!f1.getFile().isDirectory() && f2.getFile().isDirectory())
				return 1;
			else
				return ((Long) f1.getFile().lastModified()).compareTo( (Long)f2.getFile().lastModified());


		}


	}
	private static class SORTFFILEPOJOTIMEASC implements Comparator<FilePOJO>
	{

		@Override
		public int compare(FilePOJO f1, FilePOJO f2)
		{
			// TODO: Implement this method


			if (!f1.getFile().isDirectory() && f2.getFile().isDirectory())
				return -1;

			else if(f1.getFile().isDirectory() && !f2.getFile().isDirectory())
				return 1;
			else
				return ((Long) f1.getFile().lastModified()).compareTo( (Long)f2.getFile().lastModified());


		}


	}




	private static class SORTDFILEPOJOTIMEDESC implements Comparator<FilePOJO>
	{

		@Override
		public int compare(FilePOJO f1, FilePOJO f2)
		{
			// TODO: Implement this method
			if (f1.getFile().isDirectory() && !f2.getFile().isDirectory())
				return -1;

			else if(!f1.getFile().isDirectory() && f2.getFile().isDirectory())
				return 1;
			else
			{
				int i=((Long) f1.getFile().lastModified()).compareTo( (Long)f2.getFile().lastModified());
				return -(i);
			}

		}
	}

	private static class SORTFFILEPOJOTIMEDESC implements Comparator<FilePOJO>
	{

		@Override
		public int compare(FilePOJO f1, FilePOJO f2)
		{
			// TODO: Implement this method
			if (!f1.getFile().isDirectory() && f2.getFile().isDirectory())
				return -1;

			else if(f1.getFile().isDirectory() && !f2.getFile().isDirectory())
				return 1;
			else
			{
				int i=((Long) f1.getFile().lastModified()).compareTo( (Long)f2.getFile().lastModified());
				return -(i);
			}

		}
	}
	
}
	
	

