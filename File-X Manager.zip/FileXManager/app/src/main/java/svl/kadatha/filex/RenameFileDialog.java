package svl.kadatha.filex;
import android.os.*;
import android.view.*;
import android.widget.*;
import java.io.*;
import android.content.*;
import android.opengl.*;
import android.widget.AbsListView.*;
import android.view.inputmethod.*;
import android.graphics.drawable.*;
import android.graphics.*;
import android.net.*;
import java.util.*;

public class RenameFileDialog extends android.support.v4.app.DialogFragment
{
	static File OLDFILE;
	private TextView dialog_heading_textview,dialog_message_textview,no_of_files_textview,files_size_textview;
	private EditText new_file_name_edittext;
	private Button okbutton,cancelbutton;
	private DetailFragment df;
	private InputMethodManager imm;
	private Context context;
	private final int request_code=76;
	private boolean permission_requested;
	private String baseFolder="";
	private Uri uri;
	private List<String> file_list_name;
	private ProgressBarFragment pbf;
	private boolean overwritten=false;
	private ViewGroup buttons_layout;
	

	
	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		// TODO: Implement this method
		super.onCreate(savedInstanceState);
		this.setRetainInstance(true);
		pbf=new ProgressBarFragment();
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
	{
		// TODO: Implement this method
		//return super.onCreateView(inflater, container, savedInstanceState);
		context=getContext();
		View v=inflater.inflate(R.layout.fragment_create_rename_delete,container,false);
		
		df=(DetailFragment)MainActivity.FM.findFragmentById(R.id.detail_fragment);
		dialog_heading_textview=v.findViewById(R.id.dialog_fragment_rename_delete_title);
		dialog_message_textview=v.findViewById(R.id.dialog_fragment_rename_delete_message);
		dialog_message_textview.setVisibility(View.GONE);
		new_file_name_edittext=v.findViewById(R.id.dialog_fragment_rename_delete_newfilename);
		no_of_files_textview=v.findViewById(R.id.dialog_fragment_rename_delete_no_of_files);
		files_size_textview=v.findViewById(R.id.dialog_fragment_rename_delete_total_size);
		no_of_files_textview.setVisibility(View.GONE);
		files_size_textview.setVisibility(View.GONE);
		buttons_layout=v.findViewById(R.id.fragment_create_rename_delete_button_layout);
		buttons_layout.addView(new EquallyDistributedChildrenLayout(context,2));
		okbutton=buttons_layout.findViewById(R.id.first_button);
		okbutton.setText("OK");
		cancelbutton=v.findViewById(R.id.second_button);
		cancelbutton.setText("Cancel");
		
		dialog_heading_textview.setText("Rename");
		new_file_name_edittext.setText(OLDFILE.getName());
		int l=OLDFILE.getName().lastIndexOf(".");
		if(l==-1)
		{
			l=OLDFILE.getName().length();
		}
		new_file_name_edittext.setSelection(0,l);
		
		imm=(InputMethodManager)context.getSystemService(Context.INPUT_METHOD_SERVICE);
		
		okbutton.setOnClickListener(new View.OnClickListener()
		{
			public void onClick(View v)
			{
				
				final String new_name=new_file_name_edittext.getText().toString().trim();
				if(new_name.equals(OLDFILE.getName()))
				{
					imm.hideSoftInputFromWindow(new_file_name_edittext.getWindowToken(),0);
					dismissAllowingStateLoss();
					return;
				}
				if(CheckStringForSpecialCharacters.whetherStringContains(new_name))
				{
					print("Avoid name involving characters '\\*:?/'");
					return;
				}
				if(new_name.equals("")|| new_name.equals(null))
				{
					print("Please enter name");
				}
				
				
				final File f=new File(df.getTag(),new_name);
				if(f.exists() && file_list_name.contains(new_name))
				{
					
					RenameReplaceConfirmationDialog renameReplaceConfirmationDialog=new RenameReplaceConfirmationDialog();
					renameReplaceConfirmationDialog.setRenameReplaceDialogListener(new RenameReplaceConfirmationDialog.RenameReplaceDialogListener()
					{
						public void rename_file()
						{
							rename_process(f,new_name);
						}
					});
					Bundle bundle=new Bundle();
					bundle.putString("rename_file_name",new_name);
					renameReplaceConfirmationDialog.setArguments(bundle);
					renameReplaceConfirmationDialog.show(MainActivity.FM,null);
					imm.hideSoftInputFromWindow(new_file_name_edittext.getWindowToken(),0);
						
				}
				else
				{
					rename_process(f,new_name);
						
				}
					
			}
		});
		
		cancelbutton.setOnClickListener(new View.OnClickListener()
		{
			public void onClick(View v)
			{
				OLDFILE=null;
				imm.hideSoftInputFromWindow(new_file_name_edittext.getWindowToken(),0);
				dismissAllowingStateLoss();
				
			}
			
		});
		file_list_name=new ArrayList<>();
		file_list_name.addAll(Arrays.asList(OLDFILE.getParentFile().list()));
		return v;
	}

	public void rename_process(File f, String new_name)
	{
		boolean fileNameChanged=false;
		overwritten=f.exists();
		if(FileUtil.isWritable(f))
		{
			fileNameChanged=FileUtil.renameNativeFile(OLDFILE,f);
		}
		else
		{
			for(Map.Entry<Uri,String> entry : Global.URI_STRING_HASHMAP.entrySet())
			{
				if(f.getParent().startsWith(entry.getValue()))
				{
					baseFolder=entry.getValue();
					uri=entry.getKey();
					break;
				}
			}
			
			if(baseFolder.equals(""))
			{
				permission_requested=true;
				SAFPermissionHelperDialog safpermissionhelper=new SAFPermissionHelperDialog();
				safpermissionhelper.set_safpermissionhelperlistener(new SAFPermissionHelperDialog.SafPermissionHelperListener()
				{
					public void onOKBtnClicked()
					{
						checkSAFPermission();
					}

					public void onCancelBtnClicked()
					{
						dismissAllowingStateLoss();
					}
				});
				safpermissionhelper.show(MainActivity.FM,"saf_permission_dialog");
				imm.hideSoftInputFromWindow(new_file_name_edittext.getWindowToken(),0);
	
			}
			else
			{
				
				if(f.exists() && file_list_name.contains(new_name) && !f.isDirectory())
				{
						
					pbf.show(MainActivity.FM,"progressbar_dialog");
					if(FileUtil.deleteSAFFile(f,context,uri,baseFolder))
					{
						fileNameChanged=FileUtil.renameSAFFile(OLDFILE,f,context,uri,baseFolder);
					}
					
					pbf.dismissAllowingStateLoss();
					
				}
				else if(!f.exists())
				{
					fileNameChanged=FileUtil.renameSAFFile(OLDFILE,f,context,uri,baseFolder);
				}
				else
				{
					fileNameChanged=false;
				}
				
				
			}

		}

		if(fileNameChanged)
		{
			df.adapter.refresh(f);
			print("'"+OLDFILE.getName()+"' renamed to '"+  f.getName()+"'");
			OLDFILE=null;

		}
		else
		{
			print("'"+OLDFILE.getName()+"' could not be renamed");
		}
		
		imm.hideSoftInputFromWindow(new_file_name_edittext.getWindowToken(),0);
		if(!permission_requested)
		{
			dismissAllowingStateLoss();
		}
		
	}
	
	
	@Override
	public void onResume()
	{
		// TODO: Implement this method
		super.onResume();
		
		Window window=getDialog().getWindow();
		window.setLayout(Global.DIALOG_WIDTH,LayoutParams.WRAP_CONTENT);
		window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
		
		new_file_name_edittext.requestFocus();
		imm.toggleSoftInput(InputMethodManager.SHOW_FORCED,0);
		
		
	}
	
	public void checkSAFPermission()
	{

		Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
		startActivityForResult(intent, request_code);
		
	}



	// @TargetApi(Build.VERSION_CODES.LOLLIPOP)
	@Override
	public final void onActivityResult(final int requestCode, final int resultCode, final Intent resultData) 
	{

		if (requestCode == this.request_code && resultCode==getActivity().RESULT_OK) 
		{
			Uri treeUri = null;
			// Get Uri from Storage Access Framework.
			treeUri = resultData.getData();
			String uri_file_path=FileUtil.getFullPathFromTreeUri(treeUri,context);
			Iterator<Map.Entry<Uri,String>> iterator=Global.URI_STRING_HASHMAP.entrySet().iterator();
			while(iterator.hasNext())
			{
				Map.Entry<Uri,String> entry=iterator.next();
				if(entry.getValue().startsWith(uri_file_path))
				{
					iterator.remove();
				}
			}


			Global.URI_STRING_HASHMAP.put(treeUri,uri_file_path);


			// Persist access permissions.
			final int takeFlags = resultData.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
			context.getContentResolver().takePersistableUriPermission(treeUri, takeFlags);
			
			permission_requested=false;
			String new_name=new_file_name_edittext.getText().toString().trim();
			rename_process(new File(df.getTag(),new_name),new_name);

		}

	}

	@Override
	public void onDestroyView() {
		if (getDialog() != null && getRetainInstance()) {
			getDialog().setDismissMessage(null);
		}
		super.onDestroyView();

	}

	@Override
	public void onCancel(DialogInterface dialog)
	{
		// TODO: Implement this method
		
		OLDFILE=null;
		imm.hideSoftInputFromWindow(new_file_name_edittext.getWindowToken(),0);
		super.onCancel(dialog);
		
	}
	
	

	@Override
	public void onDismiss(DialogInterface dialog)
	{
		// TODO: Implement this method
		OLDFILE=null;
		imm.hideSoftInputFromWindow(new_file_name_edittext.getWindowToken(),0);
		super.onDismiss(dialog);
	}
	
	
/*
	private class RenameAsyncTask extends AsyncTask<Void,Void,Boolean>
	{
		File f;
		ProgressBarFragment pbf;
		boolean fileNameChanged;
		RenameAsyncTask(File f)
		{
			this.f=f;
		}
		@Override
		protected void onPreExecute()
		{
			// TODO: Implement this method
			super.onPreExecute();
			pbf=new ProgressBarFragment();
			fileNameChanged=false;
			hasRenameAsyncTaskRan=true;
			pbf.show(MainActivity.FM,"progressbar_dialog");

		}

		@Override
		protected Boolean doInBackground(Void[] p1)
		{
			// TODO: Implement this method
			if(fileNameChanged=FileUtil.copySAFFileNIO(OLDFILE,f,context,uri_string,baseFolder))
			{
				FileUtil.deleteSAFFile(OLDFILE,context,uri_string,baseFolder);
			}
			return fileNameChanged;
		}



		@Override
		protected void onProgressUpdate(Void[] values)
		{
			// TODO: Implement this method
			super.onProgressUpdate(values);
		}
 

		@Override
		protected void onPostExecute(Boolean result)
		{
			// TODO: Implement this method
			super.onPostExecute(result);

			if(fileNameChanged)
			{

				df.adapter.remove_item(OLDFILE);
				int indexOfFileRenamed=df.adapter.insert_item(f);
				df.recyclerView.scrollToPosition(indexOfFileRenamed);
				print("'"+OLDFILE.getName()+"' renamed to '"+  f.getName()+"'");
				OLDFILE=null;

			}
			else
			{
				print("'"+OLDFILE.getName()+"' could not be renamed");
			}
		}



	}
	*/
	private void print(String msg)
	{
		Toast.makeText(context,msg,Toast.LENGTH_SHORT).show();
	}
}
