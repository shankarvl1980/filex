package svl.kadatha.filex;
import android.view.*;
import android.content.*;
import android.util.*;
import android.view.ViewGroup.*;
import android.graphics.*;
import android.support.annotation.*;
import android.widget.*;

public class EquallyDistributedChildrenLayout extends ViewGroup
{
	private Context context;
	private int number_of_buttons;
	private int dialog_width,margin;
	EquallyDistributedChildrenLayout(Context context,int number_of_buttons)
	{
		
		super(context);
		this.context=context;
		this.number_of_buttons=number_of_buttons;
		init();
	}
	EquallyDistributedChildrenLayout(Context context, AttributeSet attr, int number_of_buttons)
	{
		super(context,attr);
		this.context=context;
		this.number_of_buttons=number_of_buttons;
		init();
	}
	
	EquallyDistributedChildrenLayout(Context context, android.util.AttributeSet attr, int defStyle, int number_of_buttons)
	{
		super(context,attr,defStyle);
		this.context=context;
		this.number_of_buttons=number_of_buttons;
		init();
	}
	
	private void init()
	{
		setLayoutParams(new MarginLayoutParams(ViewGroup.MarginLayoutParams.MATCH_PARENT,ViewGroup.MarginLayoutParams.WRAP_CONTENT));
		LayoutInflater.from(context).inflate(R.layout.buttons_layout,this,true);
		dialog_width=Global.DIALOG_WIDTH;
		margin=(int)TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP,4,getResources().getDisplayMetrics());
	}

	@Override
	protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec)
	{
		// TODO: Implement this method
		int child_count=Math.min(number_of_buttons, getChildCount());
		int distance_between_buttons=(child_count-1)*margin;
		int width_for_child=MeasureSpec.makeMeasureSpec((dialog_width-distance_between_buttons)/child_count,MeasureSpec.EXACTLY);
		int width_used=0, height_used=0;
		for(int i=0; i<child_count;i++)
		{
			
				View v=getChildAt(i);
				MarginLayoutParams lp=(MarginLayoutParams)v.getLayoutParams();
				measureChildWithMargins(v,widthMeasureSpec,width_used,heightMeasureSpec,0);
				width_used+=v.getMeasuredWidth()+lp.getMarginStart()+lp.getMarginEnd();
				height_used=v.getMeasuredHeight();
				
				LinearLayout.LayoutParams ll=new LinearLayout.LayoutParams(width_for_child,height_used);
				v.setLayoutParams(ll);
				v.setBackgroundColor(context.getResources().getColor(R.color.toolbar_background));
				
			
		}
		
		
		setMeasuredDimension(widthMeasureSpec,height_used);
	}

	
	
	@Override
	protected void onLayout(boolean p1, int p2, int p3, int p4, int p5)
	{
		// TODO: Implement this method
		int x=0,y=0;
		int child_count=Math.min(number_of_buttons, getChildCount());
		for(int i=0;i<child_count;i++)
		{
			View v=getChildAt(i);
			v.layout(x,y,x+v.getMeasuredWidth(),v.getMeasuredHeight());
			x+=v.getMeasuredWidth()+margin;
		}
		
	}

	@Override
	protected ViewGroup.LayoutParams generateDefaultLayoutParams()
	{
		// TODO: Implement this method
		return new MarginLayoutParams(ViewGroup.MarginLayoutParams.MATCH_PARENT,ViewGroup.MarginLayoutParams.WRAP_CONTENT);
	}

	@Override
	public ViewGroup.LayoutParams generateLayoutParams(AttributeSet attrs)
	{
		// TODO: Implement this method
		return new MarginLayoutParams(context,attrs);
	}

	@Override
	protected ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams p)
	{
		// TODO: Implement this method
		return generateDefaultLayoutParams();
	}

	@Override
	protected boolean checkLayoutParams(ViewGroup.LayoutParams p)
	{
		// TODO: Implement this method
		return p instanceof MarginLayoutParams;
	}

	
	
}
