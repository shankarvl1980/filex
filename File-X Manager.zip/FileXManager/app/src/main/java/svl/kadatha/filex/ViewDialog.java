package svl.kadatha.filex;
import android.os.*;
import android.view.*;
import android.widget.*;
import android.content.*;
import android.widget.SeekBar.*;
import android.graphics.drawable.*;
import android.graphics.*;
import android.widget.TableRow.*;


public class ViewDialog extends android.support.v4.app.DialogFragment
{

	private SeekBar seekbar_fontsize;
	private TinyDB tinyDB;
	private Context context;
	private Button close_button;
	private ViewGroup buttons_layout;
	private ImageButton name_asc_btn,name_desc_btn,date_asc_btn,date_desc_btn;
	private ImageButtonClickListener imageButtonClickListener;

	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		// TODO: Implement this method
		super.onCreate(savedInstanceState);
		this.setRetainInstance(true);
		
		
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
	{
		// TODO: Implement this method
		//return super.onCreateView(inflater, container, savedInstanceState);
		context=getContext();
		tinyDB=new TinyDB(context);
		View v= inflater.inflate(R.layout.fragment_view,container,false);
		
		seekbar_fontsize=v.findViewById(R.id.seekbar_fontsize);
		name_asc_btn=v.findViewById(R.id.name_asc);
		name_desc_btn=v.findViewById(R.id.name_desc);
		date_asc_btn=v.findViewById(R.id.date_asc);
		date_desc_btn=v.findViewById(R.id.date_desc);
		
		imageButtonClickListener=new ImageButtonClickListener();
		name_asc_btn.setOnClickListener(imageButtonClickListener);
		name_desc_btn.setOnClickListener(imageButtonClickListener);
		date_asc_btn.setOnClickListener(imageButtonClickListener);
		date_desc_btn.setOnClickListener(imageButtonClickListener);
		
		
		
		buttons_layout=v.findViewById(R.id.fragment_view_button_layout);
		buttons_layout.addView(new EquallyDistributedChildrenLayout(context,1));
		close_button=buttons_layout.findViewById(R.id.first_button);
		close_button.setText("Close");
		close_button.setOnClickListener(new View.OnClickListener()
		{
			public void onClick(View v)
			{
				dismissAllowingStateLoss();
			}
		});
		
		seekbar_fontsize.setProgress(Global.RECYCLER_VIEW_FONT_SIZE_FACTOR);
		
		seekbar_fontsize.setOnSeekBarChangeListener(new OnSeekBarChangeListener()
		{
			
			int progress=0;
				public void onStartTrackingTouch(SeekBar p1)
				{

				}
				public void onStopTrackingTouch(SeekBar p1)
				{
					tinyDB.putInt("recycler_view_font_size_factor",Global.RECYCLER_VIEW_FONT_SIZE_FACTOR);
					DetailFragment df=(DetailFragment)MainActivity.FM.findFragmentById(R.id.detail_fragment);
					MainActivity.FM.beginTransaction().detach(df).attach(df).commit();
				

				}
				public void onProgressChanged(SeekBar p1, int progress_value,boolean fromUser)
				{
					progress=progress_value;
					Global.RECYCLER_VIEW_FONT_SIZE_FACTOR=progress_value;
				}
				
		});
		
		
		set_selection();
		
		return v;
	}
	
	private void set_selection()
	{
		switch(Global.SORT)
		{
			case "d_name_asc":
			case "f_name_asc":
				name_asc_btn.setSelected(true);
				
				name_desc_btn.setSelected(false);
				date_asc_btn.setSelected(false);
				date_desc_btn.setSelected(false);
				break;

			case "d_name_desc":
			case "f_name_desc":
				name_desc_btn.setSelected(true);
				
				name_asc_btn.setSelected(false);
				date_asc_btn.setSelected(false);
				date_desc_btn.setSelected(false);
				break;

			case "d_date_asc":
			case "f_date_asc":
				date_asc_btn.setSelected(true);
				
				name_asc_btn.setSelected(false);
				name_desc_btn.setSelected(false);
				date_desc_btn.setSelected(false);
				break;

			case "d_date_desc":
			case "f_date_desc":
				date_desc_btn.setSelected(true);
				
				name_asc_btn.setSelected(false);
				name_desc_btn.setSelected(false);
				date_asc_btn.setSelected(false);
				break;

			default:
				name_asc_btn.setSelected(true);
				
				name_desc_btn.setSelected(false);
				date_asc_btn.setSelected(false);
				date_desc_btn.setSelected(false);
				break;
		}
	}

	@Override
	public void onResume()
	{
		// TODO: Implement this method
		super.onResume();
		Window window=getDialog().getWindow();
		window.setLayout(Global.DIALOG_WIDTH,LayoutParams.WRAP_CONTENT);
		window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
		
	}
	


	@Override
	public void onDestroyView() {
		if (getDialog() != null && getRetainInstance()) {
			getDialog().setDismissMessage(null);
		}
		super.onDestroyView();
	}
	
	private class ImageButtonClickListener implements View.OnClickListener
	{

		@Override
		public void onClick(View button)
		{
			// TODO: Implement this method
			String selected_sort;
			switch (button.getId())
			{
				case R.id.name_asc:
					selected_sort="d_name_asc";
					break;
				case R.id.name_desc:
					selected_sort="d_name_desc";
					break;
				case R.id.date_asc:
					selected_sort="d_date_asc";
					break;
				case R.id.date_desc:
					selected_sort="d_date_desc";
					break;
				default:
					selected_sort="d_name_asc";
					break;
			}
			
			if(!selected_sort.equals(Global.SORT))
			{
				Global.SORT=selected_sort;
				set_selection();
				DetailFragment df=(DetailFragment)MainActivity.FM.findFragmentById(R.id.detail_fragment);
				MainActivity.FM.beginTransaction().detach(df).attach(df).commit();
				MainActivity.TINYDB.putString("sort",Global.SORT);
			}
		}

		
		
		
	}
}

