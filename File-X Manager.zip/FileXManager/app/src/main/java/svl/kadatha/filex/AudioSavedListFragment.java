package svl.kadatha.filex;

import android.support.v4.app.*;
import android.support.v4.content.*;
import android.database.*;
import android.os.*;
import android.net.*;
import android.view.*;
import android.content.Context;
import android.provider.*;
import java.util.*;
import android.support.v7.widget.*;
import java.util.concurrent.*;
import android.widget.*;
import java.io.*;
import android.content.Intent;
import android.util.*;
import android.graphics.*;
import android.view.animation.*;
import android.view.View.*;
import android.media.*;
import android.app.*;


public class AudioSavedListFragment extends android.support.v4.app.Fragment
{

	private Context context;

	private RecyclerView audio_recycler_view;
	private AudioSavedListRecyclerAdapter audio_saved_list_adapter;
	private List<String> saved_audio_list;
	private Handler handler;
	private ImageView play_btn,remove_btn;
	private Button all_audio_list_select;
	private android.support.v7.widget.Toolbar bottom_toolbar;
	private AudioSavedListDetailsDialog audioSavedListDetailsDialog;
	private AudioSelectListener audioSelectListener;
	public List<String> audio_list_selected_array=new ArrayList<>();
	public SparseBooleanArray mselecteditems=new SparseBooleanArray();
	private boolean toolbar_visible;
	private int scroll_distance;
	private ToolbarClickListener toolbarClickListener;
	private boolean AsyncExtractIsInProgress;
	private ExtractAudioFromSavedListAsyncTask extractAudioFromSavedListAsyncTask;
	private int num_all_audio_list;
	
	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		// TODO: Implement this method
		super.onCreate(savedInstanceState);
		setRetainInstance(true);
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
	{
		// TODO: Implement this method
		context=getContext();
		handler=new Handler();

		View v=inflater.inflate(R.layout.fragment_audio_saved_list,container,false);
		bottom_toolbar=v.findViewById(R.id.audio_saved_list_bottom_toolbar);
		bottom_toolbar.addView(new CustomToolbarLayout(context,R.layout.audio_list_toolbar_layout,Global.SCREEN_WIDTH,Global.SCREEN_HEIGHT));
		play_btn=bottom_toolbar.findViewById(R.id.audio_list_play);
		remove_btn=bottom_toolbar.findViewById(R.id.audio_list_remove);
		all_audio_list_select=bottom_toolbar.findViewById(R.id.all_audio_list_select);
		
		toolbarClickListener=new ToolbarClickListener();
		play_btn.setOnClickListener(toolbarClickListener);
		remove_btn.setOnClickListener(toolbarClickListener);
		all_audio_list_select.setOnClickListener(toolbarClickListener);
		
	
		audio_recycler_view=v.findViewById(R.id.fragment_audio_saved_list_recyclerview);
		audio_recycler_view.addItemDecoration(AudioPlayerActivity.DIVIDERITEMDECORATION);
		audio_recycler_view.setLayoutManager(new LinearLayoutManager(context));
		audio_recycler_view.addOnScrollListener(new RecyclerView.OnScrollListener()
			{
	
				final int threshold=5;
				public void onScrolled(RecyclerView rv, int dx, int dy)
				{
					super.onScrolled(rv,dx,dy);
					if(scroll_distance>threshold && toolbar_visible)
					{

						bottom_toolbar.animate().translationY(bottom_toolbar.getHeight()).setInterpolator(new AccelerateInterpolator(1));
						toolbar_visible=false;
						scroll_distance=0;
					}
					else if(scroll_distance<-threshold && !toolbar_visible)
					{
						if(mselecteditems.size()>0)
						{
							bottom_toolbar.animate().translationY(0).setInterpolator(new DecelerateInterpolator(1));
							toolbar_visible=true;
							scroll_distance=0;
						}
	
					}

					if((toolbar_visible && dy>0) || (!toolbar_visible && dy<0))
					{
						scroll_distance+=dy;
					}

				}

			});
		
		saved_audio_list=new ArrayList<>();
		saved_audio_list.add(AudioPlayerActivity.CURRENT_PLAY_LIST);
		saved_audio_list.addAll(AudioPlayerActivity.AUDIO_SAVED_LIST);
		audio_saved_list_adapter=new AudioSavedListRecyclerAdapter();
		audio_recycler_view.setAdapter(audio_saved_list_adapter);
		
		num_all_audio_list=saved_audio_list.size();

		if(mselecteditems.size()==0)
		{
			bottom_toolbar.setVisibility(View.GONE);
			bottom_toolbar.animate().translationY(bottom_toolbar.getHeight()).setInterpolator(new AccelerateInterpolator(1));
			toolbar_visible=false;
		}
		else
		{
			toolbar_visible=true;
		}
		
		all_audio_list_select.setText(mselecteditems.size()+"/"+num_all_audio_list);
		return v;
	}

	@Override
	public void onAttach(Activity activity)
	{
		// TODO: Implement this method
		super.onAttach(activity);
		
		 ((AudioPlayerActivity)activity).addBroadcastListener(new AudioPlayerActivity.BroadcastListener()
		 {
		 	public void onBroadcastReceive(String action)
		 	{
		 		if(audioSavedListDetailsDialog!=null)
				{
					audioSavedListDetailsDialog.onAudioChange(AudioPlayerService.CURRENT_PLAY_NUMBER);
				}
		 	}

		 });
		 
	}

	
	
	public void toolbarSlideDown()
	{
		if(mselecteditems.size()==0)
		{

			bottom_toolbar.animate().translationY(bottom_toolbar.getHeight()).setInterpolator(new AccelerateInterpolator(1));
			toolbar_visible=false;
			scroll_distance=0;

		}
	}

	
	public void onSaveAudioList()
	{
		// TODO: Implement this method
		saved_audio_list=new ArrayList<>();
		saved_audio_list.add(AudioPlayerActivity.CURRENT_PLAY_LIST);
		saved_audio_list.addAll(AudioPlayerActivity.AUDIO_SAVED_LIST);
		clear_selection();
	
	}

	
	private class ToolbarClickListener implements View.OnClickListener
	{

		@Override
		public void onClick(View p1)
		{
			// TODO: Implement this method
			
			switch(p1.getId())
			{

				case R.id.audio_list_play:
					
					if(audio_list_selected_array.size()<1)
					{
						break;
					}
					if(!AsyncExtractIsInProgress)
					{
						extractAudioFromSavedListAsyncTask=new ExtractAudioFromSavedListAsyncTask(audio_list_selected_array);
						extractAudioFromSavedListAsyncTask.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
					}
					clear_selection();
					break;

				case R.id.audio_list_remove:
					if(audio_list_selected_array.size()<1)
					{
						break;
					}
					if(audio_list_selected_array.contains(AudioPlayerActivity.CURRENT_PLAY_LIST))
					{
						AudioPlayerService.AUDIO_QUEUED_ARRAY=new ArrayList<>();
						audio_list_selected_array.remove(AudioPlayerActivity.CURRENT_PLAY_LIST);
					}
					for(String list_name:audio_list_selected_array)
					{
						
						
						AudioPlayerActivity.AUDIO_SAVED_LIST.remove(list_name);
						saved_audio_list.remove(list_name);
						((AudioPlayerActivity)context).audioDatabaseHelper.deleteTable(list_name);
					}
					((AudioPlayerActivity)context).tinyDB.putListString("audio_saved_list",AudioPlayerActivity.AUDIO_SAVED_LIST);
					clear_selection();
					break;

				case R.id.all_audio_list_select:
					if(mselecteditems.size()<num_all_audio_list)
					{
						mselecteditems=new SparseBooleanArray();
						audio_list_selected_array=new ArrayList<>();
						
						for(int i=0;i<num_all_audio_list;i++)
						{
							mselecteditems.put(i,true);
							audio_list_selected_array.add(saved_audio_list.get(i));
						}
						
						audio_saved_list_adapter.notifyDataSetChanged();
					}
					else
					{
						clear_selection();
					}
					all_audio_list_select.setText(mselecteditems.size()+"/"+num_all_audio_list);
					break;
				default:
					clear_selection();
					break;

			}
			
			
			((AudioPlayerActivity)context).trigger_enable_disable_previous_next_btns();
		}

	}
	

	private List<AudioPOJO> fetch_audio_list(String list_name)
	{
		List<AudioPOJO> clicked_audio_list=new ArrayList<>();
		if(list_name.equals(AudioPlayerActivity.CURRENT_PLAY_LIST))
		{
	
			clicked_audio_list=AudioPlayerService.AUDIO_QUEUED_ARRAY;
	
		}

		else if(AudioPlayerActivity.AUDIO_SAVED_LIST.contains(list_name))
		{
			
			clicked_audio_list=((AudioPlayerActivity)context).audioDatabaseHelper.getAudioList(list_name);
			Iterator<AudioPOJO> it=clicked_audio_list.iterator();
			while(it.hasNext())
			{
				AudioPOJO audio=it.next();
				if(!new File(audio.getData()).exists())
				{
					((AudioPlayerActivity)context).audioDatabaseHelper.delete(list_name,audio.getId());
					it.remove();
				}
			}
			

		}
		return clicked_audio_list;

	}
	

	public void clear_selection()
	{
		
		mselecteditems=new SparseBooleanArray<>();
		audio_list_selected_array=new ArrayList<>();
		audio_saved_list_adapter.notifyDataSetChanged();
	
		bottom_toolbar.animate().translationY(bottom_toolbar.getHeight()).setInterpolator(new AccelerateInterpolator(1));
		toolbar_visible=false;
		scroll_distance=0;
		
	}
	
	
	private class ExtractAudioFromSavedListAsyncTask extends AsyncTask<Void,Void,Void>
	{
		List<String> audio_selected_list=new ArrayList<>();
		List<AudioPOJO> extracted_audio_list=new ArrayList<>();
		ProgressBarFragment pbf;
		ExtractAudioFromSavedListAsyncTask(List<String> audio_selected_list)
		{
			this.audio_selected_list=audio_selected_list;
			pbf=new ProgressBarFragment();
		}
		
		@Override
		protected void onPreExecute()
		{
			// TODO: Implement this method
			super.onPreExecute();
			AsyncExtractIsInProgress=true;
			pbf.show(((AudioPlayerActivity)context).fm,"");
		}

		@Override
		protected Void doInBackground(Void[] p1)
		{
			// TODO: Implement this method
			for(String list_name:audio_selected_list)
			{
				extracted_audio_list.addAll(fetch_audio_list(list_name));
			}
			return null;
		}

		@Override
		protected void onProgressUpdate(Void[] values)
		{
			// TODO: Implement this method
			super.onProgressUpdate(values);
		}

		@Override
		protected void onPostExecute(Void result)
		{
			// TODO: Implement this method
			super.onPostExecute(result);
			AudioPlayerService.AUDIO_QUEUED_ARRAY=new ArrayList<>();
			AudioPlayerService.AUDIO_QUEUED_ARRAY=extracted_audio_list;
			if(audioSelectListener!=null && AudioPlayerService.AUDIO_QUEUED_ARRAY.size()!=0)
			{
				AudioPlayerService.CURRENT_PLAY_NUMBER=0;
				AudioPOJO audio=AudioPlayerService.AUDIO_QUEUED_ARRAY.get(AudioPlayerService.CURRENT_PLAY_NUMBER);
				Uri data=null;
				File f=new File(audio.getData());
				if(f.exists())
				{
					data=Uri.fromFile(f);
				}
				else
				{

					data=null;
				}
				
				audioSelectListener.onAudioSelect(data,audio);

			}
			pbf.dismissAllowingStateLoss();
			((AudioPlayerActivity)context).trigger_enable_disable_previous_next_btns();
			AsyncExtractIsInProgress=false;
		}
		
	}
	

	private class AudioSavedListRecyclerAdapter extends RecyclerView.Adapter<AudioSavedListRecyclerAdapter.ViewHolder>
	{
		int first_line_font_size,second_line_font_size;

		class ViewHolder extends RecyclerView.ViewHolder
		{
			View view;
			TextView textView;
			Integer pos;
			
			

			ViewHolder(View view)
			{
				super(view);
				this.view=view;
				textView=view.findViewById(R.id.working_dir_name);
				
				view.setOnClickListener(new View.OnClickListener()
					{

						public void onClick(View p)
						{
							pos=getAdapterPosition();
							if(mselecteditems.size()>0)
							{

								onLongClickProcedure(p);
							}
							else
							{
								ProgressBarFragment pbf=new ProgressBarFragment();
								pbf.show(((AudioPlayerActivity)context).fm,"");

								Bundle bundle=new Bundle();
								bundle.putInt("pos",pos);
								bundle.putString("list_name",saved_audio_list.get(pos));
								audioSavedListDetailsDialog=new AudioSavedListDetailsDialog();
								audioSavedListDetailsDialog.setAudioSelectListener(new AudioSavedListDetailsDialog.AudioSelectListener()
									{

										public void onAudioSelect(Uri data, AudioPOJO audio)
										{

											if(audioSelectListener!=null)
											{
												audioSelectListener.onAudioSelect(data,audio);
											}



										}

										public void onLongClick(int pos,View v)
										{

										}
									});
								audioSavedListDetailsDialog.setArguments(bundle);
								audioSavedListDetailsDialog.show(((AudioPlayerActivity)context).fm,"");

								pbf.dismissAllowingStateLoss();
							}
						}

					});
				
				
				view.setOnLongClickListener(new View.OnLongClickListener()
					{
						public boolean onLongClick(View p)
						{
							onLongClickProcedure(p);
							return true;

						}
					});

					
			}
			

			private void onLongClickProcedure(View v)
			{
				pos=getAdapterPosition();
				if(mselecteditems.get(pos,false))
				{
					v.setSelected(false);
					audio_list_selected_array.remove(textView.getText());
					mselecteditems.delete(pos);
					if(mselecteditems.size()>=1)
					{
						bottom_toolbar.setVisibility(View.VISIBLE);
						bottom_toolbar.animate().translationY(0).setInterpolator(new DecelerateInterpolator(1));
						toolbar_visible=true;
						scroll_distance=0;

					}

			

					if(mselecteditems.size()==0)
					{

						bottom_toolbar.animate().translationY(bottom_toolbar.getHeight()).setInterpolator(new AccelerateInterpolator(1));
						toolbar_visible=false;
						scroll_distance=0;
		
					}


				}
				else
				{
					v.setSelected(true);
					audio_list_selected_array.add(textView.getText().toString());
					mselecteditems.put(pos,true);
					
		
					
					bottom_toolbar.setVisibility(View.VISIBLE);
					bottom_toolbar.animate().translationY(0).setInterpolator(new DecelerateInterpolator(1));
					toolbar_visible=true;
					scroll_distance=0;
					
					
					
					if(mselecteditems.size()==1)
					{

		
					}

					else if(mselecteditems.size()>1)
					{
					
					}

				}
				all_audio_list_select.setText(mselecteditems.size()+"/"+num_all_audio_list);
			}

		}

		@Override
		public AudioSavedListRecyclerAdapter.ViewHolder onCreateViewHolder(ViewGroup p1, int p2)
		{
			// TODO: Implement this method
			//View v=LayoutInflater.from(p1.getContext()).inflate(android.R.layout.simple_list_item_1,p1,false);
			View itemview=LayoutInflater.from(p1.getContext()).inflate(R.layout.working_dir_recyclerview_layout,p1,false);
			return new ViewHolder(itemview);
		}

		@Override
		public void onBindViewHolder(AudioSavedListRecyclerAdapter.ViewHolder p1, int p2)
		{
			// TODO: Implement this method

			if(Global.RECYCLER_VIEW_FONT_SIZE_FACTOR==0)
			{
				first_line_font_size=Global.FONT_SIZE_SMALL_FIRST_LINE;
				second_line_font_size=Global.FONT_SIZE_SMALL_DETAILS_LINE;


			}
			else if(Global.RECYCLER_VIEW_FONT_SIZE_FACTOR==2)
			{
				first_line_font_size=Global.FONT_SIZE_LARGE_FIRST_LINE;
				second_line_font_size=Global.FONT_SIZE_LARGE_DETAILS_LINE;
			}
			else
			{
				first_line_font_size=Global.FONT_SIZE_MEDIUM_FIRST_LINE;
				second_line_font_size=Global.FONT_SIZE_SMALL_DETAILS_LINE;
			}
			
			
			p1.textView.setTextSize(first_line_font_size);
			p1.textView.setText(saved_audio_list.get(p2));
			p1.view.setSelected(mselecteditems.get(p2,false));

		}

		@Override
		public int getItemCount()
		{
			// TODO: Implement this method
			num_all_audio_list=saved_audio_list.size();
			return num_all_audio_list;
		}


	}

	
	interface AudioSelectListener
	{
		public void onAudioSelect(Uri data, AudioPOJO audio);
	}

	public void setAudioSelectListener(AudioSelectListener listener)
	{
		audioSelectListener=listener;
	}

	
	private void print(String msg)
	{
		Toast.makeText(context,msg,Toast.LENGTH_SHORT).show();
	}

}
