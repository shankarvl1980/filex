package svl.kadatha.filex;
import java.util.*;
import java.io.*;
import android.os.*;
import android.support.v4.content.*;
import android.view.*;
import android.content.*;
import android.support.v4.os.*;
import android.os.Build.*;
import java.util.zip.*;

public class StorageUtil
{
	//TargetApi(Build.VERSION_CODES.HONEYCOMB)
	public static ArrayList<FilePOJO> getSdCardPaths(final Context context, final boolean includePrimaryExternalStorage)
    {
		final File[] externalFilesDirs=ContextCompat.getExternalFilesDirs(context,null);
		if(externalFilesDirs==null||externalFilesDirs.length==0)
			return null;
		if(externalFilesDirs.length==1)
		{
			if(externalFilesDirs[0]==null)
				return null;
			final String storageState=EnvironmentCompat.getStorageState(externalFilesDirs[0]);
			if(!Environment.MEDIA_MOUNTED.equals(storageState))
				return null;
			if(!includePrimaryExternalStorage && VERSION.SDK_INT>=VERSION_CODES.HONEYCOMB && Environment.isExternalStorageEmulated())
				return null;
		}
		final ArrayList<FilePOJO> result=new ArrayList<>();
		if(new File("/").list()!=null && new File("/").canRead())
		{
			result.add(DetailFragment.make_filePOJO(new File("/"),false,false));
		}
		
		if(includePrimaryExternalStorage || externalFilesDirs.length==1)
		{
			File f=new File(getRootOfInnerSdCardFolder(externalFilesDirs[0]));
			result.add(DetailFragment.make_filePOJO(f,false,false));
			Global.INTERNAL_STORAGE_PATH=f.getAbsolutePath();
		}
			
		for(int i=1;i<externalFilesDirs.length;++i)
		{
			final File file=externalFilesDirs[i];
			if(file==null)
				continue;
			final String storageState=EnvironmentCompat.getStorageState(file);
			if(Environment.MEDIA_MOUNTED.equals(storageState))
			{
				File f=new File(getRootOfInnerSdCardFolder(externalFilesDirs[i]));
				result.add(DetailFragment.make_filePOJO(f,false,false));
				if(i==1)
				{
					Global.EXTERNAL_STORAGE_PATH=f.getAbsolutePath();
				}
			}
				
		}
		/*
		String [] sdcardpaths=FileUtil.getExtSdCardPaths(context);
		for(String sdcardpath:sdcardpaths)
		{
			if(sdcardpath!=null && !result.contains(sdcardpath))
			{
				if(Environment.MEDIA_MOUNTED.equals(EnvironmentCompat.getStorageState(new File(sdcardpath))))
				{
					result.add(sdcardpath);
				}

			}
		}
		
		File externalStorageDirectory=Environment.getExternalStorageDirectory();
		if(externalStorageDirectory!=null && !result.contains(externalStorageDirectory.getAbsolutePath()))
		{
			if(Environment.MEDIA_MOUNTED.equals(EnvironmentCompat.getStorageState(externalStorageDirectory)))
			{
				result.add(externalStorageDirectory.getAbsolutePath());
			}
			
		}
		*/
		
		File mnt = new File("/storage");
		if (!mnt.exists())
			mnt = new File("/mnt");

		File[] fileList = mnt.listFiles(new FileFilter() {

				@Override
				public boolean accept(File pathname) {
					return pathname.isDirectory() && pathname.exists()
						&& pathname.canWrite() && !pathname.isHidden()
						&& !isSymlink(pathname);
				}
			});
		
		
		//File fileList[] = new File("/storage/").listFiles();
		for (File file : fileList)
		{     
			if(!file.getAbsolutePath().equalsIgnoreCase(Environment.getExternalStorageDirectory().getAbsolutePath()) && file.isDirectory() && file.canRead() && !result.contains(file.getAbsolutePath()))
			{
				result.add(DetailFragment.make_filePOJO(file,false,false));
			}
		}
		
		

		String[] different_sdcard_paths=new String[]
		{
		
			"/mnt/extsdcard",
			"/mnt/sdcard/external_sd",
			"/mnt/external_sd",
			"/mnt/media_rw/sdcard1",
			"/removable/microsd",
			"/mnt/emmc",
			"/data/sdext",
			"/data/sdext2",
			"/data/sdext3",
			"/data/sdext4"
		};
		
		for(String path: different_sdcard_paths)
		{
			File f=new File(path);
			if(f.exists() && f.isDirectory() && f.canWrite() && !f.isHidden() && !isSymlink(f) && !result.contains(f.getAbsolutePath()))
			{
				if(Environment.MEDIA_MOUNTED.equals(EnvironmentCompat.getStorageState(f)))
				{
					result.add(DetailFragment.make_filePOJO(f,false,false));
				}
				
			}
			
		}
		
		
		if(result.isEmpty())
			return null;
		return result;
    }

	

	public static boolean isSymlink(File file) 
	{
		try
		{
			File canon;
			if (file.getParent() == null)
			{
				canon = file;
			} else
			{
				File canonDir = file.getParentFile().getCanonicalFile();
				canon = new File(canonDir, file.getName());
			}
			return !canon.getCanonicalFile().equals(canon.getAbsoluteFile());
		}
		catch (IOException e)
		{
			return false;
		}
	}
	
	/** Given any file/folder inside an sd card, this will return the path of the sd card */
	private static String getRootOfInnerSdCardFolder(File file)
    {
		if(file==null)
			return null;
		final long totalSpace=file.getTotalSpace();
		while(true)
		{
			final File parentFile=file.getParentFile();
			if(parentFile==null||parentFile.getTotalSpace()!=totalSpace||parentFile.list()==null)
				return file.getAbsolutePath();
			file=parentFile;
		}
    }
	
}
