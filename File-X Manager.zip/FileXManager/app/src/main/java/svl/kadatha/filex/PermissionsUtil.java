package svl.kadatha.filex;
import android.os.*;
import android.support.v4.content.*;
import android.content.*;
import android.content.pm.*;
import android.support.v4.app.*;
import android.*;
import android.app.*;
import java.util.*;
import android.support.v7.app.*;

public class PermissionsUtil
{
	static final int STORAGE_PERMISSIONS_REQUEST_CODE=657;
	static final int NOTIFICATION_PERMISSION_REQUEST_CODE=675;
	private Context context;
	private Activity activity;
	private List<String>permissions_list_storage=new ArrayList<>();
	private List<String>permissions_not_granted_list=new ArrayList<>();


	
	PermissionsUtil(Context context,AppCompatActivity activity)
	{
		this.context=context;
		this.activity=activity;
		
		permissions_list_storage.add(android.Manifest.permission.READ_EXTERNAL_STORAGE);
		permissions_list_storage.add(android.Manifest.permission.WRITE_EXTERNAL_STORAGE);
		
	}
	
	public boolean check_storage_permission()
	{
		
		if(Build.VERSION.SDK_INT>=23)
		{
			for(String permission:permissions_list_storage)
			{
				//List<String>permissions_not_granted_list1=new ArrayList<>();
				int i=ContextCompat.checkSelfPermission(context,android.Manifest.permission.WRITE_EXTERNAL_STORAGE);
				//permissions_not_granted_list.add(permission);
				if(i!=PackageManager.PERMISSION_GRANTED)
				{
					permissions_not_granted_list.add(permission);
				}
			}
			if(!permissions_not_granted_list.isEmpty())
			{
				
				activity.requestPermissions(permissions_not_granted_list.toArray(new String[permissions_not_granted_list.size()]),STORAGE_PERMISSIONS_REQUEST_CODE);
				return false;
			}
			else
			{
				return true;
			}
		
		}
		return true;
	}
	
	public boolean check_notification_policy()
	{
		if(Build.VERSION.SDK_INT>=23)
		{
			
			int i=activity.checkSelfPermission(android.Manifest.permission.ACCESS_NOTIFICATION_POLICY);
			if(i!=PackageManager.PERMISSION_GRANTED)
			{
				activity.requestPermissions(new String []{"android.Manifest.permission.ACCESS_NOTIFICATION_POLICY"},NOTIFICATION_PERMISSION_REQUEST_CODE);
				return false;
					
				
			}
			else
			{
				return true;
			}
		}
		else
		{
			return true;
		}
			
	}
		
	
}
