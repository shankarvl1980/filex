package svl.kadatha.filex;
import java.util.*;
import android.net.*;
import android.content.*;
import android.content.res.*;
import android.support.v7.app.*;
import android.util.*;

public class Global
{
	static String INTERNAL_STORAGE_PATH;
	static String EXTERNAL_STORAGE_PATH;
	static HashMap<Uri,String> URI_STRING_HASHMAP=new HashMap<>();
	static int SCREEN_WIDTH,SCREEN_HEIGHT,DIALOG_WIDTH,DIALOG_HEIGHT;
	static String SORT;
	static int RECYCLER_VIEW_FONT_SIZE_FACTOR;

	
	static final String OTHER_TEXT_REGEX="(?i)txt|java|xml|cpp|c|h";
	static final String RTF_REGEX="(?i)rtf";
	static final String IMAGE_REGEX="(?i)png|jpg|jpeg|svg|gif|tif|webp";
	static final String AUDIO_REGEX="(?i)mp3|ogg|wav|aac|wma";
	static final String VIDEO_REGEX="(?i)3gp|mp4|avi|mov|flv|wmv|webm";
	static final String ZIP_REGEX="(?i)zip|rar";
	static final String UNIX_ARCHIVE_REGEX="(?i)tar|gzip|gz";
	static final String APK_REGEX="(?i)apk";
	static final String PDF_REGEX="(?i)pdf";
	static final String DOC_REGEX="(?i)doc|docx";
	static final String XLS_REGEX="(?i)xls|xlsx";
	static final String PPT_REGEX="(?i)ppt|pptx";
	static final String DB_REGEX="(?i)db";
	
	static int RECYCLERVIEWMARGIN_DP=4;
	
	static int IMAGEVIEW_DIMENSION_SMALL;
	static int IMAGEVIEW_DIMENSION_MEDIUM;
	static int IMAGEVIEW_DIMENSION_LARGE;
	
	
	static final int FONT_SIZE_SMALL_FIRST_LINE=14;
	static final int FONT_SIZE_SMALL_DETAILS_LINE=11;
	
	static final int FONT_SIZE_MEDIUM_FIRST_LINE=16;
	static final int FONT_SIZE_MEDIUM_DETAILS_LINE=12;
	
	static final int FONT_SIZE_LARGE_FIRST_LINE=18;
	static final int FONT_SIZE_LARGE_DETAILS_LINE=14;
	
	static final int IMAGE_VIEW_DIMENSION_MULTIPLIER_SMALL=9;
	static final int IMAGE_VIEW_DIMENSION_MULTIPLIER_MEDIUM=10;
	static final int IMAGE_VIEW_DIMENSION_MULTIPLIER_LARGE=11;
	
	static boolean BYTE_COUNT_BLOCK_1000;
	
	static final Set<String> SORT_CODE_SET=new HashSet<>(Arrays.asList("d_name_asc","d_name_desc","d_date_asc","d_date_desc","f_name_asc","f_name_desc","f_date_asc","f_date_desc"));
	
	static void GET_URI_PERMISSIONS_LIST(Context context)
	{
		Global.URI_STRING_HASHMAP=new HashMap<>();
		List<UriPermission> permission_list=context.getContentResolver().getPersistedUriPermissions();
		if(permission_list.size()>0)
		{
			for(UriPermission permission : permission_list)
			{
				if(permission.isWritePermission())
				{
					Uri uri=permission.getUri();
					Global.URI_STRING_HASHMAP.put(uri,FileUtil.getFullPathFromTreeUri(uri,context));
				}

			}

		}
	}
	
	static void GET_SCREEN_DIMENSIONS(Context context)
	{
		if(Global.SCREEN_WIDTH==0 || Global.SCREEN_HEIGHT==0)
		{
			int orientation=context.getResources().getConfiguration().orientation;
			if(orientation==Configuration.ORIENTATION_LANDSCAPE)
			{
				Global.SCREEN_WIDTH=((AppCompatActivity)context).getWindowManager().getDefaultDisplay().getHeight();
				Global.SCREEN_HEIGHT=((AppCompatActivity)context).getWindowManager().getDefaultDisplay().getWidth();
			}
			else
			{
				Global.SCREEN_WIDTH=((AppCompatActivity)context).getWindowManager().getDefaultDisplay().getWidth();
				Global.SCREEN_HEIGHT=((AppCompatActivity)context).getWindowManager().getDefaultDisplay().getHeight();
			}

		}
		Global.DIALOG_WIDTH=Global.SCREEN_WIDTH*90/100;
		Global.DIALOG_HEIGHT=Global.SCREEN_HEIGHT*80/100;
	}
	
	
	static void GET_SORT(TinyDB tinyDB)
	{
		Global.SORT=tinyDB.getString("sort");
		if(!Global.SORT_CODE_SET.contains(Global.SORT))
		{
			Global.SORT="d_name_asc";

		}
		
	}
	
	static int GET_RECYCLERVIEWMARGIN(Context context)
	{
		return (int)TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP,RECYCLERVIEWMARGIN_DP,context.getResources().getDisplayMetrics());
	}
	
	static void GET_IMAGEVIEW_DIMENSIONS(Context context)
	{
		
		int s=(int)TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP,4,context.getResources().getDisplayMetrics());
		IMAGEVIEW_DIMENSION_SMALL=s*Global.IMAGE_VIEW_DIMENSION_MULTIPLIER_SMALL;
		IMAGEVIEW_DIMENSION_MEDIUM=s*Global.IMAGE_VIEW_DIMENSION_MULTIPLIER_MEDIUM;
		IMAGEVIEW_DIMENSION_LARGE=s*Global.IMAGE_VIEW_DIMENSION_MULTIPLIER_LARGE;
	}
}
