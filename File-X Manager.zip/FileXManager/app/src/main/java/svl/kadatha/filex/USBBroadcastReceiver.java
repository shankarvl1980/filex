package svl.kadatha.filex;
import android.content.*;
import android.widget.*;
import android.hardware.usb.*;
import java.io.*;
import android.net.*;
import java.util.*;
import android.os.storage.*;
import java.lang.reflect.*;

public class USBBroadcastReceiver extends BroadcastReceiver
{
	static USBAttachDetachListener USBATTACHDETACHLISTENER;
	private final String usb_uri="usb://1002/UsbStorage";
	Context c;
	@Override
	public void onReceive(Context p1, Intent p2)
	{
		// TODO: Implement this method
	
		Object[] storageVolumeList;
		
		StorageManager storageManager = (StorageManager) p1.getSystemService(Context.STORAGE_SERVICE);
		try
		{
			Method getVolumeListMethod = StorageManager.class.getDeclaredMethod("getVolumeList");
			storageVolumeList = (Object[]) getVolumeListMethod.invoke(storageManager);
			
		}
		catch(Exception e){}
		
		UsbDevice ub;
		UsbInterface ubinterface;
		UsbManager manager=(UsbManager)p1.getSystemService(Context.USB_SERVICE);
		HashMap<String, UsbDevice> devicelist=manager.getDeviceList();
		Iterator<UsbDevice> it=devicelist.values().iterator();
		while(it.hasNext())
		{
			ub=it.next();
			ubinterface=ub.getInterface(0);
			int id=ub.getDeviceId();
			String s=ub.getDeviceName();
		
		}
		UsbDevice device=(UsbDevice)p2.getParcelableExtra(UsbManager.EXTRA_DEVICE);
		c=p1;
		if(p2.getAction().equals(UsbManager.ACTION_USB_DEVICE_ATTACHED))
		{
			//Toast.makeText(p1,"usb attached",Toast.LENGTH_SHORT).show();
			Uri uri=p2.getData();
			
			//String f=FileUtil.getFullPathFromTreeUri(uri,c);
			//MainActivity.STORAGE_DIR.add(null);
			
		}
		else if(p2.getAction().equals(UsbManager.ACTION_USB_DEVICE_DETACHED))
		{
			//Toast.makeText(p1,"usb detached",Toast.LENGTH_SHORT).show();
			MainActivity.STORAGE_DIR.remove(usb_uri);
		}
		
		Uri uri=p2.getData();
		if(USBATTACHDETACHLISTENER!=null)
		{
			USBATTACHDETACHLISTENER.onUSBAttachDetach();
		}
	}
	
	interface USBAttachDetachListener
	{
		public void onUSBAttachDetach();
	}
	
}
