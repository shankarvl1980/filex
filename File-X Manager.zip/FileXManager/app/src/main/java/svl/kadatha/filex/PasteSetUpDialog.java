package svl.kadatha.filex;
import android.support.v4.app.*;
import android.os.*;
import java.util.*;
import java.io.*;
import android.content.*;
import android.net.*;
import android.view.*;

public class PasteSetUpDialog extends DialogFragment
{
	private Context context;
	private Bundle bundle;
	private boolean isWritable, isSourceFromInternal,cut;
	private int request_code=103;
	private String baseFolder="",source="",source_folder,dest_folder;;
	private Uri uri,sourceUri;

	
	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		// TODO: Implement this method
		super.onCreate(savedInstanceState);
		context=getContext();
		this.setRetainInstance(true);
		setCancelable(false);

		bundle=getArguments();
		isWritable=bundle.getBoolean("isWritable");
		isSourceFromInternal=bundle.getBoolean("isSourceFromInternal");
		cut=bundle.getBoolean("cut");
		source_folder=bundle.getString("source_folder");
		dest_folder=bundle.getString("dest_folder");
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
	{
		// TODO: Implement this method
		context=getContext();
		checkForSAF_permission();
		return super.onCreateView(inflater, container, savedInstanceState);
	}
	
	
	public void checkSAFPermission()
	{

		Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
		startActivityForResult(intent, request_code);

	}



	// @TargetApi(Build.VERSION_CODES.LOLLIPOP)
	@Override
	public final void onActivityResult(final int requestCode, final int resultCode, final Intent resultData) 
	{

		if (requestCode == this.request_code && resultCode==getActivity().RESULT_OK) 
		{
			Uri treeUri = null;
			// Get Uri from Storage Access Framework.
			treeUri = resultData.getData();
			String uri_file_path=FileUtil.getFullPathFromTreeUri(treeUri,context);
			Iterator<Map.Entry<Uri,String>> iterator=Global.URI_STRING_HASHMAP.entrySet().iterator();
			while(iterator.hasNext())
			{
				Map.Entry<Uri,String> entry=iterator.next();
				if(entry.getValue().startsWith(uri_file_path))
				{
		
					iterator.remove();
				}
			}


			Global.URI_STRING_HASHMAP.put(treeUri,uri_file_path);
	

			// Persist access permissions.
			final int takeFlags = resultData.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
			context.getContentResolver().takePersistableUriPermission(treeUri, takeFlags);
			
			checkForSAF_permission();

		}
		else
		{
			dismissAllowingStateLoss();
		}

	}
	
	
	private void checkForSAF_permission()
	{
		if(!isSourceFromInternal&&cut)
		{
			for(Map.Entry<Uri,String> entry : Global.URI_STRING_HASHMAP.entrySet())
			{
				if(source_folder.startsWith(entry.getValue()))
				{
					source=entry.getValue();
					sourceUri=entry.getKey();

					break;
				}
			}

			if(source.equals(""))
			{

				SAFPermissionHelperDialog safpermissionhelper=new SAFPermissionHelperDialog();
				safpermissionhelper.set_safpermissionhelperlistener(new SAFPermissionHelperDialog.SafPermissionHelperListener()
					{
						public void onOKBtnClicked()
						{
							checkSAFPermission();
						}

						public void onCancelBtnClicked()
						{
							dismissAllowingStateLoss();
						}
					});
				safpermissionhelper.show(MainActivity.FM,"saf_permission_dialog");
				return;

			}
			else
			{
				check_permission_for_destination();
			}
		}

		else if(!isWritable)
		{
			check_permission_for_destination();
		}
		else
		{
			Class emptyService=MainActivity.getEmptyService();
			if(emptyService==null)
			{
				print("Maximum 3 services only be processed at a time");
				dismissAllowingStateLoss();
				return;
			}
			Intent intent=new Intent(context,emptyService);
			intent.setAction(cut ? "paste-cut" : "paste-copy");
			intent.putExtra("bundle",bundle);
			context.startActivity(intent);
			dismissAllowingStateLoss();
		}
		
	}
	
	private void check_permission_for_destination()
	{
		if(!isWritable)
		{
			for(Map.Entry<Uri,String> entry : Global.URI_STRING_HASHMAP.entrySet())
			{
				if(dest_folder.startsWith(entry.getValue()))
				{
					baseFolder=entry.getValue();
					uri=entry.getKey();

					break;
				}
			}

			if(baseFolder.equals(""))
			{

				SAFPermissionHelperDialog safpermissionhelper=new SAFPermissionHelperDialog();
				safpermissionhelper.set_safpermissionhelperlistener(new SAFPermissionHelperDialog.SafPermissionHelperListener()
					{
						public void onOKBtnClicked()
						{
							checkSAFPermission();
						}

						public void onCancelBtnClicked()
						{
							dismissAllowingStateLoss();
						}
					});
				safpermissionhelper.show(MainActivity.FM,"saf_permission_dialog");
				return;

			}
			else
			{
				Class emptyService=MainActivity.getEmptyService();
				if(emptyService==null)
				{
					print("Maximum 3 services only be processed at a time");
					dismissAllowingStateLoss();
					return;
				}
				Intent intent=new Intent(context,emptyService);
				intent.setAction(cut ? "paste-cut" : "paste-copy");
				bundle.putString("baseFolder",baseFolder);
				bundle.putString("sourceFolder",source);
				bundle.putParcelable("uri",uri);
				bundle.putParcelable("sourceUri",sourceUri);
				intent.putExtra("bundle",bundle);
				context.startActivity(intent);
				dismissAllowingStateLoss();
			}
		}
		else
		{
			Class emptyService=MainActivity.getEmptyService();
			if(emptyService==null)
			{
				print("Maximum 3 services only be processed at a time");
				dismissAllowingStateLoss();
				return;
			}
			Intent intent=new Intent(context,emptyService);
			intent.setAction(cut ? "paste-cut" : "paste-copy");
			bundle.putString("baseFolder",baseFolder);
			bundle.putString("sourceFolder",source);
			bundle.putParcelable("uri",uri);
			bundle.putParcelable("sourceUri",sourceUri);
			intent.putExtra("bundle",bundle);
			context.startActivity(intent);
			dismissAllowingStateLoss();
		}
	}
	
	private void print(String msg)
	{

		android.widget.Toast.makeText(context,msg,android.widget.Toast.LENGTH_SHORT).show();
	}
	
}
