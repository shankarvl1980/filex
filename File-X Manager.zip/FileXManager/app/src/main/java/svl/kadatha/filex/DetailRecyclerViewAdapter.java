package svl.kadatha.filex;
import android.widget.*;
import android.support.v7.widget.*;
import android.view.*;
import java.util.*;
import java.io.*;
import android.view.View.*;
import android.app.*;
import android.content.*;
import android.os.*;
import android.util.*;
import java.text.*;
import android.transition.*;
import android.support.v4.app.*;
import java.util.zip.*;
import com.bumptech.glide.*;
import com.bumptech.glide.load.engine.*;
import android.content.pm.*;
import android.animation.*;
import android.graphics.drawable.*;
import android.content.res.*;
import android.graphics.*;
import android.support.annotation.*;
import android.support.v7.util.*;

public class DetailRecyclerViewAdapter extends  RecyclerView.Adapter <DetailRecyclerViewAdapter.ViewHolder>
{
	
	private Context context;
	private DetailFragment df;
	private MainActivity mainActivity;
	
	
	List<FilePOJO> filePOJO_list=new ArrayList<>();
	
	private boolean file_group_everybody,archive_view;
	private CardViewClickListener cardViewClickListener;
	private DetailRecyclerViewAdapterDiffUtil detailRecyclerViewAdapterDiffUtil;


	DetailRecyclerViewAdapter(List<FilePOJO> filePOJOList,Context context,boolean archiveview)
	{
		this.context=context;
	
		this.filePOJO_list=filePOJOList;
		archive_view=archiveview;
		
		mainActivity=(MainActivity)context;
		df=(DetailFragment)MainActivity.FM.findFragmentById(R.id.detail_fragment);
	
		
		if(df.fileclickselected.exists())
		{

			mainActivity.current_dir_textview.setText(df.fileclickselected.getName());
			mainActivity.num_selected_btn.setText(df.mselecteditems.size()+"/"+df.file_list_size);
			File parent_file=df.fileclickselected.getParentFile();
			if(parent_file!=null)
			{
				if(!(archive_view && df.fileclickselected.equals(MainActivity.ARCHIVE_EXTRACT_DIR)))
				{
					mainActivity.parent_dir_imagebutton.setEnabled(true);
					mainActivity.parent_dir_imagebutton.setAlpha(255);
				}


			}
			else
			{
				mainActivity.current_dir_textview.setText("Root Directory");
				mainActivity.parent_dir_imagebutton.setEnabled(false);
				mainActivity.parent_dir_imagebutton.setAlpha(100);
			}

		}
		else if(MainActivity.LIBRARY_CATEGORIES.contains(df.fileclickselected.toString())|| df.fileclickselected.toString().equals(DetailFragment.SEARCH_RESULT))
		{
			mainActivity.current_dir_textview.setText(df.fileclickselected.toString());
			mainActivity.num_selected_btn.setText(df.mselecteditems.size()+"/"+df.file_list_size);
			mainActivity.parent_dir_imagebutton.setEnabled(false);
			mainActivity.parent_dir_imagebutton.setAlpha(100);

		}

	
	}
	
	
	class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener, AdapterView.OnLongClickListener
	{
		RecyclerViewItem view;
		Integer pos;
		
		ViewHolder (RecyclerViewItem view)
		{
			
			super(view);
			this.view=view;
			
			view.setOnClickListener(this);
			view.setOnLongClickListener(this);
			
		}

		
		@Override
		public void onClick(View p1)
		{
			pos=getAdapterPosition();
			if(df.mselecteditems.size()>0)
			{
				longClickMethod(p1);
				
			}
			else 
			{
				
				if(cardViewClickListener!=null)
				{
					FilePOJO file=filePOJO_list.get(pos);
					cardViewClickListener.onClick(getPosition(),p1,file.getFile(),file.getName());
				}
				
			}
		
		}
		
		private void longClickMethod (View v)
		{
			pos=getAdapterPosition();
			if(df.mselecteditems.get(pos,false))
			{
				df.mselecteditems.delete(pos);
				
				v.setSelected(false);
				df.file_selected_array.remove(filePOJO_list.get(pos).getFile());
				if(df.mselecteditems.size()==1)
				{
					mainActivity.rename.setEnabled(true);
					mainActivity.rename.setAlpha(255);

					if(cardViewClickListener!=null)
					{
						cardViewClickListener.onLongClick(getPosition(),v);
					}
				}

				else if(df.mselecteditems.size()>1)
				{
					mainActivity.rename.setEnabled(false);
					mainActivity.rename.setAlpha(100);

					if(cardViewClickListener!=null)
					{
						cardViewClickListener.onLongClick(getPosition(),v);
					}

				}

				if(df.mselecteditems.size()==0)
				{

					mainActivity.actionmode_finish(df.getTag());
				}
			}
			else
			{
				df.mselecteditems.put(pos,true);
				v.setSelected(true);
				df.file_selected_array.add(filePOJO_list.get(pos).getFile());



				if(df.mselecteditems.size()==1)
				{

					mainActivity.rename.setEnabled(true);
					mainActivity.rename.setAlpha(255);

				}

				else if(df.mselecteditems.size()>1)
				{
					mainActivity.rename.setEnabled(false);
					mainActivity.rename.setAlpha(100);

				}

				if(cardViewClickListener!=null)
				{
					cardViewClickListener.onLongClick(getPosition(),v);
				}
			}
			mainActivity.num_selected_btn.setText(df.mselecteditems.size()+"/"+df.file_list_size);
		}
		
		@Override
		public boolean onLongClick(View p1)
		{
			
			longClickMethod(p1);
			return true;
		}

	}

	@Override
	public ViewHolder onCreateViewHolder(ViewGroup p1, int p2)
	{
	
		return new ViewHolder(new RecyclerViewItem(context));
		
	}

	@Override
	public void onBindViewHolder(DetailRecyclerViewAdapter.ViewHolder p1, int p2)
	{
		FilePOJO file=filePOJO_list.get(p2);
		File f=file.getFile();
		String name=file.getName();
		String path=file.getPath();
		String date=file.getDate();
		String size=file.getSize();
		Integer type=file.getType();
		String ext=file.getExt();
		int alfa=file.getAlfa();
		int overlay_visisble=file.getOverlayVisibility();
		p1.view.setData(f,name,path,size,date,type,ext,alfa,overlay_visisble);
		
		
		
		p1.view.setSelected(df.mselecteditems.get(p2,false));
			
	}
/*
	@Override
	public void onBindViewHolder(DetailRecyclerViewAdapter.ViewHolder holder, int position, List<Object> payloads)
	{
		// TODO: Implement this method
		super.onBindViewHolder(holder, position, payloads);
		if(payloads.isEmpty())
		{
			onBindViewHolder(holder,position);
		}
	}

*/
	@Override
	public int getItemCount()
	{	
		
		return filePOJO_list.size();
	}
	
	public void refresh(@Nullable File fi)
	{
		if(df!=null)
		{
			if(fi!=null)
			{
				df.index_file=fi.getName();
			}
			
			
			if(filePOJO_list.size()==0)
			{
				MainActivity.FM.beginTransaction().detach(df).attach(df).commit();
			}
			else
			{
				df.refresh_data();
			}
			
		}
		MainActivity.workout_availablespace();
		
	}
	
	public void update(List<FilePOJO> new_list)
	{
		this.filePOJO_list=new_list;
	}
	
	public void notify_dataset_changed(List<FilePOJO> new_list)
	{
		List<FilePOJO> old_list=new ArrayList<>(filePOJO_list);
		detailRecyclerViewAdapterDiffUtil=new DetailRecyclerViewAdapterDiffUtil(old_list,new_list);
		DiffUtil.DiffResult diff_result=DiffUtil.calculateDiff(detailRecyclerViewAdapterDiffUtil);
		
	
		
		filePOJO_list.clear();
		filePOJO_list.addAll(new_list);
		
		diff_result.dispatchUpdatesTo(this);
		
	}

	
	public void remove_item(List<Integer> index_array)
	{
		Collections.sort(index_array,Collections.reverseOrder());
		for(Integer i: index_array)
		{
			int o=i.intValue();
			if(filePOJO_list.size()>o)
			{
				filePOJO_list.remove(o);
				notifyItemRemoved(o);
			}
		
		}
		df.file_list_size=filePOJO_list.size();
		mainActivity.num_selected_btn.setText(df.mselecteditems.size()+"/"+df.file_list_size);
	}
	
	
	
	
	public void selectAll()
	{

		df.mselecteditems=new SparseBooleanArray();
		df.file_selected_array=new ArrayList<>();
		
		for(int i=0;i<filePOJO_list.size();i++)
		{
			df.mselecteditems.put(i,true);
			df.file_selected_array.add(filePOJO_list.get(i).getFile());
			
		}
		if(df.mselecteditems.size()==1)
		{
			mainActivity.rename.setEnabled(true);
			mainActivity.rename.setAlpha(255);

		}

		else if(df.mselecteditems.size()>1)
		{
			mainActivity.rename.setEnabled(false);
			mainActivity.rename.setAlpha(100);

		}
		mainActivity.num_selected_btn.setText(df.mselecteditems.size()+"/"+df.file_list_size);
		notifyDataSetChanged();
		if(!mainActivity.TOOLBAR_SHOWN.equals("paste") && !mainActivity.TOOLBAR_SHOWN.equals("extract"))
		{
			mainActivity.actionmode_toolbar.setVisibility(View.VISIBLE);
			mainActivity.paste_toolbar.setVisibility(View.GONE);
			mainActivity.bottom_toolbar.setVisibility(View.GONE);
			mainActivity.TOOLBAR_SHOWN="actionmode";
		}
	}
	
	public void deselectAll()
	{
		mainActivity.actionmode_finish(df.getTag());
		notifyDataSetChanged();
		
	}
	

	private  String getFileSize(File f, boolean archive_view)
	{
		if(f.isDirectory())
		{
			if(f.list()!=null)
			{
				return ((Integer)f.list().length).toString()+ " Item";
			}
			else
			{
				return "";
			}

		}
		else
		{

			long file_size=0L;
			file_size=f.length();

			if(archive_view)
			{
				ZipFile zipfile=null;
				try
				{
					zipfile=new ZipFile(MainActivity.ZIP_FILE);
				}
				catch(IOException e){}
				ZipEntry zip_entry=zipfile.getEntry(f.getAbsolutePath().substring(MainActivity.ARCHIVE_CACHE_DIR_LENGTH+1));
				if(zip_entry!=null)
				{
					file_size=zip_entry.getSize();
				}
			}

			return FileUtil.humanReadableByteCount(file_size,false);

		}
	}
	
	
	interface CardViewClickListener
	{
		public void onClick(int position, View view, File f, String name);
		public void onLongClick(int position, View view);
	}
	
	
	public void setCardViewClickListener(CardViewClickListener listner)
	{
		this.cardViewClickListener=listner;
	}
	
	
	private void print(String msg)
	{
		Toast.makeText(context,msg,Toast.LENGTH_SHORT).show();
	}
	
}
