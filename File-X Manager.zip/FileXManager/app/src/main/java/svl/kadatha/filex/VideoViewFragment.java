package svl.kadatha.filex;
import android.support.v4.app.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import android.content.*;
import android.media.*;
import android.graphics.*;
import android.util.*;

public class VideoViewFragment extends Fragment 
{
	private View v;
	private CustomVideoView video_view;
	private MediaController mediacontroller;
	private MediaPlayer mediaPlayer;
	private int position=0;
	private Context context;
	private String file_path;
	private Integer idx;
	private boolean prepared,wasPlaying,completed,firststart;
	private VideoViewClickListener videoViewClickListener;
	private VideoPositionListener videoPositionListener;
	
	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		// TODO: Implement this method
		super.onCreate(savedInstanceState);
		Bundle bundle=getArguments();
		file_path=bundle.getString("file_path");
		position=bundle.getInt("position");
		idx=bundle.getInt("idx");
		firststart=bundle.getBoolean("firststart");
		setRetainInstance(true);
		
		
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
	{
		// TODO: Implement this method
		context=getContext();
		v=inflater.inflate(R.layout.fragment_video_view,container,false);
		video_view=v.findViewById(R.id.video_view);
		video_view.set_whether_firststart(firststart ? true : wasPlaying);
		
		video_view.setPlayPauseListener(new CustomVideoView.PlayPauseStopListener()
		{
			public void onPlay()
			{
				
			}
			
			public void onPause()
			{
				
			}
			
			public void onStopPlayback()
			{
				
				prepared=false;
			}
			
			public void onFocusLost()
			{
				
			}
			
			public void onFocusGain()
			{
				
			}
		});
		
		mediacontroller=new MediaController(context)
		{
			
			@Override
			public boolean dispatchKeyEvent(KeyEvent event)
			{
				if(event.getKeyCode()==KeyEvent.KEYCODE_BACK)
				{
					((VideoViewActivity)context).finish();
					return true;
				}
				return super.dispatchKeyEvent(event);
			}
			
		};
		
		video_view.setMediaController(mediacontroller);
		mediacontroller.setAnchorView(v);
		
		if(file_path!=null && !file_path.equals(""))
		{
			video_view.setVideoPath(file_path);
		}
		else if(context!=null)
		{
			video_view.setVideoURI(((VideoViewActivity)context).data);

		}
		
		video_view.setOnPreparedListener(new MediaPlayer.OnPreparedListener()
		{

			public void onPrepared(MediaPlayer mp)
			{
					
						prepared=true;
						
						video_view.seekTo(Math.max(position,50));
						
						if(firststart || wasPlaying )
						{
							video_view.start();
						}
						firststart=false;
						wasPlaying=false;
				
				 mp.setOnVideoSizeChangedListener(new MediaPlayer.OnVideoSizeChangedListener()
				 {
				 	public void onVideoSizeChanged(MediaPlayer mp, int p2, int p3)
				 	{

						
					 }
				 });
				 


			}
		});
		
		video_view.setOnCompletionListener(new MediaPlayer.OnCompletionListener()
		{
			
			public void onCompletion(MediaPlayer mp)
			{
				completed=true;
				mp.setOnVideoSizeChangedListener(new MediaPlayer.OnVideoSizeChangedListener()
				{
					public void onVideoSizeChanged(MediaPlayer mp, int p2, int p3)
					{
					
						mediacontroller.setAnchorView(video_view);
					}
				});
			}
		});

		video_view.setOnErrorListener(new MediaPlayer.OnErrorListener()
		{

			public boolean onError(MediaPlayer mp,int p2, int p3)
			{
				prepared=false;
				return true;
			}
		});
		
		v.setOnClickListener(new View.OnClickListener()
		{
				public void onClick(View vi)
				{
					
					if(videoViewClickListener!=null)
					{
						videoViewClickListener.onVideoViewClick();
					}
					
					if(mediacontroller.getVisibility()==View.GONE)
					{
						mediacontroller.setVisibility(View.VISIBLE);
						mediacontroller.show();
					}
					else
					{
						//mediacontroller.setVisibility(View.GONE);
						//mediacontroller.hide();
					}
					
					
				
				}
		});
		
		
		
		video_view.setOnFocusChangeListener(new View.OnFocusChangeListener()
		{
			public void onFocusChange(View vi, boolean hasFocus)
			{
				if(hasFocus)
				{
/*
					if(file_path!=null && !file_path.equals(""))
					{
						video_view.setVideoPath(file_path);
					}
					else if(context!=null)
					{
						video_view.setVideoURI(((VideoViewActivity)context).data);
						
					}
					*/
					mediacontroller.setVisibility(View.VISIBLE);
					
				}
				else
				{
	
					
					
					mediacontroller.setVisibility(View.GONE);
				}
			}
		});
		
			
		return v;
	}

	
	public static VideoViewFragment getNewInstance(String file_path,Integer position, Integer idx,boolean firststart)
	{
		VideoViewFragment frag=new VideoViewFragment();
		Bundle bundle=new Bundle();
		bundle.putString("file_path",file_path);
		bundle.putInt("position",position);
		bundle.putInt("idx",idx);
		bundle.putBoolean("firststart",firststart);
		
		frag.setArguments(bundle);
		return frag;
	}



	@Override
	public void setUserVisibleHint(boolean isVisibleToUser)
	{
		// TODO: Implement this method
		super.setUserVisibleHint(isVisibleToUser);
		if(isVisibleToUser)
		{
			if(file_path!=null && !file_path.equals(""))
			{
				video_view.setVideoPath(file_path);
			}
			else if(context!=null)
			{
				video_view.setVideoURI(((VideoViewActivity)context).data);

			}
			
		}
		else
		{
	
			if(video_view!=null)
			{
			
				mediacontroller.setVisibility(View.GONE);
				position=video_view.getCurrentPosition();
				video_view.stopPlayback();
				videoPositionListener.setPosition(idx,position);
				prepared=false;
			}
		}
	}

	

	@Override
	public void onSaveInstanceState(Bundle outState)
	{
		// TODO: Implement this method
		super.onSaveInstanceState(outState);
		if(video_view.isPlaying())
		{
			wasPlaying=true;
		}
		if(prepared)
		{
	
			position=video_view.getCurrentPosition();
			video_view.stopPlayback();
		}

	}
	


	@Override
	public void onDestroy()
	{
		// TODO: Implement this method
		video_view.stopPlayback();
		prepared=false;
		super.onDestroy();
		
	}

interface VideoViewClickListener
{
	public void onVideoViewClick();
}

public void setVideoViewClickListener(VideoViewClickListener listener)
{
	videoViewClickListener=listener;
}

interface VideoPositionListener
{
	public void setPosition(Integer idx, Integer positiin);
}

public void setVideoPositionListener(VideoPositionListener listener)
{
	videoPositionListener=listener;
}

	



	
	
	private void print(String msg)
	{
		Toast.makeText(context,msg,Toast.LENGTH_SHORT).show();
	}
}
