package svl.kadatha.filex;
import android.os.*;
import android.view.*;
import android.graphics.drawable.*;
import android.graphics.*;
import android.widget.SearchView.*;

public class ProgressBarFragment extends android.support.v4.app.DialogFragment
{

	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		// TODO: Implement this method
		super.onCreate(savedInstanceState);
		setRetainInstance(true);
		setCancelable(false);

	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
	{
		// TODO: Implement this method
		
		
		return inflater.inflate(R.layout.fragment_progressbar,container,false);
	}

	@Override
	public void onResume()
	{
		// TODO: Implement this method
		super.onResume();
		Window w=getDialog().getWindow();
		w.clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
		w.setLayout(Global.DIALOG_WIDTH,LayoutParams.WRAP_CONTENT);
		w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
		
	}
	@Override
	public void onDestroyView() 
	{
		if (getDialog() != null && getRetainInstance()) 
		{
			getDialog().setDismissMessage(null);
		}
		super.onDestroyView();
	}
	
	
	
	
}
