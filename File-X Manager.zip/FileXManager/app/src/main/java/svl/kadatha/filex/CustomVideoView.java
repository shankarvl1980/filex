package svl.kadatha.filex;
import android.widget.*;
import android.content.*;
import android.util.*;
import android.media.*;
import android.view.*;

public class CustomVideoView extends VideoView implements AudioManager.OnAudioFocusChangeListener
{
	private PlayPauseStopListener mListener;
	private AudioManager audio_manager;
	private Context context;
	private boolean firststart;
	public CustomVideoView(Context context) 
	{
		super(context);
		this.context=context;
	
		init();
		
	}

	public CustomVideoView(Context context, AttributeSet attrs) 
	{
		super(context, attrs);
		this.context=context;

		init();
		
	}

	public CustomVideoView(Context context, AttributeSet attrs, int defStyle) 
	{
		super(context, attrs, defStyle);
		this.context=context;
	
		init();
	}
	
	private void init()
	{
		audio_manager=(AudioManager)context.getSystemService(Context.AUDIO_SERVICE);
	}
	
	public void set_whether_firststart(boolean firststart)
	{
		this.firststart=firststart;
	}

	public void setPlayPauseListener(PlayPauseStopListener listener) 
	{
		mListener = listener;
	}

	@Override
	public void pause() 
	{
		super.pause();
		removeAudioFocus();
		if (mListener != null) 
		{
			mListener.onPause();
		}
	}

	@Override
	public void start() 
	{
		if(request_focus())
		{
			super.start();
			if (mListener != null) 
			{
				mListener.onPlay();
			}
		}

	}
	
	@Override
	public void stopPlayback()
	{
		// TODO: Implement this method
		super.stopPlayback();
		if(mListener!=null)
		{
			mListener.onStopPlayback();
		}
	}

	@Override
	public boolean dispatchKeyEvent(KeyEvent event)
	{
		// TODO: Implement this method
		if(event.getKeyCode()==KeyEvent.KEYCODE_BACK)
		{
			((VideoViewActivity)context).finish();
			return true;
		}
		return super.dispatchKeyEvent(event);
	}

	
	interface PlayPauseStopListener 
	{
		void onPlay();
		void onPause();
		void onStopPlayback();
		void onFocusLost();
		void onFocusGain();
	}


	private boolean request_focus()
	{
		
		
		
		int result =audio_manager.requestAudioFocus(this,AudioManager.STREAM_MUSIC,AudioManager.AUDIOFOCUS_GAIN);
		if(result==AudioManager.AUDIOFOCUS_REQUEST_GRANTED)
		{
			return true;
		}
		else
		{
			return false;

		}
	}

	private boolean removeAudioFocus()
	{
		return AudioManager.AUDIOFOCUS_REQUEST_GRANTED==audio_manager.abandonAudioFocus(this);
	}
	
	@Override
	public void onAudioFocusChange(int focusState)
	{
		// TODO: Implement this method
		switch(focusState)
		{
			case AudioManager.AUDIOFOCUS_GAIN:
				/*
				 if(MP!=null)
				 {
				 MP.setVolume(1f,1f);
				 }
				 */
				if(mListener!=null)
				{
					mListener.onFocusGain();
				}
				
				break;



			case AudioManager.AUDIOFOCUS_LOSS:
				if(mListener!=null)
				{
					mListener.onFocusLost();
				}
				
				if(!firststart)
				{
					pause();
				}
				firststart=false;
				break;

			case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT:
				pause();
				break;
			case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK:
				/*
				 if(MP!=null)
				 {
				 MP.setVolume(0.2f,0.2f);
				 }
				 */
				break;

		}

	}
	

}


	
	
