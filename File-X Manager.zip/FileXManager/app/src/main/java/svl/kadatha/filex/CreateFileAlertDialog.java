package svl.kadatha.filex;
import android.content.*;
import android.support.v7.app.AlertDialog;
import android.widget.*;

import java.io.*;
import android.app.*;
import android.view.*;
import android.animation.*;
import android.view.animation.*;
import android.support.v7.widget.*;
import java.util.*;
import android.os.*;
import android.view.View.*;
import android.widget.AdapterView.*;
import android.graphics.drawable.*;
import android.graphics.*;

public class CreateFileAlertDialog extends android.support.v4.app.DialogFragment
{

	private final String [] type_file={"File","Folder"};
	private	Context context;
	private Button close_button;
	private ListView file_folder_listview;
	private ViewGroup buttons_layout;
	
	
	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		// TODO: Implement this method
		super.onCreate(savedInstanceState);
		this.setRetainInstance(true);
	
	}

	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
	{
		
		context=getContext();
		View v=inflater.inflate(R.layout.fragment_create_file,container,false);
		file_folder_listview=v.findViewById(R.id.file_type_ListView);
		buttons_layout=v.findViewById(R.id.fragment_create_file_button_layout);
		buttons_layout.addView(new EquallyDistributedChildrenLayout(context,1));
		close_button=buttons_layout.findViewById(R.id.first_button);
		close_button.setText("Close");
		ArrayAdapter<String>adater=new ArrayAdapter<>(context,android.R.layout.simple_list_item_1,type_file);
		file_folder_listview.setAdapter(adater);
		file_folder_listview.setOnItemClickListener(new AdapterView.OnItemClickListener()
			{
				public void onItemClick(AdapterView<?> p1, View p2,int p3,long p4)
				{
					
					CreateFileDialog createFileDialig=new CreateFileDialog();
					Bundle bundle=new Bundle();
					bundle.putInt("file_type",p3);
					createFileDialig.setArguments(bundle);
					createFileDialig.show(MainActivity.FM,null);
					dismissAllowingStateLoss();
				}


			});
			
		close_button.setOnClickListener(new View.OnClickListener()
		{
			
			public void onClick(View v)
			{
				dismissAllowingStateLoss();
			}
		});
		
		return v;
		
	}

	@Override
	public void onResume()
	{
		// TODO: Implement this method
		super.onResume();
		Window window=getDialog().getWindow();
		window.setLayout(Global.DIALOG_WIDTH,LayoutParams.WRAP_CONTENT);
		window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
	}


	
	
	@Override
	public void onDestroyView() {
		if (getDialog() != null && getRetainInstance()) {
			getDialog().setDismissMessage(null);
		}
		super.onDestroyView();
	}
	
	
	
	private void setAnimation(View v)
	{
		Animation animation=AnimationUtils.loadAnimation(context,android.R.anim.slide_out_right);
		v.setAnimation(animation);
	}
	
	
}
