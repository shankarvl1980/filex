package svl.kadatha.filex;

public class SpacePOJO
{
	
	private String path;
	
	private long total_space;
	private long used_space;
	private long available_space;
	
	private String total_space_readable;
	private String used_space_readable;
	
	
	
	SpacePOJO(String path,long total_space,long available_space)
	{
		this.path=path;
		this.total_space=total_space;
		this.available_space=available_space;
		this.used_space=this.total_space-this.available_space;
		
		this.total_space_readable=FileUtil.humanReadableByteCount(this.total_space,false);
		this.used_space_readable=FileUtil.humanReadableByteCount(this.used_space,false);
	}
	
	public void putAvailableSpace(long space)
	{
		this.available_space=space;
		this.used_space=this.total_space-this.available_space;
		this.used_space_readable=FileUtil.humanReadableByteCount(this.used_space,false);
	}
	
	public String getTotalSpaceReadable()
	{
		return this.total_space_readable;
	}
	
	public String getUsedSpaceReadable()
	{
		return this.used_space_readable;
	}
	
	public long getAvailableSpace()
	{
		return this.available_space;
	}
}
