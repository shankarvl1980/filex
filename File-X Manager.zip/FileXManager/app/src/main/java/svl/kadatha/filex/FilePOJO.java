package svl.kadatha.filex;
import java.io.*;

public class FilePOJO
{
	private File file;
	private String name;
	private String path;
	private String date;
	private String size;
	private Integer type;
	private String ext;
	private int alfa;
	private int overlay_visible;
	
	
	FilePOJO(File f,String n,String p,String d,String s,Integer t,String ext,int a,int o)
	{
		this.file=f;
		this.name=n;
		this.path=p;
		this.date=d;
		this.size=s;
		this.type=t;
		this.ext=ext;
		this.alfa=a;
		this.overlay_visible=o;
		
	}
	
	public void setFile(File f)
	{
		this.file=f;
	}
	
	public void setName(String n)
	{
		this.name=n;
	}
	
	public void setPath(String p)
	{
		this.path=p;
	}
	
	public void setDate(String d)
	{
		this.date=d;
	}
	
	public void setSize(String s)
	{
		this.size=s;
	}
	
	public void setType(Integer t)
	{
		this.type=t;
	}

	public void setExt(String ext)
	{
		this.ext=ext;
	}
	
	public void setAlfa(int alfa)
	{
		this.alfa=alfa;
	}
	
	public void setOverlayVisibility(int overlay_visible)
	{
		this.overlay_visible=overlay_visible;
	}
	
	public File getFile()
	{
		return this.file;
	}

	public String getName()
	{
		return this.name;
	}
	
	public String getPath()
	{
		return this.path;
	}
	
	public String getDate()
	{
		return this.date;
	}

	public String getSize()
	{
		return this.size;
	}

	public Integer getType()
	{
		return this.type;
	}

	public String getExt()
	{
		return this.ext;
	}
	
	public int getAlfa()
	{
		return this.alfa;
	}

	public int getOverlayVisibility()
	{
		return this.overlay_visible;
	}

}
