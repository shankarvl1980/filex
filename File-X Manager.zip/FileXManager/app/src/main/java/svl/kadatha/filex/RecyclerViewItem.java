package svl.kadatha.filex;
import android.widget.*;
import android.content.*;
import android.util.*;
import android.view.*;
import java.io.*;
import android.content.pm.*;
import com.bumptech.glide.*;
import com.bumptech.glide.load.engine.*;
import java.util.zip.*;
import java.text.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;

public class RecyclerViewItem extends ViewGroup
{
	private Context context;
	private View view;
	private ImageView fileimageview,overlay_fileimageview;
	private TextView filenametextview, filesubfilecounttextview, filepermissionstextView,filemoddatetextview;
	private int first_line_font_size,second_line_font_size,imageview_dimension;
	private int totalwidth;
	RecyclerViewItem(Context context)
	{
		super(context);
		this.context=context;
		init();
	}
	
	RecyclerViewItem(Context context, AttributeSet attr)
	{
		super(context,attr);
		this.context=context;
		init();
	}

	RecyclerViewItem(Context context, AttributeSet attr, int defStyle)
	{
		super(context,attr,defStyle);
		this.context=context;
		init();
	}
	
	private void init()
	{
		
		setBackground(context.getResources().getDrawable(R.drawable.select_color));
		
		view=LayoutInflater.from(context).inflate(R.layout.filedetail_recyclerview_layout,this,true);
		fileimageview=view.findViewById(R.id.image_file);
		overlay_fileimageview=view.findViewById(R.id.overlay_image_file);
		filenametextview=view.findViewById(R.id.text_file_name);
		filesubfilecounttextview=view.findViewById(R.id.text_subfile_count);
		//filepermissionstextView=view.findViewById(R.id.text_file_permissions);
		filemoddatetextview=view.findViewById(R.id.text_file_moddate);
		
		
		if(Global.RECYCLER_VIEW_FONT_SIZE_FACTOR==0)
		{
			first_line_font_size=Global.FONT_SIZE_SMALL_FIRST_LINE;
			second_line_font_size=Global.FONT_SIZE_SMALL_DETAILS_LINE;

			imageview_dimension=Global.IMAGEVIEW_DIMENSION_SMALL;

		}
		else if(Global.RECYCLER_VIEW_FONT_SIZE_FACTOR==2)
		{
			first_line_font_size=Global.FONT_SIZE_LARGE_FIRST_LINE;
			second_line_font_size=Global.FONT_SIZE_LARGE_DETAILS_LINE;
			
			imageview_dimension=Global.IMAGEVIEW_DIMENSION_LARGE;
		}
		else
		{
			first_line_font_size=Global.FONT_SIZE_MEDIUM_FIRST_LINE;
			second_line_font_size=Global.FONT_SIZE_MEDIUM_DETAILS_LINE;
			
			imageview_dimension=Global.IMAGEVIEW_DIMENSION_MEDIUM;
		}

		fileimageview.getLayoutParams().width=imageview_dimension;
		fileimageview.getLayoutParams().height=imageview_dimension;
		
		overlay_fileimageview.getLayoutParams().width=imageview_dimension;
		overlay_fileimageview.getLayoutParams().height=imageview_dimension;
		
		filenametextview.setTextSize(first_line_font_size);
		filesubfilecounttextview.setTextSize(second_line_font_size);
		//p1.filepermissionstextView.setTextSize(second_line_font_size);
		filemoddatetextview.setTextSize(second_line_font_size);
		
		
		
	}

	
	@Override
	protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) 
	{
		
		int iconheight,maxHeight=0;
		int usedWidth=MainActivity.RECYCLERVIEWITEM_MARGIN;
		
		if(context.getResources().getBoolean(R.bool.is_land))
		{
			totalwidth=Global.SCREEN_HEIGHT;
		}
		else
		{
			totalwidth=Global.SCREEN_WIDTH;
		}

	
		measureChildWithMargins(fileimageview,widthMeasureSpec,usedWidth,heightMeasureSpec,0);
		measureChildWithMargins(overlay_fileimageview,widthMeasureSpec,usedWidth,heightMeasureSpec,0);
		usedWidth+=fileimageview.getMeasuredWidth();
		iconheight=fileimageview.getMeasuredHeight();
		
		measureChildWithMargins(filenametextview,widthMeasureSpec,usedWidth+MainActivity.RECYCLERVIEWITEM_MARGIN*2,heightMeasureSpec,0);
		maxHeight+=filenametextview.getMeasuredHeight();
	
		measureChildWithMargins(filesubfilecounttextview,widthMeasureSpec,usedWidth,heightMeasureSpec,maxHeight);
		usedWidth+=filesubfilecounttextview.getMeasuredWidth();
		
		measureChildWithMargins(filemoddatetextview,widthMeasureSpec,usedWidth+MainActivity.RECYCLERVIEWITEM_MARGIN*2,heightMeasureSpec,maxHeight);
		usedWidth+=filemoddatetextview.getMeasuredHeight();
		maxHeight+=filemoddatetextview.getMeasuredHeight();
		
		maxHeight=Math.max(iconheight,maxHeight);
		maxHeight+=MainActivity.RECYCLERVIEWITEM_MARGIN*2;
		
		setMeasuredDimension(widthMeasureSpec,maxHeight);
		
	
	}
	
	@Override
	protected void onLayout(boolean p1, int l, int t, int r, int b)
	{
		// TODO: Implement this method
		int layoutpadding=MainActivity.RECYCLERVIEWITEM_MARGIN;
		int x=MainActivity.RECYCLERVIEWITEM_MARGIN,y;
		
		View v=fileimageview;
		y=layoutpadding;
		v.layout(x,y,x+v.getMeasuredWidth(),y+v.getMeasuredHeight());
		
		
		v=overlay_fileimageview;
		v.layout(x,y,x+v.getMeasuredWidth(),y+v.getMeasuredHeight());
		x+=v.getMeasuredWidth()+layoutpadding;
		
		v=filenametextview;
		//y=0;
		v.layout(x,y,x+v.getMeasuredWidth(),y+v.getMeasuredHeight());
		y+=v.getMeasuredHeight();
		

		v=filesubfilecounttextview;
		v.layout(x,y,x+v.getMeasuredWidth(),y+v.getMeasuredHeight());
		x+=v.getMeasuredWidth();

		
		v=filemoddatetextview;
		v.setTextAlignment(View.TEXT_ALIGNMENT_VIEW_END);
		x=Math.max(x,totalwidth/2);
		v.layout(x,y,x+v.getMeasuredWidth(),y+v.getMeasuredHeight());
	
	}
	
	
	@Override
	protected boolean checkLayoutParams(ViewGroup.LayoutParams p) {
		return p instanceof MarginLayoutParams;
	}

	/**
	 * @return A set of default layout parameters when given a child with no layout parameters.
	 */
	@Override
	protected LayoutParams generateDefaultLayoutParams() {
		return new MarginLayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
	}

	/**
	 * @return A set of layout parameters created from attributes passed in XML.
	 */
	@Override
	public LayoutParams generateLayoutParams(AttributeSet attrs) {
		return new MarginLayoutParams(context, attrs);
	}

	/**
	 * Called when {@link #checkLayoutParams(LayoutParams)} fails.
	 *
	 * @return A set of valid layout parameters for this ViewGroup that copies appropriate/valid
	 * attributes from the supplied, not-so-good-parameters.
	 */
	@Override
	protected LayoutParams generateLayoutParams(ViewGroup.LayoutParams p) {
		return generateDefaultLayoutParams();
	}
	
	
	public void setData(File f,String name,String path,String size,String date,Integer type,String ext,int alfa,int overlay_visible)
	{
		
		overlay_fileimageview.setVisibility(overlay_visible);
		fileimageview.setAlpha(alfa);
		
		if(type==null)
		{
			Bitmap bm=MainActivity.APK_ICON_HASHMAP.get(path);
			if(bm!=null)
			{
				fileimageview.setImageBitmap(bm);
			}
			else
			{
				fileimageview.setImageDrawable(context.getDrawable(R.drawable.apk_file_icon));
			}

	
		}
		else if(type==0)
		{
			
			
			Glide.with(context).load(path).placeholder(R.drawable.picture_icon).error(R.drawable.picture_icon).diskCacheStrategy(DiskCacheStrategy.RESULT).dontAnimate().into(fileimageview);
		}
		
		else
		{
		
			Glide.clear(fileimageview);
			fileimageview.setImageDrawable(context.getDrawable( type));

		}
		
		filenametextview.setText(name);
		filesubfilecounttextview.setText(size);
		filemoddatetextview.setText(date);
		

	}
	
	public static void setIcon(Context context,String path ,ImageView fileimageview,ImageView overlay_fileimageview,Integer type,int overlay_visible)
	{
		overlay_fileimageview.setVisibility(overlay_visible);
		if(type==null)
		{
			Bitmap bm=MainActivity.APK_ICON_HASHMAP.get(path);
			if(bm!=null)
			{
				fileimageview.setImageBitmap(bm);
			}
			else
			{
				fileimageview.setImageDrawable(context.getDrawable(R.drawable.apk_file_icon));
			}


		}
		else if(type==0)
		{

			Glide.with(context).load(path).placeholder(R.drawable.picture_icon).error(R.drawable.picture_icon).diskCacheStrategy(DiskCacheStrategy.RESULT).dontAnimate().into(fileimageview);
		}
		else
		{
			Glide.clear(fileimageview);
			fileimageview.setImageDrawable(context.getDrawable( type));

		}

	}
	
}
