package svl.kadatha.filex;
import android.support.v7.app.*;
import android.content.*;
import android.widget.*;
import java.io.*;

import java.util.zip.*;
import java.util.*;
import android.view.*;
import android.support.v4.content.*;
import android.os.*;
import android.transition.*;
import android.support.v4.provider.*;
import android.net.*;
import android.support.v4.app.*;
import android.widget.GridLayout.*;
import android.graphics.drawable.*;
import android.graphics.*;


public class ArchiveSetUpDialog extends android.support.v4.app.DialogFragment
{
	
	private Context context;
	static String FOLDERCLICKSELECTED;
	static int FF_TRANS;
	
	private View zipdialogview;
	
	private TextView dialog_heading,outputfilename;
	private CheckBox create_folder_checkbox;
	
	private EditText zip_file_edittext,customdir_edittext;
	
	private RadioGroup rg;
	private RadioButton rb_current_dir,rb_custom_dir;
	private Button browsebutton,okbutton,cancelbutton;
	private String zip_file_path;
	
	private String type=new String();
	private ArrayList<String> files_selected_array=new ArrayList<>();
	private ArrayList<String> zipentry_selected_array=new ArrayList<>();
	private ViewGroup buttons_layout;
	private DetailFragment df;
	private int request_code=112;
	private boolean permission_requested;
	private String baseFolder="";
	private Uri uri;
	
	ArchiveSetUpDialog(String type)
	{
		this.type=type;
	}

	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		// TODO: Implement this method
		
		super.onCreate(savedInstanceState);
		this.setRetainInstance(true);
		files_selected_array.addAll(getArguments().getStringArrayList("files_selected_array"));
		if(getArguments().getStringArrayList("zipentry_selected_array")!=null)
		{
			zipentry_selected_array.addAll(getArguments().getStringArrayList("zipentry_selected_array"));
		}
		FOLDERCLICKSELECTED=MainActivity.STORAGE_DIR.get(1).getPath();
		
	}
	
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
	{
		// TODO: Implement this method
		zipdialogview=inflater.inflate(R.layout.fragment_archive,container,false);
		return zipdialogview;
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState)
	{
		// TODO: Implement this method
		super.onActivityCreated(savedInstanceState);
		context=getContext();
		
		dialog_heading=zipdialogview.findViewById(R.id.dialog_archive_heading);
		outputfilename=zipdialogview.findViewById(R.id.dialog_archive_outputfilename);
		create_folder_checkbox=zipdialogview.findViewById(R.id.dialog_archive_checkbox);
		
		zip_file_edittext=zipdialogview.findViewById(R.id.dialog_archive_textview_zipname);

		rg=zipdialogview.findViewById(R.id.dialog_archive_rg);
		//rb_zipname_dir=(RadioButton)zipdialogview.findViewById(R.id.dialog_archive_rb_zipname_dir);
		rb_current_dir=zipdialogview.findViewById(R.id.dialog_archive_rb_current_dir);
		rb_custom_dir=zipdialogview.findViewById(R.id.dialog_archive_rb_custom_dir);
		customdir_edittext=zipdialogview.findViewById(R.id.dialog_archive_edittext_customdir);
		browsebutton=zipdialogview.findViewById(R.id.dialog_archive_browse_button);
		buttons_layout=zipdialogview.findViewById(R.id.fragment_archive_button_layout);
		buttons_layout.addView(new EquallyDistributedChildrenLayout(context,2));
		okbutton=zipdialogview.findViewById(R.id.first_button);
		okbutton.setText("OK");
		cancelbutton=zipdialogview.findViewById(R.id.second_button);
		cancelbutton.setText("Cancel");
		browsebutton.setVisibility(View.GONE);
		customdir_edittext.setVisibility(View.GONE);
		rb_current_dir.setText(new File(files_selected_array.get(0)).getParent());
		rb_custom_dir.setText("Choose directory");
		customdir_edittext.setText(FOLDERCLICKSELECTED);
		rg.check(rb_current_dir.getId());
		df=(DetailFragment)MainActivity.FM.findFragmentById(R.id.detail_fragment);
		if(df.fileclickselected.exists() || files_selected_array.size()==1)
		{
			zip_file_path=files_selected_array.get(0);
		}
		else
		{
			zip_file_path="";
		}
		
		create_folder_checkbox.setOnCheckedChangeListener(new CheckBox.OnCheckedChangeListener()
		{
			
			public void onCheckedChanged(CompoundButton p1,boolean p2)
			{
				if(p1.isChecked())
				{
					zip_file_edittext.setEnabled(true);
					zip_file_edittext.setAlpha(255);
				}
				else
				{
					zip_file_edittext.setEnabled(false);
					zip_file_edittext.setAlpha(100);
				}
			}
		});
	
		rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener()
		{
			public void onCheckedChanged(RadioGroup rg,int pos)
			{
				if(rb_custom_dir.isChecked())
				{
					customdir_edittext.setVisibility(View.VISIBLE);
					browsebutton.setVisibility(View.VISIBLE);
					
				}
				else
				{
					customdir_edittext.setVisibility(View.GONE);
					browsebutton.setVisibility(View.GONE);
				}
			}
		});
		
		browsebutton.setOnClickListener(new View.OnClickListener()
		{
			public void onClick(View v)
			{
				if(rb_custom_dir.isChecked())
				{
					createFileSelectorFragmentTransaction(MainActivity.FM,"");
					int i=MainActivity.FM.getBackStackEntryCount();
					FF_TRANS=MainActivity.FM.getBackStackEntryAt(i-1).getId();

				}

			}


		});
		
		FileSelectorDialog.fileSelectorListener=new FileSelectorDialog.FileSelectorListener()
		{
			public void file_selected(String action)
			{
				if(action.equals("ok"))
				{
					customdir_edittext.setText(FOLDERCLICKSELECTED);
				}
				MainActivity.FM.popBackStack(FF_TRANS,0);
			}
		};
		
		switch(type)
		{
			
			case "zip":
			{
				create_folder_checkbox.setVisibility(View.GONE);
				dialog_heading.setText("Archive");
				outputfilename.setText("Output file:");
				if(files_selected_array.size()==1)
				{
					zip_file_edittext.setText(new File(files_selected_array.get(0)).getName());
				}
				else
				{
					zip_file_edittext.setText(new File(files_selected_array.get(0)).getParentFile().getName());
				}
				zip_file_edittext.setSelection(zip_file_edittext.getText().length());
				
				//rb_zipname_dir.setVisibility(View.GONE);
				okbutton.setOnClickListener(new View.OnClickListener()
					{
						public void onClick(View v)
						{
							
							String zip_file_name=zip_file_edittext.getText().toString().trim();

							if(zip_file_name.equals("") || zip_file_name.equals(null))
							{
								print("Enter zip file name");
								return;
							}
							if(CheckStringForSpecialCharacters.whetherStringContains(zip_file_name))
							{
								print("Avoid name involving characters '\\*:?/'");
								return;
							}
							
							
							String archivedestfolder=rb_current_dir.isChecked() ? rb_current_dir.getText().toString().trim() : customdir_edittext.getText().toString().trim();
							/*
							 if((archivedestfolder+File.separator).startsWith(files_selected_array.get(0)+File.separator))
							 {
							 print("Archive file cannot be in the subfolder of files selected for archive");
							 return;
							 }

							 */
							
							File f=new File(archivedestfolder,zip_file_name);
							if(!FileUtil.isWritable(f))
							{
								
								for(Map.Entry<Uri,String> entry : Global.URI_STRING_HASHMAP.entrySet())
								{
									if(archivedestfolder.startsWith(entry.getValue()))
									{
										baseFolder=entry.getValue();
										uri=entry.getKey();
										break;
									}
								}


								if(baseFolder.equals(""))
								{
									
									permission_requested=true;
									SAFPermissionHelperDialog safpermissionhelper=new SAFPermissionHelperDialog();
									safpermissionhelper.set_safpermissionhelperlistener(new SAFPermissionHelperDialog.SafPermissionHelperListener()
										{
											public void onOKBtnClicked()
											{
												checkSAFPermission();
											}

											public void onCancelBtnClicked()
											{
												dismissAllowingStateLoss();
											}
										});
									safpermissionhelper.show(MainActivity.FM,"saf_permission_dialog");
									return;
								}
							
							}
							
							final Class emptyService=MainActivity.getEmptyService();
							if(emptyService==null)
							{
								print("Maximum 3 services only be processed at a time");
								return;
							}
							final Bundle bundle=new Bundle();
							bundle.putStringArrayList("files_selected_array",files_selected_array);
							bundle.putString("dest_folder",archivedestfolder);
							bundle.putString("zip_file_path",zip_file_path);
							bundle.putString("zip_file_name",zip_file_name);
							bundle.putString("action",type);
							bundle.putString("baseFolder",baseFolder);
							bundle.putParcelable("uri",uri);
							zip_file_name=zip_file_name+".zip";
							if(rb_current_dir.isChecked() && !zip_file_edittext.getText().toString().trim().equals(""))
							{
								
								
								if(Arrays.asList(new File(rb_current_dir.getText().toString().trim()).list()).contains(zip_file_name))
								{
									if(!new File(rb_current_dir.getText().toString().trim(),zip_file_name).isDirectory())
									{
										ArchiveReplaceConfirmationDialog archiveReplaceConfirmationDialog=new ArchiveReplaceConfirmationDialog();
										archiveReplaceConfirmationDialog.setArchiveReplaceDialogListener(new ArchiveReplaceConfirmationDialog.ArchiveReplaceDialogListener()
											{
												public void onYes()
												{
													Intent intent=new Intent(context,emptyService);
													intent.setAction("archive-zip");
													intent.putExtra("bundle",bundle);
													context.startActivity(intent);
													dismissAllowingStateLoss();
												}
											});
										archiveReplaceConfirmationDialog.setArguments(bundle);
										archiveReplaceConfirmationDialog.show(MainActivity.FM,null);
										
									}
									else
									{
										print("A directory with output file name already exists. '"+zip_file_name+"'");
									}
								
								}
								else
								{
								
									Intent intent=new Intent(context,emptyService);
									intent.setAction("archive-zip");
									intent.putExtra("bundle",bundle);
									context.startActivity(intent);
									dismissAllowingStateLoss();
									
								}
								
							}
						
							else if(rb_custom_dir.isChecked() && !zip_file_edittext.getText().toString().trim().equals(""))
							{
								if(new File(customdir_edittext.getText().toString().trim()).exists())
								{
									
									if(Arrays.asList(new File(customdir_edittext.getText().toString().trim()).list()).contains(zip_file_name))
									{
								
										if(!new File(customdir_edittext.getText().toString().trim(),zip_file_name).isDirectory())
										{
											ArchiveReplaceConfirmationDialog archiveReplaceConfirmationDialog=new ArchiveReplaceConfirmationDialog();
											archiveReplaceConfirmationDialog.setArchiveReplaceDialogListener(new ArchiveReplaceConfirmationDialog.ArchiveReplaceDialogListener()
											{
												public void onYes()
												{
													Intent intent=new Intent(context,emptyService);
													intent.setAction("archive-zip");
													intent.putExtra("bundle",bundle);
													context.startActivity(intent);
													dismissAllowingStateLoss();
												}
											});
											archiveReplaceConfirmationDialog.setArguments(bundle);
											archiveReplaceConfirmationDialog.show(MainActivity.FM,null);
										}
										else
										{
											print("A directory with output file name already exists. '"+zip_file_name+"'");
										}
										
									}
									else
									{


										Intent intent=new Intent(context,emptyService);
										intent.setAction("archive-zip");
										intent.putExtra("bundle",bundle);
										context.startActivity(intent);
										dismissAllowingStateLoss();
									}
									
								}
								else
								{

									print("Directory mentioned does not exist or not valid");
								}

							}
						
						}

					});
					break;
			}
			
			case "unzip":
			{
				
				dialog_heading.setText("Extract");
				outputfilename.setText("Output folder:");
				zip_file_edittext.setText(new File(files_selected_array.get(0)).getName().replace(".zip",""));
				zip_file_edittext.setSelection(zip_file_edittext.getText().length());
				okbutton.setOnClickListener(new View.OnClickListener()
					{

						public void onClick(View v)
						{
							String zip_output_folder=zip_file_edittext.getText().toString().trim();
					
							final Class emptyService=MainActivity.getEmptyService();
							if(emptyService==null)
							{
								print("Maximum 3 services only be processed at a time");
								return;
							}
							final Bundle bundle=new Bundle();
							bundle.putStringArrayList("files_selected_array",files_selected_array);
							bundle.putStringArrayList("zipentry_selected_array",zipentry_selected_array);
							bundle.putString("zip_file_path",zip_file_path);
							bundle.putString("action",type);
							bundle.putBoolean("archive_view",false);
							
							
							if(rb_current_dir.isChecked())
							{
								bundle.putString("dest_folder", rb_current_dir.getText().toString().trim());
								bundle.putString("zip_file_name",zip_output_folder);
								if(create_folder_checkbox.isChecked())
								{

									if(zip_output_folder.equals("")|| zip_output_folder.equals(null))
									{
										print("Enter output folder name");
										return;
									}

									if(CheckStringForSpecialCharacters.whetherStringContains(zip_output_folder))
									{
										print("Avoid name involving characters '\\*:?/'");
										return;
									}
									
									check_file_writable(new File(rb_current_dir.getText().toString().trim(),zip_output_folder));
									
									
									bundle.putString("baseFolder",baseFolder);
									bundle.putParcelable("uri",uri);
									if(Arrays.asList(new File(rb_current_dir.getText().toString()).list()).contains(zip_output_folder))
									{
										
										if(new File(rb_current_dir.getText().toString(),zip_output_folder).isDirectory())
										{
											ArchiveReplaceConfirmationDialog archiveReplaceConfirmationDialog=new ArchiveReplaceConfirmationDialog();
											archiveReplaceConfirmationDialog.setArchiveReplaceDialogListener(new ArchiveReplaceConfirmationDialog.ArchiveReplaceDialogListener()
												{
													public void onYes()
													{
														Intent intent=new Intent(context,emptyService);
														intent.setAction("archive-unzip");
														intent.putExtra("bundle",bundle);
														context.startActivity(intent);
														dismissAllowingStateLoss();
													}
												});
											archiveReplaceConfirmationDialog.setArguments(bundle);
											archiveReplaceConfirmationDialog.show(MainActivity.FM,null);
										}
										else
										{
											print("A file with output folder name already exists.");
										}
											
										return;
									}
									
									
									Intent intent=new Intent(context,emptyService);
									intent.setAction("archive-unzip");
									intent.putExtra("bundle",bundle);
									context.startActivity(intent);
									dismissAllowingStateLoss();
								
								}
								else
									
								{
									check_file_writable(new File(rb_current_dir.getText().toString().trim()));
									
									
									bundle.putString("baseFolder",baseFolder);
									bundle.putParcelable("uri",uri);
									bundle.putString("zip_file_name",null);
									
									
									Intent intent=new Intent(context,emptyService);
									intent.setAction("archive-unzip");
									intent.putExtra("bundle",bundle);
									context.startActivity(intent);
									dismissAllowingStateLoss();
									
								}

							}
							else if(rb_custom_dir.isChecked())
							{
								
								if(new File(customdir_edittext.getText().toString().trim()).exists())
								{
									
									bundle.putString("dest_folder", customdir_edittext.getText().toString().trim());
									bundle.putString("zip_file_name",zip_output_folder);

									if(create_folder_checkbox.isChecked())
									{
										
										if(zip_output_folder.equals("")|| zip_output_folder.equals(null))
										{
											print("Enter output folder name");
											return;
										}

										if(CheckStringForSpecialCharacters.whetherStringContains(zip_output_folder))
										{
											print("Avoid name involving characters '\\*:?/'");
											return;
										}
										
										check_file_writable(new File(customdir_edittext.getText().toString().trim(),zip_output_folder));
										bundle.putString("baseFolder",baseFolder);
										bundle.putParcelable("uri",uri);
										if(Arrays.asList(new File(customdir_edittext.getText().toString()).list()).contains(zip_output_folder))
										{
											
											if(new File(customdir_edittext.toString(),zip_output_folder).isDirectory())
											{
												ArchiveReplaceConfirmationDialog archiveReplaceConfirmationDialog=new ArchiveReplaceConfirmationDialog();
												archiveReplaceConfirmationDialog.setArchiveReplaceDialogListener(new ArchiveReplaceConfirmationDialog.ArchiveReplaceDialogListener()
													{
														public void onYes()
														{
															Intent intent=new Intent(context,emptyService);
															intent.setAction("archive-unzip");
															intent.putExtra("bundle",bundle);
															context.startActivity(intent);
															dismissAllowingStateLoss();
														}
													});
												archiveReplaceConfirmationDialog.setArguments(bundle);
												archiveReplaceConfirmationDialog.show(MainActivity.FM,null);
												
											}
											else
											{
												print("A file with output folder name already exists in the selected directory.");
											}
											
											return;
										}
								
										
										Intent intent=new Intent(context,emptyService);
										intent.setAction("archive-unzip");
										intent.putExtra("bundle",bundle);
										context.startActivity(intent);
										dismissAllowingStateLoss();
										
									}
									else
									{
										check_file_writable(new File(customdir_edittext.getText().toString().trim()));
										
										bundle.putString("baseFolder",baseFolder);
										bundle.putParcelable("uri",uri);
										bundle.putString("zip_file_name",null);
										
										
										Intent intent=new Intent(context,emptyService);
										intent.setAction("archive-unzip");
										intent.putExtra("bundle",bundle);
										context.startActivity(intent);
										dismissAllowingStateLoss();

									}
								}
								else
								{
									print("Directory mentioned does not exist or valid");
								}
								
							}
						}
					});
					break;
				
			}
			
		}
		
		cancelbutton.setOnClickListener(new View.OnClickListener()
		{
			public void onClick(View v)
			{
				dismissAllowingStateLoss();
			}
			
		});
		
	}

	private void check_file_writable(File f)
	{
		boolean isWritable=false;
		isWritable=FileUtil.isWritable(f);
		if(!isWritable)
		{
			for(Map.Entry<Uri,String> entry : Global.URI_STRING_HASHMAP.entrySet())
			{
				if(f.getAbsolutePath().startsWith(entry.getValue()))
				{
					baseFolder=entry.getValue();
					uri=entry.getKey();
					break;
				}
			}


			if(baseFolder.equals(""))
			{

				permission_requested=true;
				SAFPermissionHelperDialog safpermissionhelper=new SAFPermissionHelperDialog();
				safpermissionhelper.set_safpermissionhelperlistener(new SAFPermissionHelperDialog.SafPermissionHelperListener()
					{
						public void onOKBtnClicked()
						{
							checkSAFPermission();
						}

						public void onCancelBtnClicked()
						{
							dismissAllowingStateLoss();
						}
					});
				safpermissionhelper.show(MainActivity.FM,"saf_permission_dialog");
				return;
			}

		}
	}
	
	
	@Override
	public void onResume()
	{
		// TODO: Implement this method
		super.onResume();
		Window window=getDialog().getWindow();
		window.setLayout(Global.DIALOG_WIDTH,LayoutParams.WRAP_CONTENT);
		window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
		
	}

	
	@Override
	public void onDestroyView() {
		if (getDialog() != null && getRetainInstance()) {
			getDialog().setDismissMessage(null);
		}
		super.onDestroyView();
		
	}
	

	public void checkSAFPermission()
	{
		Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
		startActivityForResult(intent, request_code);

	}


	// @TargetApi(Build.VERSION_CODES.LOLLIPOP)
	@Override
	public final void onActivityResult(final int requestCode, final int resultCode, final Intent resultData) 
	{

		if (requestCode == this.request_code && resultCode==getActivity().RESULT_OK) 
		{
			Uri treeUri = null;
			// Get Uri from Storage Access Framework.
			treeUri = resultData.getData();
			String uri_file_path=FileUtil.getFullPathFromTreeUri(treeUri,context);
			Iterator<Map.Entry<Uri,String>> iterator=Global.URI_STRING_HASHMAP.entrySet().iterator();
			while(iterator.hasNext())
			{
				Map.Entry<Uri,String> entry=iterator.next();
				if(entry.getValue().startsWith(uri_file_path))
				{
			
					iterator.remove();
				}
			}


			Global.URI_STRING_HASHMAP.put(treeUri,uri_file_path);


			// Persist access permissions.
			final int takeFlags = resultData.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
			context.getContentResolver().takePersistableUriPermission(treeUri, takeFlags);
			
			permission_requested=false;
			okbutton.callOnClick();
			
		}
		else
		{
			cancelbutton.callOnClick();
		}

	}
	
	
	
	static void createFileSelectorFragmentTransaction(final android.support.v4.app.FragmentManager fm,String file_clicked)
	{
		if(new File(file_clicked).isDirectory() || file_clicked.equals(""))
		{
			FileSelectorDialog ff=new FileSelectorDialog();
			
			android.support.v4.app.FragmentTransaction ft=fm.beginTransaction();
			ft.addToBackStack(file_clicked);
			ft.setTransition(android.support.v4.app.FragmentTransaction.TRANSIT_FRAGMENT_FADE);
			ff.show(ft,file_clicked);
		}

	}
	
	
	private void print(String msg)
	{

		android.widget.Toast.makeText(context,msg,android.widget.Toast.LENGTH_SHORT).show();
	}
	
}
