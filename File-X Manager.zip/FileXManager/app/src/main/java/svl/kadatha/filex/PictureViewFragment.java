package svl.kadatha.filex;
import android.content.*;
import android.graphics.*;
import android.os.*;
import android.support.v4.app.*;
import android.support.v4.view.*;
import android.support.v7.widget.*;
import android.util.*;
import android.view.*;
import android.view.animation.*;
import android.widget.*;
import com.bumptech.glide.*;
import com.bumptech.glide.load.engine.*;
import java.io.*;
import java.util.*;
import android.net.*;
import android.support.v4.content.*;
import android.support.design.widget.*;


public class PictureViewFragment extends Fragment
{

	private ViewPager view_pager;
	private Context context;
	private ImageViewPagerAdapter image_view_adapter;
	private int file_selected_idx=0;
	private RecyclerView recyclerview;
	private android.support.v7.widget.Toolbar toolbar;
	private LinearLayoutManager lm;
	private PictureSelectorAdapter picture_selector_adapter;
	private List<File> album_list;
	private SparseBooleanArray selected_item_sparseboolean;
	private int recyclerview_image_width,preview_image_offset;
	private Handler handler;
	private Runnable runnable;
	private boolean is_menu_opened;
	private android.support.v7.widget.ListPopupWindow listPopWindow;
	private ArrayList<ListPopupWindowPOJO> list_popupwindowpojos;
	private TextView title;
	private ImageView overflow;
	private File currently_shown_file;
	private final int delay=4000;
	private List<File> files_selected_for_delete;
	private List<File> deleted_files;
	private boolean permission_requested;
	private String baseFolder="";
	private Uri uri;
	private final int saf_request_code=234;
	private final int crop_request_code=890;
	private DeleteFileAsyncTask delete_file_async_task;
	private boolean asynctask_running;
	private String file_path;
	private Uri data;
	private ProgressBarFragment pbf;
	private LocalBroadcastManager localBroadcastManager;
	private int floating_button_height;
	private FloatingActionButton floating_back_button;
	

	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		// TODO: Implement this method
		super.onCreate(savedInstanceState);
		setRetainInstance(true);
		context=getContext();
		data=((PictureViewActivity)getContext()).data;
		Bundle bundle=getArguments();
		file_path=bundle.getString("file_path");

		currently_shown_file=new File(file_path);
		
		album_list=new ArrayList<>();
		File album_dir=currently_shown_file.getParentFile();
		if(album_dir!=null && album_dir.list()!=null)
		{
			
			File [] sub_files=album_dir.listFiles();
			pbf=new ProgressBarFragment();
			pbf.show(((PictureViewActivity)context).fm,"");
			int size=sub_files.length;
			for(int i=0; i<size;i++)
			{
				if(!sub_files[i].isDirectory())
				{
					String file_name=sub_files[i].getName();
					String file_ext="";
					int idx=file_name.lastIndexOf(".");
					if(idx!=-1)
					{
						file_ext=file_name.substring(idx+1);
						if(file_ext.matches(Global.IMAGE_REGEX))
						{
							album_list.add(sub_files[i]);
						}
						else if(file_name.equals(currently_shown_file.getName()))
						{
							album_list.add(currently_shown_file);
						}
					
					}
					else if(file_name.equals(currently_shown_file.getName()))
					{
						album_list.add(currently_shown_file);
					}

				}
			}
			
			pbf.dismissAllowingStateLoss();

		}
		else
		{
			album_list.add(currently_shown_file);
	
		}
		
		Collections.sort(album_list,FileComparator.FileComparate(Global.SORT));
		file_selected_idx=album_list.indexOf(currently_shown_file);
		
		list_popupwindowpojos=new ArrayList<>();
		list_popupwindowpojos.add(new ListPopupWindowPOJO(R.drawable.delete_icon,"Delete"));
		list_popupwindowpojos.add(new ListPopupWindowPOJO(R.drawable.send_icon,"Send"));
		list_popupwindowpojos.add(new ListPopupWindowPOJO(R.drawable.properties_icon,"Properties"));
		list_popupwindowpojos.add(new ListPopupWindowPOJO(R.drawable.properties_icon,"Set as Wallpaper"));
		
		floating_button_height=(int)TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP,146,context.getResources().getDisplayMetrics());
	}
	

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
	{
		// TODO: Implement this method
		context=getContext();
		localBroadcastManager=LocalBroadcastManager.getInstance(context);
		View v=inflater.inflate(R.layout.fragment_picture_view,container,false);
		
		handler=new Handler();
		toolbar=v.findViewById(R.id.activity_picture_toolbar);
		title=v.findViewById(R.id.activity_picture_name);
		overflow=v.findViewById(R.id.activity_picture_overflow);
		overflow.setOnClickListener(new View.OnClickListener()
			{
				public void onClick(View v)
				{
					is_menu_opened=true;
					listPopWindow.show();
				}
			});

		listPopWindow=new android.support.v7.widget.ListPopupWindow(context);
		listPopWindow.setAdapter(new ListPopupWindowArrayAdapter(context,0,list_popupwindowpojos));
		listPopWindow.setAnchorView(overflow);
		listPopWindow.setWidth(getResources().getDimensionPixelSize(R.dimen.list_popupwindow_width));
		listPopWindow.setModal(true);
		listPopWindow.setOnItemClickListener(new AdapterView.OnItemClickListener()
			{
				public void onItemClick(AdapterView<?> adapterview, View v, int p1,long p2)
				{

					final Bundle bundle=new Bundle();
					final ArrayList<String> files_selected_array=new ArrayList<>();

					switch(p1)
					{
						case 0:

							if(!currently_shown_file.exists())
							{
								print("not able to process");
								break;
							}
							DeleteFileAlertDialogOtherActivity deleteFileAlertDialogOtherActivity=new DeleteFileAlertDialogOtherActivity();

							files_selected_array.add(currently_shown_file.getAbsolutePath());
							bundle.putStringArrayList("files_selected_array",files_selected_array);
							deleteFileAlertDialogOtherActivity.setArguments(bundle);
							deleteFileAlertDialogOtherActivity.setDeleteFileDialogListener(new DeleteFileAlertDialogOtherActivity.DeleteFileAlertDialogListener()
								{
									public void onSelectOK()
									{
										if(!asynctask_running)
										{
											asynctask_running=true;
											files_selected_for_delete=new ArrayList<>();
											deleted_files=new ArrayList<>();
											files_selected_for_delete.add(currently_shown_file);
											delete_file_async_task=new DeleteFileAsyncTask();
											delete_file_async_task.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
										}

									}
								});
							deleteFileAlertDialogOtherActivity.show(((PictureViewActivity)context).fm,"deletefilealertotheractivity");
							break;
							
						case 1:
							Uri src_uri;
							if(currently_shown_file.exists())
							{
								src_uri=Uri.fromFile(currently_shown_file);
							}
							else
							{
								src_uri=data;
							}
							if(src_uri==null)
							{
								print("not able to process");
								break;
							}
							ArrayList<Uri> uri_list=new ArrayList<>();
							uri_list.add(src_uri);
							try
							{
								FileIntentDispatch.sendUri(context,uri_list);
							}
							catch(IOException e){}
							break;
							
						case 2:
							if(!currently_shown_file.exists())
							{
								print("not able to process");
								break;
							}
							files_selected_array.add(currently_shown_file.getAbsolutePath());
							bundle.putStringArrayList("files_selected_array",files_selected_array);
							PropertiesDialog propertiesDialog=new PropertiesDialog();
							propertiesDialog.setArguments(bundle);
							propertiesDialog.show(((PictureViewActivity)context).fm,"properties_dialog");
							break;
							
						case 3:
							Uri uri;
							if(currently_shown_file.exists())
							{
								uri=Uri.fromFile(currently_shown_file);
							}
							else
							{
								uri=data;
							}
							if(uri==null)
							{
								print("not able to process");
								break;
							}
							File tempFile=new File(((PictureViewActivity)getContext()).CacheDir,currently_shown_file.getName());
							Intent intent=InstaCropperActivity.getIntent(context,uri,Uri.fromFile(tempFile),currently_shown_file.getName(),Global.SCREEN_WIDTH,Global.SCREEN_HEIGHT,100);
							startActivityForResult(intent,crop_request_code);
							
							
							break;
						default:
							break;


					}

					listPopWindow.dismiss();

				}


			});
		listPopWindow.setOnDismissListener(new PopupWindow.OnDismissListener()
			{
				public void onDismiss()
				{
					is_menu_opened=false;
					handler.removeCallbacks(runnable);
					handler.postDelayed(runnable,delay);
				}

			});
		view_pager=v.findViewById(R.id.activity_picture_view_viewpager);
		floating_back_button=v.findViewById(R.id.floating_button_picture_fragment);
		floating_back_button.setOnClickListener(new View.OnClickListener()
			{
				public void onClick(View v)
				{
					((PictureViewActivity)context).onBackPressed();
				}

			});

		recyclerview=v.findViewById(R.id.activity_picture_view_recyclerview);
		recyclerview.addOnScrollListener(new RecyclerView.OnScrollListener()
			{
				public void onScrolled(RecyclerView rv, int dx,int dy)
				{
					handler.removeCallbacks(runnable);
					handler.postDelayed(runnable,delay);
				}
			});
		recyclerview_image_width=(int)getResources().getDimension(R.dimen.image_preview_dimen);
		if(getResources().getBoolean(R.bool.is_land))
		{
			recyclerview.setPadding(Global.SCREEN_HEIGHT/2-recyclerview_image_width/2,0,Global.SCREEN_HEIGHT/2-recyclerview_image_width/2,0);
		}
		else
		{
			recyclerview.setPadding(Global.SCREEN_WIDTH/2-recyclerview_image_width/2,0,Global.SCREEN_WIDTH/2-recyclerview_image_width/2,0);
		}

		preview_image_offset=(int)getResources().getDimension(R.dimen.layout_margin);
		selected_item_sparseboolean=new SparseBooleanArray();

		image_view_adapter=new ImageViewPagerAdapter(album_list);
		view_pager.setAdapter(image_view_adapter);
		view_pager.setCurrentItem(file_selected_idx);
		selected_item_sparseboolean.put(file_selected_idx,true);
		picture_selector_adapter=new PictureSelectorAdapter(album_list);
		lm=new LinearLayoutManager(context,LinearLayoutManager.HORIZONTAL,false);
		recyclerview.setLayoutManager(lm);
		recyclerview.setAdapter(picture_selector_adapter);
		lm.scrollToPositionWithOffset(file_selected_idx,-preview_image_offset);


		view_pager.addOnPageChangeListener(new ViewPager.OnPageChangeListener()
			{

				public void onPageSelected(int i)
				{
					lm.scrollToPositionWithOffset(i,-preview_image_offset);
					selected_item_sparseboolean=new SparseBooleanArray();
					selected_item_sparseboolean.put(i,true);
					picture_selector_adapter.notifyDataSetChanged();

				}

				public void onPageScrollStateChanged(int i)
				{

				}

				public void onPageScrolled(int i,float p2, int p3)
				{
					file_selected_idx=i;
					currently_shown_file=album_list.get(i);
					title.setText(currently_shown_file.getName());

				}
			});
		
		runnable=new Runnable()
		{
			public void run()
			{
				if(!is_menu_opened)
				{
					toolbar.animate().translationY(-toolbar.getHeight()).setInterpolator(new DecelerateInterpolator(1));
					recyclerview.animate().translationY(recyclerview.getHeight()).setInterpolator(new DecelerateInterpolator(1));
					floating_back_button.animate().translationY(floating_button_height).setInterpolator(new DecelerateInterpolator(1));

				}

			}
		};
		handler.postDelayed(runnable,delay);
		return v;
	}
	
	
	public static PictureViewFragment getNewInstance(String file_path)
	{
		PictureViewFragment frag=new PictureViewFragment();
		Bundle bundle=new Bundle();
		bundle.putString("file_path",file_path);
		frag.setArguments(bundle);
		return frag;
	}

	 public void checkSAFPermission()
	 {

	 	Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
	 	startActivityForResult(intent, saf_request_code);

	 }

	 // @TargetApi(Build.VERSION_CODES.LOLLIPOP)
	 @Override
	 public final void onActivityResult(final int requestCode, final int resultCode, final Intent resultData) 
	 {
	 	super.onActivityResult(requestCode,resultCode,resultData);
		switch(requestCode)
		{
			
			case saf_request_code:
				 if (resultCode==getActivity().RESULT_OK) 
				 {
					 Uri treeUri = null;
					 // Get Uri from Storage Access Framework.
					 treeUri = resultData.getData();
					 String uri_file_path=FileUtil.getFullPathFromTreeUri(treeUri,context);
					 Iterator<Map.Entry<Uri,String>> iterator=Global.URI_STRING_HASHMAP.entrySet().iterator();
					 while(iterator.hasNext())
					 {
						 Map.Entry<Uri,String> entry=iterator.next();
						 if(entry.getValue().startsWith(uri_file_path))
						 {
							 iterator.remove();
						 }
					 }


					 Global.URI_STRING_HASHMAP.put(treeUri,uri_file_path);


					 // Persist access permissions.
					 final int takeFlags = resultData.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
					 context.getContentResolver().takePersistableUriPermission(treeUri, takeFlags);
					 
					 permission_requested=false;
					 delete_file_async_task=new DeleteFileAsyncTask();
					 delete_file_async_task.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);

				 }
				 else
				 {
					 //cancel_button.callOnClick();
					 print("Permission was not granted");
				 }
			
				
				break;
			case crop_request_code:
				

				 if(resultCode==getActivity().RESULT_OK)
				 {
					 pbf=new ProgressBarFragment();
					 pbf.show(((PictureViewActivity)context).fm,"");
					 Uri uri=resultData.getData();
					 String file_name=resultData.getStringExtra(InstaCropperActivity.EXTRA_FILE_NAME);
					 File f=new File(((PictureViewActivity)context).CacheDir,file_name);
					 android.app.WallpaperManager wm=android.app.WallpaperManager.getInstance(context);
					 if(wm.isWallpaperSupported() && wm.isSetWallpaperAllowed())
						 try
						 {
							 wm.setStream(context.getContentResolver().openInputStream(uri));
							 print("set as wallpaper");
						 }
						 catch(IOException e){}
						 finally
						 {
							 if(f.exists())
							 {
								 f.delete();
							 }
						 }
					 else
					 {
					
						 if(f.exists())
						 {
							 f.delete();
						 }
						 
					 }
					 pbf.dismissAllowingStateLoss();
				 }
				 else
				 {
					 print("could not be set as wallpaper");
				 }
				
				break;
				
				default:
				break;
				
			
		}


	 }

	 
	private class ImageViewPagerAdapter extends PagerAdapter
	{
		List<File> albumFileList =new ArrayList<>();


		ImageViewPagerAdapter(List<File> file_list)
		{
			albumFileList=file_list;

			title.setText(currently_shown_file.getName());

		}

		@Override
		public int getCount()
		{
			// TODO: Implement this method
			return albumFileList.size();
		}

		@Override
		public boolean isViewFromObject(View p1, Object p2)
		{
			// TODO: Implement this method
			return p1.equals(p2);
		}

		@Override
		public Object instantiateItem(ViewGroup container, int position)
		{
			// TODO: Implement this method

			TouchImageView image_view;
			View v=LayoutInflater.from(context).inflate(R.layout.picture_viewpager_layout,container,false);
			image_view=v.findViewById(R.id.picture_viewpager_layout_imageview);
			image_view.setMaxZoom(6);
			image_view.setOnClickListener(new View.OnClickListener()
				{
					public void onClick(View v)
					{
						if(toolbar.getGlobalVisibleRect(new Rect()))
						{
							//disappear
							toolbar.animate().translationY(-toolbar.getHeight()).setInterpolator(new DecelerateInterpolator(1)); 
							recyclerview.animate().translationY(recyclerview.getHeight()).setInterpolator(new DecelerateInterpolator(1));
							floating_back_button.animate().translationY(floating_button_height).setInterpolator(new DecelerateInterpolator(1));
							
							handler.removeCallbacks(runnable);
							
							

						}
						else
						{
							//appear
							toolbar.animate().translationY(0).setInterpolator(new AccelerateInterpolator(1)); 
							recyclerview.animate().translationY(0).setInterpolator(new AccelerateInterpolator(1));
							floating_back_button.animate().translationY(0).setInterpolator(new AccelerateInterpolator(1));
							
							handler.postDelayed(runnable,delay);
						}

					}
				});

			File f=albumFileList.get(position);
			Glide.with(context).load(f.exists() ? f : data).placeholder(R.drawable.picture_icon).error(R.drawable.picture_icon).diskCacheStrategy(DiskCacheStrategy.SOURCE).dontAnimate().into(image_view);
			container.addView(v);
			return v;

		}

		@Override
		public int getItemPosition(Object object)
		{
			// TODO: Implement this method
			return POSITION_NONE;
		}

		@Override
		public void destroyItem(ViewGroup container, int position, Object object)
		{
			// TODO: Implement this method
			container.removeView((View)object);
		}

		@Override
		public CharSequence getPageTitle(int position)
		{
			// TODO: Implement this method
			return albumFileList.get(position).getName();
		}

	}


	private class PictureSelectorAdapter extends RecyclerView.Adapter<PictureSelectorAdapter.VH>
	{
		List<File> picture_list=new ArrayList<>();
		PictureSelectorAdapter(List<File>list)
		{
			picture_list=list;
		}



		@Override
		public PictureSelectorAdapter.VH onCreateViewHolder(ViewGroup parent, int p2)
		{
			// TODO: Implement this method
			View v=LayoutInflater.from(context).inflate(R.layout.picture_selector_recyclerview_layout,parent,false);
			return new VH(v);
		}

		@Override
		public void onBindViewHolder(PictureSelectorAdapter.VH p1, int p2)
		{
			// TODO: Implement this method
			File f=picture_list.get(p2);
			Glide.with(context).load(f.exists() ? f : data).placeholder(R.drawable.picture_icon).error(R.drawable.picture_icon).diskCacheStrategy(DiskCacheStrategy.SOURCE).dontAnimate().into(p1.imageview);
			//Glide.with(context).load(picture_list.get(p2)).placeholder(R.drawable.picture_icon).error(R.drawable.picture_icon).diskCacheStrategy(DiskCacheStrategy.RESULT).dontAnimate().into(p1.imageview);

			p1.v.setSelected(selected_item_sparseboolean.get(p2,false));

		}

		@Override
		public int getItemCount()
		{
			// TODO: Implement this method
			return picture_list.size();
		}

		private class VH extends RecyclerView.ViewHolder implements View.OnClickListener
		{
			View v;
			ImageView imageview;
			VH(View view)
			{
				super(view);
				v=view;
				imageview=v.findViewById(R.id.picture_viewpager_layout_imageview);
				v.setOnClickListener(this);


			}

			@Override
			public void onClick(View p1)
			{
				// TODO: Implement this method
				view_pager.setCurrentItem(getAdapterPosition());

			}

		}

	}
	
	private void send_broadcast(LocalBroadcastManager manager)
	{

		Intent intent=new Intent();
		intent.setAction(MainActivity.FILE_DELETE_INTENT_ACTION);
		intent.putExtra("deleted",true);
		manager.sendBroadcast(intent);
	}

	private class DeleteFileAsyncTask extends AsyncTask<Void,File,Boolean>
	{

		String file_src;
		List<File> src_file_list=new ArrayList<>();
		int counter_no_files;
		long counter_size_files;
		String current_file_name,sd_uri;
		boolean isFromInternal;
		long file_size_denominator;
		String size_of_files_format;
		ProgressBarFragment pbf=new ProgressBarFragment();

		DeleteFileAsyncTask()
		{

			src_file_list.addAll(files_selected_for_delete);

		}


		@Override
		protected void onPreExecute()
		{
			// TODO: Implement this method
			pbf.show(((PictureViewActivity)context).fm,"progressbar_dialog");

		}

		@Override
		protected void onCancelled(Boolean result)
		{
			// TODO: Implement this method
			super.onCancelled(result);

			if(deleted_files.size()>0)
			{
				album_list.removeAll(deleted_files);
				if(album_list.size()<1)
				{
					//finish();
				}
				image_view_adapter.notifyDataSetChanged();
				picture_selector_adapter.notifyDataSetChanged();
				
				send_broadcast(localBroadcastManager);
				
			}

			pbf.dismissAllowingStateLoss();
			asynctask_running=false;

		}

		@Override
		protected Boolean doInBackground(Void...p)
		{
			// TODO: Implement this method
			boolean success=false;

			//if(new File(df.getTag()).exists())
			{
				isFromInternal=FileUtil.isFromInternal(files_selected_for_delete.get(0));
				success=deleteFromFolder();
			}
			/*
			 else
			 {
			 library_search=true;
			 success=deleteFromLibrarySearch();
			 }
			 */
			return success;
		}


		private boolean deleteFromLibrarySearch()
		{

			boolean success=false;
			int iteration=0;
			int size=src_file_list.size();
			for(int i=0;i<size;i++)
			{
				File f=src_file_list.get(i);
				if(FileUtil.isFromInternal(f))
				{
					current_file_name=f.getName();
					success=deleteNativeDirectory(f);
					if(success)
					{
						deleted_files.add(f);
					}
					files_selected_for_delete.remove(f);
				}
				else
				{

					for(Map.Entry<Uri,String> entry : Global.URI_STRING_HASHMAP.entrySet())
					{
						if(f.getAbsolutePath().startsWith(entry.getValue()))
						{
							baseFolder=entry.getValue();
							uri=entry.getKey();
							break;
						}
					}
					if(baseFolder.equals(""))
					{
						cancel(true);
						permission_requested=true;
						SAFPermissionHelperDialog safpermissionhelper=new SAFPermissionHelperDialog();
						safpermissionhelper.set_safpermissionhelperlistener(new SAFPermissionHelperDialog.SafPermissionHelperListener()
							{
								public void onOKBtnClicked()
								{
									checkSAFPermission();
								}

								public void onCancelBtnClicked()
								{
									//dismissAllowingStateLoss();
								}
							});
						safpermissionhelper.show(MainActivity.FM,"saf_permission_dialog");

						return false;
					}

					if(isCancelled())
					{
						return false;
					}
					current_file_name=src_file_list.get(iteration).getName();
					publishProgress(f);
					success=FileUtil.deleteSAFFile(f,context,uri,baseFolder);
					if(success)
					{
						deleted_files.add(f);
					}
					files_selected_for_delete.remove(f);

				}
				iteration++;
			}

			return success;
		}


		private boolean deleteFromFolder()
		{
			boolean success=false;
			int iteration=0;
			if(isFromInternal)
			{
				int size=src_file_list.size();
				for(int i=0;i<size;i++)
				{
					File f=src_file_list.get(i);
					current_file_name=f.getName();
					success=deleteNativeDirectory(f);
					if(success)
					{
						deleted_files.add(f);
					}
					files_selected_for_delete.remove(f);
				}

			}
			else
			{

				for(Map.Entry<Uri,String> entry : Global.URI_STRING_HASHMAP.entrySet())
				{
					if(files_selected_for_delete.get(0).getAbsolutePath().startsWith(entry.getValue()))
					{
						baseFolder=entry.getValue();
						uri=entry.getKey();
						break;
					}
				}

				if(baseFolder.equals(""))
				{
					cancel(true);
					permission_requested=true;
					SAFPermissionHelperDialog safpermissionhelper=new SAFPermissionHelperDialog();
					safpermissionhelper.set_safpermissionhelperlistener(new SAFPermissionHelperDialog.SafPermissionHelperListener()
						{
							public void onOKBtnClicked()
							{
								checkSAFPermission();
							}

							public void onCancelBtnClicked()
							{
								//dismissAllowingStateLoss();
							}
						});
					safpermissionhelper.show(MainActivity.FM,"saf_permission_dialog");
					return false;
				}

				int size=src_file_list.size();
				for(int i=0;i<size;i++)
				{
					File file=src_file_list.get(i);
					if(isCancelled())
					{
					  	return false;
					}
					current_file_name=src_file_list.get(iteration).getName();
					publishProgress(file);
					success=FileUtil.deleteSAFFile(file,context,uri,baseFolder);
					if(success)
					{
					 	deleted_files.add(file);
					}
					files_selected_for_delete.remove(file);
					iteration++;

				}

			}
			return success;
		}


		public boolean deleteNativeDirectory(final File folder) 
		{     
			boolean success=false;

			if (folder.isDirectory())            //Check if folder file is a real folder
			{
				if(isCancelled())
				{
					return false;
				}

				File[] list = folder.listFiles(); //Storing all file name within array
				int size=list.length;
				if (list != null)                //Checking list value is null or not to check folder containts atleast one file
				{
					for (int i = 0; i < size; i++)    
					{
						if(isCancelled())
						{
							return false;
						}

						File tmpF = list[i];
						if (tmpF.isDirectory())   //if folder  found within folder remove that folder using recursive method
						{
							success=deleteNativeDirectory(tmpF);
						}

						else
						{

							counter_no_files++;
							counter_size_files+=tmpF.length();
							size_of_files_format=FileUtil.humanReadableByteCount(counter_size_files,false);
							publishProgress(tmpF);
							success=tmpF.delete(); //else delete filr
						}

					}
				}

				if(folder.exists())  //delete empty folder
				{
					counter_no_files++;
					publishProgress(folder);
					success=folder.delete();
				}

			}
			else
			{
				if(isCancelled())
				{
					return false;
				}

				counter_no_files++;
				counter_size_files+=folder.length();
				size_of_files_format=FileUtil.humanReadableByteCount(counter_size_files,false);
				publishProgress(folder);
				success=folder.delete();
			}

			return success;
		}


		@Override
		protected void onPostExecute(Boolean result)
		{
			// TODO: Implement this method

			super.onPostExecute(result);
			if(deleted_files.size()>0)
			{
				album_list.removeAll(deleted_files);
				image_view_adapter.notifyDataSetChanged();
				picture_selector_adapter.notifyDataSetChanged();
				send_broadcast(localBroadcastManager);
				
				if(album_list.size()<1)
				{
					((PictureViewActivity)context).finish();
				}
	
			}
			pbf.dismissAllowingStateLoss();
			asynctask_running=false;

		}

	}

	private void print(String msg)
	{
		Toast.makeText(context,msg,Toast.LENGTH_SHORT).show();
	}
	
}
