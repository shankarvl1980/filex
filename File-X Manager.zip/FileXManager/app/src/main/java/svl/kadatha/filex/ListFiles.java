package svl.kadatha.filex;
import java.io.*;
import java.util.*;
import android.view.*;


public class ListFiles
{
	static List<FilePOJO> List(String file_name,List<FilePOJO> list, boolean extract_icon, boolean archive_view)
	{
		String pattern_name,pattern_long;
		if(MainActivity.SHOW_HIDDEN_FILE)
		{
			
			pattern_name="-A";
			pattern_long="-lA";
			
		}
		else
		{
			pattern_name="";
			pattern_long="-l";
		}
		
		String [] command_line_name={"ls",pattern_name,file_name,"|","cat"};
		String [] command_line_long={"ls",pattern_long,file_name,"|","cat"};
		
		
		try
		{
			//java.lang.Process process_name=Runtime.getRuntime().exec(pattern_name+file_name + " | " +" cat ");
			java.lang.Process process_name=Runtime.getRuntime().exec(command_line_name);
			BufferedReader bf_name=new BufferedReader(new InputStreamReader(process_name.getInputStream()));
			String line_name;
			
			//java.lang.Process process_long=Runtime.getRuntime().exec(pattern_long+file_name + " | " +" cat ");
			java.lang.Process process_long=Runtime.getRuntime().exec(command_line_long);
			BufferedReader bf_long=new BufferedReader(new InputStreamReader(process_long.getInputStream()));
			String line_long;
			
			bf_long.readLine();
			while((line_name=bf_name.readLine())!=null && (line_long=bf_long.readLine())!=null)
			{
			//(File f,String n,String p,String d,String s,Integer t,String ext)
			
				String [] split_line=line_long.split("\\s+");
				String permission=split_line[0];
				//if(permission.startsWith("^[^d].+"))
				
				String n=line_name;
				String p=file_name+File.separator+n;
				File f=new File(p);
				String d=DetailFragment.getFileSize(f,archive_view);
				String s=DetailFragment.getFileSize(f,archive_view);
				int overlay_visible=View.INVISIBLE;
				int alfa=225;
				String ext="";
				int idx=n.lastIndexOf(".");
				if(idx!=-1)
				{
					ext=n.substring(idx+1);
				}
				if(ext.matches(Global.VIDEO_REGEX))
				{
					overlay_visible=View.VISIBLE;
				}
				if(MainActivity.SHOW_HIDDEN_FILE && f.isHidden())
				{
					alfa=100;
				}
				int t=DetailFragment.getFileType(f,ext);
				list.add(new FilePOJO(f,n,p,d,s,t,ext,alfa,overlay_visible));
				
			}
			
			process_name.waitFor();
			process_long.waitFor();
		
			
		}
		catch(Exception e){}
		
		/*
		try
		{
			//java.lang.Process process_name=Runtime.getRuntime().exec(pattern_name+file_name + " | " +" cat ");
			java.lang.Process process_name=Runtime.getRuntime().exec(command_line_name);
			BufferedReader bf_name=new BufferedReader(new InputStreamReader(process_name.getInputStream()));
			String line_name;

			//java.lang.Process process_long=Runtime.getRuntime().exec(pattern_long+file_name + " | " +" cat ");
			java.lang.Process process_long=Runtime.getRuntime().exec(command_line_long);
			BufferedReader bf_long=new BufferedReader(new InputStreamReader(process_long.getInputStream()));
			String line_long;

			bf_long.readLine();
			while((line_name=bf_name.readLine())!=null && (line_long=bf_long.readLine())!=null)
			{
				//(File f,String n,String p,String d,String s,Integer t,String ext)
				String [] split_line=line_long.split("\\s+");
				String permission=split_line[0];
				//if(permission.matches("^d.+"))
				if(permission.startsWith("d"))
				{
					continue;
				}
				String n=line_name;
				String p=file_name+File.separator+n;
				File f=new File(p);
				String d=MainActivity.getFileSize(f,archive_view);
				String s=MainActivity.getFileSize(f,archive_view);
				String ext="";
				int idx=n.lastIndexOf(".");
				if(idx!=-1)
				{
					ext=n.substring(idx+1);
				}
				Integer t=MainActivity.getFileType(f,ext);
				list.add(new FilePOJO(f,n,p,d,s,t,ext));

			}

			process_name.waitFor();
			process_long.waitFor();


		}
		catch(Exception e){}
		*/
		return list;
		
	}
}
